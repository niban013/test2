﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using vsnet8.i18n;
using vsnet8.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace vsnet8.Controllers
{
    public class EmployeeDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
    }
    public class HomeController : Controller
    {
        private readonly LocalizedKeys _localizer;

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, LocalizedKeys localizer)
        {
            _localizer = localizer;
            _logger = logger;
        }
        public IActionResult LoadForm(string type)
        {


            var fields = GenerateFields(type);


            return PartialView("_DynamicForm", fields);
        }
        public IActionResult Indexaz()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Index3()
        {
            return View();
        }
        public IActionResult Index2()
        {
            var connectionString = "";
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                var repo = new GenericRepository<DynamicField2>(conn);

                // Dictionary → Model
                var dict = new Dictionary<string, string>
                {
                    ["form_id"] = "F001",
                    ["field_name"] = "姓名",
                    ["field_value"] = "小明"
                };

                var model = repo.MapFromDictionary(dict);

                // 插入
                int newId = repo.Insert(model);

                // 更新
                dict["field_value"] = "小明更新";
                dict["Id"] = newId.ToString();
                var updateModel = repo.MapFromDictionary(dict);
                repo.Update(updateModel);

                // 取得單筆
                var item = repo.GetById(newId);

                // 刪除
                repo.Delete(newId);

                // 交易示例
                repo.ExecuteInTransaction(tran =>
                {
                    repo.Insert(new DynamicField2 { FormId = "F002", FieldName = "性別", FieldValue = "男" }, tran);
                    repo.Insert(new DynamicField2 { FormId = "F002", FieldName = "年齡", FieldValue = "20" }, tran);
                });

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    var formRepo = new GenericRepository<DynamicForm>(conn);
                    var fieldRepo = new GenericRepository<DynamicField>(conn);

                    // ✅ 交易自動管理
                    GenericRepository<DynamicForm>.ExecuteTransaction(conn, (c, t) =>
                    {
                        // Insert DynamicForm
                        var form = new DynamicForm { FormName = "表單A" };
                        int formId = formRepo.Insert(form, t);

                        // Insert 多筆 DynamicField
                        var fields = new List<DynamicField>
        {
            new DynamicField { FormId = formId.ToString(), FieldName = "姓名", FieldValue = "小明" },
            new DynamicField { FormId = formId.ToString(), FieldName = "年齡", FieldValue = "20" }
        };

                        foreach (var f in fields)
                        {
                            fieldRepo.Insert(f, t);
                        }

                        // 其他 Model 也可以在這裡操作
                    });
                }
            }
            return View();
        }
        public IActionResult Indexvue()
        {
            return View();
        }
        public IActionResult LoadCheckTable(string type)
        {
            var fields = LoadCheckFields(type);


            return PartialView("_DynamicCheckTable", fields);

        }
        private List<DynamicField> GenerateFields(string type)
        {
            var list = new List<DynamicField>();

            list.Add(new DynamicField
            {
                Name = "Name",
                Label = "姓名",
                Pattern = "",
                Must = false,
                Type = FieldType.Label,
                Width = 3,
                Order = 1
            });
            list.Add(new DynamicField
            {
                Name = "Age",
                Label = "年齡",
                Must = true,
                Type = FieldType.Numeric,
                Placeholder = "請輸入年齡",
                Width = 3,
                Pattern = "",
                Order = 2
            });
            list.Add(new DynamicField
            {
                Name = "DueDate",
                Label = "到期日",
                Must = true,
                Type = FieldType.Date,
                Placeholder = "請輸入到期日",
                Width = 3,
                Pattern = "",
                Order = 3
            });
            if (type == "employee")
            {
                list.Add(new DynamicField
                {
                    Name = "Dept",
                    Label = "部門",
                    Must = true,
                    Type = FieldType.Select2,
                    Options = new()
                    {
                       new SelectItem{Value="1",Text="正常",Color="lightgreen"},
        new SelectItem{Value="2",Text="警告",Color="yellow"},
        new SelectItem{Value="3",Text="異常",Color="lightcoral"}
                    }
                });
            }

            if (type == "customer")
            {
                list.Add(new DynamicField
                {
                    Name = "City",
                    Label = "城市",
                    Type = FieldType.Select2,
                    Options = new()
            {
                new SelectItem{Value="taipei",Text="台北"},
                new SelectItem{Value="hsinchu",Text="新竹"}
            }
                });
            }

            return list;
        }
        public List<DynamicField> LoadCheckFields(string type)

        {
            var list = new List<DynamicField>();

            if (type == "equipment")
            {
                list.Add(new DynamicField
                {
                    Must = true,
                    Name = "oil",
                    Label = "油量",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Pattern = "",
                });

                list.Add(new DynamicField
                {
                    Name = "checktime",
                    Label = "檢查時間",
                    Width = 3,
                    Type = FieldType.Date,
                    Pattern = "",
                });

                list.Add(new DynamicField
                {
                    Name = "status",
                    Label = "設備狀態",
                    Type = FieldType.Select2,
                    Width = 3,
                    Pattern = "",
                    DefaultValue = "正常",
                    Options = new List<SelectItem>{
                new SelectItem{Value="1",Text="正常",Color="lightgreen"},
                new SelectItem{Value="2",Text="警告",Color="yellow"},
                new SelectItem{Value="3",Text="異常",Color="red"}
            }
                });
            }

            if (type == "temperature")
            {
                list.Add(new DynamicField
                {
                    Must = true,
                    Name = "temp1",
                    Label = "入口溫度",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Pattern = ""
                });

                list.Add(new DynamicField
                {
                    Name = "temp2",
                    Label = "出口溫度",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Pattern = ""
                });
            }

            return list;
        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Indextb()
        {
            var employeeSchema = new List<TableSchema>
            {
                new()
                {
                    TableId = "EmployeeTable",
                    AjaxUrl = "/Home/GetData/1",
                    FetchMode = FetchMode.All,

                    Features = new TableFeatures
                    {
                        Checkbox = true,
                        Export = true,
                        RowButtons = true,
                        ColumnToggle = true,
                        RowSelect = true,
                        SelectAll = true,
                        VirtualScroll = true,
                        ColumnFilter = false,   // 可選，每欄都有 filter
                        StickyHeader = true    // 可選，表頭固定
                    },

                    Config = new TableConfig
                    {
                        PageLength = 2,
                        VirtualScrollHeight = "500px",
                        Searching = false,
                        Ordering = false,
                        Paging = true,
                        LengthChange = true,
                        StateSave = true
                    },

                    ToolbarButtons =
                    {
                        new("Add", "add","bi-pencil","btn btn-danger" ),
                        new("Delete Selected", "deleteSelected","bi-pencil", "btn btn-danger" ),
                        new("Reload", "reload","bi-pencil", "btn btn-secondary" )
                    },

                    Columns =
                    {
                        new("Name"),
                        new("Age"),
                        new("Salary", "currency")
                    },

                    RowButtons =
                    { new(){ Title="", Event="edit3", CssClass="btn btn-sm btn-primary",Icon="bi-pencil"},
                        new(){ Title="Edit", Event="edit", CssClass="btn btn-sm btn-primary",Icon="bi-pencil"},
                        new(){ Title="Delete", Event="delete", CssClass="btn btn-sm btn-danger"}
                    }
                }
            };

            ViewBag.Tables = employeeSchema;// new List<TableSchema> { employeeSchema };

            return View();
        }
        public IActionResult Indextw()
        {
            var culture = System.Globalization.CultureInfo.CurrentCulture.Name;
            var uiCulture = System.Globalization.CultureInfo.CurrentUICulture.Name;
            Console.WriteLine($"Culture={culture}, UICulture={uiCulture}");
            var hello = _localizer.Hello;
            // 建立三組資料，刻意在每一組都加入一個名為 "tgtest" 的欄位
            var sectionConfigs = new Dictionary<string, List<DynamicField>>();

            // 第一組：個人資料
            //sectionConfigs["BasicInfo"] = new List<DynamicField> {
            //    new() { Name = "Name", Label = "姓名", Value="kkk", Type = FieldType.Label, DefaultValue = "張小明", Width = 3, Order = 1 },
            //    new() { Name = "Age", Label = "Age",Value="55", Type = FieldType.Label, Must = true, Width = 3, Order = 2 },

                              //};

            // 第二組：詳情設定
            sectionConfigs["Details"] = new List<DynamicField> {
                            new() { Name = "Age",Label = "年齡",Type = FieldType.Textbox, Must = true, Width = 3, Order = 1,  Min = "0",
                Max = "100" },

    new() { Name = "test",Label = "test",Type = FieldType.Radio, Must = true, Width = 3, Order = 1,  Options = new List<SelectItem>
    {
        new() { Value = "1", Text = "選項一" },
        new() { Value = "2", Text = "選項二" }
        
    },
        //InverseSelect = true,

    //DefaultValue = "2"
                       },
                //    new() { Name = "tgtest",Label = "測試欄位B", Type = FieldType.File, Must = true, Width = 3, Order = 2 }
                //,
                // new()
                //{ Must = true,
                //    Name = "status",
                //    Label = "設備狀態",
                //    Type = FieldType.Select2,
                //    Width = 3,
                //    Pattern = "",
                //    DefaultValue = "2",
                //    Options = new List<SelectItem>{
                //        new SelectItem{Value="1",Text="正常",Color="lightgreen"},
                //        new SelectItem{Value="2",Text="警告",Color="yellow"},
                //        new SelectItem{Value="3",Text="異常",Color="red"}
                //    }
                //}

            };

            // 第三組：系統設定
            //sectionConfigs["Settings"] = new List<DynamicField> {
            //            new() { Name = "DueDate", Label = "到期日",DefaultValue="2026-03-13",  Min = DateTime.Now.ToString("yyyy-MM-dd"),Type = FieldType.Date, Must = true, Width = 3, Order = 1 },
            //            new() { Name = "tgtest", Label = "測試欄位C", Type = FieldType.Textbox, Must = false, Width = 3, Order = 2 },
            //            new()
            //            {
            //                Name = "status",
            //                Label = "設備狀態",
            //                Type = FieldType.Dropdown,
            //                Width = 3,
            //                Pattern = "",
            //                DefaultValue = "正常",
            //                Options = new List<SelectItem>{
            //                    new SelectItem{Value="1",Text="正常",Color="lightgreen"},
            //                    new SelectItem{Value="2",Text="警告",Color="yellow"},
            //                    new SelectItem{Value="3",Text="異常",Color="red"}
            //                }
            //            }


            //        };
            ViewBag.Model = "Read";
            return View(sectionConfigs);
        }



        [HttpPost]
        public IActionResult SaveAll([FromBody] Dictionary<string, Dictionary<string, string>> allData)
        {
            if (allData == null || !allData.Any())
            {
                return Json(new { success = false, message = "無效的資料傳送" });
            }

            try
            {
                // 1. 取得特定區塊的值 (例如：BasicInfo 中的 tgtest)
                if (allData.ContainsKey("BasicInfo"))
                {
                    var basicTgTest = allData["BasicInfo"].GetValueOrDefault("tgtest");
                    // 處理 BasicInfo 邏輯...
                }

                // 2. 遍歷所有區塊進行處理
                foreach (var section in allData)
                {
                    string sectionName = section.Key; // 如 "Details"
                    var fields = section.Value;      // 該區塊內的所有欄位字典

                    // 這裡可以寫入資料庫或進行商業邏輯驗證
                    Console.WriteLine($"處理區塊: {sectionName}, 欄位數: {fields.Count}");
                }

                return Json(new { success = true, message = "全數區塊儲存成功！" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        [HttpGet]
        public JsonResult CheckUsername(string value)
        {
            bool exists = !true;// _db.Users.Any(u => u.UserName == value);
            return Json(new { valid = !exists, message = exists ? "帳號已存在" : "" });
        }

        [HttpGet]
        public IActionResult GetData(int id)
        {
            var data = new List<EmployeeDto>
            {
                new EmployeeDto{ Id=1, Name="Tom", Age=30, Salary=5000 },
                new EmployeeDto{ Id=2, Name="Mary", Age=28, Salary=6200 },
                new EmployeeDto{ Id=3, Name="John", Age=35, Salary=7000 }
            };

            return Json(new { data = data });
        }

        // AjaxUrl="/Employee/GetData?mode=all" 或 "?mode=page"
        [HttpGet]
        public IActionResult GetData2(string mode)
        {
            // 假資料
            var allData = new[]
            {
                new { Id = 1, Name = "Tom", Age = 30, Salary = 5000 },
                new { Id = 2, Name = "Mary", Age = 28, Salary = 6200 },
                new { Id = 3, Name = "John", Age = 35, Salary = 7000 },
                new { Id = 4, Name = "Anna", Age = 32, Salary = 5800 },
                new { Id = 5, Name = "Mike", Age = 40, Salary = 7200 },
                new { Id = 6, Name = "Linda", Age = 26, Salary = 4900 },
                new { Id = 7, Name = "Steve", Age = 38, Salary = 6500 },
                new { Id = 8, Name = "Lucy", Age = 31, Salary = 5300 }
            };

            if (mode == "all")
            {
                // 全量模式，DataTables 只要 { data: [...] }
                return Json(new { data = allData });
            }
            else
            {
                // 分頁模式，DataTables serverSide
                int start = int.Parse(Request.Query["start"].FirstOrDefault() ?? "0");
                int length = int.Parse(Request.Query["length"].FirstOrDefault() ?? "10");
                string searchValue = Request.Query["search[value]"].FirstOrDefault()?.ToLower() ?? "";

                var filtered = allData
                    .Where(d => string.IsNullOrEmpty(searchValue) || d.Name.ToLower().Contains(searchValue))
                    .ToList();

                var paged = filtered.Skip(start).Take(length);

                return Json(new
                {
                    draw = Request.Query["draw"].FirstOrDefault(),
                    recordsTotal = allData.Length,
                    recordsFiltered = filtered.Count,
                    data = paged
                });
            }
        }

        // 🔥 提供 schema（模擬 DB）
        [HttpGet]
        public IActionResult GetFormSchema()
        {
            //     var schema = new
            //     {
            //         fields = new object[]
            //{
            //          new {
            //              id = "name",
            //              type = "text",
            //              label = "姓名",
            //              required = true
            //          },
            //          new {
            //              id = "country",
            //              type = "dropdown",
            //              label = "國家",
            //              options = new[]
            //              {
            //                  new { value = "TW", text = "台灣" },
            //                  new { value = "US", text = "美國" }
            //              }
            //          }
            //}
            //     };
            var schema = new
            {
                tabs = new[]
        {
                new {
                    id = "tab1",
                    name = "基本資料",
                    panels = new object[]
                    {
                        new {
                            id = "p1",
                            title = "個人資料",
                            fields = new object[]
                            {
                                new {
                                    id = "name",
                                    type = "text",
                                    label = "姓名",
                                    required = true
                                },
                                new {
                                     id = "country",
                                     type = "dropdown",
                                     label = "國家",
                                     options = new[]
                                     {
                                         new { value = "TW", text = "台灣" },
                                         new { value = "US", text = "美國" }
                                     }
                                 }
                            }
                        },
                        new {
                            id = "p2",
                            title = "其他資訊",
                            fields = new object[]
                            {
                                new {
                                    id = "name",
                                    type = "text",
                                    label = "姓名"
                                }
                            }
                        },

                    }
                }
            }
            };

            return Ok(schema); // ✅ 建議用這個
        }
    }
}
