﻿using Dapper;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;

namespace vsnet8.Models
{
    public class DynamicField2
    {
        public int Id { get; set; }

        [Column("form_id")]
        public string FormId { get; set; }

        [Column("field_name")]
        public string FieldName { get; set; }

        [Column("field_value")]
        public string FieldValue { get; set; }
    }

    public class GenericRepository<T> where T : class, new()
    {
        private readonly IDbConnection _conn;

        public GenericRepository(IDbConnection conn)
        {
            _conn = conn;
        }

        #region Dictionary → Model
        public T MapFromDictionary(Dictionary<string, string> dict)
        {
            var obj = new T();
            var props = typeof(T).GetProperties();

            foreach (var prop in props)
            {
                var colAttr = prop.GetCustomAttribute<ColumnAttribute>();
                var key = colAttr != null ? colAttr.Name : prop.Name;

                if (dict.TryGetValue(key, out var val))
                {
                    try
                    {
                        var targetType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                        var convertedValue = Convert.ChangeType(val, targetType);
                        prop.SetValue(obj, convertedValue);
                    }
                    catch
                    {
                        // 可選 log
                    }
                }
            }

            return obj;
        }
        #endregion

        #region Insert / Update
        public int Insert(T model, IDbTransaction tran = null)
        {
            var props = typeof(T).GetProperties()
                .Where(p => p.Name.ToLower() != "id"); // 排除 Id

            var columns = props.Select(p => p.GetCustomAttribute<ColumnAttribute>()?.Name ?? p.Name);
            var parameters = props.Select(p => "@" + p.Name);

            var sql = $"INSERT INTO {typeof(T).Name} ({string.Join(",", columns)}) " +
                      $"VALUES ({string.Join(",", parameters)}); SELECT CAST(SCOPE_IDENTITY() as int);";

            return _conn.QuerySingle<int>(sql, model, tran);
        }

        public int Update(T model, IDbTransaction tran = null)
        {
            var props = typeof(T).GetProperties()
                .Where(p => p.Name.ToLower() != "id"); // 排除 Id

            var sets = props.Select(p => $"{p.GetCustomAttribute<ColumnAttribute>()?.Name ?? p.Name}=@{p.Name}");

            var sql = $"UPDATE {typeof(T).Name} SET {string.Join(",", sets)} WHERE Id=@Id";

            return _conn.Execute(sql, model, tran);
        }
        #endregion

        #region Delete
        public int Delete(int id, IDbTransaction tran = null)
        {
            var sql = $"DELETE FROM {typeof(T).Name} WHERE Id=@Id";
            return _conn.Execute(sql, new { Id = id }, tran);
        }
        #endregion

        #region Get / List
        public T GetById(int id)
        {
            var sql = $"SELECT * FROM {typeof(T).Name} WHERE Id=@Id";
            return _conn.QuerySingleOrDefault<T>(sql, new { Id = id });
        }

        public IEnumerable<T> GetAll()
        {
            var sql = $"SELECT * FROM {typeof(T).Name}";
            return _conn.Query<T>(sql);
        }

        public IEnumerable<T> Query(string whereClause, object param = null)
        {
            var sql = $"SELECT * FROM {typeof(T).Name} WHERE {whereClause}";
            return _conn.Query<T>(sql, param);
        }
        #endregion

        #region Transaction 支援
        public void ExecuteInTransaction(Action<IDbTransaction> action)
        {
            if (_conn.State != ConnectionState.Open) _conn.Open();
            using (var tran = _conn.BeginTransaction())
            {
                try
                {
                    action(tran);
                    tran.Commit();
                }
                catch
                {
                    tran.Rollback();
                    throw;
                }
            }
        }
        #endregion
    }
}
