using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic.FileIO;
using System.Diagnostics;
using System.Text.Json;
using vs8.Models;
using FieldType = vs8.Models.FieldType;

namespace vs8.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpPost]
        public IActionResult GetPanel2(string panelId, string type)
        {

            var vm = new DynamicPanelVM();

            vm.PanelId = panelId;
            vm.Title = $"Panel {type}";

            vm.Fields = new List<DynamicField>
{
    new DynamicField
    {
        Name="Temp",
        Label="�ū�",
        Type=FieldType.Text,
        Must=true
    },
    new DynamicField
    {
        Name="Date",
        Label="���",
        Type=FieldType.Date
    }
};

            return PartialView("_DynamicPanel", vm);

        }

        [HttpPost]
        public IActionResult GetCheckPanel(string panelId)
        {

            // �����
            var vm = new DynamicCheckVM
            {
                PanelId = panelId,
                Rows = new List<DynamicCheckRow>
                {
                    new DynamicCheckRow{ Item="���O" },
                    new DynamicCheckRow{ Item="�ū�" },
                    new DynamicCheckRow{ Item="�y�q" }
                }
            };

            return PartialView("_DynamicCheckPanel", vm);

        }
        public IActionResult Index()
        {// ������Ʈw
            var fakeTabs = new List<FormTab>
{
    new FormTab
    {
        TabId = "tab1",
        TabName = "�]�Ƹ��",
        Panels = new List<FormPanel>
        {
            new FormPanel
            {
                PanelId = "equipA",
                Url = "/Home/GetPanel",
                ParamJson = "{\"type\":\"A\"}"
            },
            new FormPanel
            {
                PanelId = "equipB",
                Url = "/Home/GetPanel",
                ParamJson = "{\"type\":\"B\"}"
            }
        }
    },
    new FormTab
    {
        TabId = "tab2",
        TabName = "ñ�ָ��",
        RequireTab = "tab1",
        Panels = new List<FormPanel>
        {
            new FormPanel
            {
                PanelId = "signA",
                Url = "/Home/GetPanel",
                ParamJson = "{\"type\":\"SIGN\"}"
            }
        }
    },
    new FormTab
    {
        TabId = "tab3",
        TabName = "�ˬd�M��",
        RequireTab = "tab2",
        Panels = new List<FormPanel>
        {
            new FormPanel
            {
                PanelId = "checkTable",
                Url = "/Home/GetCheckPanel",
                ParamJson = "{\"type\":\"CHECK\"}"
            }
        }
    }
};
            // �N������ন ViewModel
            var schema = new DynamicFormSchema
            {
                tabs = fakeTabs.Select(t => new DynamicTabVM
                {
                    TabId = t.TabId,
                    RequireTab = t.RequireTab,
                    Panels = t.Panels.Select(p => new DynamicPanelVM
                    {
                        PanelId = p.PanelId,
                        Url = p.Url,
                        Param = JsonSerializer.Deserialize<Dictionary<string, object>>(p.ParamJson)
                    }).ToList()
                }).ToList()
            };

            return View(schema);
        }

        public IActionResult GetPanel(string panelId, string type)
        {
            // �����
            var fields = new List<DynamicField>
    {
        new DynamicField { Name="Name", Label="�W��", Type=FieldType.Text, Must=true },
        new DynamicField { Name="Model", Label="����", Type=FieldType.Text, Must=false }
    };

            return PartialView("_DynamicPanel", fields);
        }

        public IActionResult GetCheckPanel(string panelId, string type)
        {
            // �����
            var fields = new List<DynamicField>
    {
        new DynamicField {Name = "Item1", Label = "�ˬd����1", Type = FieldType.Text, Must = true},
        new DynamicField { Name="Item2", Label="�ˬd����2", Type=FieldType.Select, Must=false,
            Options=new List<SelectOption>
            {
                new SelectOption{Value="OK", Text="OK", Color="lightgreen"},
                new SelectOption{Value="NG", Text="NG", Color="pink"}
            }
        }
    };

            return PartialView("_DynamicCheckRow", fields);
        }
        //public IActionResult Index()
        //{
        //    return View();
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
