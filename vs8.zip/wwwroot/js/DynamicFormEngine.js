﻿var DynamicFormEngine = (function () {

    let schema;
    let container;
    let cache = {};

    function init(formSchema, selector) {
        schema = formSchema;
        container = $(selector);

        initTabs();
        loadTabPanels("tab1");
        initEvents();
    }

    function initTabs() {
        $('#formTabs a').on('show.bs.tab', function (e) {
            let require = $(e.target).data("require");
            if (!require) return;

            if (!validateTab(require)) {
                alert("請先完成上一頁");
                e.preventDefault();
            }
        });

        $('#formTabs a').on('shown.bs.tab', function (e) {
            let tabId = $(e.target).data("bsTarget").replace("#", "");
            loadTabPanels(tabId);
        });
    }

    function loadTabPanels(tabId) {
        let tab = schema.tabs.find(t => t.TabId == tabId);
        if (!tab) return;

        let tabEl = $("#" + tabId);
        let panelContainer = tabEl.find(".panelContainer");

        tab.Panels.forEach(p => {
            if (panelContainer.find('[data-panelid="' + p.PanelId + '"]').length > 0) {
                restorePanel(p.PanelId);
                return;
            }

            $.post(p.Url, {
                panelId: p.PanelId,
                ...p.Param
            }, function (html) {
                panelContainer.append(html);
                restorePanel(p.PanelId);
            });
        });
    }

    function initEvents() {
        container.on("input change", ".dynamicInput", function () {
            let panelId = $(this).closest("[data-panelid]").data("panelid");
            let name = $(this).attr("name");
            let val = $(this).val();

            if (!cache[panelId]) cache[panelId] = {};
            cache[panelId][name] = val;

            checkRow($(this));
        });
    }

    function restorePanel(panelId) {
        if (!cache[panelId]) return;
        let panel = container.find('[data-panelid="' + panelId + '"]');
        Object.keys(cache[panelId]).forEach(name => {
            panel.find('[name="' + name + '"]').val(cache[panelId][name]);
        });
    }

    function validateTab(tabId) {
        let ok = true;
        $("#" + tabId).find(".dynamicInput").each(function () {
            let must = $(this).data("must");
            let val = $(this).val();
            $(this).removeClass("is-invalid");

            if (must && (!val || val === "")) {
                $(this).addClass("is-invalid");
                ok = false;
            }
        });
        return ok;
    }

    function checkRow(el) {
        let row = el.closest("tr");
        let val = el.val();

        if (val) {
            row.find(".statusCell").html(
                '<i class="bi bi-check-circle text-success"></i>'
            );
        } else {
            row.find(".statusCell").html(
                '<i class="bi bi-x-circle text-danger"></i>'
            );
        }
    }

    /** 新增方法: 取得 cache 內容 **/
    function getCache() {
        return JSON.parse(JSON.stringify(cache)); // 深拷貝防止外部修改
    }

    /** 新增方法: 顯示 cache 到 console 或 callback **/
    function showCache(callback) {
        const data = getCache();
        if (callback && typeof callback === "function") {
            callback(data);
        } else {
            console.log("DynamicFormEngine Cache:", data);
        }
    }

    return {
        init: init,
        getCache: getCache,
        showCache: showCache
    };

})();