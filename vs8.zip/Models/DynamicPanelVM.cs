using Microsoft.VisualBasic.FileIO;

namespace vs8.Models
{
    public class SelectOption
    {

        public string Value { get; set; }

        public string Text { get; set; }
        public string Color { get; set; }
    }
    public enum FieldType
    {

        Text,

        Number,

        Date,

        Select,

        Upload

    }
    public class DynamicField
    {

        public string Name { get; set; }

        public string Label { get; set; }

        public FieldType Type { get; set; }

        public bool Must { get; set; }

        public string Placeholder { get; set; }

        public List<SelectOption> Options { get; set; }

    }
    public class DynamicPanelVM
    {

        public string PanelId { get; set; }

        public string Title { get; set; }
        public string Url { get; set; }
        public Dictionary<string, object> Param { get; set; } = new();
        public List<DynamicField> Fields { get; set; } = new();

    }

    public class DynamicCheckVM
    {

        public string PanelId { get; set; }
        public string Url { get; set; }
        public Dictionary<string, object> Param { get; set; } = new();
        public List<DynamicCheckRow> Rows { get; set; } = new();

    }

    public class DynamicCheckRow
    {

        public string Item { get; set; }

        public string Value { get; set; } = "5";

        public DateTime? Time { get; set; } = DateTime.Now;

    }

    public class DynamicFormSchema
    {
        public List<DynamicTabVM> tabs { get; set; } = new();
    }
    public class FormPanel
    {
        // Panel ���ߤ@ ID�]���� container �� data-panelid�^
        public string PanelId { get; set; }

        // ���o Panel PartialView �� URL
        public string Url { get; set; }

        // �ǵ� URL ���Ѽ� JSON �r��]�i�ন Dictionary<string, object>�^
        public string ParamJson { get; set; }
    }
    public class FormTab
    {
        // Tab ���ߤ@ ID�A�����e�� <div id="tabId">
        public string TabId { get; set; }

        // Tab �W�١]�e�ݼ��Ҥ�r�^
        public string TabName { get; set; }

        // �̿઺�e�@�� TabId�]�i�š^�A�e�@�� Tab �����~��}�Ҧ� Tab
        public string RequireTab { get; set; }

        // �o�� Tab �U������ Panel
        public List<FormPanel> Panels { get; set; } = new();
    }
    public class DynamicTabVM
    {
        public string TabId { get; set; }
        public string RequireTab { get; set; }
        public List<DynamicPanelVM> Panels { get; set; } = new();
    }

   
}
