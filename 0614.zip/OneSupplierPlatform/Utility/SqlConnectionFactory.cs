﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace OneSupplierPlatform.Utility
{

    public interface ITransactionContext
    {
        IDbConnection Connection { get; }
        IDbTransaction Transaction { get; }

        //void Begin();
        //void Commit();
        //void Rollback();
    }
    // =========================
    // Connection Factory (Multi DB)
    // =========================
    public class SqlConnectionFactory : IDbConnectionFactory
    {
        private readonly IConfiguration _config;

        public SqlConnectionFactory(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection CreateConnection(string dbName = "AMSC-SQLDB")
        {
            var connStr = _config.GetConnectionString(dbName);

            var conn = new SqlConnection(connStr);
            conn.Open();
            return conn;
        }
    }
    public static class TransactionExtensions
    {
        public static async Task UseTransactionAsync(
            this ITransactionContext ctx,
            Func<ITransactionContext, Task> action)
        {
            var repo = (GenericRepository)ctx;
            if (repo.Transaction != null)
                throw new InvalidOperationException("Transaction already started");

            repo.Begin();

            try
            {
                await action(ctx);
                repo.Commit();
            }
            catch
            {
                repo.Rollback();
                throw;
            }
        }
    }
    // =========================
    // RepositoryIGenericRepository,
    // =========================
    public class GenericRepository : ITransactionContext, IDisposable
    {
        private readonly IDbConnectionFactory _factory;
        private readonly string _dbName;
        private IDbConnection _conn;
        private IDbTransaction _tx;
        public GenericRepository(IDbConnectionFactory factory, string dbName = "AMSC-SQLDB")
        {
            _factory = factory;
            _dbName = dbName;
        }

        // =========================
        // ITransactionContext
        // =========================
        public IDbConnection Connection => _conn ??= _factory.CreateConnection(_dbName);
        public IDbTransaction Transaction => _tx;

        // =========================
        // Transaction
        // =========================
        internal void Begin()
        {
            if (_tx != null)
                throw new InvalidOperationException("Transaction already started");
            if (_conn == null)
                _conn = _factory.CreateConnection(_dbName);

            if (_conn.State != ConnectionState.Open)
                _conn.Open();

            _tx = _conn.BeginTransaction();
        }

        internal void Commit()
        {
            _tx?.Commit();
            _tx?.Dispose();
            _tx = null;
        }

        internal void Rollback()
        {
            _tx?.Rollback();
            _tx?.Dispose();
            _tx = null;
        }
        public void Dispose()
        {
            _tx?.Dispose();
            _conn?.Dispose();
            _tx = null;
            _conn = null;
        }
    }
}
