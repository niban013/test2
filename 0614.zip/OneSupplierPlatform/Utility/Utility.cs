﻿using OneSupplierPlatform.Configuration;

namespace OneSupplierPlatform.Utility
{
    public static class ApiHelper
    {
        public static class AppConfig
        {
            public static AppOptions Value { get; set; } = default!;
        }

        public static string GetApiUrl()
        {
            return AppConfig.Value.CapAuth.ApiUrl;
        }
    }
}
