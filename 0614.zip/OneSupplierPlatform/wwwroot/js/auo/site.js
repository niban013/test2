﻿//(function ($) {

//    $.fn.loadingDots = function (options) {

//        const settings = $.extend({
//            color: '#3498db',
//            size: 12,
//            gap: 8,
//            text: ''
//        }, options);

//        if (!$('#loadingDotsStyle').length) {

//            $('head').append(`
//                <style id="loadingDotsStyle">

//                    .loading-wrap{
//                        display:flex;
//                        flex-direction:column;
//                        justify-content:center;
//                        align-items:center;
//                        gap:10px;
//                    }

//                    .loading-dots{
//                        display:flex;
//                        justify-content:center;
//                        align-items:center;
//                        gap:var(--gap);
//                    }

//                    .loading-dots span{
//                        width:var(--size);
//                        height:var(--size);
//                        border-radius:50%;
//                        background:var(--color);
//                        animation:dotsBounce 1.4s infinite ease-in-out both;
//                    }

//                    .loading-dots span:nth-child(1){
//                        animation-delay:-0.32s;
//                    }

//                    .loading-dots span:nth-child(2){
//                        animation-delay:-0.16s;
//                    }

//                    @keyframes dotsBounce{
//                        0%,80%,100%{ transform:scale(0); }
//                        40%{ transform:scale(1); }
//                    }

//                    .loading-text{
//                        font-size:14px;
//                        color:#666;
//                    }

//                </style>
//            `);
//        }

//        return this.each(function () {

//            $(this).html(`
//                <div class="loading-wrap">
//                    <div class="loading-dots"
//                         style="
//                            --color:${settings.color};
//                            --size:${settings.size}px;
//                            --gap:${settings.gap}px">
//                        <span></span>
//                        <span></span>
//                        <span></span>
//                    </div>

//                    <div class="loading-text">
//                        ${settings.text || ''}
//                    </div>
//                </div>
//            `);
//        });
//    };

//})(jQuery);

//window.Loading = {

//    count: 0,

//    show(text = '') {

//        this.count++;

//        $('#globalLoading').css('display', 'flex');

//        const $text = $('#globalLoading .loading-text');

//        if (text) {
//            $text.text(text).show();
//        } else {
//            $text.text('').hide();
//        }
//    },

//    hide() {

//        this.count = Math.max(0, this.count - 1);

//        if (this.count === 0) {
//            $('#globalLoading').hide();
//        }
//    },

//    forceHide() {
//        this.count = 0;
//        $('#globalLoading').hide();
//    }
//};

//(function ($) {

//    $(document).ajaxStart(function () {
//        Loading.show();
//    });

//    $(document).ajaxStop(function () {
//        Loading.hide();
//    });

//    $(document).ajaxError(function () {
//        Loading.hide();
//    });

//})(jQuery);

//(function () {

//    const oldFetch = window.fetch;

//    window.fetch = async function (...args) {

//        Loading.show();

//        try {
//            const res = await oldFetch(...args);
//            return res;
//        }
//        finally {
//            Loading.hide();
//        }
//    };

//})();

//$(document).on('submit', 'form', function () {

//    const $form = $(this);

//    if ($form.data('lock')) return false;

//    $form.data('lock', true);

//    Loading.show('處理中...');

//    // ❌ 不要 setTimeout
//    // ❌ 不要 hide

//    // MVC submit 會 reload page
//});
//$(document).on('click', '[data-loading]', function (e) {

//    const $el = $(this);

//    if ($el.data('lock')) {
//        e.preventDefault();
//        return false;
//    }

//    $el.data('lock', true);

//    Loading.show($el.data('loading-text') || '處理中...');

//    //const url = $el.attr('href');

//    //if (url) {
//    //    e.preventDefault();
//    //    window.location.href = url;   // ❗ 立即跳
//    //}
//});

//function createSafeProxy(obj) {
//    return new Proxy(obj || {}, {
//        get(target, prop) {

//            if (prop in target) {
//                const value = target[prop];

//                // 深層 object 繼續 proxy
//                if (typeof value === "object" && value !== null) {
//                    return createSafeProxy(value);
//                }

//                return value;
//            }

//            // 避免 undefined chain crash
//            return undefined;
//        }
//    });
//}

//window.Config = createSafeProxy(window.appConfig);
async function callAsmxProxy(methodName, params) {
    const response = await fetch(`${window.AppBasePath}Supplier/GetERP`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            methodName: methodName, // 指定要呼叫 ASMX 的哪個 Function
            params: params          // 傳入該 Function 需要的參數物件
        })
    });
    const result = await response.json();
    return result.d; // 自動解開 ASMX 的 .d
}

function isEmpty(val) {


    if (val === undefined || val === null) {
        return true;
    }

    if (typeof val === "string") {
        return val.trim() === "";
    }

    if (Array.isArray(val)) {
        return val.length === 0;
    }

    if (val instanceof File) {
        return !val.name;
    }

    return false;
}
$(document).on("mouseenter", ".tooltip-auto", function () {

    let instance = bootstrap.Tooltip.getInstance(this);

    if (!instance) {
        instance = new bootstrap.Tooltip(this, {
            title: this.dataset.title || "",
            placement: "top",
            trigger: "manual",   // ⭐ 改 manual
            container: "body"
        });
    }

    instance.show(); // ⭐ 直接顯示
});

$(document).on("mouseleave", ".tooltip-auto", function () {
    const instance = bootstrap.Tooltip.getInstance(this);
    if (instance) instance.hide();
});


window.showAlert = (title, text, icon = 'success') => {
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        confirmButtonColor: '#004070', // 使用您的友達藍
        confirmButtonText: '確定'
    });
};

//window.showConfirm = (title, text, callback) => {
//    Swal.fire({
//        title: title,
//        text: text,
//        icon: 'warning',
//        showCancelButton: true,
//        confirmButtonColor: '#004070',
//        cancelButtonColor: '#d33',
//        confirmButtonText: '確定',
//        cancelButtonText: '取消'
//    }).then((result) => {
//        if (result.isConfirmed && callback) {
//            callback();
//        }
//    });
//};
window.showConfirm = (title, text, callback) => {
    // 加上 return，讓外部可以接到 Promise
    return Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#004070',
        cancelButtonColor: '#d33',
        confirmButtonText: '確定',
        cancelButtonText: '取消'
    }).then((result) => {
        // 1. 保留原本邏輯：如果有 callback 且點擊確定，則執行
        if (result.isConfirmed && typeof callback === 'function') {
            callback();
        }

        // 2. 擴展功能：回傳 true/false 給外部的 await 接收
        return result.isConfirmed;
    });
};


$.ajaxSetup({
    beforeSend: function (xhr) {
        // 💡 從 Layout 產生的那個隱藏 input 取值
        var token = $('input[name="__RequestVerificationToken"]').val();
        if (token) {
            xhr.setRequestHeader("RequestVerificationToken", token);
        }
    },
    // 💡 當任何 AJAX 發生錯誤時觸發
    error: function (xhr, status, error) {
        const data = xhr.responseJSON;
        if (!data) return;

        // 1. 取得後端 Filter 傳來的資訊
        const msg = (data && data.message) ? data.message : "系統連線異常";
        const reqId = (data && data.requestId) ? data.requestId : "N/A";
        const isFatal = data && data.isFatal === true;
        const targetUrl = (data && data.redirectUrl) ? data.redirectUrl : "/Error/Index";
        if (data && data.isFatal) {
            xhr.isHandledByGlobal = true;

            Swal.fire({
                title: data.isFatal ? '系統異常' : '提醒',
                html: `${data.message}<br/><br/><small class="text-muted">錯誤編號：${data.requestId}</small>`,
                icon: data.isFatal ? 'error' : 'warning',
                confirmButtonColor: '#004070',
                confirmButtonText: data.isFatal ? '查看詳細資訊' : '確定',
                allowOutsideClick: !data.isFatal
            }).then((result) => {
                if (data.isFatal && result.isConfirmed) {
                    window.location.href = data.redirectUrl;
                }
            }); 
        } 
    }
});
