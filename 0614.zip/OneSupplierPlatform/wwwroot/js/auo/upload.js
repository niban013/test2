﻿
if (typeof window !== 'undefined' && typeof window.crypto !== 'undefined' && !window.crypto.randomUUID) {
    window.crypto.randomUUID = function () {
        return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    };
}
function getUploadKey(file) {
    return file.clientId ?? file.id;
}
window.PreviewModule = (() => {
    async function handleSSAAFUpload(
        val,
        container,
        stepKey
    ) {

        const formData = new FormData();

        formData.append("file", val);

        const store =
            AppBootstrap.get("FlowStore");

        return new Promise((resolve) => {

            $.ajax({

                url: "/Supplier/UploadSSAAF",

                type: "POST",

                data: formData,

                processData: false,

                contentType: false,

                success(response) {

                    try {

                        console.log("收到後端資料：", response);

                        for (const mapkey in response) { 
                            if (!response.hasOwnProperty(mapkey)) continue;

                            const value = isEmpty(response[mapkey]) ? "" : response[mapkey]; 
                            const selector = `input[data-field='${mapkey}'], select[data-field='${mapkey}'], textarea[data-field='${mapkey}']`; 
                            container.querySelectorAll(selector).forEach(el => {
                            
                                if (el.type === "checkbox") {
                                    el.checked = !!value; 
                                }
                                else if (el.type === "radio") {
                                    el.checked = (el.value === value.toString());
                                }
                                else {
                                    el.value = value; 
                                    if (el.dataset.type === "dropdown") {
                                        el.dataset.value = value;
                                    }
                                } 
                                GraphV2.notify(stepKey, mapkey, value);
                                store.setTouched(stepKey, mapkey);
                            });
                        }

                        // ✅ success
                        resolve(true);

                    } catch (e) {

                        console.error(e);

                        resolve(false);
                    }
                },

                error(xhr, status, error) {

                    console.error(
                        "出錯了：",
                        error
                    );

                    resolve(false);
                }
            });
        });
    }
    //async function tempUpload(file) {

    //    if (!(file.file instanceof File)) {
    //        throw new Error("tempUpload: invalid file");
    //    }

    //    const fd = new FormData();
    //    fd.append("file", file.file);

    //    const res = await fetch(
    //        `${window.AppBasePath}api/file/TempUpload`,
    //        {
    //            method: "POST",
    //            body: fd
    //        }
    //    );

    //    if (!res.ok) {
    //        throw new Error(`temp upload failed: ${res.status}`);
    //    }

    //    const contentType = res.headers.get("content-type");

    //    let json = null;

    //    // =========================
    //    // safe parse
    //    // =========================
    //    if (contentType && contentType.includes("application/json")) {
    //        json = await res.json();
    //    } else {
    //        const text = await res.text();
    //        try {
    //            json = JSON.parse(text);
    //        } catch {
    //            json = { token: text };
    //        }
    //    }

    //    if (!json || !json.token) {
    //        throw new Error("temp upload: missing token");
    //    }

    //    return json.token;
    //}
    async function validateBeforeNotify(el, val) {

        const parsed = parseRule(el.dataset.rule);

        for (const r of parsed.validators) {

            const [name, arg] = r.split(":");
            const fn = ValidationRules[name];

            if (!fn) continue;

            const result = await fn(val, { arg });

            if (result !== true) {
                return {
                    valid: false,
                    message: result
                };
            }
        }

        return { valid: true };
    }
    async function importfile(ctx) {

        ctx.store.clearError(ctx.stepKey, ctx.key);
        ctx.store.setStatus(ctx.stepKey, ctx.key, null);

        FieldStatus.clear(ctx.target);

        const result =
            await validateBeforeNotify(
                ctx.target,
                ctx.newValue
            );

        // ❌ FAIL → rollback MUST use oldValue
        if (!result.valid) {

            FieldStatus.set(
                ctx.target,
                "error",
                result.message
            );

            // 🔥 CRITICAL FIX：
            // UI 回復「舊檔」
            //adapter.setValue(target, oldValue);
            FieldStatus.clear(ctx.target);
            // ❗ NOTHING ELSE

        }
        var mappingResult = false
        if (result.valid && ctx.target.type === "file" //&&
            // ctx.target.id === "upload_ssaaf"
        ) {

            let oldfile = ctx.store.get(ctx.stepKey, ctx.key) 
            const ok = await handleSSAAFUpload(
                ctx.newValue,
                ctx.container,
                ctx.stepKey
            );

            if (!ok) {
                mappingResult = false;
            }
            else {
                let file = {
                    id: isEmpty(oldfile?.id) ? '' : oldfile?.id,
                    clientId: crypto.randomUUID(),
                    name: ctx.newValue.name,
                    lazy: true,
                    file: ctx.newValue,
                    status: "Pending",
                    error: null,
                    progress: 100
                };

                // ⭐ 這裡才 upload
                //const token = await tempUpload(file);
                //file.token = token;
                //file.lazy = false;
                //file.status = "pending";
                GraphV2.notify(ctx.stepKey, ctx.key, file); 
                mappingResult = true;
            } 
        }

        return mappingResult;
    }
    function initTooltips() {
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
            if (el._tooltip) return;

            el._tooltip = new bootstrap.Tooltip(el, {
                html: true,
                container: 'body'
            });
        });
    }
    function isPreviewOpen() {

        return $(".drive-right")
            .hasClass("preview-open");
    }
    function togglePreview() {

        const next = !isPreviewOpen();

        setPreviewLayout(next);

        if (!next) {

            flushPreview();

            $(".drive-item")
                .removeClass("active");
        }

        return next;
    }
    function setPreviewLayout(open, forceFull = false) {

        $(".drive-left").toggleClass("preview-open", open);

        $(".drive-right").toggleClass("preview-open", open).toggleClass("force-full", forceFull);
    }
    // =========================
    // STATE（原封不動）
    // =========================
    let PreviewState = {
        version: 0,
        type: null,
        payload: null
    };

    const $panel = () => $("#previewPanel");

    // =========================
    // 原 function（全部保留簽名）
    // =========================

    function flushPreview(type = null, payload = null) {

        const $p = $panel();

        // =========================
        // cleanup old iframe
        // =========================

        const prevIframe = $p.find("iframe");

        if (prevIframe.length) {

            prevIframe.attr("src", "about:blank");
            prevIframe.remove();
        }

        // =========================
        // revoke old pdf url
        // =========================

        if (
            PreviewState.type === "pdf" &&
            PreviewState.payload &&
            PreviewState.payload !== payload
        ) {
            URL.revokeObjectURL(PreviewState.payload);
        }

        $p.empty();

        // =========================
        // update state
        // =========================

        PreviewState.type = type;
        PreviewState.payload = payload;

        // =========================
        // empty
        // =========================

        if (!type) {

            $p.removeData("file-name");

            $p.html(`
            <div class="empty">
                Select file
            </div>
        `);

            PreviewWorker.destroy();

            return;
        }

        // =========================
        // pdf
        // =========================

        if (type === "pdf") {

            const iframe = document.createElement("iframe");

            iframe.src = payload;

            iframe.style.cssText =
                "width:100%;height:100%;border:0;";

            $p.append(iframe);

            return;
        }

        // =========================
        // image
        // =========================

        if (type === "image") {

            const bitmap = payload;

            const canvas = document.createElement("canvas");

            const ctx = canvas.getContext("2d");

            canvas.width = bitmap.width;
            canvas.height = bitmap.height;

            ctx.drawImage(bitmap, 0, 0);

            canvas.style.cssText =
                "max-width:100%;max-height:100%;object-fit:contain;";

            $p.append(canvas);

            bitmap.close?.();

            return;
        }

        // =========================
        // error
        // =========================

        if (type === "error") {

            $p.html(payload);
        }
    }

    function renderImage(bitmap, version) {

        if (version !== PreviewState.version) {

            bitmap.close?.();
            return;
        }

        flushPreview("image", bitmap);
    }

    function renderPdf(url, version) {

        if (version !== PreviewState.version) {

            URL.revokeObjectURL(url);
            return;
        }

        flushPreview("pdf", url);
    }

    function forceDownload(blob, fileName) {

        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = fileName || "download";

        document.body.appendChild(a);
        a.click();
        a.remove();

        setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    function showUnsupported(blob, message = "", fileName = "download", version) {

        if (version !== PreviewState.version) return;

        const html = `
            <div class="empty text-center">
                ⚠ 無法預覽此檔案<br>
                ${message ? `<small>${message}</small><br>` : ""}
                ${blob
                ? `<button class="btn-download">下載</button>`
                : `<div>無法下載</div>`
            }
            </div>
        `;

        flushPreview("error", html);

        if (blob) {
            $(".btn-download").off("click").on("click", () => {
                forceDownload(blob, fileName);
            });
        }
    }
    function normalizeFileArray(value) {

    if (!value) return [];

    if (Array.isArray(value)) return value;

    return [value];
}
    async function removeFile(stepKey, key, clientId) {

        const store = FileRuntime.getStore();
        let raw = store.get(stepKey, key);

        // =========================
        // normalize single / multi file
        // =========================
        let current = [];
        if (raw) {
            current = Array.isArray(raw) ? raw : [raw];
        }

        const file = current.find(f => f.clientId === clientId);
        if (!file) return;

        // =========================
        // server delete only if exists
        // =========================
        if (file.status === "success" && file.id) {

            Swal.fire({
                title: '正在刪除檔案...',
                text: '請稍後，系統正處理交易中。',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            try {

                const res = await fetch(
                    `${window.AppBasePath}api/file/${file.id}`,
                    { method: "DELETE" }
                );

                const json = await res.json(); 
                if (!res.ok || !json.Success) {
                    throw new Error(json.Message || "delete failed");
                }  
                await Swal.fire({
                    icon: 'success',
                    title: '已刪除檔案',
                    text: `檔案名：${file?.name}`,
                    confirmButtonText: '確定'
                });
               
            } catch (error) {
                showAlert('系統錯誤', '連線失敗或發生未知錯誤', 'error');
            } 
        }

        // =========================
        // local remove (ONLY by clientId)
        // =========================
        const next = current.filter(f => f.clientId !== clientId);

        // 如果原本是單檔，就保留單檔格式；多檔保持陣列
        const finalValue = raw && !Array.isArray(raw)
            ? next[0] || null
            : next;

        GraphV2.notify(stepKey, key, finalValue);

        const previewId = file.clientId || file.id;
        const currentfileId = $("#previewPanel").data("file-id");

        if (previewId === currentfileId) {
            PreviewModule.resetPreview();
        }
    }

    // =========================
    // Worker（不變）
    // =========================
    const PreviewWorker = (() => {

        let worker = null;
        let url = null;

        function getWorker() {

            if (worker) return worker;

            const code = `
                self.onmessage = async function (e) {
                    const { blob, type } = e.data;
                    try {
                        if (type.startsWith("image/")) {
                            const bitmap = await createImageBitmap(blob);
                            self.postMessage({ bitmap });
                        } else {
                            self.postMessage({ blob });
                        }
                    } catch (err) {
                        self.postMessage({ error: err.message });
                    }
                };
            `;

            const blob = new Blob([code], { type: "application/javascript" });
            url = URL.createObjectURL(blob);

            worker = new Worker(url);
            return worker;
        }

        function destroy() {
            if (worker) worker.terminate();
            if (url) URL.revokeObjectURL(url);
            worker = null;
            url = null;
        }

        return { getWorker, destroy };

    })();

    // =========================
    // PreviewService（不變但私有）
    // =========================
    const PreviewService = {

        open: async function (stepKey, key, file) {

            const $p = $panel();

            $p.data("file-name", file.name);
            $p.html(`<div class="empty">⏳ 載入中...</div>`);

            const version = ++PreviewState.version;

            let realFile;

            try {
                realFile = await FileRuntime.ensureFileObject(file, stepKey, key);
            } catch {
                if (version !== PreviewState.version) return;
                showUnsupported(null, "載入失敗", file.name, version);
                return;
            }

            const blob = realFile instanceof File ? realFile : realFile?.file;

            if (!blob) {
                showUnsupported(null, "無內容", file.name, version);
                return;
            }

            let handled = false;

            const worker = PreviewWorker.getWorker();

            const handler = (e) => {
                handled = true;

                if (version !== PreviewState.version) return;

                if (e.data.error) {
                    showUnsupported(blob, "預覽失敗", file.name, version);
                    return;
                }

                const type = (file.type || blob.type || "").toLowerCase();

                if (e.data.bitmap && type.startsWith("image/")) {
                    renderImage(e.data.bitmap, version);
                    return;
                }

                if (type === "application/pdf") {
                    const url = URL.createObjectURL(blob);
                    renderPdf(url, version);
                    return;
                }

                showUnsupported(blob, "不支援預覽", file.name, version);
            };
            worker.addEventListener(
                "message",
                handler,
                { once: true }
            );

            worker.onerror = () => {
                showUnsupported(blob, "worker error", file.name, version);
            };

            worker.postMessage({ blob, type: file.type || blob.type || "" });

            setTimeout(() => {
                if (!handled && version === PreviewState.version) {
                    showUnsupported(blob, "逾時", file.name, version);
                }
            }, 5000);
        }
    };

    // =========================
    // PUBLIC API（只開這些）
    // =========================

    function resetPreview() {

        PreviewState.version++;

        flushPreview();

        setPreviewLayout(false);
    }
    function setUploadMode(mode) {

        const isSingle = mode === "single";

        // 左側清單（multi only）
        $(".multi-only").toggleClass("d-none", isSingle);

        // 右側 preview panel（single / multi 都要）
        $(".single-only").toggleClass("d-none", !isSingle);

        // optional：可以加 class 控制 layout
        $("#uploadModal").toggleClass("single-mode", isSingle);
    }
    function buildTooltip(file, extra = "") {

        const sizeKB = file.size ? Math.round(file.size / 1024) : 0;
        const time = file.lastModified
            ? new Date(file.lastModified).toLocaleString()
            : (file.uploadTime || "");

        return `
        <div style="text-align:left">
            <b>${file.name || "unknown"}</b><br>
            Size: ${sizeKB} KB<br>
            Time: ${time}
            ${extra ? `<br><span style="color:#dc3545">${extra}</span>` : ""}
        </div>
    `;
    }
    function getFileIcon(file) {
        if (file.status === "error") {
            return "❌";
        }
        const type = (file.type || "").toLowerCase();
        const name = (file.name || "").toLowerCase();

        // =========================
        // 圖片
        // =========================
        if (type.startsWith("image/")) {
            return "🖼️";
        }

        // =========================
        // PDF
        // =========================
        if (type === "application/pdf" || name.endsWith(".pdf")) {
            return "📕";
        }

        // =========================
        // Excel
        // =========================
        if (
            type.includes("spreadsheet") ||
            name.endsWith(".xls") ||
            name.endsWith(".xlsx")
        ) {
            return "📊";
        }

        // =========================
        // Word
        // =========================
        if (
            type.includes("word") ||
            name.endsWith(".doc") ||
            name.endsWith(".docx")
        ) {
            return "📄";
        }

        // =========================
        // 壓縮檔
        // =========================
        if (
            name.endsWith(".zip") ||
            name.endsWith(".rar") ||
            name.endsWith(".7z")
        ) {
            return "🗜️";
        }

        // =========================
        // 可執行 / DLL
        // =========================
        if (
            name.endsWith(".exe") ||
            name.endsWith(".dll")
        ) {
            return "⚙️";
        }

        // =========================
        // 預設
        // =========================
        return "📎";
    }
    function render(stepKey, key, files) {

        const $list = $("#uploadList");

        $list.empty();

        const failCount =
            files.filter(x => x.status === "error").length;

        $("#uploadSummary").html(

            failCount
                ? `
            <div class="alert alert-danger py-1 px-2 mb-2">
                ⚠ ${failCount} 個檔案上傳失敗
            </div>
        `
                : ""
        );

        files.forEach(file => {
            const isError =
                file.status === "error";

            const icon = isError
                ? "❌"
                : getFileIcon(file);

            const tooltip = buildTooltip(
                file,
                file.error
            );

            const percent = file.progress || 0;

            const isUploading =
                file.status === "uploading";

            const isPending =
                file.status === "pending";

            const isSuccess =
                file.status === "success";
            const disableView =
                isUploading || isPending;
            const statusText =
                isUploading
                    ? `Uploading ${percent}%`
                    : isPending
                        ? "Waiting..."
                        : isError
                            ? "Failed"
                            : "Completed";

            const $item = $(` 
                        <li class="drive-item ${isError ? "file-error" : ""}" data-client-id="${file.clientId || file.id}"> 
                            <div class="drive-name" 
                                 data-bs-toggle="tooltip"
                                 data-bs-html="true"
                                 title='${tooltip}'>

                                <span class="drive-icon">
                                    ${icon}
                                </span> 
                                <div class="flex-grow-1 overflow-hidden"> 
                                <div>

                                <span class="drive-scroll"> 
                                    <span class="drive-text">
                                        ${file.name}
                                    </span> 
                                </span> 
                            </div>

                             ${(isUploading || isPending) ? ` <div class="progress mt-1" style="height:18px;">

                            <div class="progress-bar  upload-progress progress-bar-striped ${isUploading ? "progress-bar-animated" : ""}" 
                                role="progressbar" style="width:${percent}%"> 
                                ${percent}% 
                            </div> 
                            </div> ` : ""}

                            </div> 
                            </div> 

                            <div class="drive-actions"> 
                                <button  class="btn btn-sm btn-outline-primary btn-view" ${disableView ? "disabled" : ""}>
                                    ${isError ? "Retry" : "View"}
                                </button>

                                <button class="btn btn-sm btn-outline-danger btn-del">
                                    Del
                                </button> 
                            </div> 
                        </li>
                      `);
            // =========================
            // preview
            // =========================

            const $viewBtn = $item.find(".btn-view");
            const $name = $item.find(".drive-name");

            $viewBtn
                .off("click")
                .on("click", async (e) => {

                    e.stopPropagation();

                    $(".drive-item").removeClass("active");
                    $item.addClass("active");

                    // =========================
                    // ERROR → RETRY
                    // =========================
                    if (file.status === "error") {

                        const controller = PreviewModule._uploadController;
                        const ctx = PreviewModule._ctx;

                        file.status = "pending";
                        file.error = null;
                        file.progress = 0;

                        PreviewModule.refreshList(stepKey, key, files);
                        //const ctx = {
                        //    stepKey,
                        //    key
                        //};
                        await controller.uploadSingleFile(
                            ctx,
                            key,
                            file,
                            files
                        );

                        return;
                    }

                    // =========================
                    // NORMAL → PREVIEW
                    // =========================
                    setPreviewLayout(true);

                    await PreviewService.open(stepKey, key, file);
                });
            $name
                .off("click")
                .on("click", async () => {
                    if (togglePreview())
                        $viewBtn.trigger("click");
                });

            // =========================
            // delete
            // =========================

            $item.find(".btn-del")
                .off("click")
                .on("click", async (e) => {

                    e.stopPropagation();

                    await removeFile(stepKey, key, file.clientId);

                    const store = FileRuntime.getStore();
                    const updated = store.get(stepKey, key) || [];

                    // ⭐ 只做一件事：統一刷新 UI
                    PreviewModule.refreshList(stepKey, key, updated);

                    const previewName =
                        $("#previewPanel").data("file-name");

                    if (previewName === file.name) {
                        resetPreview();
                    }
                });

            $list.append($item);
        });
        initTooltips();
    }
    function updateFileRow(file) {
        const uploadKey = getUploadKey(file);

        const $row = $(`.drive-item[data-client-id="${uploadKey}"]`);

        if (!$row || !$row.length) return;

        const percent = file.progress || 0;

        const isUploading = file.status === "uploading";

        const isPending = file.status === "pending";

        const isError =  file.status === "error";

        const statusText =  isUploading ? `Uploading ${percent}%` : isPending ? "Waiting..."  : isError  ? "Failed" : "Completed";

        // =========================
        // status text
        // =========================



        // =========================
        // progress
        // =========================

        const $bar =  $row.find(".upload-progress");

        if ($bar.length) {

            $bar.css("width", `${percent}%`).text(`${percent}%`);

            if (!isUploading && !isPending) {
                $bar.closest(".progress").remove();
            }
        }
    }
    function refreshList(stepKey, key, files) {
        render(stepKey, key, files);
    }
    async function loadFiles(ctx) {
        const store = FileRuntime.getStore();
        let key = ctx.key.replace('.file','')
        
        const FormInfo = window.FlowStore.get("supplier", "FormInfo") || {};

        // =========================
        // 1. 從後端拿 metadata list
        // =========================
        let res = await fetch(
            `${window.AppBasePath}api/file/list?formno=${FormInfo?.formno}&key=${key}`
        );
        let result = await res.json(); 
        // ⭐ ApiResponse 解包
        if (!result.Success) {
            throw new Error(result.Message || "load file list failed");
        }
        let files = (result.Data || []).map(f => ({
            id: f.FileId,
            name: f.FileName,
            lazy: true,
            file: null,
            status: "success",
            error: null,
            progress: 100
        }));
        //let files = result.Data || [];

        // =========================
        // 2. normalize（只放 metadata，不下載）
        // =========================
        //files = (files || []).map(f => ({
        //    id: f.FileId,              // serverId
        //    name: f.FileName,
        // //   size: f.size,
        // //   type: f.type,
        //    lazy: true,            // ⭐ 重點：還沒下載 blob
        //    file: null,           // ⭐ 不放 File object
        //    status: "success",
        //    error: null,
        //    progress: 100
        //}));

        store.safeSet(ctx.stepKey, ctx.key, files);
        render(ctx.stepKey, ctx.key, files);
    }
    function openUploadModal(ctx) {

        let controller = new UploadController(ctx);
        PreviewModule._uploadController = controller; // ⭐ 加這行
        PreviewModule._ctx = ctx;

        resetPreview();

        const store = window.FileRuntime.getStore();
        const file = store.get(ctx.stepKey, ctx.key);

        //UploadContext.open(ctx);

        const isMulti = ctx.mode == 'single' ? false : true;
        setUploadMode(ctx.mode);

        $("#uploadModal").modal("show");

        $("#uploadModal").one("shown.bs.modal", async () => {

            if (isMulti) {
                setPreviewLayout(false);
                loadFiles(ctx);
                $panel().html(`<div class="empty">Select file</div>`);

            } else if (file) {

                $("#uploadList").empty();
                setPreviewLayout(true, true);
                await PreviewService.open(ctx.stepKey, ctx.key, file);
            }
        });
    }
    function registerEffects(config) {
        if (typeof GraphV2 === 'undefined') return;

        GraphV2.register({
            type: "effect",
            stepKey: config.stepKey,
            deps: [config.fullKey],
            target: config.fullKey,
            run: ({ data }) => {
                if (!config?.$row || config?.$row?.length === 0) return;
                const targetKey = config.fullKey;
                const files = data[targetKey] || [];
                const hasFile = files.length > 0; 
                const $icon = config?.$row.find("td i.bi");
                $icon.attr(
                    "class",
                    hasFile
                        ? "bi bi-file-earmark-text text-success"
                        : "bi bi-file-earmark text-secondary"
                );
                 
                const $badge = config?.$row.find("td span.badge");
                if ($badge.length > 0) { 
                    $badge.text(files.length); 
                    $badge.attr(
                        "class",
                        hasFile
                            ? "badge bg-success align-middle ms-1"
                            : "badge bg-secondary align-middle ms-1"
                    );
                }
            }
        });
    }
    // =========================
    // 外部只拿這些
    // =========================
    return {
        openUploadModal,
        setPreviewLayout,
        resetPreview,
        refreshList, removeFile,
        updateFileRow, importfile,
        init: function () {

            $(document).on("click", ".uploadBtn, .btn-upload", function () {
                const $btn = $(this);
                const stepKey = $btn.data("step");
                const field = $btn.data("field");
                const col = $btn.data("col") || "";
                const fullKey = col !== "" ? `${field}.${col}` : field;
                const fieldName = $btn.data("fieldName");
                const headerid = $btn.data("headerid");
                const formno = $btn.data("formno");
                const $row = $btn.closest("tr");

               
                if ($btn.hasClass("uploadBtn")) {
                    registerEffects({
                        stepKey: stepKey,
                        fullKey: fullKey,
                        $row: $row
                    });
                }

                // 不論是哪種按鈕，最後都開啟上傳 Modal
                window.PreviewModule.openUploadModal({
                    stepKey: stepKey,
                    key: fullKey,
                    $row: $row,
                    mode: $btn.hasClass("uploadBtn") ?'multi':'single'
                });
            }); 
            

            $(document).on("hidden.bs.modal", "#uploadModal", function () {

                PreviewModule.resetPreview();

                const controller =  PreviewModule._uploadController;

                controller?.abortAll?.();
            });
            $(document).on("hide.bs.modal", "#uploadModal", function (e) {

                const controller = PreviewModule._uploadController;

                const hasUploading = controller?.hasActiveUploads?.();

                if (!hasUploading)
                    return;

                e.preventDefault();

                alert("檔案上傳中，請稍候完成");
            });
        }, 
    };

})();

 
window.FileRuntime = (() => {

    const inflightMap = new Map();
    // =========================
    // ⭐ LRU Cache (File Object)
    // =========================
    const fileCache = new Map(); // file.id → File
    const MAX_CACHE = 30;

    function touchCache(fileId, fileObj) {

        if (fileCache.has(fileId)) {
            fileCache.delete(fileId);
        }

        fileCache.set(fileId, {
            file: fileObj,
            ts: Date.now()
        });

        // LRU cleanup
        if (fileCache.size > MAX_CACHE) {

            const oldest = [...fileCache.entries()]
                .sort((a, b) => a[1].ts - b[1].ts)[0];

            if (oldest) {
                fileCache.delete(oldest[0]);
            }
        }
    }

    function getCache(fileId) {
        const hit = fileCache.get(fileId);
        if (!hit) return null;

        hit.ts = Date.now(); // refresh
        return hit.file;
    }
    function getStore() {
        return AppBootstrap.get("FlowStore"); //AppBootstrap.get("FormStore");
    }

    //function buildKey(stepKey, field, col) {
    //    return col ? `${field}.${col}` : field;
    //}

    // =========================
    // ⭐ 共用下載（in-flight + cache + abort）
    // =========================
    async function ensureFileObject(file, stepKey, key) {

        if (file instanceof File) return file;
        if (file.file instanceof File) return file.file;
        if (file.status === "error") {
            throw new Error(file.error || "檔案錯誤");
        }
        if (!file.lazy) return file;

        const cached = getCache(file.id);
        if (cached) return cached;

        if (inflightMap.has(file.id)) {
            const prev = inflightMap.get(file.id);
            prev.controller.abort();
            inflightMap.delete(file.id);
        }

        const controller = new AbortController();

        const promise = (async () => {

            try {

                const res = await fetch(
                    `${window.AppBasePath}api/file/${file.id}`,
                    {
                        signal: controller.signal
                    }
                );

                // =========================
                // HTTP error
                // =========================
                if (!res.ok) {
                    throw new Error(`下載失敗: ${res.status}`);
                }

                // =========================
                // API JSON error fallback
                // =========================
                const contentType =
                    res.headers.get("content-type");

                if (contentType?.includes("application/json")) {

                    const err = await res.json();

                    throw new Error(
                        err.message || "API error"
                    );
                }

                // =========================
                // blob
                // =========================
                const blob = await res.blob();

                if (!blob || blob.size === 0) {
                    throw new Error("空檔案");
                }

                const realFile = new File(
                    [blob],
                    file.name,
                    {
                        type:
                            blob.type ||
                            "application/octet-stream"
                    }
                );

                // =========================
                // update runtime state safely
                // =========================
                file.file = realFile;
                file.lazy = false;

                // ⭐ cache
                touchCache(file.id, realFile);

                const store = getStore();
                const current =
                    store.get(stepKey, key);

                if (Array.isArray(current)) {

                    const target =
                        current.find(
                            f => f.id === file.id
                        );

                    if (target) {

                        target.lazy = false;
                        target.file = realFile;
                    }
                }

                return realFile;
            }

            catch (err) {

                // =========================
                // abort → 不污染 state
                // =========================
                if (err.name === "AbortError") {
                    return null;
                }

                console.error(err);

                // ⚠️ 只標記 lazy，不要動 file
                file.lazy = true;

                throw err;
            }

            finally {

                inflightMap.delete(file.id);
            }

        })();

        inflightMap.set(file.id, { controller, promise });

        return promise;
    }

    return {
        ensureFileObject,
        //buildKey,
        getStore
    };

})();
 
function normalizeFileValue(value) {

    if (!value) return null;

    // array
    if (Array.isArray(value)) {
        return value.map(v =>
            typeof v === "string"
                ? v
                : v?.name
        ).filter(Boolean);
    }

    // object file model
    if (typeof value === "object") {
        return value.name || null;
    }

    // DB string
    if (typeof value === "string") {
        return value;
    }

    return null;
}
window.FilePlugin = {
     
    setFileUI(wrapper, value) {

        const input = wrapper.querySelector(".file-input");
        const nameEl = wrapper.querySelector(".file-name");
        const actions = wrapper.querySelector(".file-actions");
        const lineEl = wrapper.querySelector(".file-line");

        const name =
            typeof value === "string"
                ? value
                : value?.name;

        const hasFile = !!name;

        input.classList.toggle("d-none", hasFile);

        if (nameEl) {
            nameEl.textContent = name || "";
            nameEl.classList.toggle("d-none", !hasFile);
        }

        if (lineEl) {
            lineEl.dataset.title = name || "";
        }

        actions?.classList.toggle("d-none", !hasFile);
    },
    init(el, ctx) {
        const setFileUI = FilePlugin.setFileUI;
        if (!(el instanceof HTMLInputElement) || el.type !== "file") {
            return;
        }

        const wrapper = el.closest(".file-wrapper");

        if (!wrapper) {
            console.warn("FilePlugin: missing wrapper", el);
            return;
        }


        const store = FileRuntime.getStore();

        const state = store.get(ctx.stepKey, ctx.key);
        const lineEl = wrapper.querySelector(".file-line");

        // ⭐⭐⭐ 這裡放 DB hydrate（你問的那段）
        const dbValue = lineEl?.dataset.title || null;
        const fieldId = lineEl?.dataset.fileid || null;
        if (dbValue && !state) { 
            let file =  {
                id: fieldId,
                clientId: crypto.randomUUID(),
                name: dbValue,
                lazy: true,
                file: null,
                status: "success",
                error: null,
                progress: 100
            }; 
            store.safeSet(ctx.stepKey, ctx.key, file);
        }

        // =========================
        // UI render（一定要在 hydrate 後）
        // =========================
        const finalState = store.get(ctx.stepKey, ctx.key);
        // =========================
        // UI render
        // =========================
        setFileUI(wrapper, finalState || dbValue);
        // upload change
        // =========================
        el.addEventListener("change", () => {

            const rawFiles = el.multiple
                ? Array.from(el.files || [])
                : el.files?.[0] || null;

            let files = null;

            if (Array.isArray(rawFiles)) {

                files = rawFiles.map(f => ({
                    id: crypto.randomUUID(),
                    clientId: crypto.randomUUID(),
                    name: f.name,
                    size: f.size,
                    type: f.type,
                    file: f,
                    status: "success",
                    lazy: false,
                    isNew: true,
                    server: false
                }));
                //store.safeSet(ctx.stepKey, ctx.key, files);
                GraphV2.notify(ctx.stepKey, ctx.key, files);

                setFileUI(wrapper, files);
            } else if (rawFiles) {

                files = {
                    id: crypto.randomUUID(),
                    clientId: crypto.randomUUID(),
                    name: rawFiles.name,
                    size: rawFiles.size,
                    type: rawFiles.type,
                    file: rawFiles,
                    status: "success",
                    lazy: false,
                    isNew: true,
                    server: false
                };
            }


        });

        // =========================
        // click handler
        // =========================
        wrapper.addEventListener("click", async (e) => {
            e.stopPropagation();
            el.value = "";
            if (e.target.closest(".file-preview-btn")) { 
                PreviewModule.openUploadModal({
                    stepKey: ctx.stepKey,
                    key: ctx.key,
                    mode: "single",
                    file: store.get(ctx.stepKey, ctx.key)
                });

                return;
            }

            if (e.target.closest(".file-remove")) {  
                el.value = ""; 
                let file = store.get(ctx.stepKey, ctx.key)
                await PreviewModule.removeFile(ctx.stepKey, ctx.key, file.clientId);
                //store.safeSet(ctx.stepKey, ctx.key, null);
                GraphV2.notify(ctx.stepKey, ctx.key, null);

                setFileUI(wrapper, null);
            }
        });
    },
    render(wrapper, files) {

        const actions = wrapper.querySelector(".file-actions");
        const name = wrapper.querySelector(".file-name");
        const lineEl = wrapper.querySelector(".file-line");
        if (lineEl)
            lineEl.dataset.title = file.name;
        const hasFile = files && (Array.isArray(files) ? files.length > 0 : true);

        // =========================
        // ⭐ 控制顯示/隱藏
        // =========================
        if (actions) {
            actions.classList.toggle("d-none", !hasFile);
        }

        if (name) {
            name.textContent = hasFile
                ? (Array.isArray(files) ? files[0].name : files.name)
                : "";
        }
    }

};


class UploadController { 
    constructor(ctxProvider) {

        this.ctxProvider = ctxProvider;
        this.uploadPool = new Map(); // key → xhr
        this.$modal = $("#uploadModal");

        this.$fileInput = $("<input type='file' multiple style='display:none'>");
        $("body").append(this.$fileInput);

        this.bind();
    }
    hasActiveUploads() {
        return this.uploadPool.size > 0;
    }
    abortAll() {

        for (const [, xhr] of this.uploadPool) {
            try {
                xhr.abort();
            } catch { }
        }

        this.uploadPool.clear();
    }
    async retryFile(stepKey, key, fileModel) {

        const store = FileRuntime.getStore();

        const merged = store.get(stepKey, key) || [];

        try {

            const uploadKey = getUploadKey(fileModel);
            fileModel.status = "uploading";
            fileModel.progress = 0;
            fileModel.error = null;

            PreviewModule.refreshList(stepKey, key, merged);

            //const fd = new FormData();
            //fd.append("file", fileModel.file); 

            let ItemName = this.ctxProvider.$row != undefined ? this.ctxProvider.$row.find("td:eq(0) .tooltip-auto").data("title") : key.replace('.file', '') || ""
            const FormInfo = window.FlowStore.get("supplier", "FormInfo") || {};
            const fd = new FormData();
            fd.append(`ItemId`, key.replace('.file', '') || "");
            fd.append(`ItemName`, ItemName);
            fd.append(`Headerid`, isEmpty(FormInfo?.headerid) ? '' : FormInfo?.headerid);
            fd.append(`FormNo`, isEmpty(FormInfo?.formno) ? '' : FormInfo?.formno);
            fd.append(`FileId`, '');
            fd.append(`FileName`, fileModel.name); 
            fd.append(`File`, fileModel.file);

            const result =
                await this.uploadWithProgress(
                    `${window.AppBasePath}api/file/UploadFileAsync`,
                    fd,
                    percent => {
                        fileModel.progress = percent;
                        PreviewModule.refreshList(stepKey, key, merged);
                    },
                    uploadKey
                );

            fileModel.status = "success";
            fileModel.progress = 100;
            fileModel.id = result.Data.FileId;
            fileModel.name = result.Data.FileName;
            fileModel.lazy = false;
            fileModel.uploadTime = new Date().toISOString();

        } catch (err) {

            fileModel.status = "error";
            fileModel.error = err.message || "retry failed";
        }

        store.safeSet(stepKey, key, merged);
        GraphV2.notify(stepKey, key, merged);
        PreviewModule.refreshList(stepKey, key, merged);
    }
    bind() {
        this.$modal.off("click.myUpload");
        this.$modal.on("click.myUpload", "#btnSelectFile", () => {
            this.$fileInput.trigger("click");
        });


        this.$fileInput.off("change.myUpload");
        this.$fileInput.on("change.myUpload", async (e) => {
            await this.handleFiles(e.target.files);
            e.target.value = "";
        });


        this.$modal.off("dragover.myUpload");
        this.$modal.on("dragover.myUpload", e => e.preventDefault());

        this.$modal.off("drop.myUpload");
        this.$modal.on("drop.myUpload", async (e) => {
            e.preventDefault();
            const files = e.dataTransfer || e.originalEvent.dataTransfer;
            if (files && files.files) {
                await this.handleFiles(files.files);
            }
        });
    }

    validateFile(file) {

        const ext = file.name
            .split(".")
            .pop()
            .toLowerCase();

        const deny = ["exe", "dll"];

        if (deny.includes(ext)) {
            return "不允許的檔案格式";
        }
        const config = window.appConfig; 
        if (file.size > 20 * 1024 * 1024) {
            return "檔案超過 20MB";
        }

        return null;
    }

    //createFileModel(file) {

    //    const error = this.validateFile(file);

    //    return {

    //        id: crypto.randomUUID(),

    //        file: error ? null : file,

    //        name: file.name,
    //        type: file.type,
    //        size: file.size,

    //        status: error ? "error" : "success",
    //        error,

    //        lazy: false,
    //        isNew: true
    //    };
    //}
    async uploadSingleFile(
        ctx,
        key,
        fileModel,
        merged
    ) {

        const store = FileRuntime.getStore();

        try {

            // =========================
            // uploading
            // =========================
            const uploadKey = getUploadKey(fileModel);
            fileModel.status = "uploading";
            fileModel.error = null;

            PreviewModule.refreshList(
                ctx.stepKey,
                key,
                merged
            );
         
            // =========================
            // formdata
            // =========================

            const FormInfo = window.FlowStore.get("supplier", "FormInfo") || {};
            let ItemName = ctx.$row != undefined ? ctx.$row.find("td:eq(0) .tooltip-auto").data("title") : key.replace('.file', '') || ""
             
            const fd = new FormData();
            fd.append(`ItemId`, key.replace('.file', '') || "");
            fd.append(`ItemName`, ItemName);
            fd.append(`Headerid`, isEmpty(FormInfo?.headerid) ? '' : FormInfo?.headerid);
            fd.append(`FormNo`, isEmpty(FormInfo?.formno) ? '' : FormInfo?.formno);
            fd.append(`FileId`, '');
            fd.append(`FileName`, fileModel.name);
       /*     fd.append(`Active`, "Y");*/
         /*   fd.append(`CUser`, "1204636");*/
            fd.append(`File`, fileModel.file);

            //fd.append(
            //    "file",
            //    fileModel.file
            //);

            // =========================
            // upload
            // =========================

            const result =
                await this.uploadWithProgress(
                    `${window.AppBasePath}api/file/UploadFileAsync`,
                    fd,
                    percent => { 
                        fileModel.progress = percent;
                        PreviewModule.updateFileRow(fileModel); 
                    },
                    uploadKey
                );

            // =========================
            // success
            // =========================


            if (!result.Success) {
                throw new Error(`上傳失敗: 可能上傳副檔有限制`);
            }
            fileModel.status = "success";

            fileModel.progress = 100;

            fileModel.uploadTime = new Date().toISOString();

            // backend id
            fileModel.id = result.Data.FileId;
            fileModel.name = result.Data.FileName;
            // lazy mode
            //fileModel.file = result;
            fileModel.lazy = false;
            fileModel.status = "success";
            fileModel.error = null;
        } catch (err) { 
            console.error(err);  
            if (
                err.message === "upload aborted" ||
                err.name === "AbortError"
            ) {

                fileModel.status = "pending";
                fileModel.progress = 0;
                fileModel.error = null; 
                return;
            }
             
            fileModel.status = "error";
            fileModel.error = err.message || "upload failed";
        }

        //store.safeSet(
        //    ctx.stepKey,
        //    key,
        //    merged
        //);

        GraphV2.notify(
            ctx.stepKey,
            key,
            merged
        );

        PreviewModule.refreshList(
            ctx.stepKey,
            key,
            merged
        );
    }
    uploadWithProgress(
        url,
        formData,
        onProgress,
        uploadKey
    ) {

        return new Promise((resolve, reject) => {

            const xhr = new XMLHttpRequest();

            xhr.open("POST", url);

            // =========================
            // register upload pool
            // =========================
            if (uploadKey) {

                this.uploadPool.set(
                    uploadKey,
                    xhr
                );
            }

            // =========================
            // progress
            // =========================
            xhr.upload.onprogress = e => {

                if (!e.lengthComputable)
                    return;

                const percent = Math.round(
                    (e.loaded / e.total) * 100
                );

                onProgress?.(percent);
            };

            // =========================
            // success
            // =========================
            xhr.onload = () => {

                this.uploadPool.delete(
                    uploadKey
                );

                if (
                    xhr.status >= 200 &&
                    xhr.status < 300
                ) {

                    try {

                        const result =
                            JSON.parse(
                                xhr.responseText
                            );

                        // ⭐ API fail
                        if (!result.Success) {

                            reject(
                                new Error(result.Message || "upload failed")
                            );

                            return;
                        }

                        resolve(result);

                    } catch (err) {

                        reject(
                            new Error(
                                "invalid api response"
                            )
                        );
                    }

                } else {

                    reject(
                        new Error(
                            `Upload failed (${xhr.status})`
                        )
                    );
                }
            };

            // =========================
            // network error
            // =========================
            xhr.onerror = () => {

                this.uploadPool.delete(
                    uploadKey
                );

                reject(
                    new Error("network error")
                );
            };

            // =========================
            // abort
            // =========================
            xhr.onabort = () => {

                this.uploadPool.delete(
                    uploadKey
                );

                reject(
                    new Error("upload aborted")
                );
            };

            // =========================
            // timeout
            // =========================
            xhr.ontimeout = () => {

                this.uploadPool.delete(
                    uploadKey
                );

                reject(
                    new Error("upload timeout")
                );
            };

            xhr.send(formData);
        });
    } 
    async handleFiles(files) {

        const ctx = this.ctxProvider;
        const key = ctx.key;

        const store = FileRuntime.getStore();

        const current = store.get(ctx.stepKey, key) || [];

        const merged = [...current];

        // =========================
        // create file models
        // =========================

        const newItems = [];

        Array.from(files).forEach(f => {

            // duplicate
            if (merged.some(x => x.name === f.name)) {
                return;
            }

            // validate
            const validateError = this.validateFile(f);

            const model = {
                // backend file id
                id: null,

                // temp client id
                clientId: crypto.randomUUID(),

                // meta
                name: f.name,
                size: f.size,
                type: f.type,

                // actual file
                file: f,

                // upload state
                status: validateError ? "error" : "pending",

                error: validateError || null,

                // %
                progress: 0,

                // server lazy mode
                lazy: false,

                // UI state
                isNew: true,

                uploadTime: null
            };

            merged.push(model);
            newItems.push(model);
        });

        // =========================
        // render immediately
        // =========================

        //store.safeSet(
        //    ctx.stepKey,
        //    key,
        //    merged
        //);

        GraphV2.notify(
            ctx.stepKey,
            key,
            merged
        );

        PreviewModule.refreshList(
            ctx.stepKey,
            key,
            merged
        );

        // =========================
        // upload queue
        // =========================

        const uploadables =
            newItems.filter(x =>
                x.status === "pending"
            );

        // parallel uploads
        await Promise.allSettled(
            uploadables.map(file =>
                this.uploadSingleFile(
                    ctx,
                    key,
                    file,
                    merged
                )
            )
        );

        // final refresh
        //store.safeSet(
        //    ctx.stepKey,
        //    key,
        //    merged
        //);

        GraphV2.notify(
            ctx.stepKey,
            key,
            merged
        );

        PreviewModule.refreshList(
            ctx.stepKey,
            key,
            merged
        );
    }
}


$(() => {
    window.PreviewModule.init();
}); 

