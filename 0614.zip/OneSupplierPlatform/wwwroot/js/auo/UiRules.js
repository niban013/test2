﻿window.UiRules = (() => {

    function findField(stepKey, field) {

        const [fieldName, colRef] = field.split('.');

        const selector = colRef
            ? `[data-step='${stepKey}'][data-field='${fieldName}'][data-col='${colRef}']`
            : `[data-step='${stepKey}'][data-field='${fieldName}']`;

        return document.querySelector(selector);
    }
    function commit(stepKey, field, value) {
        GraphV2.notify(stepKey, field, value);
    }
    // =====================================================
    // UI Scheduler
    // =====================================================

    let uiQueue = [];
    let scheduled = false;

    function scheduleUI(fn) {

        uiQueue.push(fn);

        if (scheduled) return;

        scheduled = true;

        setTimeout(flushUI, 0);
    }

    function flushUI() {

        const tasks = uiQueue;

        uiQueue = [];
        scheduled = false;

        for (const fn of tasks) {
            fn();
        }
    }

    // =====================================================
    // Registry
    // =====================================================

    const registry = new Map();

    // =====================================================
    // Rehydrate
    // =====================================================

    function rehydrate(stepKey) {

        const store = AppBootstrap.get("FlowStore");
        const data = store.getStep(stepKey);

        // 防止 rehydrate 自己觸發 re-entry loop
        if (rehydrate._running === stepKey)
            return;

        rehydrate._running = stepKey;

        try {

            for (const item of registry.values()) {

                if (item.stepKey !== stepKey)
                    continue;

                const renderer = renderers[item.ui.type];

                if (!renderer)
                    continue;

                renderer({
                    stepKey,
                    field: item.field,
                    value: data?.[item.field],
                    data,
                    ui: item.ui
                });
            }

        } finally {
            rehydrate._running = null;
        }
    }

    // =====================================================
    // Renderers
    // =====================================================

    const renderers = {

        // -----------------------------------------
        // specialRadio
        // -----------------------------------------
        specialRadio({
            stepKey,
            field,
            value
        }) {

            scheduleUI(() => {

                window.FieldBinder.setSpecailRadio(
                    stepKey,
                    field,
                    value
                );

            });
        },

        // -----------------------------------------
        // toggleGroup
        // -----------------------------------------
        toggleGroup({
            stepKey,
            field,
            value,
            data,
            ui
        }) {

            scheduleUI(() => {

                const groupEl =
                    document.querySelector(
                        `[data-group="${ui.group}"]`
                    );

                if (!groupEl)
                    return;

                const collapse =
                    groupEl.querySelector(
                        ".accordion-collapse"
                    );

                const fields =
                    groupEl.querySelectorAll(
                        "[data-field]"
                    );

                const visible =
                    typeof ui.showWhen === "function"
                        ? ui.showWhen(value, data)
                        : value === ui.showWhen;

                if (visible) {

                    groupEl.classList.remove("d-none");

                    collapse?.classList.add("show");

                    fields.forEach(x => {

                        x.disabled = false;

                        const f = x.dataset.field;

                        if (!f) return;

                        FlowStore.clearDisabled(
                            stepKey,
                            f
                        );
                        commit(stepKey, f, data?.[f]);
                    });

                }
                else {

                    groupEl.classList.add("d-none");

                    collapse?.classList.remove("show");

                    const patch = {};

                    fields.forEach(x => {

                        x.disabled = true;

                        const f = x.dataset.field;

                        if (!f) return;

                        FlowStore.setDisabled(
                            stepKey,
                            f,
                            true
                        );

                        FlowStore.clearError(
                            stepKey,
                            f
                        );

                        FlowStore.setStatus(
                            stepKey,
                            f,
                            null
                        );

                        patch[f] = null;
                    });

                    if (Object.keys(patch).length) {

                        GraphV2.batchNotify(
                            stepKey,
                            patch
                        );
                    }
                }
            });
        },

        // -----------------------------------------
        // asyncOptions
        // -----------------------------------------
        asyncOptions({
            stepKey,
            field,
            data,
            ui
        }) {

            scheduleUI(async () => {

                try {

                    const list =
                        await ui.fetch({
                            stepKey,
                            data
                        });

                    window.FieldBinder.setOptions(
                        stepKey,
                        field,
                        list || []
                    );

                }
                catch (err) {

                    console.error(
                        "asyncOptions error:",
                        err
                    );
                }
            });
        },

        // -----------------------------------------
        // lookupModal
        // -----------------------------------------
        lookupModal({
            stepKey,
            field,
            ui
        }) {

            scheduleUI(() => {

                const el =
                    findField(
                        stepKey,
                        field
                    );

                if (!el)
                    return;

                window.FieldBinder.bindLookupModal(
                    stepKey,
                    field,
                    {
                        modalUrl: ui.modalUrl,
                        modalId: ui.modalId,
                        mapping: ui.mapping
                    }
                );
            });
        }
    };

    // =====================================================
    // Register
    // =====================================================

    function register(cfg) {

        const {
            stepKey,
            field,
            deps = [field],
            ui
        } = cfg;

        const id =  `ui.${ui.type}.${stepKey}.${field}`;

        // 已存在直接跳過
        if (registry.has(id))
            return;

        registry.set(id, {
            stepKey,
            field,
            deps,
            ui
        });

        GraphV2.register({

            id: id,

            stepKey,

            type: "ui",

            deps,

            run: async ({
                data,
                stepKey
            }) => {

                const renderer =
                    renderers[ui.type];

                if (!renderer)
                    return;

                await renderer({
                    stepKey,
                    field,
                    value: data?.[field],
                    data,
                    ui
                });
            }
        });
    }

    return {

        register,

        rehydrate,

        refresh(stepKey) {
            rehydrate(stepKey);
        }
    };

})();