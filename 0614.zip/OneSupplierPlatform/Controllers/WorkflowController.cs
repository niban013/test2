﻿using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.Workflow;

namespace OneSupplierPlatform.Controllers
{
    public class WorkflowController : BaseController
    {
        private readonly WorkflowDispatcher _dispatcher;


        public WorkflowController(WorkflowDispatcher dispatcher)
        {
            _dispatcher = dispatcher;
        }

        [HttpPost]
        public async Task<IActionResult> Run([FromBody] WorkflowRequest request)
        {
            var result = await _dispatcher.Execute(request);
            return Ok(result);
        }
    }
}
