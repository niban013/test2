﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OneSupplierPlatform.Helper;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Services;

namespace OneSupplierPlatform.Controllers
{
    public class SupplierQueryController : BaseController
    {
        private readonly ISupplierService _supplierService;

        private List<SupplierItem> GetAllMockData()
        {
            var list = new List<SupplierItem>();
            // 這裡模擬產生 25 筆測試資料，以便測試分頁效果
            for (int i = 1; i <= 25; i++)
            {
                list.Add(new SupplierItem
                {
                    FormNo = (400 + i).ToString(),
                    VendorName = $"AUO MSC MEXICO S.A. DE C.V. ({i})",
                    VendorCode = "1600004301",
                    CreateDate = DateTime.Today,
                    FlowerStatus = i % 2 == 0 ? "SAVED" : "Return",
                    ApplyType = "ES",
                    Applicant = "Lily Huang 黃麗康",
                    Department = "MSCB_AO"
                });
            }
            return list;
        }


        public SupplierQueryController(ISupplierService supplierService)
        {
            _supplierService = supplierService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var model = new vmSupplierQuery { PageNumber = 1 };
            //await ProcessQueryAndPagination(model);
            //Logger.LogInformation(JsonConvert.SerializeObject(model));
            model = JsonConvert.DeserializeObject<vmSupplierQuery>(mock.j8);
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Index(vmSupplierQuery model)
        {
            //await ProcessQueryAndPagination(model);
            model = JsonConvert.DeserializeObject<vmSupplierQuery>(mock.j8);
            Logger.LogInformation(JsonConvert.SerializeObject(model));
            return View(model);
        }


        private async Task ProcessQueryAndPagination(vmSupplierQuery model)
        {
            var query = await _supplierService.QuerySuppierAll(model);

            model.TotalItems = query.Count();
            if (model.PageNumber < 1) model.PageNumber = 1;
            model.Results = query
                .Skip((model.PageNumber - 1) * model.PageSize)
                .Take(model.PageSize)
                .ToList();
        }
    }
}
