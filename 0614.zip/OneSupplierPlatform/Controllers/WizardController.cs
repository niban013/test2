using Microsoft.AspNetCore.Mvc;
using One_Supplier_Platform.Models;
using System.Runtime.Intrinsics.X86;
using System;
using System.Text.Json;
using One_Supplier_Platform.Services;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace One_Supplier_Platform.Controllers
{
    public class WizardController : BaseController
    {
        private const string SESSION_KEY = "WizardData";

        private static readonly List<WizardStepOption> Steps = new()
        {
            new WizardStepOption { StepIndex = 0, Title = "Apply New Supplier", PartialView = "Supplier/_StepApplyNewSupplier", Locked = false },
            new WizardStepOption { StepIndex = 1, Title = "Supplier Information", PartialView = "Supplier/_StepSupplierInformation" },
            new WizardStepOption { StepIndex = 2, Title = "File List", PartialView = "Supplier/_StepFileList" },
            //new WizardStepOption { StepIndex = 3, Title = "�\�����", PartialView = "_StepTesting" },
            //new WizardStepOption { StepIndex = 4, Title = "���u��I", PartialView = "_StepDelivery" },
        };

        private WizardViewModel GetWizardData()
        {
            var json = HttpContext.Session.GetString(SESSION_KEY);
            return json != null ? JsonSerializer.Deserialize<WizardViewModel>(json)! : new WizardViewModel();
        }

        //private void SaveWizardData(WizardViewModel data)
        //{
        //    HttpContext.Session.SetString(SESSION_KEY, JsonSerializer.Serialize(data));
        //}

        // ����
        public IActionResult Index()
        {
            var wizardData = GetWizardData();
            //  ViewBag.Steps = Steps;
            ViewBag.WizardData = wizardData;
            return View(Steps);
        }

        
         

        //// AutoSave API
        //[HttpPost]
        //public IActionResult AutoSave(int stepIndex, [FromForm] Dictionary<string, string> formData)
        //{
        //    var wizardData = GetWizardData();

        //    // �������: �C����줣�i��
        //    foreach (var kv in formData)
        //    {
        //        if (string.IsNullOrWhiteSpace(kv.Value))
        //            return Json(new { success = false, message = $"��� {kv.Key} ���ର��" });
        //    }

        //    // ��s���
        //    switch (stepIndex)
        //    {
        //        case 0: wizardData.Requirement = formData; break;
        //        case 1: wizardData.Design = formData; break;
        //        case 2: wizardData.Development = formData; break;
        //        case 3: wizardData.Testing = formData; break;
        //        case 4: wizardData.Delivery = formData; break;
        //    }

        //    SaveWizardData(wizardData);

        //    return Json(new { success = true });
        //}

        //// ���ҨB�J�O�_�i�i�U�@�B
        //[HttpPost]
        //public IActionResult ValidateStep(int stepIndex, [FromForm] Dictionary<string, string> formData)
        //{
        //    bool valid = formData.Values.All(v => !string.IsNullOrWhiteSpace(v));
        //    if (!valid)
        //        return Json(new { success = false, message = "�ж�g��Ƥ~��i�U�@�B" });

        //    return AutoSave(stepIndex, formData);
        //}

        //[HttpGet]
        //public JsonResult CheckUsername(string value)
        //{
        //    bool exists = !true;// _db.Users.Any(u => u.UserName == value);
        //    return Json(new { valid = !exists, message = exists ? "�b���w�s�b" : "" });
        //}

        //[HttpPost]
        //public IActionResult SaveSelectedMaker(string code, string name)
        //{
        //    try
        //    {
        //        // �ˬd���
        //        if (string.IsNullOrEmpty(code))
        //        {
        //            return Json(new { success = false, message = "�N�X���ର��" });
        //        }

        //        // �N�襤����Ʀs�J Session (�ݤޥ� Microsoft.AspNetCore.Http)
        //        // �o�˧A�b LoadStep(1) �� PartialView �N�i�HŪ���o�� Session ���
        //        //HttpContext.Session.SetString("SelectedMakerCode", code);
        //        //HttpContext.Session.SetString("SelectedMakerName", name);

        //        // ��^���\���G���e�� JS
        //        return Json(new { success = true });
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(new { success = false, message = ex.Message });
        //    }
        //}


        ////[HttpGet]
        ////public IActionResult GetData(int id)
        ////{
        ////    var data = new List<EmployeeDto>
        ////    {
        ////        new EmployeeDto{ Id=1, Name="Tom", Age=30, Salary=5000 },
        ////        new EmployeeDto{ Id=2, Name="Mary", Age=28, Salary=6200 },
        ////        new EmployeeDto{ Id=3, Name="John", Age=35, Salary=7000 }
        ////    };

        ////    return Json(new { data = data });
        ////}

        //[HttpGet]
        //public async Task<IActionResult> GetSupplierData(string makername, string companyid, string makerlist)
        //{
        //    makername = "MITSUI";
        //    companyid = "2";
        //    if (string.IsNullOrEmpty(makername)) return BadRequest();

        //    SupplierService _supplierService = new SupplierService();
        //    var viewModel = await _supplierService.GetSupplierDetail(makername, companyid, makerlist);

        //    if (viewModel == null)
        //    {
        //        return NotFound(new { message = "�䤣������Ӹ��" });
        //    }

        //    return Json(new { data = viewModel });
        //    //return PartialView("_MakerGrid", viewModel);
        //    // return Json(viewModel); // �^�ǵ��e�� JavaScript 
        //}


    }
}