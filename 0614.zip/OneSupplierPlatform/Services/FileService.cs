﻿using Microsoft.AspNetCore.StaticFiles;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Service;
using OneSupplierPlatform.Utility;


namespace OneSupplierPlatform.Services
{

    public interface IFileService
    {
        Task<string> UploadFileAsync(FlmFileInfo file);

        Task<List<FlmFileInfo>> GetFilesAsync(string itemKey, string formNo);


        Task<FlmFileInfo> GetFileAsync(string fileid);


        Task<bool> DeleteFileAsync(string fileid);
    }



    public class FileService : BaseService, IFileService
    {
        private readonly ITransactionContext _repo;
        private readonly FlowerService _flowerService;
        private readonly OneSupplierFLMService _oneSupplierFLMService;
        public FileService(OneSupplierFLMService oneSupplierFLMService, ITransactionContext repo) : base()
        {
            _repo = repo;

            _oneSupplierFLMService = oneSupplierFLMService;
        }


        public async Task<string> UploadFileAsync(FlmFileInfo file)
        {
            var uploadfileId = string.Empty;
            var bDelete = false;
            var sql = "";
            if (string.IsNullOrEmpty(file.FileId))
            {
                sql = string.Format(@"select fileid from osp_vendor_file_r
                                where  item_id ='{0}' and fileName='{1}' and formno ='{2}' 
                                and Active ='Y'", file.ItemId, file.FileName, file.FormNo);
            }
            else
            {
                sql = string.Format(@"select fileid from osp_vendor_file_r
                                where  fileid ='{0}' and Active ='Y'", file.FileId);
            }
            var fileId = (await _repo.QueryAsync<string>(sql, new { })).ToList().FirstOrDefault();
            if (!string.IsNullOrEmpty(fileId))
            {
                if (await _oneSupplierFLMService.CheckFileIDByFileIdAsync(fileId))
                {
                    bDelete = await _oneSupplierFLMService.DeleteFileFromFileServerAsync(fileId, file.CUser);
                }
                bDelete = true;
            }
            else
            {
                bDelete = true;
            }

            if (!bDelete)
            {
                throw new Exception("刪除檔案失敗");
            }

            var bizID = "vendor" + "_" + file.FormNo + "_" + file.ItemId;

            if (file.File != null && file.File.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await file.File.CopyToAsync(memoryStream);
                    byte[] fileBytes = memoryStream.ToArray();
                    uploadfileId = await _oneSupplierFLMService.UploadFileToFLMAsync(fileBytes, file.FileName, bizID, file.CUser);

                    if (!string.IsNullOrEmpty(uploadfileId))
                    {
                        if (!string.IsNullOrEmpty(fileId))
                        {
                            sql = string.Format(@"update osp_vendor_file_r
                                set FileId ='{3}'
                                where  item_id ='{0}' and fileName='{1}' and formno ='{2}'
                                and Active ='Y'", file.ItemId, file.FileName, file.FormNo, uploadfileId);
                        }
                        else
                        {
                            sql = string.Format(@"insert into osp_vendor_file_r(Headerid,FormNo,item_id,item_name,FileId,FileName,Active,CUser,CDate)
                                                values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',getdate())",

                                                    file.Headerid, file.FormNo, file.ItemId, file.ItemName, uploadfileId, file.FileName, "Y", file.CUser);
                        }
                        //await _repo.ExecuteSqlAsync(sql);
                    }
                    else
                    {
                        uploadfileId = "fail";
                    }
                }
            }
            return uploadfileId;
        }

        //public async Task<List<FlmFileInfo>> GetFilesAsync(string itemKey, string formNo)
        //{
        //    await Task.Delay(100); // 模擬 DB delay

        //    // =========================
        //    // mock data（可依 itemKey / formNo 分流）
        //    // =========================
        //    var data = new List<FlmFileInfo>();

        //    if (itemKey == "A001")
        //    {
        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "1",
        //            FileName = "demo1.png"
        //        });

        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "2",
        //            FileName = "contract.pdf"
        //        });
        //    }
        //    else if (itemKey == "B002")
        //    {
        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "3",
        //            FileName = "report.xlsx"
        //        });
        //    }
        //    else
        //    {
        //        data.Add(new FlmFileInfo
        //        {
        //            ItemId = itemKey,
        //            FileId = "abc",
        //            FileName = "default.txt"
        //        });
        //    }

        //    return data;
        //}
        public async Task<List<FlmFileInfo>> GetFilesAsync(string itemKey, string formNo)
        {
            var sql = string.Format(@"select item_id ItemId,fileid FileId,filename FileName from osp_vendor_file_r 
                                    where  item_id ='{0}'  and formno ='{1}' and FileId <>''
                                    and Active ='Y'", itemKey, formNo);
            var result = await _repo.QueryAsync<FlmFileInfo>(sql);
            return result?.ToList() ?? new List<FlmFileInfo>();
        }

        public async Task<bool> DeleteFileAsync(string fileid)
        {
            var bDelete = false;
            var sql = string.Format(@"select fileid,headerid from osp_vendor_file_r
                                    where  FileId ='{0}'
                                    and Active ='Y'", fileid);
            var fileInfo = (await _repo.QueryAsync<FlmFileInfo>(sql, new { })).ToList().FirstOrDefault();
            if (fileInfo != null)
            {
                if (await _oneSupplierFLMService.CheckFileIDByFileIdAsync(fileInfo.FileId))
                {
                    bDelete = await _oneSupplierFLMService.DeleteFileFromFileServerAsync(fileInfo.FileId, fileInfo.CUser);
                }
                bDelete = true;
            }
            else
            {
                bDelete = true;
            }
            if (!bDelete)
            {
                throw new Exception("刪除檔案失敗");
            }
            sql = string.Format(@"delete osp_vendor_file_r where FileId ='{0}'", fileInfo.FileId);
            // var deleteFile = await _repo.ExecuteAsync(sql);
            sql = string.Format(@"update osp_vendor_header_r set upload_ssaaf ='' where headerid ='{0}'", fileInfo.Headerid);

            return true;// await _repo.ExecuteAsync(sql);
        }

        public async Task<FlmFileInfo> GetFileAsync(string fileid)
        {
            FlmFileInfo file = new FlmFileInfo();

            var sql = string.Format(@"select item_id ItemId
                    ,FormNo FormNo
                    ,item_name ItemName
                    ,fileid FileId
                    ,filename FileName from osp_vendor_file_r 
                where FileId ='{0}'  
                and Active ='Y'", fileid);
            var result = await _repo.QueryAsync<FlmFileInfo>(sql);


            if (result?.ToList().FirstOrDefault() != null)
            {
                file = result?.ToList().FirstOrDefault();
                var filename = result?.ToList().FirstOrDefault().FileName;
                var empno = result?.ToList().FirstOrDefault().CUser;
                file.bytes = await _oneSupplierFLMService.GetFileAsync(fileid, filename, empno);
                file.Mime = GetMimeType(filename);
            }

            //var bytes = await File.ReadAllBytesAsync(@"C:\Users\Honjay\Pictures\下載.png");

            //var fileName = Path.GetFileName(@"C:\Users\Honjay\Pictures\下載.png");
            //file.bytes = bytes;
            //file.Mime = GetMimeType(fileName);
            //file.FileName = fileName;
            return file;
        }

        private string GetMimeType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(fileName, out string contentType))
            {
                contentType = "application/octet-stream";
            }
            return contentType;
        }
    }


}
