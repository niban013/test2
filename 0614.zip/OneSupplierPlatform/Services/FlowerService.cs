﻿using Com.Auo.Flower;
using OneSupplierPlatform.Infrastructure;

namespace OneSupplierPlatform.Services
{
    public class FlowerService : BaseService
    {

        public static string FormKind => AppFinder.GetService<IConfiguration>().GetValue<string>("FlowerSettings:BPMFORMKIND");
        public static string Company => AppFinder.GetService<IConfiguration>().GetValue<string>("FlowerSettings:COMPANYCODE");
        FlowERUtil FlowERUtil;
        public FlowerService() : base()
        {
            FlowERUtil = new FlowERUtil(Company);
        }

        //private string GetEmpIDByEmpNo(string empNo)
        //{
        //    if (empNo.IndexOf('-') > -1)
        //    {
        //        return empNo;
        //    }

        //    string? text = ConfigurationSettings.AppSettings["COMPANYCODE"];
        //    if (string.IsNullOrEmpty(text))
        //    {
        //        throw new Exception("COMPANYCODE have not setting in web.config.");
        //    }

        //    return text.Trim() + "-" + empNo;
        //}
        //public static string GetMethod(string url)
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
        //    HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
        //    httpWebRequest.Method = "GET";
        //    httpWebRequest.Headers.Add("formKind", FormKind);
        //    httpWebRequest.Headers.Add("securityCode", SecrtyCode);
        //    HttpWebResponse httpWebResponse;
        //    try
        //    {
        //        httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
        //    }
        //    catch (Exception ex)
        //    {
        //        return ex.Message + url + FormKind + SecrtyCode;
        //    }

        //    Stream responseStream = httpWebResponse.GetResponseStream();
        //    StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);
        //    string result = streamReader.ReadToEnd();
        //    streamReader.Close();
        //    responseStream.Close();
        //    return result;
        //}
        //public static string SecrtyCode = ConfigurationSettings.AppSettings["BPMSECRTYCODE"].Trim();
        //public string APIUrl = System.Configuration.ConfigurationManager.AppSettings["BPMAPIURL"];
        //public int CreateNewForm(string p_strFormKind, string p_strFiller)
        //{
        //    string text = "";
        //    try
        //    {
        //        p_strFiller = GetEmpIDByEmpNo(p_strFiller);
        //        text = GetMethod(APIUrl + "/Form/CreateNewForm?formKind=" + p_strFormKind + "&filler=" + p_strFiller);
        //        return JsonConvert.DeserializeObject<ActionReturnGeneralModel>(text).formNo;
        //    }
        //    catch
        //    {
        //        throw new Exception(text);
        //    }
        //}

        public int GetFormNo()
        {
            return FlowERUtil.CreateNewForm(FormKind, "1204636");
        }

    }
}
