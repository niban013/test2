﻿ 
using System.Text.Json;
using OneSupplierPlatform.Models;

namespace OneSupplierPlatform.Services
{
    public class CapAuthService
    {
        private readonly HttpClient _http;
        private readonly IConfiguration _config;

        public CapAuthService(HttpClient http, IConfiguration config)
        {
            _config = config;
            _http = http;
        }

        // 取得 User 資訊
        public async Task<CapUser?> GetUserInfoAsync(string token)
        {
            var ApiUrl = _config["CapAuth:ApiUrl"];
            var url =
                $"{ApiUrl}/GetUserInfoByToken?authToken={token}";

            var response = await _http.GetAsync(url);

            // ⭐ 關鍵：401 / 403 直接當作失效
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized ||
                response.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                return null;
            }

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var json = await response.Content.ReadAsStringAsync();

            if (string.IsNullOrWhiteSpace(json))
                return null;

            // ⭐ 有些 CAP 會回 error JSON
            if (json.Contains("invalid", StringComparison.OrdinalIgnoreCase))
                return null;

            return JsonSerializer.Deserialize<CapUser>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
        }

        // 功能權限
        public async Task<bool> CheckAuthAsync(
            string token,
            string company,
            string sysId,
            string func)
        {
            var ApiUrl = _config["CapAuth:ApiUrl"];
            var url =
                $"{ApiUrl}/CheckAuth" +
                $"?authToken={token}" +
                $"&company={company}" +
                $"&sysId={sysId}" +
                $"&func={func}";

            var response = await _http.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return false;

            var result =
                await response.Content.ReadAsStringAsync();

            return result.Contains(
                "true",
                StringComparison.OrdinalIgnoreCase);
        }
    }
}
