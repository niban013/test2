namespace OneSupplierPlatform.Models.Infra
{
    public class MenuItemViewModel
    {
        public int NodeId { get; set; }
        public int ParentId { get; set; }
        public string ItemText { get; set; } = "Home";
        public string ItemLink { get; set; } = "Home";
        public string ItemTarget { get; set; } = "_self";
        public string PageClass { get; set; }
        public List<MenuItemViewModel> Children { get; set; } = new();
    }
}