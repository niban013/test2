﻿namespace OneSupplierPlatform.Models
{ 
    public class SharedResource
    {
    }
}
