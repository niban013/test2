﻿namespace OneSupplierPlatform.Models
{
    public class CapUser
    {
        public string UserId { get;set; }
        public string RealName { get; set; }
        public string EmployeeId { get;set; }
        public string DepartmentId { get;set; }
        public string Email { get;set; }
        public int BossLevel { get; set; }
        public string CompanyName { get; set; }
        public string Site { get; set; }
    }
}



 