﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NLog;
using NLog.Web;
using OneSupplierPlatform.Configuration;
using OneSupplierPlatform.Filter;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Helper.Localizer;
using OneSupplierPlatform.Helpers;
using OneSupplierPlatform.i18n;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Services;
using OneSupplierPlatform.Utility;
using OneSupplierPlatform.Workflow;
using OneSupplierService;
using System.Collections.Concurrent;
using System.Globalization;
using System.ServiceModel;
using static OneSupplierPlatform.Utility.ApiHelper;


var logger = LogManager.Setup().LoadConfigurationFromAppSettings().GetCurrentClassLogger();
logger.Debug("init main");

try
{
    var builder = WebApplication.CreateBuilder(args);
    DapperAutoJsonPropertyMapper.WatchAndRegisterAllModels();
    builder.Services.AddAutoMapper(config => { }, typeof(Program).Assembly);
    builder.Logging.ClearProviders();
    builder.Host.UseNLog();
    builder.Services.AddWebOptimizer(pipeline =>
    {
#if DEBUG
        // DEBUG 模式：僅壓縮個別檔案，不合併成一包 (方便你在 F12 看到獨立檔案)
        //pipeline.MinifyJsFiles("lib/jquery/dist/jquery.min.js");
        //pipeline.MinifyJsFiles("js/**/*.js");
        //pipeline.MinifyCssFiles("css/**/*.css");
#else
         // RELEASE 模式：執行打包與合併
            // --- JS 部分 ---
            pipeline.AddJavaScriptBundle("/dist/jquery-bundle.js", "lib/jquery/dist/jquery.min.js").MinifyJavaScript();

            // 2. Bootstrap (排除目錄下的 .min.js，讓 WebOptimizer 幫你壓)
            pipeline.AddJavaScriptBundle("/dist/bootstrap-bundle.js", "js/bootstrap/**/*.js").MinifyJavaScript();

            // 3. DataTables (嚴格順序)
            pipeline.AddJavaScriptBundle("/dist/dts-bundle.js",
                "js/dts/dataTables.min.js",                 // 這是原始檔，WebOptimizer 會幫你壓
                "js/dts/dataTables.bootstrap5.min.js",   // 以下皆為 .min，WebOptimizer 會直接合併不重複壓
                "js/dts/dataTables.buttons.min.js",
                "js/dts/dataTables.responsive.min.js",
                "js/dts/responsive.bootstrap5.min.js",
                "js/dts/dataTables.colReorder.min.js"
            ).MinifyJavaScript(); // 確保這行有加，它會處理混合檔案的壓縮邏輯

            // 4. 其他
            pipeline.AddJavaScriptBundle("/dist/select2-bundle.js", "js/select2/**/*.js").MinifyJavaScript();
            pipeline.AddJavaScriptBundle("/dist/sweetalert2-bundle.js", "js/sweetalert2/**/*.js").MinifyJavaScript();
            
            //以下有順序，不能亂調
            pipeline.AddJavaScriptBundle("/dist/auo-bundle.js",
                "js/auo/site.js",
                "js/auo/StepLoader.js",
                "js/auo/ValidationCenter.js",
                "js/auo/upload.js",
                "js/auo/AppController.js",   
                "js/auo/AppBootstrap.js", 
                "js/auo/DynamicTablePro.js"
            ).MinifyJavaScript();
             
            //// --- CSS 部分 ---
            //// 依樣畫葫蘆，按目錄拆分 CSS 
            pipeline.AddCssBundle("/dist/bootstrap-bundle.css", "css/bootstrap/**/*.css").MinifyCss();
            pipeline.AddCssBundle("/dist/dts-bundle.css", "css/dts/**/*.css").MinifyCss();
            pipeline.AddCssBundle("/dist/select2-bundle.css", "css/select2/**/*.css").MinifyCss();
            pipeline.AddCssBundle("/dist/sweetalert2-bundle.css", "css/sweetalert2/**/*.css").MinifyCss();
            pipeline.AddCssBundle("/dist/auo-bundle.css", "css/auo/**/*.css").MinifyCss();
#endif
    });



    var langCache = new ConcurrentDictionary<string, string>();
    var langPath = Path.Combine(Directory.GetCurrentDirectory(), "i18n", "Lang");
    foreach (var file in Directory.GetFiles(langPath, "*.json"))
    {
        var culture = Path.GetFileNameWithoutExtension(file); // zh-TW / en-US
        var content = File.ReadAllText(file);
        langCache[culture] = content;
    }

    // DI
    builder.Services.AddSingleton(langCache);

    builder.Services.AddLocalization();
    builder.Services.AddScoped<LocalizedKeys>();
    // 啟用 Session
    builder.Services.AddDistributedMemoryCache();
    builder.Services.AddSession(options =>
    {
        options.IdleTimeout = TimeSpan.FromMinutes(30); // Session 30 分鐘沒動作就過期
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
    });

    builder.Services.AddControllersWithViews(options =>
    {
        //options.Filters.Add<CapAuthorizeAttribute>();
        //將全域過濾器加入集合
        options.Filters.Add<GlobalExceptionFilter>();
        //options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
    }).AddNewtonsoftJson(options =>
    {
        // 這行很關鍵：確保 JSON 輸出名稱與 [JsonProperty] 定義完全一致
        // 而不會被自動轉成小駝峰 (CamelCase)
        options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();

    }).AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true; // 忽略大小寫
    });

    // 1. 從設定檔取得連線字串
    var connectionString = builder.Configuration.GetConnectionString("AMSC-SQLDB");


    //builder.Services.AddScoped<SQLDBHelper>();
    builder.Services.Configure<AppOptions>(
    builder.Configuration);

    // 註冊 WCF Client
    builder.Services.AddScoped<OneSupplierFLM.FLMService>(sp =>
    {
        // 取得設定檔介面
        var config = sp.GetRequiredService<IConfiguration>();
        var flmSection = config.GetSection("FLMConfig");

        // 1. 讀取 Binding 數值 (從 appsettings.json)
        var timeout = TimeSpan.FromMinutes(flmSection.GetValue<int>("TimeoutMinutes", 10));
        var maxBuffer = flmSection.GetValue<long>("MaxBufferSize", 2147483647);

        var binding = new WS2007HttpBinding(SecurityMode.TransportWithMessageCredential)
        {
            OpenTimeout = timeout,
            CloseTimeout = timeout,
            ReceiveTimeout = timeout,
            SendTimeout = timeout,
            MaxReceivedMessageSize = maxBuffer,
            MaxBufferPoolSize = maxBuffer,
            UseDefaultWebProxy = true
        };

        binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
        binding.Security.Message.ClientCredentialType = MessageCredentialType.UserName;

        // 2. 建立 Client (URL 從設定檔讀取)
        var endpoint = new EndpointAddress(flmSection["Url"]);
        var client = new OneSupplierFLM.FLMServiceClient(binding, endpoint);

        // 3. 注入帳號密碼 (會自動從環境變數或 JSON 覆蓋)
        // 注意：階層式讀取建議使用 config["FLMConfig:Security:Password"]
        client.ClientCredentials.UserName.UserName = config["FLMConfig:Security:UserName"];
        client.ClientCredentials.UserName.Password = config["FLMConfig:Security:Password"];

        return client;
    });



    builder.Services.AddScoped<OneSupplierPlatformServiceSoapClient>(sp =>
    {
        var config = sp.GetRequiredService<IConfiguration>();
        var url = config["ExternalServices:AsmxUrl"];

        var client = new OneSupplierPlatformServiceSoapClient(
            OneSupplierPlatformServiceSoapClient.EndpointConfiguration.OneSupplierPlatformServiceSoap,
            new EndpointAddress(url)
        );

        // 如果是 HTTPS，有時需要忽略憑證錯誤（測試環境用）
        // client.ClientCredentials.ServiceCertificate.SslCertificateAuthentication = ...

        return client;
    });
    //builder.Services.AddScoped<ITransactionContext, GenericRepository>();
    //builder.Services.AddScoped<GenericRepository>();
    //builder.Services.AddScoped<TransactionExecutor>();
    //builder.Services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();

    //builder.Services.AddScoped<GenericRepository>();
    //builder.Services.AddScoped<ITransactionContext>(sp => sp.GetRequiredService<GenericRepository>());
    //builder.Services.AddScoped<TransactionExecutor>();

    builder.Services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();

    // Transaction + Repository 合一
    builder.Services.AddScoped<GenericRepository>();

    // 讓 ITransactionContext 指向同一個 instance
    builder.Services.AddScoped<ITransactionContext>(sp =>
        sp.GetRequiredService<GenericRepository>());

    //builder.Services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
    ////builder.Services.AddScoped<IGenericRepository, GenericRepository>();
    //builder.Services.AddScoped<TransactionExecutor>();
    //builder.Services.AddScoped<GenericRepository>();
    // 3. 註冊你的 SupplierService 介面與實作
    //builder.Services.AddScoped<ISupplierService, SupplierService>();
    //builder.Services.Scan(scan => scan
    //.FromAssemblyOf<Program>()
    //.AddClasses(classes => classes.Where(type => type.Name.EndsWith("Service") && !type.IsAbstract))
    //.AsImplementedInterfaces() // 有介面的對應介面
    //.AsSelf()                  // 沒介面（或需要直接用類別）的也幫我註冊一份
    //.WithScopedLifetime());
    builder.Services.Scan(scan => scan
    .FromAssemblyOf<Program>()

    // =========================
    // Service
    // =========================
    .AddClasses(classes =>
        classes.Where(type =>
            type.Name.EndsWith("Service") &&
            !type.IsAbstract))
    .AsImplementedInterfaces()
    .AsSelf()
    .WithScopedLifetime()

    // =========================
    // Workflow
    // =========================
    .AddClasses(classes =>
        classes.Where(type =>
            type.Name.EndsWith("Workflow") &&
            !type.IsAbstract &&
            !type.IsInterface))
    .AsSelf()
    .WithScopedLifetime()
);
    builder.Services.AddHttpClient<CapAuthService>();

    builder.Services
        .AddAuthentication(
            CookieAuthenticationDefaults.AuthenticationScheme)
        .AddCookie(options =>
        {
            options.Cookie.Name = "APP_AUTH";

            options.AccessDeniedPath = "/Auth/Denied";

            options.ExpireTimeSpan = TimeSpan.FromHours(8);

            options.SlidingExpiration = true;

            // SSO 很重要
            options.Cookie.HttpOnly = true;

            options.Cookie.SameSite = SameSiteMode.Lax;

            options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;

            // 不讓 ASP.NET 自己跳 LoginPath
            options.Events.OnRedirectToLogin =
                context =>
                {
                    context.Response.StatusCode = 401;
                    return Task.CompletedTask;
                };
        });


    builder.Services.AddAuthorization();

    builder.Services.AddHttpContextAccessor();


    //builder.Services.AddScoped<OrderService>();

    builder.Services.AddSingleton<WorkflowDispatcher>();

    var app = builder.Build();
    AppConfig.Value = app.Services
    .GetRequiredService<IOptions<AppOptions>>()
    .Value;

    var dispatcher = app.Services.GetRequiredService<WorkflowDispatcher>();

    dispatcher.Scan(typeof(Program).Assembly);


    var appSettings = app.Configuration.GetSection("FlowerSettings").GetChildren();

    // 2. 動態寫入 ConfigurationManager 記憶體
    foreach (var setting in appSettings)
    {
        if (setting.Key != null)
        {
            System.Configuration.ConfigurationManager.AppSettings.Set(setting.Key, setting.Value);
        }
    }


    app.UsePathBase("/OneSupplierPlatform");
#if DEBUG
    app.UseDeveloperExceptionPage(); // 讓開發時直接看到詳細報錯
#else
        app.UseExceptionHandler("/Error/Index"); // 正式環境導向錯誤頁
#endif
    //if (app.Environment.IsDevelopment())
    //{
    //    app.UseDeveloperExceptionPage(); // 讓開發時直接看到詳細報錯
    //}
    //else
    //{
    //    app.UseExceptionHandler("/Error/Index"); // 正式環境導向錯誤頁
    //} 

    // 2. 啟用中介軟體 (必須放在 UseStaticFiles 之前)
    app.UseWebOptimizer();
    app.UseStaticFiles();
    app.UseCookiePolicy();


    var supportedCultures = new[]
    {
        new CultureInfo("zh-TW"),
        new CultureInfo("en-US")
    };

    var localizationOptions = new RequestLocalizationOptions
    {
        DefaultRequestCulture = new RequestCulture("zh-US"), //預設英文
        SupportedCultures = supportedCultures,
        SupportedUICultures = supportedCultures
    };

    // 可加上 QueryStringProvider 支援 ?culture=en-US
    localizationOptions.RequestCultureProviders = new List<IRequestCultureProvider>
    {
        new CookieRequestCultureProvider(),        // 優先讀 Cookie
        new QueryStringRequestCultureProvider()    // 次要：支援 ?culture=xx
    };

    app.UseRequestLocalization(localizationOptions);


    app.UseRouting();

    app.UseMiddleware<I18nMiddleware>();

    app.UseSession(); // 一定要在 UseRouting 後

    app.UseAuthentication();

    app.UseMiddleware<CapMiddleware>();

    app.UseAuthorization();

    app.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");

    AppFinder.ServiceProvider = app.Services;

    app.Run();
}
catch (Exception exception)
{
    // 捕捉啟動時的異常
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    // 確保在應用程式結束前關閉 NLog，清空快取
    LogManager.Shutdown();
}
