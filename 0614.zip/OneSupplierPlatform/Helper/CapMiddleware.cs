﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Services;
using System.Security.Claims;

namespace OneSupplierPlatform.Helpers
{
    public class CapMiddleware
    {
        private readonly RequestDelegate _next;

        private readonly IConfiguration _config;

        public CapMiddleware(RequestDelegate next, IConfiguration config)
        {
            _next = next;
            _config = config;
        }

        public async Task InvokeAsync(HttpContext context, CapAuthService capService)
        {
            var enabled = _config.GetValue<bool>("CapAuth:Enabled");

            if (!enabled)
            {
                await _next(context);
                return;
            }
            var cookieName = _config["CapAuth:CookieName"];
            var path = context.Request.Path.Value?.ToLower() ?? "";

            // 排除靜態資源
            if (
                path.StartsWith("/css") ||
                path.StartsWith("/js") ||
                path.StartsWith("/lib") ||
                path.StartsWith("/images") ||
                path.StartsWith("/favicon")
            )
            {
                await _next(context);
                return;
            }

            // 排除 Auth
            if (path.StartsWith("/auth"))
            {
                await _next(context);
                return;
            }

            // 已登入 ASP.NET
            if (context.User.Identity?.IsAuthenticated == true)
            {
                await _next(context);
                return;
            }
            var retry = context.Request.Cookies["CAP_RETRY"];

            if (retry == "1")
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("SSO failed (loop blocked)");
                return;
            }
            // 取得 CAP Cookie
            var token = context.Request.Cookies[cookieName];

            // 沒 CAP Token
            if (string.IsNullOrWhiteSpace(token))
            {
                RedirectToCap(context);
                return;
            }

            // 驗證 CAP Token
            var user = await capService.GetUserInfoAsync(token);

            // CAP 驗證失敗
            if (user == null)
            {
                // ⭐ 清掉壞 token
                context.Response.Cookies.Delete(cookieName);

                RedirectToCap(context);
                return;
            }

            // 建立 Claims
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier,user.UserId ?? ""),
                new Claim(ClaimTypes.Name,user.RealName ?? ""),
                new Claim("EmployeeId",user.EmployeeId ?? ""),
                new Claim(ClaimTypes.Email,user.Email ?? ""),
                new Claim("DepartmentId", user.DepartmentId ?? ""),
                new Claim("BossLevel", user.BossLevel.ToString() ?? ""),
                new Claim("CompanyName", user.CompanyName ?? ""),
                new Claim("Site", user.Site ?? ""),
                new Claim("Photo",ExtendTool.GetUserPhotoUrl(user?.EmployeeId))
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            var principal = new ClaimsPrincipal(identity);

            // ASP.NET 登入
            await context.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
            context.User = principal;
            context.Response.Cookies.Delete("CAP_RETRY");

            await _next(context);
        }

        private void RedirectToCap(HttpContext context)
        {
            var LoginUrl = _config["CapAuth:LoginUrl"];
            var returnUrl =
                $"{context.Request.Scheme}://" +
                $"{context.Request.Host}" +
                $"{context.Request.Path}" +
                $"{context.Request.QueryString}";

            var appPath =
                $"{context.Request.Scheme}://" +
                $"{context.Request.Host}";

            context.Response.Cookies.Append(
            "CAP_RETRY",
            "1",
            new CookieOptions
            {
                Expires = DateTimeOffset.UtcNow.AddMinutes(5),
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Lax
            });
            var url =
                $"{LoginUrl}" +
                $"?ReturnUrl={Uri.EscapeDataString(returnUrl)}" +
                $"&AppPath={Uri.EscapeDataString(appPath)}";

            context.Response.Redirect(url);
        }
    }
}
