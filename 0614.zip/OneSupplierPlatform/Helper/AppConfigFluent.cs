﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text.Json;

namespace OneSupplierPlatform.Helper
{
    // =========================
    // Fluent Builder
    // =========================
    public class AppConfigBuilder
    {
        internal Dictionary<string, SectionRule> Sections { get; } = new();

        public SectionBuilder Section(string name)
        {
            var rule = new SectionRule();
            Sections[name] = rule;
            return new SectionBuilder(this, rule);
        }
    }

    public class SectionRule
    {
        public bool IncludeAll { get; set; }
        public HashSet<string> IncludeKeys { get; set; } = new();
        public HashSet<string> ExcludeKeys { get; set; } = new();
    }

    public class SectionBuilder
    {
        private readonly AppConfigBuilder _parent;
        private readonly SectionRule _rule;

        public SectionBuilder(AppConfigBuilder parent, SectionRule rule)
        {
            _parent = parent;
            _rule = rule;
        }

        public AppConfigBuilder All()
        {
            _rule.IncludeAll = true;
            return _parent;
        }

        public AppConfigBuilder Only(params string[] keys)
        {
            _rule.IncludeKeys = keys.ToHashSet();
            return _parent;
        }

        public AppConfigBuilder Exclude(params string[] keys)
        {
            _rule.ExcludeKeys = keys.ToHashSet();
            return _parent;
        }
    }

    // =========================
    // Razor Helper
    // =========================
    public static class AppConfigExtensions
    {
        public static IHtmlContent AppConfig(
            this IHtmlHelper html,
            Action<AppConfigBuilder> build)
        {
            var config = html.ViewContext.HttpContext.RequestServices
                .GetRequiredService<IConfiguration>();

            var builder = new AppConfigBuilder();
            build(builder);

            var result = new Dictionary<string, object?>();

            foreach (var section in builder.Sections)
            {
                var sectionName = section.Key;
                var rule = section.Value;

                var configSection = config.GetSection(sectionName);

                if (!configSection.Exists())
                    continue;

                result[sectionName] = Bind(configSection, rule);
            }

            var json = JsonSerializer.Serialize(result);

            return new HtmlString($@"
<script>
(function () {{

    const rawConfig = {json};

    function createSafeProxy(target) {{
        if (target === null || typeof target !== 'object') {{
            return target;
        }}

        return new Proxy(target, {{
            get(obj, prop) {{

                const value = obj[prop];

                if (value === undefined) {{
                    return undefined;
                }}

                if (value !== null && typeof value === 'object') {{
                    return createSafeProxy(value);
                }}

                return value;
            }}
        }});
    }}

    window.Config = createSafeProxy(rawConfig || {{}});

    console.log('Config loaded:', window.Config);

}})();
</script>");
        }

        // =========================
        // Bind Engine
        // =========================
        private static object Bind(
            IConfigurationSection section,
            SectionRule rule)
        {
            var children = section.GetChildren().ToList();

            if (!children.Any())
                return section.Value;

            var dict = new Dictionary<string, object?>();

            foreach (var child in children)
            {
                if (rule.ExcludeKeys.Contains(child.Key))
                    continue;

                if (!rule.IncludeAll &&
                    rule.IncludeKeys.Count > 0 &&
                    !rule.IncludeKeys.Contains(child.Key))
                {
                    continue;
                }

                dict[child.Key] = Bind(child, rule);
            }

            return dict;
        }
    }
}
