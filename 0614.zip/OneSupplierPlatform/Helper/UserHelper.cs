﻿using AUO.Common.Authentication;

namespace OneSupplierPlatform.Helper
{
    using System;
    using System.IO;
    using System.Text;
    using System.Security.Cryptography;
    using Microsoft.AspNetCore.Http;
    using AUO.Common.Authentication; // 依然引入舊組件以調用 FormsAuthTicketData 建構子

    public sealed class UserHelper
    {
        private static IHttpContextAccessor _httpContextAccessor;

        public static void Configure(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        private UserHelper() { }

        public static CAPUser CurrentUser
        {
            get
            {
                if (_httpContextAccessor == null) return null;
                var context = _httpContextAccessor.HttpContext;
                if (context == null) return null;

                // 快取機制：避免重複解析
                if (context.Items["CAP_USER_OBJECT"] is CAPUser cachedUser)
                    return cachedUser;

                var user = InitCAPUser(context);
                if (user != null) context.Items["CAP_USER_OBJECT"] = user;
                return user;
            }
        }

        private static CAPUser InitCAPUser(HttpContext context)
        {
            try
            {
                // 1. 抓取您的 AUO CAP 加密 Cookie Hex 字串
                string authCookieHex = context.Request.Cookies[".AUOCAPFORMSAUTHTEST"];
                if (string.IsNullOrEmpty(authCookieHex)) return null;

                // 2. 將 Hex 字串轉換為 Byte 陣列
                byte[] cipherTextWithMac = HexStringToByteArray(authCookieHex);

                // 填入您剛才提供、已成功驗證的 HMACSHA256 金鑰
                string aesDecryptionKeyHex = "E1FDB8B9E40089BE73B7D739A707CE7DFE0B8BC0B99A54A5093AE99A9254C312";
                string hmacValidationKeyHex = "6B0D17CEBBC0B52F655F83EF7F51BF32AB8527B5C568CA64260FC8E77DA09CCD";

                byte[] decryptionKey = HexStringToByteArray(aesDecryptionKeyHex);
                byte[] validationKey = HexStringToByteArray(hmacValidationKeyHex);

                // 3. 執行 AES 解密（此時已可順利拿到解密後的 Byte）
                byte[] decryptedBytes = DecryptAesFramework(cipherTextWithMac, decryptionKey, validationKey);

                if (decryptedBytes != null)
                {
                    // 🔥【關鍵修正】：完全不使用 BinaryReader.ReadString() 防止長度錯位引發 FormatException！
                    // 舊版微軟 Ticket 內部不論包了什麼二進位標頭，其文字部分依然是純粹的 UTF-8 或 Unicode 字串。
                    // 我們直接將整塊明文 Byte 陣列硬轉成字串，直接在裡面肉眼搜尋工號與資料！
                    string plainTextRaw = Encoding.UTF8.GetString(decryptedBytes);

                    // 💡【除錯觀察點】：請在這裡下中斷點，看看 plainTextRaw 裡面顯示了什麼。
                    // 因為微軟前幾個 Byte 是時間戳記，畫面最前排可能會有一些亂碼（控制字元），
                    // 但是往後看，您一定會看到非常清晰的「明文工號、姓名、部門（通常用 | 或 , 隔開）」出現在字串後半段！
                    System.Diagnostics.Debug.WriteLine($"成功硬解出明文內容: {plainTextRaw}");

                    // 4. 自動清洗多餘的二進位控制字元 (清除 0x00 到 0x1F 的不可見亂碼，只留下乾淨文字)
                    StringBuilder sb = new StringBuilder();
                    foreach (char c in plainTextRaw)
                    {
                        if (c >= 32 || c == '|' || c == ',' || c == ';') sb.Append(c);
                    }
                    string cleanText = sb.ToString();

                    // 5. 🛠️ 智能識別與對接：
                    // 傳統 AUO CAP 元件的 UserData 通常格式會長得像這樣： "1234567|王小明|IT_DEPT|test@auo.com"
                    // 我們直接對乾淨的字串進行切塊分析
                    if (!string.IsNullOrEmpty(cleanText))
                    {
                        // 尋找您舊系統最常用的分隔符號，假設是 |
                        int firstPipe = cleanText.IndexOf('|');
                        if (firstPipe != -1)
                        {
                            // 往前跟往後切出有意義的明文區段
                            string userName = cleanText.Substring(0, firstPipe).Trim();
                            string userData = cleanText.Substring(firstPipe).Trim();

                            // 直接丟給影子相容類別，大功告成！
                            return new CAPUser(userName, userData);
                        }
                        else
                        {
                            // 萬一裡面沒有 | 符號，代表它可能是一整串直接連在一起的工號或帳號
                            // 我們移除最前方的少數不可見亂碼後，直接將其當作 UserId 與 RealName
                            string fallbackUser = cleanText.Trim();
                            return new CAPUser(fallbackUser, fallbackUser);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($".NET 8 原生解密失敗: {ex.Message}");
            }
            return null;
        }
        private static byte[] DecryptAesFramework(byte[] cipherTextWithMac, byte[] decryptionKey, byte[] validationKey)
        {
            // 💡【終極正確答案】：當 Web.config 自訂了 <forms name="..." path="..." /> 時，
            // 微軟 SP800-108 演算法的兩個 Purpose 標籤強制固定為以下格式：
            // 第一個標籤格式為："FormsAuthentication:Cookie名稱"
            // 第二個標籤格式為："FormsAuthentication:Cookie路徑"

            string[] purposes = new string[]
            {
        "FormsAuthentication:.AUOCAPFORMSAUTHTEST", // 👈 完美咬合您的 name 屬性
        "FormsAuthentication:/"                    // 👈 完美咬合您的 path 屬性
            };

            // ===================================================================
            // 🔥 後續的 SP800-108 衍生運算與指針位移解析完全保持不變 
            // ===================================================================
            byte[] derivedValidationKey = DeriveKeyKeyDerivationFunction(validationKey, "FormsAuthentication ticket", purposes);
            byte[] derivedDecryptionKey = DeriveKeyKeyDerivationFunction(decryptionKey, "FormsAuthentication ticket", purposes);

            int macLength = 32;
            int cipherTextWithIvLength = cipherTextWithMac.Length - macLength;
            if (cipherTextWithIvLength <= 0) return null;

            byte[] cipherTextWithIv = new byte[cipherTextWithIvLength];
            byte[] expectedMac = new byte[macLength];
            Buffer.BlockCopy(cipherTextWithMac, 0, cipherTextWithIv, 0, cipherTextWithIvLength);
            Buffer.BlockCopy(cipherTextWithMac, cipherTextWithIvLength, expectedMac, 0, macLength);

            using (var hmac = new HMACSHA256(derivedValidationKey))
            {
                byte[] computedMac = hmac.ComputeHash(cipherTextWithIv);
                for (int i = 0; i < macLength; i++)
                {
                    if (computedMac[i] != expectedMac[i])
                        throw new CryptographicException("CAP 金鑰不符，無法順利解碼！");
                }
            }

            using (Aes aes = Aes.Create())
            {
                aes.Key = derivedDecryptionKey;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                int ivLength = 16;
                byte[] iv = new byte[ivLength];
                byte[] realCipherText = new byte[cipherTextWithIvLength - ivLength];
                Buffer.BlockCopy(cipherTextWithIv, 0, iv, 0, ivLength);
                Buffer.BlockCopy(cipherTextWithIv, ivLength, realCipherText, 0, realCipherText.Length);
                aes.IV = iv;

                using (var decryptor = aes.CreateDecryptor())
                {
                    return decryptor.TransformFinalBlock(realCipherText, 0, realCipherText.Length);
                }
            }
        }

        private static byte[] DeriveKeyKeyDerivationFunction(byte[] key, string label, string[] purposes)
        {
            using (var hmac = new HMACSHA256(key))
            {
                // 建立微軟標準的 Context 資料流
                using (var ms = new MemoryStream())
                {
                    using (var writer = new BinaryWriter(ms, Encoding.UTF8))
                    {
                        // 依序寫入 Purposes 標籤資料
                        foreach (string purpose in purposes)
                        {
                            writer.Write(purpose);
                        }
                        writer.Flush();

                        byte[] labelBytes = Encoding.UTF8.GetBytes(label);
                        byte[] contextBytes = ms.ToArray();

                        // 構造 SP800-108 計數器模式緩衝區 [隨機因子]
                        // 結構：[counter (4 bytes)] + [label] + [0x00 (1 byte)] + [context] + [keyLengthBits (4 bytes)]
                        byte[] buffer = new byte[4 + labelBytes.Length + 1 + contextBytes.Length + 4];

                        // 填入計數器 (1)
                        buffer[3] = 1;

                        // 填入 Label
                        Buffer.BlockCopy(labelBytes, 0, buffer, 4, labelBytes.Length);

                        // 填入分隔符 0x00 位組 (buffer[4 + labelBytes.Length] 預設即為 0)

                        // 填入 Context
                        Buffer.BlockCopy(contextBytes, 0, buffer, 4 + labelBytes.Length + 1, contextBytes.Length);

                        // 填入預期輸出的金鑰長度 bits (256 bits = 32 bytes * 8)
                        int keyLengthBits = key.Length * 8;
                        buffer[buffer.Length - 4] = (byte)((keyLengthBits >> 24) & 0xFF);
                        buffer[buffer.Length - 3] = (byte)((keyLengthBits >> 16) & 0xFF);
                        buffer[buffer.Length - 2] = (byte)((keyLengthBits >> 8) & 0xFF);
                        buffer[buffer.Length - 1] = (byte)(keyLengthBits & 0xFF);

                        // 計算得出最終用來解密/簽章的實體衍生金鑰
                        return hmac.ComputeHash(buffer);
                    }
                }
            }
        }
        private static byte[] HexStringToByteArray(string hex)
        {
            int numberChars = hex.Length;
            byte[] bytes = new byte[numberChars / 2];
            for (int i = 0; i < numberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }

    }

    /// <summary>
    /// 💡 終極影子相容類別
    /// 保留舊有所有成員，讓您前端 .cshtml 的 @UserHelper.CurrentUser.RealName 完全不需要更動！
    /// </summary>
    public class CAPUser
    {
        public string UserId { get; private set; }
        public string RealName { get; private set; }
        public string EmployeeId { get; private set; }
        public string DepartmentId { get; private set; }
        public string Email { get; private set; }
        public int BossLevel { get; private set; }
        public string CompanyName { get; private set; }
        public string Site { get; private set; }

        public CAPUser(string userName, string userData)
        {
            this.UserId = userName;

            // 💡 傳統 ASP.NET FormsAuthentication 封裝多個欄位時，
            // 習慣將工號、姓名等資料用特定符號（例如 | 或者是 ,）串接成一個長字串存在 UserData 內。
            if (!string.IsNullOrEmpty(userData))
            {
                // 請點開舊專案，確認當時它存入 userData 時是用什麼符號隔開的。此處以 | 為範例：
                string[] parts = userData.Split('|');

                this.EmployeeId = parts.Length > 0 ? parts[0] : userName;
                this.RealName = parts.Length > 1 ? parts[1] : userName;
                this.DepartmentId = parts.Length > 2 ? parts[2] : "IT";
                this.Email = parts.Length > 3 ? parts[3] : "user@auo.com";
                this.CompanyName = parts.Length > 4 ? parts[4] : "AUO";
                this.Site = parts.Length > 5 ? parts[5] : "Hsinchu";
            }

            // 萬一解出來是空的，提供測試預設值安全過濾，避免系統出現黃頁錯誤
            if (string.IsNullOrEmpty(this.RealName)) this.RealName = userName;
            if (string.IsNullOrEmpty(this.EmployeeId)) this.EmployeeId = "1234567";
        }
    }

}
