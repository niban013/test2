﻿using System.Collections.Concurrent;
using System.Globalization;

namespace OneSupplierPlatform.Helper.Localizer
{
    public class I18nMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ConcurrentDictionary<string, string> _langCache;

        public I18nMiddleware(RequestDelegate next, ConcurrentDictionary<string, string> langCache)
        {
            _next = next;
            _langCache = langCache;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            string culture = CultureInfo.CurrentUICulture.Name;

            if (!_langCache.TryGetValue(culture, out var langJson))
            {
                langJson = "{}"; // fallback
            } 
            context.Items["LangJson"] = langJson; 
            await _next(context);
        }
    }
}
