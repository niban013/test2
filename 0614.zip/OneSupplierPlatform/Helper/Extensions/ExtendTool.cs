﻿using Dapper;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OneSupplierPlatform.Helper.Extensions;
using OneSupplierPlatform.Infrastructure;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Data;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;

namespace OneSupplierPlatform.Helper.Extensions
{
    public static class DapperAutoJsonPropertyMapper
    {
        /// <summary>
        /// 自動掃描並註冊所有含有 [JsonProperty] 的類別
        /// </summary>
        public static void WatchAndRegisterAllModels()
        {
            // 1. 取得目前執行專案的組件 (可以換成您 Model 所在的特定 Assembly，例如 Assembly.Load("Your.Model.Project"))
            var assembly = Assembly.GetExecutingAssembly();

            // 2. 篩選出：所有包含「至少一個屬性掛有 [JsonProperty] 標籤」的類別
            var targetTypes = assembly.GetTypes()
                .Where(t => t.IsClass && !t.IsAbstract)
                .Where(t => t.GetProperties().Any(p => p.GetCustomAttribute<JsonPropertyAttribute>() != null));

            // 3. 批量將對照地圖規則餵給 Dapper
            foreach (var type in targetTypes)
            {
                var map = new CustomPropertyTypeMap(type, (t, columnName) =>
                {
                    return t.GetProperties().FirstOrDefault(prop =>
                    {
                        // 優先比對 JsonProperty 的 PropertyName
                        var attr = prop.GetCustomAttribute<JsonPropertyAttribute>();
                        if (attr != null && string.Equals(attr.PropertyName, columnName, StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                        // 若無標籤則退回比對屬性原名
                        return string.Equals(prop.Name, columnName, StringComparison.OrdinalIgnoreCase);
                    });
                });

                SqlMapper.SetTypeMap(type, map);
            }
        }
    }
    public class ColumnList<T> : System.Collections.IEnumerable
    {
        public List<ColumnSchema> AllColumns = new();

        // 支援 Lambda: 會自動對應到 { x => x.Prop }
        public void Add(System.Linq.Expressions.Expression<Func<T, object>> expr)
        {
            string pName = ExtendTool.GetPropertyName(expr);
            string jName = ExtendTool.GetJsonName(typeof(T), pName);
            AllColumns.Add(new ColumnSchema(jName, pName));
        }

        // 支援字串: 會自動對應到 { "City" }
        public void Add(string propertyName)
        {
            string jName = ExtendTool.GetJsonName(typeof(T), propertyName);
            AllColumns.Add(new ColumnSchema(jName, propertyName));
        }

        // 必須實作 IEnumerable 才能使用初始化器語法糖
        public System.Collections.IEnumerator GetEnumerator() => AllColumns.GetEnumerator();
    }

    public static class ExtendTool
    {
        // 快取緩存：Key 是 "類別全名.屬性名"，Value 是 "Json ID"
        private static readonly ConcurrentDictionary<string, string> _nameCache = new();

        //public static string GetPropertyName(LambdaExpression expr)
        //{
        //    MemberExpression member = expr.Body as MemberExpression;
        //    if (member == null && expr.Body is UnaryExpression unary)
        //        member = unary.Operand as MemberExpression;

        //    return member?.Member.Name ?? throw new ArgumentException("無效的表達式");
        //}


        /// <summary>
        /// 方法 1：將 Lambda 表達式 (x => x.MakerCode) 轉為字串 "MakerCode"
        /// </summary>
        public static string GetPropertyName(LambdaExpression propertySelector)
        {
            MemberExpression member = propertySelector.Body as MemberExpression;

            // 處理 Boxing 情況 (例如 int 轉 object 會產生 UnaryExpression)
            if (member == null && propertySelector.Body is UnaryExpression unary)
            {
                member = unary.Operand as MemberExpression;
            }

            if (member == null)
                throw new ArgumentException($"表達式 {propertySelector} 不是有效的屬性存取。");

            return member.Member.Name;
        }

        /// <summary>
        /// 方法 2：取得屬性上的 [JsonProperty] 名稱，若無則回傳原名 (泛型版)
        /// </summary>
        public static string GetJsonName<T>(string propertyName)
        {
            return GetJsonName(typeof(T), propertyName);
        }

        /// <summary>
        /// 方法 2 的實作：支援 Type 物件傳入
        /// </summary>
        public static string GetJsonName(Type type, string propertyName)
        {
            string cacheKey = $"{type.FullName}.{propertyName}";

            return _nameCache.GetOrAdd(cacheKey, _ =>
            {
                PropertyInfo prop = type.GetProperty(propertyName);
                if (prop == null) return propertyName;

                // 取得 Newtonsoft.Json 的 JsonPropertyAttribute
                var attr = prop.GetCustomAttribute<JsonPropertyAttribute>();

                // 如果有定義 PropertyName 則回傳，否則回傳 C# 屬性原名
                return attr?.PropertyName ?? propertyName;
            });
        }


        public static List<T> ToList<T>(this DataTable dt) where T : new()
        {
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var obj = new T();
                foreach (var prop in properties)
                {
                    // 比對欄位名稱是否存在且有值
                    if (dt.Columns.Contains(prop.Name) && row[prop.Name] != DBNull.Value)
                    {
                        prop.SetValue(obj, Convert.ChangeType(row[prop.Name], prop.PropertyType));
                    }
                }
                return obj;
            }).ToList();
        }

        /// <summary>
        /// 自動根據目前的 Partial View 檔名產生 data-section 屬性字串
        /// </summary>
        public static IHtmlContent GetPartialSection(this IHtmlHelper htmlHelper, object suffix = null)
        {
            var viewPath = htmlHelper.ViewContext.ExecutingFilePath;
            if (string.IsNullOrEmpty(viewPath)) return HtmlString.Empty;

            string fileNameOnly = Path.GetFileNameWithoutExtension(viewPath);

            // 如果有傳入後綴（如 ID 或 Index），就接在檔名後面
            string finalSectionId = suffix != null
                ? $"{fileNameOnly}_{suffix}"
                : fileNameOnly;

            return new HtmlString($"data-section=\"{finalSectionId}\"");
        }


        public static string GetString(this Dictionary<string, object>? dict, string key)
        {
            if (dict == null) return "";
            return dict.ContainsKey(key) ? dict[key]?.ToString() : null;
        }

        public static List<string> GetList(this Dictionary<string, object> dict, string key)
        {
            if (dict == null) return new List<string>();

            if (!dict.ContainsKey(key)) return new List<string>();

            var arr = dict[key] as JArray;
            return arr?.ToObject<List<string>>();
        }

        public static T GetObject<T>(this Dictionary<string, object> dict, string key)
        {
            if (!dict.ContainsKey(key)) return default;

            var obj = dict[key] as JObject;
            return obj != null ? obj.ToObject<T>() : default;
        }


        public static T ToModel<T>(this IDictionary<string, object> dict)
        {
            return JObject.FromObject(dict).ToObject<T>();
        }


        public static List<VendorFile> ConvertToVendorFiles(string jsonString, string headerId = "", string formNo = "", string cUser = "")
        {
            var resultList = new List<VendorFile>();
            var jObject = JObject.Parse(jsonString);
            var itemGroups = new Dictionary<string, Dictionary<string, string>>();

            foreach (var property in jObject.Properties())
            {

                string rawKey = property.Name;
                string value = property.Value?.ToString() ?? "";


                string[] parts = rawKey.Split('.');
                if (parts.Length != 2) continue;

                string itemKey = parts[0];
                string attribute = parts[1];

                if (!itemGroups.ContainsKey(itemKey))
                {
                    itemGroups[itemKey] = new Dictionary<string, string>();
                }
                itemGroups[itemKey][attribute] = value;
            }


            foreach (var kvp in itemGroups)
            {
                string itemKey = kvp.Key;                     // "vc1_ssa" 等
                var attributes = kvp.Value;                   // 包含 score, file, expired 的字典

                string fileContent = attributes.ContainsKey("file") ? attributes["file"] : "";

                // 如果 file 欄位有多個檔案（如 "1,2,3"），則拆分成多筆資料
                var fileIds = string.IsNullOrEmpty(fileContent)
                    ? new string[] { "" }
                    : fileContent.Split(',');

                foreach (var fileId in fileIds)
                {
                    var vendorFile = new VendorFile
                    {
                        HeaderId = headerId,
                        FormNo = formNo,
                        ItemId = itemKey,
                        ItemName = "",
                        expired = attributes.ContainsKey("expired") ? attributes["expired"] : "",
                        Score = attributes.ContainsKey("score") ? attributes["score"] : "",
                        FileId = fileId,
                        FileName = "",
                        Active = "Y",
                        CUser = cUser,
                        CDate = DateTime.Now
                    };

                    resultList.Add(vendorFile);
                }
            }

            return resultList;
        }




        public static async Task<List<SelectItem>> CallAsmxPostAsync(string asmxUrl, string methodName, Dictionary<string, string> parameters = null)
        {
            var _config = AppFinder.GetService<IConfiguration>();
            // 1. 組合完整 URL (服務路徑 + 方法名稱)
            string fullUrl = $"{_config["ExternalServices:BaseUrl"]}/{asmxUrl}/{methodName}";
            //    $"http://localhost:51004/WS/{asmxUrl.TrimEnd('/')}/{methodName}";
            //string asmxUrl = $"{_config["ExternalServices:BaseUrl"]}/{methodName}";
            using var client = new HttpClient();
            List<SelectItem> result = new List<SelectItem>();
            try
            {
                switch (methodName)
                {
                    case "GetCountry":
                    case "GetGroupCode":
                    case "FetchTradeTerm":
                        parameters = new Dictionary<string, string>() { { "keyword", "" } };
                        break;
                    case "FetchTax":
                        return result;
                }

                var safeParams = parameters ?? new Dictionary<string, string>();
                var content = new FormUrlEncodedContent(safeParams);

                // 4. 發送 POST 請求
                var response = await client.PostAsync(fullUrl, content);

                // 5. 檢查狀態碼 (若 ASMX 端沒開啟 HttpPost 協定，此處會噴 500 或 405 錯誤)
                if (response.IsSuccessStatusCode)
                {
                    var responseXml = await response.Content.ReadAsStringAsync();

                    XDocument xdoc = XDocument.Parse(responseXml);
                    XNamespace ns = "http://tempuri.org/";
                    // 使用 ns + "string" 來定位元素
                    string jsonContent = xdoc.Element(ns + "string")?.Value;
                    if (!string.IsNullOrEmpty(jsonContent))
                    {
                        using var doc = JsonDocument.Parse(jsonContent);
                        switch (methodName)
                        {
                             
                            case "FetchCurrency":
                            case "FetchPaymentTerm":
                            case "FetchFreight":
                            case "GetCountry":
                            case "GetMakerGroupCode":
                            case "GetTechnology":
                            case "GetGroupCode":
                            case "FetchTradeTerm":
                                result = doc.RootElement.EnumerateArray()
                                .Select(item => new SelectItem
                                {
                                    Text = item.GetProperty("text").GetString() ?? "",
                                    Value = item.GetProperty("value").GetString() ?? "",
                                    Color = ""
                                })
                                .ToList();
                                break;
                            case "FetchTax":
                                break;
                        }

                    }
                    return result;
                }
                else
                {
                    string errorDetail = await response.Content.ReadAsStringAsync();
                    throw new Exception($"呼叫失敗: {response.StatusCode}, 詳細原因: {errorDetail}");
                }
            }
            catch (Exception ex)
            {
                // 處理網路錯誤或逾時
                return result;
            }
        }

        public static Dictionary<string, object> ToJsonFieldDictionary(this object entity)
        {
            var dictionary = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            if (entity == null) return dictionary;

            // 情況 A：如果傳入的是 IDictionary<string, object> (例如 ExpandoObject / dynamic 動態物件)
            if (entity is IDictionary<string, object> dynamicDict)
            {
                foreach (var kvp in dynamicDict)
                {
                    dictionary[kvp.Key] = kvp.Value;
                }
                return dictionary;
            }

            // 情況 B：如果是匿名物件 (Anonymous Type) 或一般強型別類別
            // 使用 TypeDescriptor 可以同時相容匿名物件與一般類別的屬性反射
            var properties = TypeDescriptor.GetProperties(entity);

            foreach (PropertyDescriptor prop in properties)
            {
                string jsonKey = prop.Name;

                // 嘗試取得屬性上的 JsonPropertyAttribute (注意：匿名物件不會有此 Attribute)
                var jsonPropertyAttr = prop.Attributes[typeof(JsonPropertyAttribute)] as JsonPropertyAttribute;
                if (jsonPropertyAttr != null && !string.IsNullOrEmpty(jsonPropertyAttr.PropertyName))
                {
                    jsonKey = jsonPropertyAttr.PropertyName;
                }

                // 取得數值並寫入字典
                var value = prop.GetValue(entity);
                dictionary[jsonKey] = value;
            }

            return dictionary;
        }

        private static string GetContentType(string path)
        {
            var ext = Path.GetExtension(path).ToLower();

            return ext switch
            {
                ".png" => "image/png",
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".pdf" => "application/pdf",
                ".xls" => "application/vnd.ms-excel",
                ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                _ => "application/octet-stream"
            };
        }
        public static bool DeleteFile(string formno, string name)
        {
            return true;
        }
        public static IFormFile CreateFormFile(string formno, string name)
        {
            var tempPath = "";
            //Path.Combine(
            //    _env.WebRootPath,
            //    "temp",
            //    token + Path.GetExtension(file.FileName)
            //);
            var stream = new FileStream(tempPath, FileMode.Open);

            var fileName = Path.GetFileName(tempPath);

            IFormFile file = new FormFile(
                stream,
                0,
                stream.Length,
                "File",
                fileName
            )
            {
                Headers = new HeaderDictionary(),
                ContentType = GetContentType(tempPath)
            };

            return file;
        }


        public static string GetUserPhotoUrl(string empId)
        {
            string result = string.Empty;
            if (empId.ToUpper().StartsWith("X"))
            {
                //XM
                //result = string.Format("http://10.5.13.188/xm_photo/{0}.jpg", empId); //xUserPhotoUrlTempate
                result = string.Format("https://aushrap3/AUOPhoneBookPhoto/xm_photo/{0}.jpg", empId);
            }
            else if (empId.ToUpper().StartsWith("S"))
            {
                //SZ
                //result = string.Format("http://10.5.13.188/photo/{0}.jpg", empId); //sUserPhotoUrlTempate
                result = string.Format("https://aushrap3/AUOPhoneBookPhoto/sz_photo/{0}.jpg", empId);
            }
            else if (empId.ToUpper().StartsWith("K"))
            {
                //KS
                //result = string.Format("http://10.5.13.188/photo/{0}.jpg", empId); //sUserPhotoUrlTempate
                result = string.Format("https://aushrap3/AUOPhoneBookPhoto/ks_photo/{0}.jpg", empId);
            }
            else
            {
                /*  2021-08-19 
                   舊：http://au3hr8/photo/1552090.jpg
                   新：http://auohqitmap01/AUOPhoneBookPhoto/photo/1552090.jpg                 
                */
                //result = string.Format("http://au3hr8/photo/{0}.jpg", empId); //normalUserPhotoUrlTemplate
                result = string.Format("https://auohqitmap01/AUOPhoneBookPhoto/photo/{0}.jpg", empId);
            }

            return result;
        }



    }


}

