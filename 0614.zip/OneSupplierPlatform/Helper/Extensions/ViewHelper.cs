﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;


//using Newtonsoft.Json;
using System.Reflection;
using System.Text.Json;
namespace OneSupplierPlatform.Helper.Extensions
{
    //public static class WorkflowServiceCollectionExtensions
    //{
    //    public static IServiceCollection AddWorkflows(
    //        this IServiceCollection services,
    //        params Assembly[] assemblies)
    //    {
    //        var workflowTypes = assemblies
    //            .SelectMany(a => a.GetTypes())
    //            .Where(t =>
    //                t.GetCustomAttribute<WorkflowModuleAttribute>() != null)
    //            .Where(t => !t.IsAbstract && !t.IsInterface);

    //        foreach (var type in workflowTypes)
    //        {
    //            services.AddScoped(type);
    //        }

    //        return services;
    //    }
    //}
    public static class ViewHelper
    {
        public static string ResolveValue(string value, string defaultValue)
        {
            return !string.IsNullOrEmpty(value) ? value : (defaultValue ?? "");
        }
        public static IHtmlContent RenderAppConfig(this IHtmlHelper htmlHelper, string sectionName = "FileUploadConfig")
        {
            var config = htmlHelper.ViewContext.HttpContext.RequestServices.GetRequiredService<IConfiguration>();

            // 1. 取得指定的整個區塊 (例如 FrontendConfig)
            var section = config.GetSection(sectionName);

            // 2. 將該區塊轉換為 Dictionary，方便序列化
            var settings = section.AsEnumerable()
                .Where(x => x.Value != null)
                .ToDictionary(x => x.Key.Replace($"{sectionName}:", ""), x => x.Value);

            // 3. 序列化為 JSON (使用 CamelCase 讓 JS 好讀)
            var jsonOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
            var json = System.Text.Json.JsonSerializer.Serialize(settings, jsonOptions);

            return new HtmlString($"<script>window.appConfig = {json};</script>");
        }

        public static Dictionary<string, string> MapKeysToJsonProperty<T>(Dictionary<string, object> rawData)
        {
            if (rawData == null) return new Dictionary<string, string>();

            // 1. 取得該類別中所有屬性與 [JsonProperty] 的對照表 (快取機制可優化效能)
            var mapping = typeof(T)
                .GetProperties()
                .Select(p => new
                {
                    PropertyName = p.Name, // 例如 "MakerCode"
                    JsonName = p.GetCustomAttribute<JsonPropertyAttribute>()?.PropertyName // 例如 "maker_code"
                })
                // 只抓取有標記 JsonProperty 的屬性
                .Where(x => !string.IsNullOrEmpty(x.JsonName))
                .ToDictionary(x => x.PropertyName, x => x.JsonName);

            var result = new Dictionary<string, string>();

            // 2. 遍歷原始資料進行 Key 替換
            foreach (var item in rawData)
            {
                // 如果屬性名有標記 JsonProperty，則換成標記名；否則維持原 Key
                string finalKey = mapping.TryGetValue(item.Key, out var jsonName) ? jsonName : item.Key;
                result[finalKey] = (string)item.Value;
            }

            return result;
        }
    }
}
