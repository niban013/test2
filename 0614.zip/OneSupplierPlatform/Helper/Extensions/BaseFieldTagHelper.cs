﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using OneSupplierPlatform.Models.Infra;

namespace OneSupplierPlatform.Helper.Extensions
{
    public abstract class BaseFieldTagHelper : TagHelper
    {
        public BaseDynamicField Field { get; set; }

        protected string RawValue => ViewHelper.ResolveValue(Field?.ColValue, Field?.DefaultValue);

        protected string GetId()
        {
            var prefix = Field?.EnumType switch
            {
                FieldType.Textbox => "ttb",
                FieldType.Numeric => "num",
                FieldType.Date => "dtp",
                FieldType.Dropdown => "ddl",
                FieldType.Select2 => "s2",
                FieldType.Textarea => "txt",
                FieldType.Upload => "file",
                //FieldType.ShowFile => "show",
                FieldType.Radio => "rdo",
                _ => "fld"
            };
            return $"{prefix}{Field?.ColName}";
        }

        protected string MustAttr => Field?.Must == true ? "true" : "false";
    }
}
