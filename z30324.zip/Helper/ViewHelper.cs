﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;
using vsnet8.Models;

namespace vsnet8.Helper
{
    public static class ViewHelper
    {
        /// <summary>
        /// 取得 Controller_Action
        /// </summary>
        public static string GetPageKey(this IHtmlHelper html)
        {
            var route = html.ViewContext.RouteData.Values;
            var controller = route["controller"]?.ToString();
            var action = route["action"]?.ToString();

            return $"{controller}_{action}";
        }

        /// <summary>
        /// Controller_Action_Tab
        /// </summary>
        public static string GetPageTabKey(this IHtmlHelper html, string tabId)
        {
            var baseKey = html.GetPageKey();
            return $"{baseKey}_{tabId}";
        }

        public static IHtmlContent RenderDynamicFormTypesAuto(this IHtmlHelper html, Dictionary<string, List<DynamicField>> model)
        {
            if (model is not Dictionary<string, List<DynamicField>> dict)
                return HtmlString.Empty;

            var sb = new StringBuilder();

            sb.AppendLine("<script>");
            foreach (var tab in model)
            {
                sb.AppendLine($"/**");
                sb.AppendLine($" * @typedef {{");

                foreach (var field in tab.Value)
                {
                    var type = "string"; // 預設

                    if (field.Type.ToString() == "number" || field.Type.ToString() == "int") type = "number";
                    if (field.Type.ToString() == "date") type = "string"; // date 可改成 string 或 Date
                    sb.AppendLine($" *   {field.Name}: {type};");
                }

                sb.AppendLine($" * }} {tab.Key};");
                sb.AppendLine();
            }

            sb.AppendLine("/// <reference types=\"jquery\" />");
            sb.AppendLine("/** @type {Object.<string, any>} */");
            sb.AppendLine("var vm = vm || {};");
            sb.AppendLine("</script>");

            return new HtmlString(sb.ToString());
        }
    }
}
