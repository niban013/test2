﻿window.AppController = (() => {
     
    const state = {
        stepsRef: null,
        currentStep: null,
        setStep: null,
        currentPage: null,
        fileCache: { steps: {} },
        loading: false
    };
    
    function initSelect2(container) {
        function setSelect2Background(select) {
            let color = select.find("option:selected").data("color") || "";
            select.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }
        function formatOption(item) {
            if (!item.id) return item.text;
            let color = $(item.element).data("color") || "";
            return $('<div style="background:' + color + '; padding:4px 6px;">' + item.text + '</div>');
        }

        function formatSelection(item) { return item.text; }

        $(container).find("select.select2").each(function () {

            const $el = $(this);

            if ($el.data("select2")) return;

            $el.select2({
                width: "100%",
                placeholder: $el.attr("placeholder") || "請選擇",
                allowClear: true,
                templateResult: formatOption,
                templateSelection: formatSelection
            });
            setTimeout(() => {
                setSelect2Background($el);
            }, 0);
            $el.on("select2:select select2:clear", function () {
                setSelect2Background($el);
                // 🔥 強制同步 value
                const value = $el.val();

                // 🔥 直接用原生 dispatch（比 trigger 穩）
                $el[0].dispatchEvent(new Event("change", { bubbles: true }));
            });

            $el.trigger("change.select2");
        });
    }
    
    function getStepKey() {
        return `step${state.currentStep.value || 1}`;
    }

    async function init({ steps, currentStep, setStep }) {

        state.stepsRef = steps;
        state.currentStep = currentStep;
        state.setStep = setStep;
        await registerModules();
        await load();

        const ribbon = document.querySelector('.wizard-ribbon');
        if (ribbon) {
            ribbon.style.setProperty('--total', steps.value.length);
        }
    }
    async function registerModules() {

        AppBootstrap.register("FormStore", FormStore);
        //AppBootstrap.register("FormValidation", FormValidation);
        AppBootstrap.register("FilePlugin", FilePlugin);
        AppBootstrap.register("FieldBinder", FieldBinder);
        //AppBootstrap.register("ComputedRegistry", ComputedRegistry);
        AppBootstrap.register("ComputedEngine", ComputedEngine); 
        //if (window.FieldBinder)
        //    AppBootstrap.register("FieldBinder", FieldBinder);
        // 如果你有這些
        //if (window.FieldStatus)
        //    AppBootstrap.register("FieldStatus", FieldStatus);

        //if (window.ValidationCenter)
        //    AppBootstrap.register("ValidationCenter", ValidationCenter);

        await AppBootstrap.wait(); // 🔥 等全部 ready

        //const computed = AppBootstrap.get("ComputedEngine");
        //computed.init();
        //computed.enable();
           
    }
    async function load() {

        if (state.loading) return;
        state.loading = true;

        try {

            const stepIndex = state.currentStep.value;
            const stepKey = `step${stepIndex}`;

            const container = await StepLoader.load(stepIndex, state);

            state.currentPage = window.StepPages?.[stepKey];

         
            initSelect2(container)
            hydrateFields(container, stepKey); 
            const fieldBinder = AppBootstrap.get("FieldBinder");
            fieldBinder.bindFields(container, stepKey);
            return container;

        } finally {
            state.loading = false;
        }
    }
    function hydrateFields(container, stepKey) {
        const store = AppBootstrap.get("FormStore");
        container
            .querySelectorAll("input[data-field], select[data-field], textarea[data-field]")
            .forEach(el => {

                 
                const rawCol = el.dataset.col;
                const col = rawCol && rawCol.trim() ? rawCol.trim() : null;
                const key = makeKey(el.dataset.field, col);

                const storeVal = store.get(stepKey, key);

                // 🟢 Store 優先
                if (storeVal !== undefined && storeVal !== null) {

                    if (el.type === "checkbox") {
                        el.checked = storeVal;

                    } else if (el.type === "radio") {
                        el.checked = (el.value === storeVal);

                    }
                    else if (el.type === "file") {

                        // ❌ 永遠不要回填 file input value

                        // ✅ 改成更新 UI 顯示區
                        const file = storeVal;

                        const wrapper = el.closest(".file-wrapper");

                        if (wrapper) {

                            const nameEl = wrapper.querySelector(".file-name");
                           
                            if (file instanceof File) {
                                nameEl.textContent = file.name;
                                const lineEl = wrapper.querySelector(".file-line");
                                if (lineEl)
                                    lineEl.dataset.title = file.name;
                            }
                            else if (Array.isArray(file)) {
                                nameEl.textContent = file.length
                                    ? file.map(f => f.name).join(", ")
                                    : "";
                            }
                            else if (file?.name) {
                                nameEl.textContent = file.name;
                            }
                            else {
                                nameEl.textContent = "";
                            }
                        }
                    }
                    else {
                        el.value = storeVal;
                    }

                } else {

                    // 🔵 UI 補 Store（只做一次）
                    let val;

                    if (el.type === "checkbox") {
                        val = el.checked;

                    } else if (el.type === "radio") {

                        const checked = container.querySelector(
                            `input[data-field='${key}']:checked`
                        );

                        val = checked ? checked.value : null;

                    } else {
                        val = el.value;
                    }

                    if (val !== undefined && val !== null && val !== "") {
                      /*  const token = Symbol(`${stepKey}.${key}`);*/
                        store.safeSet(stepKey, key, val);
                    }
                }
            });
    } 
    async function next() {

        const stepKey = getStepKey();
        const store = AppBootstrap.get("FormStore");
        if (!store.isStepValid(stepKey)) {
            alert("請修正錯誤");
            return;
        }

        state.setStep(state.currentStep.value + 1);
        await load();
    }

    async function prev() {
        state.setStep(state.currentStep.value - 1);
        await load();
    }

    async function goTo(i) {
        state.setStep(Number(i));
        await load();
    }

    async function finish() {
        const store = AppBootstrap.get("FormStore"); 
        const payload = {}; 
        state.stepsRef.value.forEach(s => {
            payload[`step${s.StepIndex}`] = store.getDirty(`step${s.StepIndex}`);
            store.markStepSubmitted(`step${s.StepIndex}`);
        });

        console.log("FINAL:", payload);

        await fetch("/Home/Save", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
    }

    return {
        init,
        next,
        prev,
        goTo,
        finish,
        getState: () => state
    };

})();