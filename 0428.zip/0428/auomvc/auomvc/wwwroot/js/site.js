﻿$(document).on("mouseenter", ".tooltip-auto", function () {

    let instance = bootstrap.Tooltip.getInstance(this);

    if (!instance) {
        instance = new bootstrap.Tooltip(this, {
            title: this.dataset.title || "",
            placement: "top",
            trigger: "manual",   // ⭐ 改 manual
            container: "body"
        });
    }

    instance.show(); // ⭐ 直接顯示
});

$(document).on("mouseleave", ".tooltip-auto", function () {
    const instance = bootstrap.Tooltip.getInstance(this);
    if (instance) instance.hide();
}); 

function resolveType($el) {

    if ($el.is(":file")) return "file";
    if ($el.is(":radio")) return "radio";
    if ($el.is(":checkbox")) return "checkbox";
    if ($el.is("select") && $el.hasClass("select2")) return "select2";
    if ($el.is("select") && !$el.hasClass("select2")) return "select";
    if ($el.is("textarea")) return "textarea";

    if ($el.is("input")) {
        return $el.prop("type") || "text"; // text/number/date...
    }

    return "unknown";
}


const ValueHandler = {

    // =========================
    // ⭐ 取得值（統一出口）
    // =========================
    get($el) {

        const type = resolveType($el);

        switch (type) {

            case "file":
                return $el.data("file") || null;

            case "radio":
                return $(`input[name="${$el.attr("name")}"]:checked`).val() || "";

            case "checkbox":
                return $el.is(":checked");

            case "select":
                return $el.val();
            case "select2":
                return $el.val()?.trim() || "";
            case "textarea":
            case "text":
            case "number":
            case "date":
                return $el.val()?.trim() || "";

            default:
                return $el.text().trim() || "";
        }
    },

    // =========================
    // ⭐ 設定值（統一入口🔥）
    // =========================
    set($el, value, options = {}) {

        const type = resolveType($el);
        const { silent = false, vm, tabKey, field, inline } = options;

        switch (type) {

            case "file":
                if (!value) return;

                if (inline) {
                    const $group = $el.closest(".dynamic-file");
                    const $filenameLabel = $group.find(".filename-label");
                    const $previewBtn = $group.find(".preview-btn");
                    const $deleteBtn = $group.find(".delete-btn");

                    const fileObj = Array.isArray(value) ? value[0] : value;
                    const fileName = fileObj?.filename || fileObj?.name || "";

                    $filenameLabel.text(fileName);
                    $previewBtn.show();
                    $deleteBtn.show();


                    $deleteBtn.off("click").on("click", () => {
                        $el.val("");
                        $el.data("file", null);

                        $filenameLabel.text("");
                        $previewBtn.hide();
                        $deleteBtn.hide();

                        if (vm && vm.removeFile) {
                            vm.removeFile(tabKey, field, fileName);
                        }
                    });

                    $previewBtn.off("click").on("click", async () => {
                        if (vm && vm.previewFile) {
                            await vm.previewFile(tabKey, fileObj, field);
                        }
                        /*     await vm.previewFile(tabKey, { name: field, lazy: true });*/
                    });
                }
                return;

            case "radio":
                $(`input[name="${$el.attr("name")}"][value="${value}"]`).prop("checked", true);
                break;

            case "checkbox":
                $el.prop("checked", !!value);
                break;

            case "select":
                $el.val(value).trigger("change");
                break;

            default:
                if ($el.is("input, textarea")) {
                    $el.val(value);
                } else {
                    $el.text(value);
                }
        }

        if (!silent) {
            $el.trigger("input");
        }
    }
};