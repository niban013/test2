﻿namespace auomvc.Models
{
    public enum FieldType
    {
        OnlyLabel,
        Hidden,
        Label,
        Textbox,
        Dropdown,
        Select2,
        Numeric,
        Date,
        Textarea,
        File,
        ShowFile,
        Radio,
        Hybrid
    }
    public static class Safe
    {
        public static bool False(bool? v) => v == true;
        public static int Value(int? v, int def) => v ?? def;
    }
    public static class RuleSchemaRegistry
    {
        public static readonly Dictionary<FieldType, HashSet<string>> ValidationRules = new()
        {
            [FieldType.Textbox] = new() { "required", "maxlength", "pattern", "async", "map" },
            [FieldType.Numeric] = new() { "required", "min", "max" },
            [FieldType.Date] = new() { "required", "min", "max" },
            [FieldType.Textarea] = new() { "required", "maxlength" },
            [FieldType.Dropdown] = new() { "required" },
            [FieldType.Radio] = new() { "required" },
            [FieldType.File] = new() { "required", "accept", "maxsize", "async", "map" },
        };

        public static readonly Dictionary<FieldType, HashSet<string>> BehaviorRules = new()
        {
            [FieldType.Hidden] = new() { "readonly", "hidden" },
            [FieldType.Textbox] = new() { "readonly", "hidden" },
            [FieldType.Numeric] = new() { "readonly", "hidden" },
            [FieldType.Date] = new() { "readonly", "hidden" },
            [FieldType.Textarea] = new() { "readonly", "hidden" },
            [FieldType.Dropdown] = new() { "readonly", "hidden" },
            [FieldType.Radio] = new() { "readonly", "hidden" },
            [FieldType.File] = new() { "readonly", "hidden", "multiple" },
        };

        public static bool AllowValidation(FieldType t, string rule)
            => ValidationRules.TryGetValue(t, out var set) && set.Contains(rule);

        public static bool AllowBehavior(FieldType t, string rule)
            => BehaviorRules.TryGetValue(t, out var set) && set.Contains(rule);
    }
    public class BaseDynamicField
    {
        //public string? GroupKey { get; set; }


        public string ColName { get; set; }

        public string ColId { get; set; }
        public string Col { get; set; } = "";
        public string? Value { get; set; }
        public bool? Must { get; set; }

        public string Type { get; set; }
        public int? Min { get; set; }
        public int? Max { get; set; }
        public int? MaxLength { get; set; }
        public string? DefaultValue { get; set; }
        public string? Pattern { get; set; } = ""; // string / number /yyyy/mm/dd
        public string? Placeholder { get; set; }

        public bool? Readonly { get; set; }
        public string? AsyncUrl { get; set; } = "";
        public string? Target { get; set; } = "";
        public bool? Hidden { get; set; }

        public int? Width { get; set; } = 6; // bootstrap col
        public int? Order { get; set; }   // 顯示順序
        public string? OptionStr { get; set; }
        public bool? InverseSelect { get; set; } = false;


    }
    public static class OptionParser
    {
        public static List<SelectItem> Parse(string optionstr)
        {
            var list = new List<SelectItem>();

            if (string.IsNullOrWhiteSpace(optionstr))
                return list;

            var pairs = optionstr.Split(':');

            foreach (var p in pairs)
            {
                var kv = p.Split(',');

                if (kv.Length == 2)
                {
                    list.Add(new SelectItem
                    {
                        Value = kv[1].Trim(),
                        Text = kv[0].Trim(),
                        Color = kv[1].Trim()
                    });
                }
            }

            return list;
        }
    }
    // =========================
    // Domain Model（高階模型）
    // =========================
    public class DynamicField
    {
        //public string GroupKey { get; set; }
        public string Col { get; set; }
        public string ColId { get; set; }
        public string ColName { get; set; }

        public string? Value { get; set; }
        public FieldType Type { get; set; }
        public string AsyncUrl { get; set; }
        public string Target { get; set; }
        public string DefaultValue { get; set; }
        // UI Meta
        public string Placeholder { get; set; }
        public int Width { get; set; }
        public int Order { get; set; }

        public List<SelectItem> Options { get; set; } = new();

        // Validation rules
        public List<ValidationRule> ValidationRules { get; set; } = new();

        // Behavior rules
        public List<BehaviorRule> BehaviorRules { get; set; } = new();

        // Helpers
        public bool HasValidation(string name)
            => ValidationRules.Any(x => x.Name == name);

        public bool HasBehavior(string name)
            => BehaviorRules.Any(x => x.Name == name);
    }
    public class SelectItem
    {
        public string Value { get; set; }
        public string Color { get; set; }  // 新增顏色
        public string Text { get; set; }
    }
    // =========================
    // Validation Rule
    // =========================
    public class ValidationRule
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public ValidationRule() { }

        public ValidationRule(string name, string value = null)
        {
            Name = name;
            Value = value;
        }
    }

    // =========================
    // Behavior Rule
    // =========================
    public class BehaviorRule
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public BehaviorRule() { }

        public BehaviorRule(string name, string value = null)
        {
            Name = name;
            Value = value;
        }
    }

    // =========================
    // Mapper（核心轉換層）
    // =========================
    public static class DynamicFieldMapper
    {
        public static DynamicField ToDomain(BaseDynamicField e)
        {
            var type = Enum.Parse<FieldType>(e.Type);

            return new DynamicField
            {
                ColId = e.ColId,
                ColName = e.ColName,
                Col = e.Col,
                Value = e.Value,
                Type = type,
                //GroupKey = e.GroupKey ?? "",
                Options = OptionParser.Parse(e.OptionStr ?? ""), // ⭐ 這行

                Width = e.Width ?? 3,
                Order = e.Order ?? 0,
                Placeholder = e.Placeholder ?? "",
                DefaultValue = e.DefaultValue ?? "",
                ValidationRules = MapValidation(e),
                BehaviorRules = MapBehavior(e)
            };
        }

        public static BaseDynamicField ToEntity(DynamicField d)
        {
            var e = new BaseDynamicField
            {
                ColId = d.ColId,
                ColName = d.ColName,
                //GroupKey = d.GroupKey,
                Type = d.Type.ToString(),
                Placeholder = d.Placeholder,
                Width = d.Width,
                Order = d.Order
            };

            foreach (var r in d.ValidationRules)
            {
                switch (r.Name)
                {
                    case "required":
                        e.Must = true;
                        break;

                    case "min":
                        e.Min = Convert.ToInt32(r.Value);
                        break;

                    case "max":
                        e.Max = Convert.ToInt32(r.Value);
                        break;

                    case "pattern":
                        e.Pattern = r.Value;
                        break;
                }
            }

            foreach (var r in d.BehaviorRules)
            {
                switch (r.Name)
                {
                    case "readonly":
                        e.Readonly = true;
                        break;

                    case "hidden":
                        e.Hidden = true;
                        break;
                }
            }

            return e;
        }

        // =========================
        // Validation mapping
        // =========================
        private static List<ValidationRule> MapValidation(BaseDynamicField e)
        {
            var rules = new List<ValidationRule>();
            var type = Enum.Parse<FieldType>(e.Type);

            void Add(string name, string value = null)
            {
                if (RuleSchemaRegistry.AllowValidation(type, name))
                    rules.Add(new ValidationRule(name, value));
            }

            // ✔ Must
            if (e.Must == true)
                Add("required");

            // ✔ numeric rules
            if (type == FieldType.Numeric)
            {
                if (e.Min.HasValue)
                    Add("min", e.Min.Value.ToString());

                if (e.Max.HasValue)
                    Add("max", e.Max.Value.ToString());
            }

            // ✔ textbox rules
            if (type == FieldType.Textbox)
            {
                if (e.MaxLength.HasValue)
                    Add("maxlength", e.MaxLength.Value.ToString());

                if (!string.IsNullOrEmpty(e.AsyncUrl))
                    Add("async", e.AsyncUrl);
                // ✔ ⭐ 新增 map
                if (!string.IsNullOrEmpty(e.Target))
                    Add("map", e.Target);

                if (!string.IsNullOrEmpty(e.Pattern))
                    Add("pattern", e.Pattern);
            }
            // ✔ file rules
            if (type == FieldType.File)
            {
                if (!string.IsNullOrEmpty(e.AsyncUrl))
                    Add("async", e.AsyncUrl);

                if (!string.IsNullOrEmpty(e.Target))
                    Add("map", e.Target);

                // ⭐ accept (用 Pattern 或自訂欄位)
                if (!string.IsNullOrEmpty(e.Pattern))
                    Add("accept", e.Pattern);

                // ⭐ maxsize（你可以用 Max 當 MB）
                if (e.Max.HasValue)
                    Add("maxsize", e.Max.Value.ToString());
            }
            return rules;
        }

        // =========================
        // Behavior mapping
        // =========================
        private static List<BehaviorRule> MapBehavior(BaseDynamicField e)
        {
            var rules = new List<BehaviorRule>();
            var type = Enum.Parse<FieldType>(e.Type);

            void Add(string name)
            {
                if (RuleSchemaRegistry.AllowBehavior(type, name))
                    rules.Add(new BehaviorRule(name));
            }

            if (e.Readonly == true)
                Add("readonly");

            if (e.Type == "Hidden")
                Add("hidden");

            return rules;
        }
    }

    // =========================
    // Optional: Fluent Builder（程式產生用）
    // =========================
    public static class FieldFluentExtensions
    {
        public static DynamicField Required(this DynamicField f)
        {
            f.ValidationRules.Add(new ValidationRule("required"));
            return f;
        }

        public static DynamicField Min(this DynamicField f, int v)
        {
            f.ValidationRules.Add(new ValidationRule("min", v.ToString()));
            return f;
        }

        public static DynamicField Max(this DynamicField f, int v)
        {
            f.ValidationRules.Add(new ValidationRule("max", v.ToString()));
            return f;
        }

        public static DynamicField Readonly(this DynamicField f)
        {
            f.BehaviorRules.Add(new BehaviorRule("readonly"));
            return f;
        }

        public static DynamicField Hidden(this DynamicField f)
        {
            f.BehaviorRules.Add(new BehaviorRule("hidden"));
            return f;
        }
    }
}