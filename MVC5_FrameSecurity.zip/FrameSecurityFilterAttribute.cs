using System.Web.Mvc;

public class FrameSecurityFilterAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext filterContext)
    {
        var response = filterContext.HttpContext.Response;
        response.Headers["X-Frame-Options"] = "SAMEORIGIN";
        response.Headers["Content-Security-Policy"] = "frame-ancestors 'self'";
        base.OnActionExecuting(filterContext);
    }
}
