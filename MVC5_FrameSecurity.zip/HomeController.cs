using System.Web.Mvc;

[FrameSecurityFilter]
public class HomeController : Controller
{
    public ActionResult Index()
    {
        return View();
    }

    public ActionResult Page1()
    {
        return View();
    }

    public ActionResult Page2()
    {
        return View();
    }
}
