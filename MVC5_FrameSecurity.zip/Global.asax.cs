using System;
using System.Web;

public class MvcApplication : System.Web.HttpApplication
{
    protected void Application_Start()
    {
        // 標準 MVC 設定略
    }

    protected void Application_BeginRequest()
    {
        var response = HttpContext.Current.Response;
        response.Headers["X-Frame-Options"] = "SAMEORIGIN";
        response.Headers["Content-Security-Policy"] = "frame-ancestors 'self'";
    }
}
