﻿using Newtonsoft.Json;
using OneSupplierPlatform.Helper.Extensions;
using System.Text.RegularExpressions;

namespace OneSupplierPlatform.Models
{
    public enum FieldType
    {
        Label,
        Textbox,
        Dropdown,
        Select2,
        Numeric,
        Date,
        Textarea,
        Radio,
        File,
        //Hiddden,
        Hybrid,
        OnlyLabel,
    }

    public static class RuleSchemaRegistry
    {
        public static readonly Dictionary<FieldType, HashSet<string>> ValidationRules = new()
        {
            [FieldType.OnlyLabel] = new() { "required" },
            [FieldType.Textbox] = new() { "required", "maxlength", "pattern", "async", "map" },
            [FieldType.Numeric] = new() { "required", "min", "max" },
            [FieldType.Date] = new() { "required", "min", "max" },
            [FieldType.Textarea] = new() { "required", "maxlength" },
            [FieldType.Dropdown] = new() { "required" },
            [FieldType.Radio] = new() { "required" },
            [FieldType.File] = new() { "required", "accept", "maxsize", "async", "map" },
        };

        public static readonly Dictionary<FieldType, HashSet<string>> BehaviorRules = new()
        {
            [FieldType.Label] = new() { "readonly", "hidden" },
            [FieldType.Textbox] = new() { "readonly", "hidden" },
            [FieldType.Numeric] = new() { "readonly", "hidden" },
            [FieldType.Date] = new() { "readonly", "hidden" },
            [FieldType.Textarea] = new() { "readonly", "hidden" },
            [FieldType.Dropdown] = new() { "readonly", "hidden" },
            [FieldType.Radio] = new() { "readonly", "hidden" },
            [FieldType.File] = new() { "readonly", "hidden", "multiple" },
        };

        public static bool AllowValidation(FieldType t, string rule)
            => ValidationRules.TryGetValue(t, out var set) && set.Contains(rule);

        public static bool AllowBehavior(FieldType t, string rule)
            => BehaviorRules.TryGetValue(t, out var set) && set.Contains(rule);
    }

    //public class DynamicSupplierFileField : BaseDynamicField
    //{
    //    public string VCType { get; set; }
    //    public string ExpiredDate { get; set; } = "N";

    //    [System.Text.Json.Serialization.JsonIgnore]
    //    public bool IsExpired
    //    {
    //        get => ExpiredDate?.Trim() == "Y";
    //        set => ExpiredDate = value ? "Y" : "N";
    //    }
    //    public List<string> FileList { get; set; } = new List<string>();
    //}


    // =========================
    // Domain Model（高階模型）
    // =========================
    public class DynamicField
    {
        public string ColId { get; set; }
        public string ColName { get; set; }
        public string Col { get; set; }
        public string? ColValue { get; set; }
        public FieldType EnumType { get; set; }
        public string AsyncUrl { get; set; } = string.Empty;
        public string Target { get; set; } = string.Empty;
        public string DefaultValue { get; set; } = string.Empty;
        // UI Meta
        public string Placeholder { get; set; } = string.Empty;
        public int Width { get; set; } = 3;
        public int Order { get; set; } = 1;
        public string RuntimeKey { get; set; }
        public Dictionary<string, DynamicField> Children { get; set; } = new();

        public List<SelectItem> Options { get; set; } = new();

        // Validation rules
        public List<ValidationRule> ValidationRules { get; set; } = new();

        // Behavior rules
        public List<BehaviorRule> BehaviorRules { get; set; } = new();

        // Helpers
        public bool HasValidation(string name)
            => ValidationRules.Any(x => x.Name == name);

        public bool HasBehavior(string name)
            => BehaviorRules.Any(x => x.Name == name);
    }

    // =========================
    // Validation Rule
    // =========================
    public class ValidationRule
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public ValidationRule() { }

        public ValidationRule(string name, string value = null)
        {
            Name = name;
            Value = value;
        }
    }

    // =========================
    // Behavior Rule
    // =========================
    public class BehaviorRule
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public BehaviorRule() { }

        public BehaviorRule(string name, string value = null)
        {
            Name = name;
            Value = value;
        }
    }

    //// =========================
    //// Mapper（核心轉換層）
    //// =========================
    //public static class DynamicFieldMapper
    //{
    //public static DynamicField ToDomain(BaseDynamicField e)
    //    {
    //        var domain = new DynamicField
    //        {
    //            ColId = e.ColId,
    //            ColName = e.ColName,
    //            Col = e.Col,
    //            ColValue = e.ColValue,
    //            EnumType = e.EnumType,

    //            Options = OptionParser.Parse(e.OptionStr ?? ""),

    //            Width = e.Width ?? 3,
    //            Order = e.Order ?? 0,
    //            Placeholder = e.Placeholder ?? "",
    //            DefaultValue = e.DefaultValue ?? "",

    //            ValidationRules = MapValidation(e),
    //            BehaviorRules = MapBehavior(e)
    //        };

    //        // ⭐⭐⭐ NEW：遞迴 Children
    //        if (e.Children != null && e.Children.Count > 0)
    //        {
    //            foreach (var c in e.Children)
    //            {
    //                domain.Children ??= new Dictionary<string, DynamicField>();

    //                domain.Children[c.Key] = ToDomain(c.Value);
    //            }
    //        }

    //        return domain;
    //    }

    //    //public static BaseDynamicField ToEntity(DynamicField d)
    //    //{
    //    //    var e = new BaseDynamicField
    //    //    {
    //    //        ColId = d.ColId,
    //    //        ColName = d.ColName,
    //    //        EnumType = d.EnumType.ToString(),
    //    //        Placeholder = d.Placeholder,
    //    //        Width = d.Width,
    //    //        Order = d.Order
    //    //    };

    //    //    foreach (var r in d.ValidationRules)
    //    //    {
    //    //        switch (r.Name)
    //    //        {
    //    //            case "required":
    //    //                e.Must = true;
    //    //                break;

    //    //            case "min":
    //    //                e.Min = r.Value;
    //    //                break;

    //    //            case "max":
    //    //                e.Max = r.Value;
    //    //                break;

    //    //            case "pattern":
    //    //                e.Pattern = r.Value;
    //    //                break;
    //    //        }
    //    //    }

    //    //    foreach (var r in d.BehaviorRules)
    //    //    {
    //    //        switch (r.Name)
    //    //        {
    //    //            case "readonly":
    //    //                e.Readonly = true;
    //    //                break;

    //    //                //case "hidden":
    //    //                //    e.Hidden = true;
    //    //                //    break;
    //    //        }
    //    //    }

    //    //    return e;
    //    //}

    //    // =========================
    //    // Validation mapping
    //    // =========================
    //    private static List<ValidationRule> MapValidation(BaseDynamicField e)
    //    {
    //        var rules = new List<ValidationRule>();
    //        var type = Enum.Parse<FieldType>(e.EnumType.ToString());

    //        void Add(string name, string value = null)
    //        {
    //            if (RuleSchemaRegistry.AllowValidation(type, name))
    //                rules.Add(new ValidationRule(name, value));
    //        }

    //        // ✔ Must
    //        if (e.Must == true)
    //            Add("required");

    //        // ✔ numeric rules
    //        if (type == FieldType.Numeric)
    //        {
    //            if (e.Min.HasValue)
    //                Add("min", e.Min.Value.ToString());

    //            if (e.Max.HasValue)
    //                Add("max", e.Max.Value.ToString());
    //        }

    //        // ✔ textbox rules
    //        if (type == FieldType.Textbox)
    //        {
    //            //if (e.MaxLength.HasValue)
    //            //    Add("maxlength", e.MaxLength.Value.ToString());

    //            if (!string.IsNullOrEmpty(e.AsyncUrl))
    //                Add("async", e.AsyncUrl);
    //            // ✔ ⭐ 新增 map
    //            if (!string.IsNullOrEmpty(e.Target))
    //                Add("map", e.Target);

    //            if (!string.IsNullOrEmpty(e.Pattern))
    //                Add("pattern", e.Pattern);
    //        }
    //        // ✔ file rules
    //        if (type == FieldType.File)
    //        {
    //            if (!string.IsNullOrEmpty(e.AsyncUrl))
    //                Add("async", e.AsyncUrl);

    //            if (!string.IsNullOrEmpty(e.Target))
    //                Add("map", e.Target);

    //            // ⭐ accept (用 Pattern 或自訂欄位)
    //            if (!string.IsNullOrEmpty(e.Pattern))
    //                Add("accept", e.Pattern);

    //            // ⭐ maxsize（你可以用 Max 當 MB）
    //            if (e.Max.HasValue)
    //                Add("maxsize", e.Max.Value.ToString());
    //        }
    //        return rules;
    //    }

    //    // =========================
    //    // Behavior mapping
    //    // =========================
    //    private static List<BehaviorRule> MapBehavior(BaseDynamicField e)
    //    {
    //        var rules = new List<BehaviorRule>();
    //        var type = Enum.Parse<FieldType>(e.EnumType.ToString());

    //        void Add(string name)
    //        {
    //            if (RuleSchemaRegistry.AllowBehavior(type, name))
    //                rules.Add(new BehaviorRule(name));
    //        }

    //        if (e.Readonly == true)
    //            Add("readonly");

    //        if (e.EnumType.ToString() == "Hidden" || e.IsDisplay == false)
    //            Add("hidden");

    //        return rules;
    //    }
    //}
    public class BaseDynamicField
    {
        /// <summary>
        /// 欄位代碼
        /// </summary>
        public string ColId { get; set; }

        /// <summary>
        /// 欄位名稱
        /// </summary>
        public string ColName { get; set; }


        public string ColValue { get; set; } = "";
        /// <summary>
        /// 預設填值
        /// </summary>
        public string? DefaultValue { get; set; } = "";

        private string _enumTypeStr = "label";
        //[JsonInclude]

        //internal string EnumTypeRaw
        //{
        //    get => _enumTypeStr;
        //    set => _enumTypeStr = value;
        //}

        [JsonProperty("EnumTypeRaw")]
        internal string EnumTypeRaw
        {
            get => _enumTypeStr;
            set => _enumTypeStr = value;
        }
        public FieldType EnumType => ParseEnum(_enumTypeStr);


        // 必需輸入 

        private string _must = "Y";

        [JsonProperty("MustRaw")]
        internal string MustRaw
        {
            get => _must;
            set => _must = value;
        }

        public bool IsMust
        {
            get => _must.Trim() == "Y";
            set => _must = value ? "Y" : "N";
        }
        /// <summary>
        /// 重態欄位產生區塊標識
        /// </summary>
        public string Section { get; set; } = "";
        /// <summary>
        /// 最小值判斷(數值、日期)
        /// </summary>
        public int? Min { get; set; } // 使用 string 以相容數字(0)與日期(2024-01-01)
        /// <summary>
        ///  /// <summary>
        /// 最大值判斷(數值、日期)
        /// </summary>
        /// </summary>
        public int? Max { get; set; }

        /// <summary>
        /// 檢查正則表示
        /// </summary>
        public string Pattern { get; set; } = "";
        public string Col { get; set; }



        public string IsScore { get; set; }



        /// <summary>
        /// 未輸入時佔位值
        /// </summary>
        public string? Placeholder { get; set; } = "";
        /// <summary>
        /// 非定位時，欄位寬位
        /// </summary>
        public int? Width { get; set; } = 3; // bootstrap col
        public int? Order { get; set; } = 1;   // 顯示順序
        /// <summary>
        /// 只讀
        /// </summary>
        public bool Readonly { get; set; } = false;

        private string _displayStr = "Y";

        [JsonProperty("DisplayRaw")]
        internal string DisplayRaw
        {
            get => _displayStr;
            set => _displayStr = value;
        }

        public bool IsDisplay => _displayStr == "Y";
        /// <summary>
        /// 是否隱藏
        /// </summary>
        //public bool Hidden
        //{
        //    get => Display == "N";
        //}



        public string? OptionStr { get; set; }


        public string SheetName { get; set; } = "";

        public string SheetColumn { get; set; } = "";

        /// <summary>
        /// 欄位定位點
        /// </summary>
        public string Position { get; set; } = "";

        /// <summary>
        /// 欄位描述
        /// </summary>
        public string ColumnDesc { get; set; } = "";

        protected string RedirectStr { get; set; } = "";

        // 必需輸入
        public bool IsRedirect
        {
            get => RedirectStr.Trim() == "Y";
            set => RedirectStr = value ? "Y" : "N";
        }

        public bool InverseSelect
        {
            get => ColId.Trim() == "maker_type";
        }
        public string Target
        {
            get
            {
                if (ColId.Trim() == "facility_address" && !string.IsNullOrEmpty(AsyncUrl))
                {
                    return "latitude=latitude,longitude=longitude";
                }
                return "";
            }
            //set;

        }

        public string AsyncUrl { get; set; } = "";
        public Dictionary<string, BaseDynamicField> Children { get; set; } = new();


        public BaseDynamicField()
        {
            EnumTypeRaw = "label";
        }

        private static FieldType ParseEnum(string value)
        {
            var s = value?.Trim().ToLower() ?? "";

            if (s.Contains("radio")) return FieldType.Radio;
            if (s.Contains("date") || s.Contains("picker")) return FieldType.Date;
            if (s.Contains("numeric") || s.Contains("deci")) return FieldType.Numeric;
            if (s.Contains("textarea") || s.Contains("area")) return FieldType.Textarea;
            if (s.Contains("text")) return FieldType.Textbox;
            if (s.Contains("select2")) return FieldType.Select2;
            if (s.Contains("drop")) return FieldType.Dropdown;
            if (s.Contains("file")) return FieldType.File;

            return FieldType.Label;
        }
        // ⭐ clone + override type
        public BaseDynamicField WithType(FieldType type)
        {
            return new BaseDynamicField
            {
                ColId = this.ColId,
                ColName = this.ColName,
                Col = this.Col,
                ColValue = this.ColValue,

                DefaultValue = this.DefaultValue,

                IsMust = this.IsMust,
                Pattern = this.Pattern,
                Min = this.Min,
                Max = this.Max,

                Readonly = this.Readonly,

                OptionStr = this.OptionStr,

                Width = this.Width,
                Order = this.Order,

                DisplayRaw = this.DisplayRaw,
                EnumTypeRaw = type.ToString().ToLower(),

                Children = this.Children // ⚠ 如果要完全安全要 deep copy
            };
        }
        public BaseDynamicField Clone()
        {
            return new BaseDynamicField()
            {
                ColId = this.ColId,
                ColName = this.ColName,
                Col = this.Col,
                ColValue = this.ColValue,

                DefaultValue = this.DefaultValue,

                IsMust = this.IsMust,
                Min = this.Min,
                Max = this.Max,
                Pattern = this.Pattern,

                Readonly = this.Readonly,

                OptionStr = this.OptionStr,

                Width = this.Width,
                Order = this.Order,

                EnumTypeRaw = this.EnumTypeRaw,
                DisplayRaw = this.DisplayRaw,

                Children = this.Children // ⚠ 若要安全需 deep clone
            };
        }
        //public BaseDynamicField ApplyTagHelper(DfFieldTagHelper t)
        //{
        //    return new BaseDynamicField(this.EnumType)
        //    {
        //        ColName = this.ColName ?? t.Name,
        //        ColId = this.ColId ?? t.Name,
        //        ColValue = this.ColValue ?? t.Value,
        //        Col = this.Col ?? t.Col,
        //        Must = string.IsNullOrEmpty(t.IsMust.ToString()) ? this.Must : t.IsMust.Value,
        //        AsyncUrl = this.AsyncUrl ?? t.AsyncUrl,
        //        Min = this.Min ?? t.Min,
        //        Max = this.Max ?? t.Max,
        //        Pattern = this.Pattern ?? t.Pattern,
        //        Placeholder = this.Placeholder ?? t.Placeholder,
        //        DefaultValue = this.DefaultValue ?? t.DefaultValue,
        //        OptionStr = this.OptionStr ?? t.OptionStr,
        //        Readonly = string.IsNullOrEmpty(t.Readonly.ToString()) ? this.Readonly : t.Readonly.Value,
        //        DisplayStr = t.IsDisplay == true ? "Y" : "N",
        //        //Target = this.Target ?? t.Target,
        //        Width = this.Width ?? t.Width,
        //        Order = this.Order ?? t.Order,
        //    };
        //}

    }


    public static class OptionParser
    {
        public static List<SelectItem> Parse(string optionstr)
        {
            var list = new List<SelectItem>();

            if (string.IsNullOrWhiteSpace(optionstr))
                return list;

            if (optionstr.EndsWith(".asmx"))
            {
                var str = optionstr.Split(',');
                return list;// ExtendTool.CallAsmxPostAsync(str[1], str[0]).Result; 
            }

            if (optionstr.Contains('^'))
            {
                return optionstr
                   .Split(new[] { '^' }, StringSplitOptions.RemoveEmptyEntries)
                   .Select(group =>
                   {
                       var parts = group.Split(',');
                       return new SelectItem
                       {

                           Text = parts.Length > 0 ? parts[0].Trim() : "",
                           Value = parts.Length > 1 ? parts[1].Trim() : "",
                           Color = parts.Length > 1 ? parts[1].Trim() : ""
                       };
                   })
                   .ToList();
            }
            if (Regex.IsMatch(optionstr, ",|;|/"))
            {
                return optionstr.Split(new char[] { ',', ';', '/' }, StringSplitOptions.RemoveEmptyEntries)
                   .Select(item => new SelectItem
                   {
                       Value = item?.Trim() ?? "",
                       Text = item?.Trim() ?? "",
                       Color = item?.Trim() ?? ""
                   })
                   .ToList();
            }

            return list;
        }
    }


    public class SelectItem
    {
        public string Value { get; set; }
        public string Color { get; set; }  // 新增顏色
        public string Text { get; set; }
    }


}