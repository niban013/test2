﻿using Microsoft.AspNet.SignalR;
using mvc5.autofac;
using Quartz;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.Service
{
    public class JobStatusListener : IJobListener
    {
        public string Name => "GlobalJobStatusListener";

        public Task JobToBeExecuted(IJobExecutionContext context, CancellationToken cancellationToken = default)
        {
            var scheduler = context.Scheduler;
            var key = context.JobDetail.Key.Name;

            scheduler.Context.Put($"{key}_IsRunning", true);
            // 執行前清除最後完成時間 (因為正在執行)
            var timeKey = $"{key}_LastCompleted";
            scheduler.Context.Remove(timeKey);
            var jobKey = context.JobDetail.Key;
            var quartzService = context.Scheduler.Context.Get("QuartzService") as IQuartzService;
            var jobinfo = quartzService.GetJobAsync(jobKey);

            //var hub = GlobalHost.ConnectionManager.GetHubContext<JobHub>();
            //hub.Clients.All.jobUpdated($"Job {context.JobDetail.Key.Name} 已完成");
            // SignalR 更新（同前）
            var hub = GlobalHost.ConnectionManager.GetHubContext<JobHub>();
            hub.Clients.All.updateTrigger(jobinfo);
            //var hub = GlobalHost.ConnectionManager.GetHubContext<JobHub>();
            //hub.Clients.All.jobUpdated($"Job {context.JobDetail.Key.Name} 執行開始");

            return Task.CompletedTask;
        }

        public Task JobExecutionVetoed(IJobExecutionContext context, CancellationToken cancellationToken = default)
        {
            return Task.CompletedTask;
        }

        public Task JobWasExecuted(IJobExecutionContext context, JobExecutionException jobException, CancellationToken cancellationToken = default)
        {
            var scheduler = context.Scheduler;
            var key = context.JobDetail.Key.Name;
            var cnt = $"{key}_CompletedCount";
            scheduler.Context.Put($"{key}_IsRunning", false);
            scheduler.Context.Put($"{key}_LastCompleted", DateTime.Now);
            // 累加完成次數（無論每次處理多少筆，這裡就是「完成 1 次」）
             
            // 更新完成次數
            if (!scheduler.Context.ContainsKey(cnt))
                scheduler.Context[cnt] = 0;
            scheduler.Context[cnt] = (int)scheduler.Context[cnt] + 1;

            var jobKey = context.JobDetail.Key;
            var quartzService = context.Scheduler.Context.Get("QuartzService") as IQuartzService;
            var jobinfo = quartzService.GetJobAsync(jobKey);

            //var hub = GlobalHost.ConnectionManager.GetHubContext<JobHub>();
            //hub.Clients.All.jobUpdated($"Job {context.JobDetail.Key.Name} 已完成");
            // SignalR 更新（同前）
            var hub = GlobalHost.ConnectionManager.GetHubContext<JobHub>();
            hub.Clients.All.updateTrigger(jobinfo);

            return Task.CompletedTask;
        }
    }
}