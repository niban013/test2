﻿using ClosedXML.Excel;
using MiniExcelLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Service
{
    public class ExcelExportService
    { // 允許匯出的資料表白名單
        private readonly HashSet<string> allowedTables = new HashSet<string>
    {
        "Customers",
        "Orders",
        "Products"
    };

        private readonly string _connStr = "Server=.;Database=TestDB;User Id=sa;Password=1234;";

        public void ImportCustomers(Stream excelStream, int batchSize = 5000)
        {
            using (var conn = new SqlConnection(_connStr))
            {
                conn.Open();

                // ⚡ 建議：匯入前資料庫 Recovery Model 為 Simple 或 Bulk-Logged
                using (var tran = conn.BeginTransaction())
                {
                    try
                    {
                        // 1️⃣ 讀取 Excel 流式資料
                        var rows = MiniExcel.Query(excelStream, useHeaderRow: true);

                        // 2️⃣ 建立 DataTable 模板
                        var dt = new DataTable();
                        dt.Columns.Add("CustomerId", typeof(int));
                        dt.Columns.Add("CustomerName", typeof(string));
                        dt.Columns.Add("Age", typeof(int));

                        int count = 0;

                        // 3️⃣ SqlBulkCopy 使用 TableLock 以最小化日誌
                        using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tran))
                        {
                            bulk.DestinationTableName = "Customers";
                            bulk.BatchSize = batchSize;
                            bulk.ColumnMappings.Add("CustomerId", "CustomerId");
                            bulk.ColumnMappings.Add("CustomerName", "CustomerName");
                            bulk.ColumnMappings.Add("Age", "Age");

                            foreach (var row in rows)
                            {
                                var dict = row as IDictionary<string, object>;
                                var dr = dt.NewRow();
                                dr["CustomerId"] = dict["客戶編號"];
                                dr["CustomerName"] = dict["客戶名稱"];
                                dr["Age"] = dict["年齡"];
                                dt.Rows.Add(dr);
                                count++;

                                // 4️⃣ 每 batchSize 行寫入一次
                                if (count % batchSize == 0)
                                {
                                    bulk.WriteToServer(dt);
                                    dt.Clear();
                                }
                            }

                            // 5️⃣ 寫入剩下的資料
                            if (dt.Rows.Count > 0)
                            {
                                bulk.WriteToServer(dt);
                                dt.Clear();
                            }
                        }

                        // 6️⃣ 成功 commit
                        tran.Commit();
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
        public byte[] ExportCustomers(string tableName)
        {
            
            //if (!allowedTables.Contains(tableName))
            //    throw new System.ArgumentException("無效的資料表名稱");
            var ms = new MemoryStream();
            string connStr = "Server=(localdb)\\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;";
            string sql = "SELECT * FROM customers"; // 資料幾十萬筆都 OK
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT * FROM Customers", conn))
                using (var reader = cmd.ExecuteReader())
                using (ms = new MemoryStream())
                {
                    MiniExcel.SaveAs(ms, reader, sheetName: "Customers");
                    ms.Position = 0;

                    // 第2階段：用 ClosedXML 套用樣式
                    using (var wb = new XLWorkbook(ms))
                    {
                        var ws = wb.Worksheet(1);

                        // Header 藍底白字
                        var headerRange = ws.RangeUsed().FirstRow();
                        headerRange.Style.Fill.BackgroundColor = XLColor.LightBlue;
                        headerRange.Style.Font.FontColor = XLColor.White;
                        headerRange.Style.Font.Bold = true;
                        headerRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                        // 數字右對齊、文字左對齊
                        var usedRange = ws.RangeUsed();
                        foreach (var cell in usedRange.CellsUsed().Skip(headerRange.CellCount()))
                        {
                            if (double.TryParse(cell.Value.ToString(), out _))
                                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                            else
                                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                        }

                        // 自動欄寬
                        ws.Columns().AdjustToContents();

                        // 重新寫回 MemoryStream
                        using (var outMs = new MemoryStream())
                        {
                            wb.SaveAs(outMs);
                            return outMs.ToArray();
                        }
                    }

                }
            }
        }
        
    }
}