namespace mvc5.autofac
{
    public enum DbKeys
    {
        LocalSqlServer,
        SqlServer_DB1,
        SqlServer_DB2,
        Oracle_DB1,
        DefaultConnection,
    }
}
