﻿using Autofac;
using Autofac.Core;
using Microsoft.AspNet.SignalR;
using mvc5.Controllers;
using mvc5.Service;
using Quartz;
using Quartz.Impl.Matchers;
using Quartz.Impl.Triggers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using static System.Formats.Asn1.AsnWriter;

namespace mvc5.autofac
{
    public class QuartzService : IQuartzService
    {
        private readonly ISchedulerFactory _factory;
        public IScheduler Scheduler { get; private set; }  // <-- 新增公開屬性

        private readonly ILifetimeScope _scope;
        public QuartzService(ISchedulerFactory factory, ILifetimeScope scope)
        {
            _scope = scope;
            _factory = factory;
        }
        public async Task NotifyFrontendAsync(string message)
        {
            var context = GlobalHost.ConnectionManager.GetHubContext<JobHub>();
            context.Clients.All.jobUpdated(message);  // ✅ 主動推送更新
        }
        public async Task<bool> IsJobRunning(JobKey jobKey)
        {
            var currentlyExecuting = await Scheduler.GetCurrentlyExecutingJobs();
            return currentlyExecuting.Any(x => x.JobDetail.Key.Equals(jobKey));
        }
        //public async Task<IScheduler> GetScheduler()
        //{
        //    return _scheduler;
        //}
        public async Task StartAsync()
        {
            if (Scheduler == null || Scheduler.IsShutdown)
            {
                Scheduler = await _factory.GetScheduler();
                Scheduler.Context.Put("QuartzService", this);
                await Scheduler.Start();
            }
            //if (!_scheduler.IsStarted)
            //    await _scheduler.Start();
        }
        public async Task<JobViewModel> GetJobAsync(JobKey jobKey)
        { 
            var triggers = await Scheduler.GetTriggersOfJob(jobKey);
           
            var detail = await Scheduler.GetJobDetail(jobKey);
          

            ITrigger trigger = triggers.FirstOrDefault();
            var triggerState = trigger != null
                ? await Scheduler.GetTriggerState(trigger.Key)
                : TriggerState.None;

            // 從 Scheduler.Context 取得 CompletedCount 與 CompletedTime
            var context = Scheduler.Context;
            context.TryGetValue($"{jobKey.Name}_IsRunning", out object isRunningObj);
            context.TryGetValue($"{jobKey.Name}_CompletedCount", out object completedCountObj);
            context.TryGetValue($"{jobKey.Name}_LastCompleted", out object completedTimeObj);

            bool isRunning = (bool?)isRunningObj ?? false;
            DateTime? lastCompleted = (DateTime?)completedTimeObj;
            bool isPaused = trigger != null && (await Scheduler.GetTriggerState(trigger.Key)) == TriggerState.Paused;
            int? completedCount = ((int?)completedCountObj) is int c ? c : 0;

            string status;
            if (isRunning) status = "Running";
            else if (isPaused) status = "Paused";
            else if (lastCompleted.HasValue) status = "Completed";
            else status = "None";
            var model = new JobViewModel
            {
                JobName = jobKey.Name,
                Group = jobKey.Group,
                Description = detail.Description,
                Trigger = trigger?.Key.Name ?? "(無)",
                NextFireTime = trigger?.GetNextFireTimeUtc()?.ToLocalTime().DateTime,
                PreviousFireTime = trigger?.GetPreviousFireTimeUtc()?.ToLocalTime().DateTime,
                CompletedTime = lastCompleted,
                CompletedCount = completedCount,
                State = status
            };
            return model;
        }
        /// <summary>
        /// 取得所有 Job 狀態與資訊
        /// </summary>
        public async Task<List<JobViewModel>> GetAllJobsAsync()
        {
            var jobList = new List<JobViewModel>();
            var jobGroups = await Scheduler.GetJobGroupNames();

            foreach (var group in jobGroups)
            {
                var jobKeys = await Scheduler.GetJobKeys(GroupMatcher<JobKey>.GroupEquals(group));

                foreach (var jobKey in jobKeys)
                {
                    var detail = await Scheduler.GetJobDetail(jobKey);
                    var triggers = await Scheduler.GetTriggersOfJob(jobKey);

                    ITrigger trigger = triggers.FirstOrDefault();
                    var triggerState = trigger != null
                        ? await Scheduler.GetTriggerState(trigger.Key)
                        : TriggerState.None;

                    // 從 Scheduler.Context 取得 CompletedCount 與 CompletedTime
                    var context = Scheduler.Context;
                    context.TryGetValue($"{jobKey.Name}_IsRunning", out object isRunningObj);
                    context.TryGetValue($"{jobKey.Name}_CompletedCount", out object completedCountObj);
                    context.TryGetValue($"{jobKey.Name}_LastCompleted", out object completedTimeObj);

                    bool isRunning = (bool?)isRunningObj ?? false;
                    DateTime? lastCompleted = (DateTime?)completedTimeObj;
                    bool isPaused = trigger != null && (await Scheduler.GetTriggerState(trigger.Key)) == TriggerState.Paused;
                    int? completedCount = ((int?)completedCountObj) is int c ? c : 0;

                    string status;
                    if (isRunning) status = "Running";
                    else if (isPaused) status = "Paused";
                    else if (lastCompleted.HasValue) status = "Completed";
                    else status = "None";

                    jobList.Add(new JobViewModel
                    {
                        JobName = jobKey.Name,
                        Group = jobKey.Group,
                        Description = detail.Description,
                        Trigger = trigger?.Key.Name ?? "(無)",
                        NextFireTime = trigger?.GetNextFireTimeUtc()?.ToLocalTime().DateTime,
                        PreviousFireTime = trigger?.GetPreviousFireTimeUtc()?.ToLocalTime().DateTime,
                        CompletedTime = lastCompleted,
                        CompletedCount = completedCount,
                        State = status
                    });
                }
            }

            return jobList;
        }
        //public async Task ScheduleAllJobs()
        //{
        //    // 從 Autofac 解析所有 IJob 類別
        //    var jobTypes = _scope.ComponentRegistry.Registrations
        //        .SelectMany(r => r.Services.OfType<TypedService>())
        //        .Where(s => typeof(IJob).IsAssignableFrom(s.ServiceType))
        //        .Select(s => s.ServiceType)
        //        .ToList();

        //    foreach (var jobType in jobTypes)
        //    {
        //        string jobName = jobType.Name;

        //        // 建 JobDetail
        //        IJobDetail job = JobBuilder.Create(jobType)
        //            .WithIdentity(jobName, "DefaultGroup")
        //            .Build();

        //        // 建定時 Trigger (例如每 10 秒執行一次)
        //        ITrigger trigger = TriggerBuilder.Create()
        //            .WithIdentity(jobName + "_Trigger", "DefaultGroup")
        //            .StartNow()
        //            .WithSimpleSchedule(x => x.WithIntervalInSeconds(10).RepeatForever())
        //            .Build();

        //        await _scheduler.ScheduleJob(job, trigger);
        //    }
        //}
        public async Task<DateTimeOffset> AddJob<T>(DateTimeOffset startTime, TimeSpan interval, Dictionary<string, object> jobDataMap) where T : IJob
        {
            if (Scheduler == null || !Scheduler.IsStarted)
                await StartAsync(); // 確保 scheduler 已啟動
            
            var jobName = typeof(T).Name;

            var job = JobBuilder.Create<T>()
                .WithIdentity(jobName, jobName + "_Group")
                .Build();

            job.JobDataMap.PutAll(jobDataMap);

            var trigger = new SimpleTriggerImpl(
                jobName + "_SimpleTrigger",
                jobName + "_TriggerGroup",
                startTime,
                null,
                SimpleTriggerImpl.RepeatIndefinitely,
                interval
            );

            return await Scheduler.ScheduleJob(job, trigger);
        }

        public async Task<DateTimeOffset> AddJob<T>(string cronTime, string jobData) where T : IJob
        {
            if (Scheduler == null || !Scheduler.IsStarted)
                await StartAsync(); // 確保 scheduler 已啟動

            var jobName = typeof(T).Name;

            var job = JobBuilder.Create<T>()
                .WithIdentity(jobName, jobName + "_Group")
                .UsingJobData("jobData", jobData)
                .Build();

            var trigger = new CronTriggerImpl(
                jobName + "_CronTrigger",
                jobName + "_TriggerGroup",
                cronTime
            );

            return await Scheduler.ScheduleJob(job, trigger);
        }

        public async Task<bool> UpdateTime<T>(TimeSpan interval) where T : IJob
        {
            if (Scheduler == null || !Scheduler.IsStarted)
                await StartAsync(); // 確保 scheduler 已啟動

            var jobName = typeof(T).Name;
            var triggerKey = new TriggerKey(jobName + "_SimpleTrigger", jobName + "_TriggerGroup");

            var trigger = await Scheduler.GetTrigger(triggerKey) as SimpleTriggerImpl;
            trigger.RepeatInterval = interval;

            await Scheduler.RescheduleJob(triggerKey, trigger);
            return true;
        }

        public async Task<bool> UpdateTime<T>(string cronTime) where T : IJob
        {
            if (Scheduler == null || !Scheduler.IsStarted)
                await StartAsync(); // 確保 scheduler 已啟動

            var jobName = typeof(T).Name;
            var triggerKey = new TriggerKey(jobName + "_CronTrigger", jobName + "_TriggerGroup");

            var trigger = await Scheduler.GetTrigger(triggerKey) as CronTriggerImpl;
            trigger.CronExpression = new CronExpression(cronTime);

            await Scheduler.RescheduleJob(triggerKey, trigger);
            return true;
        }

        public async Task<bool> Delete<T>() where T : IJob
        {
            if (Scheduler == null || !Scheduler.IsStarted)
                await StartAsync(); // 確保 scheduler 已啟動

            var jobName = typeof(T).Name;
            var jobKey = new JobKey(jobName, jobName + "_Group");
            return await Scheduler.DeleteJob(jobKey);
        }

        public void PauseAll() => Scheduler.PauseAll();
        public void ResumeAll() => Scheduler.ResumeAll();
        public async Task ShutdownAsync()
        {
            if (Scheduler != null && !Scheduler.IsShutdown)
            {
                await Scheduler.Shutdown(waitForJobsToComplete: true);
            }
        }
        public void Shutdown() => Scheduler.Shutdown(waitForJobsToComplete: true);
    }
}