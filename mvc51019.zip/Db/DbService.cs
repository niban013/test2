﻿//using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5
{
    public class DbService : IDbService
    {
        private readonly string _connectionString;

        public DbService(string connectionName = "DefaultConnection")
        {
            _connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;";//ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;
        }

        private IDbConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }

        public async Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return await conn.QueryAsync<T>(sql, param, commandType: commandType);
            }
        }
        public IEnumerable<T> Query<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return conn.Query<T>(sql, param, commandType: commandType);
            }
        }
        public async Task<T> QueryFirstOrDefaultAsync<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return await conn.QueryFirstOrDefaultAsync<T>(sql, param, commandType: commandType);
            }
        }

        public async Task<int> ExecuteAsync(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return await conn.ExecuteAsync(sql, param, commandType: commandType);
            }
        }
        public async Task<DataTable> QueryDataTableAsync(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                using (var reader = await conn.ExecuteReaderAsync(sql, param, commandType: commandType))
                {
                    var dataTable = new DataTable();
                    dataTable.Load(reader);
                    return dataTable;
                } 
            } 
        }
    }
}
