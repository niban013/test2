﻿using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            filters.Add(new FrameOptionsFilter());
       
            filters.Add(new SSOAuthorizeAttribute()); // 全域授權攔截
        }
    }
}
