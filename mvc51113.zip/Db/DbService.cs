﻿//using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5
{
    public class DbService : IDbService
    {
        private readonly string _connectionString;

        public DbService(string connectionName = "DefaultConnection")
        {
            _connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;";//ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;
        }

        private IDbConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }

        public async Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return await conn.QueryAsync<T>(sql, param, commandType: commandType);
            }
        }
        public IEnumerable<T> Query<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return conn.Query<T>(sql, param, commandType: commandType);
            }
        }
        public async Task<T> QueryFirstOrDefaultAsync<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return await conn.QueryFirstOrDefaultAsync<T>(sql, param, commandType: commandType);
            }
        }

        public async Task<int> ExecuteAsync(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                return await conn.ExecuteAsync(sql, param, commandType: commandType);
            }
        }
        public async Task<DataTable> QueryDataTableAsync(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = CreateConnection())
            {
                using (var reader = await conn.ExecuteReaderAsync(sql, param, commandType: commandType))
                {
                    var dataTable = new DataTable();
                    dataTable.Load(reader);
                    return dataTable;
                } 
            } 
        }



        /// <summary>
        /// 將 DataTable 批次插入 MSSQL
        /// </summary>
        /// <param name="table">DataTable 資料來源</param>
        /// <param name="tableName">資料表名稱</param>
        public async Task InsertDataTableAsync(DataTable table, string tableName)
        {
            if (table == null) throw new ArgumentNullException(nameof(table));
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException(nameof(tableName));
            if (table.Rows.Count == 0) return;

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();

                // 建立單一 INSERT 多 VALUES 的 SQL
                string sql = DataTableToBatchInsertSql(table, tableName);

                using (var cmd = new SqlCommand(sql, conn))
                {
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }
        public static async Task BulkInsertAsync(DataTable table, string tableName, string connectionString, DbTypeEnum dbType)
        {
            if (table == null || table.Rows.Count == 0) return;

            switch (dbType)
            {
                case DbTypeEnum.SqlServer:
                    await BulkInsertSqlServerAsync(table, tableName, connectionString);
                    break;
                case DbTypeEnum.Oracle:
                    await BulkInsertOracleAsync(table, tableName, connectionString);
                    break;
                default:
                    throw new NotSupportedException("不支援的資料庫類型");
            }
        }

        // ---------------- SQL Server ----------------
        private static async Task BulkInsertSqlServerAsync(DataTable table, string tableName, string connectionString)
        {
            using var conn = new SqlConnection(connectionString);
            await conn.OpenAsync();

            var sb = new StringBuilder();
            sb.AppendLine("BEGIN");
            for (int i = 0; i < table.Rows.Count; i++)
            {
                sb.Append($"INSERT INTO {tableName} (");
                sb.Append(string.Join(",", table.Columns.Cast<DataColumn>().Select(c => $"[{c.ColumnName}]")));
                sb.Append(") VALUES (");
                sb.Append(string.Join(",", table.Columns.Cast<DataColumn>().Select(c => $"@{c.ColumnName}_{i}")));
                sb.AppendLine(");");
            }
            sb.AppendLine("END;");

            using var cmd = new SqlCommand(sb.ToString(), conn);

            for (int i = 0; i < table.Rows.Count; i++)
            {
                foreach (DataColumn col in table.Columns)
                {
                    string paramName = $"@{col.ColumnName}_{i}";
                    object value = table.Rows[i][col] ?? DBNull.Value;

                    // 自動判斷類型
                    SqlDbType sqlType = col.DataType switch
                    {
                        Type t when t == typeof(string) => SqlDbType.NVarChar,
                        Type t when t == typeof(int) => SqlDbType.Int,
                        Type t when t == typeof(long) => SqlDbType.BigInt,
                        Type t when t == typeof(decimal) => SqlDbType.Decimal,
                        Type t when t == typeof(double) => SqlDbType.Float,
                        Type t when t == typeof(float) => SqlDbType.Real,
                        Type t when t == typeof(DateTime) => SqlDbType.DateTime,
                        Type t when t == typeof(bool) => SqlDbType.Bit,
                        Type t when t == typeof(byte[]) => SqlDbType.VarBinary,
                        _ => SqlDbType.NVarChar
                    };

                    cmd.Parameters.Add(paramName, sqlType).Value = value;
                }
            }

            await cmd.ExecuteNonQueryAsync();
        }

        // ---------------- Oracle ----------------
        private static async Task BulkInsertOracleAsync(DataTable table, string tableName, string connectionString)
        {
            using var conn = new OracleConnection(connectionString);
            await conn.OpenAsync();

            var sb = new StringBuilder();
            sb.AppendLine("BEGIN");
            for (int i = 0; i < table.Rows.Count; i++)
            {
                sb.Append($"INSERT INTO {tableName} (");
                sb.Append(string.Join(",", table.Columns.Cast<DataColumn>().Select(c => c.ColumnName)));
                sb.Append(") VALUES (");
                sb.Append(string.Join(",", table.Columns.Cast<DataColumn>().Select(c => $":{c.ColumnName}_{i}")));
                sb.AppendLine(");");
            }
            sb.AppendLine("END;");

            using var cmd = new OracleCommand(sb.ToString(), conn) { BindByName = true };

            for (int i = 0; i < table.Rows.Count; i++)
            {
                foreach (DataColumn col in table.Columns)
                {
                    string paramName = $":{col.ColumnName}_{i}";
                    object value = table.Rows[i][col] ?? DBNull.Value;

                    OracleDbType oracleType = col.DataType switch
                    {
                        Type t when t == typeof(string) => OracleDbType.NVarchar2,
                        Type t when t == typeof(int) => OracleDbType.Int32,
                        Type t when t == typeof(long) => OracleDbType.Int64,
                        Type t when t == typeof(decimal) => OracleDbType.Decimal,
                        Type t when t == typeof(double) => OracleDbType.BDouble,
                        Type t when t == typeof(float) => OracleDbType.BFloat,
                        Type t when t == typeof(DateTime) => OracleDbType.Date,
                        Type t when t == typeof(bool) => OracleDbType.Int16,
                        Type t when t == typeof(byte[]) => OracleDbType.Blob,
                        _ => OracleDbType.NVarchar2
                    };

                    cmd.Parameters.Add(paramName, oracleType).Value = value;
                }
            }

            await cmd.ExecuteNonQueryAsync();
        }
        /// <summary>
        /// 將 DataTable 轉成單一 INSERT 多 VALUES 語法
        /// </summary>
        private string DataTableToBatchInsertSql(DataTable table, string tableName)
        {
            var sb = new StringBuilder();
            var columns = new StringBuilder();

            for (int i = 0; i < table.Columns.Count; i++)
            {
                if (i > 0) columns.Append(", ");
                columns.Append($"[{table.Columns[i].ColumnName}]");
            }

            sb.Append($"INSERT INTO [{tableName}] ({columns}) VALUES ");

            for (int r = 0; r < table.Rows.Count; r++)
            {
                var row = table.Rows[r];
                if (r > 0) sb.Append(", ");

                sb.Append("(");

                for (int c = 0; c < table.Columns.Count; c++)
                {
                    if (c > 0) sb.Append(", ");

                    var col = table.Columns[c];
                    var val = row[col];

                    if (val == null || val == DBNull.Value)
                    {
                        sb.Append("NULL");
                    }
                    else if (col.DataType == typeof(string))
                    {
                        string s = val.ToString().Replace("'", "''");
                        sb.Append($"N'{s}'"); // Unicode 支援簡體中文
                    }
                    else if (col.DataType == typeof(DateTime))
                    {
                        DateTime dt = (DateTime)val;
                        sb.Append($"'{dt:yyyy-MM-dd HH:mm:ss.fff}'");
                    }
                    else if (col.DataType == typeof(bool))
                    {
                        sb.Append(((bool)val) ? "1" : "0");
                    }
                    else
                    {
                        sb.Append(val);
                    }
                }

                sb.Append(")");
            }

            sb.Append(";");

            return sb.ToString();
        }






    }
}
