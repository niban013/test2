﻿using MvcDbFactoryDemo.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc5.autofac
{
    public class AutofacConfig
    {
        public static IContainer Configure()
        {
            var builder = new ContainerBuilder();

            // 註冊 Connection Factory
            builder.Register<Func<string, IDbConnection>>(c =>
            {
                return dbKey =>
                {
                    switch (dbKey)
                    {
                        case "SqlServer_DB1":
                            return new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString);

                        case "Oracle_DB1":
                            return new OracleConnection(ConfigurationManager.ConnectionStrings["Oracle_DB1"].ConnectionString);

                        case "SqlServer_DB2":
                            return new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServer_DB2"].ConnectionString);

                        default:
                            throw new ArgumentException($"找不到指定的 dbKey: {dbKey}");
                    }
                };
            });

            // 註冊 DbSession
            builder.Register<IDbSession>(c =>
            {
                var factory = c.Resolve<Func<string, IDbConnection>>();
                // dbKey 在 Resolve 時決定
                var dbKey = c.ResolveNamed<string>("dbKey");
                var conn = factory(dbKey);
                return new DbSession(conn);
            }).InstancePerLifetimeScope();

            // 註冊 Repository (可以自動注入 IDbSession)
            builder.RegisterType<UserRepository>();

            return builder.Build();
        }
    }
}
