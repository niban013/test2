﻿using mvc5.autofac;
using mvc5.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class JobController : Controller
    {
        private readonly IQuartzService _quartzService;

        public JobController(IQuartzService quartzService)
        {
            _quartzService = quartzService;
        }

        public async Task<ActionResult> StartJob()
        {
            await _quartzService.StartAsync();

            await _quartzService.AddJob<ExampleJob>(
                DateTimeOffset.UtcNow.AddSeconds(1),
                TimeSpan.FromSeconds(5),
                new Dictionary<string, object> { { "Message", "Hello Quartz" } }
            );

            return Content("Job 已啟動");
        }
    }
}