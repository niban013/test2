﻿using MiniExcelLibs;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class NpoiMemoryStream : MemoryStream
    {
        public bool AllowClose { get; set; }
        public NpoiMemoryStream()
        {
            AllowClose = true;
        }

        public override void Close()
        {
            if (AllowClose)
            {
                base.Close();
            }
        }
    }
    public class DownloadController : Controller
    {
        // 模擬進度的儲存區（記憶體）
        private static readonly ConcurrentDictionary<string, int> ProgressStore = new ConcurrentDictionary<string, int>();

        // ✅ Step 1. 前端呼叫開始下載
        [HttpPost]
        public ActionResult Start(string fileName)
        {
            string downloadId = Guid.NewGuid().ToString();
            ProgressStore[downloadId] = 0;

            // 開新 Thread 模擬背景產生檔案
            Task.Run(() =>
            {
                for (int i = 1; i <= 100; i++)
                {
                    Thread.Sleep(100); // 模擬耗時
                    ProgressStore[downloadId] = i;
                }

                // 模擬產生檔案
                var filePath = Path.Combine(Server.MapPath("~/App_Data"), $"{fileName}.txt");
                System.IO.File.WriteAllText(filePath, "這是模擬產生的檔案內容。");
            });

            return Json(new { success = true, id = downloadId });
        }

        // ✅ Step 2. 前端輪詢進度
        [HttpGet]
        public ActionResult Progress(string id)
        {
            if (ProgressStore.TryGetValue(id, out int progress))
                return Json(new { progress }, JsonRequestBehavior.AllowGet);

            return Json(new { progress = 0 }, JsonRequestBehavior.AllowGet);
        }

        // ✅ Step 3. 下載完成時提供檔案下載
        [HttpGet]
        public ActionResult GetFile(string fileName)
        {
            string filePath = Path.Combine(Server.MapPath("~/App_Data"), $"{fileName}.txt");
            if (!System.IO.File.Exists(filePath))
                return HttpNotFound();

            return File(filePath, "text/plain", $"{fileName}.txt");
        }

        // ✅ Step 3: 即時 stream 下載 MiniExcel
        // ✅ Stream Excel 下載 (直接寫入 Response, 取得大小)
        // ✅ Stream Excel 下載
        [HttpGet]
        public void GetFileStream(string fileName)
        {
            Response.Clear();
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("Content-Disposition", $"attachment; filename={fileName}.xlsx");

            var workbook = new XSSFWorkbook();
            var sheet = workbook.CreateSheet("Sheet1");

            var headerRow = sheet.CreateRow(0);
            headerRow.CreateCell(0).SetCellValue("Name");
            headerRow.CreateCell(1).SetCellValue("Value");

            var data = new dynamic[]
            {
        new { Name="產品", Value="報告" },
        new { Name="日期", Value=DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") },
        new { Name="數值", Value=12345 }
    };

            for (int i = 0; i < data.Length; i++)
            {
                var row = sheet.CreateRow(i + 1);
                row.CreateCell(0).SetCellValue(data[i].Name);
                row.CreateCell(1).SetCellValue(data[i].Value.ToString());
            }
            var ms = new NpoiMemoryStream();
            ms.AllowClose = false; //先禁止Close
            
          
            //，让这段执行结束后这个MemoryStream可以被正常关闭回收
                                  //using (var ms = new MemoryStream())
                                  //{
            workbook.Write(ms);
                ms.Position = 0;
            // 設定 Content-Length
            Response.AddHeader("Content-Length", ms.Length.ToString());
            byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = ms.Read(buffer, 0, buffer.Length)) > 0)
                {
                    Response.OutputStream.Write(buffer, 0, bytesRead);
                    Response.Flush(); // 立即送給前端
                }
            //}
            ms.AllowClose = true; //重新允许Close
            ms = null;
            Response.End(); // 不要再回傳 ActionResult
        }


    }
}
 