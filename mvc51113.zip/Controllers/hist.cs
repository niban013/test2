﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc5.Controllers
{
	public class hist
	{

		public string getlist(string col) 
		{
			return "";
		} 
        public string getdata(string col)
        {
            return "";
        }
    }
}