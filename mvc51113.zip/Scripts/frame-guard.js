(function () {
    document.addEventListener("DOMContentLoaded", function () {

        try {
            // 嘗試存取 top.location.href，如果不同 origin 會拋錯
            if (window.top.location.origin !== window.location.origin) {
                document.body.innerHTML = "<h2>禁止外部嵌入父頁</h2>";
            }
        } catch (e) {
            // 跨域存取失敗 → 外站嵌入
            document.body.innerHTML = "<h2>禁止外部嵌入父頁</h2>";
        }
    if (window.top === window.self) {
        // 被直接打開，導回父頁並附上 returnUrl
        var path = window.location.pathname + window.location.search;
        var redirectUrl = '/Index.html#iframe=' + encodeURIComponent(path);
        window.location.replace(redirectUrl);
    } 
    

    });

})();
