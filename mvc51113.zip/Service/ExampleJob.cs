﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.Service
{
    [DisallowConcurrentExecution]
    public class ExampleJob : IJob
    {
        public async Task Execute(IJobExecutionContext context)
        {
            Console.WriteLine($"[ExampleJob] 執行時間: {DateTime.Now}");
            await Task.Delay(2000); // 模擬工作耗時 2 秒
        }
    }
}