﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class SSOAuthorizeAttribute : AuthorizeAttribute
    { // 可設定允許匿名的 flag
        //public bool AllowAnonymous { get; set; }
        // MVC5 支援 [AllowAnonymous]
        public virtual void OnAuthorization(AuthorizationContext filterContext)
        {
            if (filterContext == null)
                throw new ArgumentNullException(nameof(filterContext));

            // 放行 [AllowAnonymous]
            if (filterContext.ActionDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true) ||
                filterContext.ActionDescriptor.ControllerDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true))
            {
                return;
            }

            // 呼叫基底方法做授權檢查
            base.OnAuthorization(filterContext);
        }

        protected override bool AuthorizeCore(System.Web.HttpContextBase httpContext)
        {
            //var user = httpContext.Session["CurrentUser"] as UserInfo;
            //if (user == null)
            //{
            //    var ssoCookie = httpContext.Request.Cookies["SSO_AUTH"];
            //    user = SSOAuthService.ValidateToken(ssoCookie?.Value);
            //    if (user != null)
            //        httpContext.Session["CurrentUser"] = user;
            //}
            //httpContext.User = new GenericPrincipal(new GenericIdentity(user.UserName), user.Roles);


            //// ✅ STEP 1：確認 SSO 是否提供登入資訊（Cookie 或 Header）
            //var token = httpContext.Request.Cookies["SSO_AUTH"]?.Value
            //            ?? httpContext.Request.Headers["X-SSO-TOKEN"];

            //if (string.IsNullOrEmpty(token))
            //    return false;

            //// ✅ STEP 2：呼叫第三方 SSO 驗證
            //var  user = SSOAuthService.ValidateToken(token);
            //if (user == null)
            //    return false;

            //// ✅ STEP 3：檢查是否有此頁面權限
            //var path = httpContext.Request.Path;
            //var hasPermission = PermissionService.HasAccess(user.UserName, path);
            //if (!hasPermission)
            //    return false;

            //// ✅ STEP 4：掛上使用者身分
            //httpContext.User = new GenericPrincipal(
            //    new GenericIdentity(user.UserName), user.Roles);

            return true;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            //if (AllowAnonymous)
            //{
            //    base.HandleUnauthorizedRequest(filterContext);
            //    return;
            //}
            //var user = filterContext.HttpContext.User;

            //// 未登入 → 導向第三方 SSO 登入
            //if (!user?.Identity?.IsAuthenticated ?? true)
            //{
            //    string ssoLoginUrl = "https://sso.example.com/login?returnUrl=" +
            //                          HttpUtility.UrlEncode(filterContext.HttpContext.Request.Url.AbsoluteUri);
            //    filterContext.Result = new RedirectResult(ssoLoginUrl);
            //}
            //else
            //{
            //    // 已登入但無權限 → 回傳 403
            //    filterContext.Result = new HttpStatusCodeResult(403);
            //}
            //// 判斷是否為 AJAX
            //if (filterContext.HttpContext.Request.IsAjaxRequest())
            //{
            //    filterContext.Result = new JsonResult
            //    {
            //        Data = new { success = false, message = "Unauthorized" },
            //        JsonRequestBehavior = JsonRequestBehavior.AllowGet
            //    };
            //    filterContext.HttpContext.Response.StatusCode = 403;
            //    return;
            //}

            //// 未登入 → 自動導向 SSO 登入頁
            //var currentUrl = filterContext.HttpContext.Request.Url.AbsoluteUri;
            //string ssoLoginUrl = "https://sso.example.com/login?returnUrl=" + HttpUtility.UrlEncode(currentUrl);

            //filterContext.Result = new RedirectResult(ssoLoginUrl);
            //// 若是普通請求（iframe 用的），導向 ErrorController
            ////filterContext.Result = new RedirectResult("/Error/NotFound");
            ////filterContext.HttpContext.Response.StatusCode = 404;
            //var routeData = filterContext.RouteData;
            //var actionName = routeData.Values["action"]?.ToString();
            //var controllerName = routeData.Values["controller"]?.ToString();

            //// 範例：針對某些 action 直接轉首頁
            //if (actionName.Equals("Secret", StringComparison.OrdinalIgnoreCase))
            //{
            //    filterContext.Result = new RedirectResult("/Error/NotFound");
            //    //filterContext.Result = new RedirectResult("~/Home/Index");
            //    return;
            //}

            //// 針對其他頁面顯示登入頁
            ////filterContext.Result = new RedirectToRouteResult(
            ////    new System.Web.Routing.RouteValueDictionary
            ////    {
            ////    { "controller", "Account" },
            ////    { "action", "Login" },
            ////    { "ReturnUrl", filterContext.HttpContext.Request.RawUrl }
            ////    });
        }
    }

}