﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class FrameOptionsFilter : ActionFilterAttribute
    {/// <summary>
     /// 允許的來源 (可設定 'self' 或特定網域)
     /// </summary>
       

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var response = filterContext.HttpContext.Response;

            // X-Frame-Options + CSP
            response.Headers["X-Frame-Options"] = "SAMEORIGIN";
            response.Headers["Content-Security-Policy"] = "frame-ancestors 'self'";

            base.OnActionExecuting(filterContext);
        }
        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            // 限制 iframe 嵌入來源
            //filterContext.HttpContext.Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
            base.OnResultExecuting(filterContext);
        }
    }

}