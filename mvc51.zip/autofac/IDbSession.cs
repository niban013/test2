﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.autofac
{
    public interface IDbSession : IDisposable
    {
        IDbConnection Connection { get; }
        IDbTransaction Transaction { get; }
 
        // Transaction
        void BeginTransaction();
        //Task BeginTransactionAsync();
        void Commit();
        //Task CommitAsync();
        void Rollback();
        //Task RollbackAsync();
        // 同步
        IDbCommand CreateCommand(string sql, CommandType commandType = CommandType.Text, IDictionary<string, object> parameters = null);
        int ExecuteNonQuery(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
       
        object ExecuteScalar(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        IDataReader ExecuteReader(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);

        // 非同步
        //Task<int> ExecuteNonQueryAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default);
        //Task<object> ExecuteScalarAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default);
        //Task<IDataReader> ExecuteReaderAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default);
        // 呼叫儲存程序
        int ExecuteProcedure(string procName, IDictionary<string, object> parameters = null);
        //Task<int> ExecuteProcedureAsync(string procName, IDictionary<string, object> parameters = null, CancellationToken cancellationToken = default);
        DataTable GetDataTable(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        //Task<DataTable> GetDataTableAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default);

        DataTable ExecuteProcedureToDataTable(string procName, IDictionary<string, object> parameters = null);
       
        //Task<DataTable> ExecuteProcedureToDataTableAsync(string procName, IDictionary<string, object> parameters = null, CancellationToken cancellationToken = default);
        void BulkInsert(DataTable dt);
    }
}