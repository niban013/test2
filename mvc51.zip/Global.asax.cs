﻿using Autofac.Integration.Mvc;
using Autofac;
using mvc5.AutoFac;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using mvc5.autofac;
using Oracle.ManagedDataAccess.Client;
using System;
using Quartz.Impl;
using Quartz;
using mvc5.Service;
using Quartz.Impl.Matchers;

namespace mvc5
{
    //public static Type GeneratedEnum { get; private set; }
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {  // 自動生成 DbKeys enum
            //GeneratedEnum = DbEnumGenerator.GenerateEnum();
            //var log4netConfigFile = new FileInfo(Server.MapPath("~/log4net.config"));
            //log4net.Config.XmlConfigurator.Configure(log4netConfigFile);
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            var builder = new ContainerBuilder();
            builder.RegisterControllers(typeof(MvcApplication).Assembly);
            // 註冊 HttpContextBase
            builder.RegisterModule<AutofacWebTypesModule>();
            builder.RegisterModule(new AutoFacModule());

            //var container = AutofacConfig.Configure();
            // 註冊 Connection Factory
            // 讀取所有 connectionStrings
            foreach (ConnectionStringSettings cs in ConfigurationManager.ConnectionStrings)
            {
                if (string.IsNullOrWhiteSpace(cs.Name) || string.IsNullOrWhiteSpace(cs.ConnectionString))
                    continue;

                builder.Register<IDbConnection>(ctx =>
                {
                    IDbConnection conn;
                    switch (cs.ProviderName.ToLower())
                    {
                        case "system.data.sqlclient":
                            conn = new SqlConnection(cs.ConnectionString);
                            break;

                        case "oracle.manageddataaccess.client":
                            conn = new OracleConnection(cs.ConnectionString);
                            break;

                        // 之後要支援 MySQL / PostgreSQL 可以再擴充
                        // case "mysql.data.mysqlclient":
                        //     conn = new MySqlConnection(cs.ConnectionString);
                        //     break;

                        default:
                            throw new NotSupportedException($"尚未支援的 Provider: {cs.ProviderName}");
                    }
                    return conn;
                })
                .Named<IDbConnection>(cs.Name)  // 每個連線用 connectionString name 當作 key
                .InstancePerLifetimeScope();
                // 預設 SQL Server DB1
                //builder.Register(c => new DbSession(
                //    new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString)))
                //    .As<IDbSession>()
                //    .InstancePerLifetimeScope();

                builder.Register<IDbSession>(c =>
                {
                    // 預設資料庫
                    return new DbSession(new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString));
                }).As<IDbSession>().InstancePerLifetimeScope();


                // 註冊 DbSession 也用相同名字
                builder.Register<IDbSession>(ctx =>
                {
                    var conn = ctx.ResolveNamed<IDbConnection>(cs.Name);
                    return new DbSession(conn);
                })
                .Named<IDbSession>(cs.Name)
                .InstancePerLifetimeScope();
            }



            // 註冊 Repository (可以自動注入 IDbSession)
            //builder.RegisterType<UserRepository>();


            // 註冊 DbService，依照 ConnectionString 名稱
            //builder.RegisterType<DbService>()
            //       .As<IDbService>()
            //       .WithParameter("connectionName", "DefaultConnection")
            //       .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(typeof(MvcApplication).Assembly)
           .Where(t => t.Name.EndsWith("Service"))   // 類別名稱結尾是 Service
                .AsSelf() // 註冊成自己
                                                     .AsImplementedInterfaces()                // 依照介面注入，例如 UserService → IUserService

           .InstancePerLifetimeScope();              // MVC/WebApi 常用 Scope

            builder.RegisterType<StdSchedulerFactory>()
                    .As<ISchedulerFactory>()
                    .SingleInstance();
            builder.RegisterType<QuartzService>()
                   .As<IQuartzService>()
                   .SingleInstance()
                   .OnActivated(async e =>
                   {
                       // 容器解析完畢時啟動 Quartz
                       await e.Instance.StartAsync();
                       e.Instance.Scheduler.ListenerManager.AddJobListener(new JobStatusListener());
                   })
                   .OnRelease(async service =>
                   {
                       // Autofac Dispose 時自動 Shutdown
                       await service.ShutdownAsync();
                   });

           

            //   builder.Register(c =>
            //   {
            //       var schedulerFactory = c.Resolve<ISchedulerFactory>();
            //       var scheduler = schedulerFactory.GetScheduler().Result;
            //       // 註冊全域 Listener
            //       scheduler.ListenerManager.AddJobListener(new JobStatusListener());

            //       scheduler.Start().Wait();
            //       return scheduler;
            //   }).As<IScheduler>()
            //   .SingleInstance()
            //   .OnRelease(async scheduler =>
            //   {
            //       if (scheduler != null && !scheduler.IsShutdown)
            //       {
            //           await scheduler.Shutdown(waitForJobsToComplete: true);
            //       }
            //   });

            // Quartz Service
            //builder.RegisterType<QuartzService>()
            //       .As<IQuartzService>()
            //       .SingleInstance();

            // Job 也要註冊 (假設有 ExampleJob)
            //builder.RegisterType<ExampleJob>().As<IJob>();

            // 掃描目前 Assembly (或指定 Assembly)，自動註冊所有 IJob
            //builder.RegisterAssemblyTypes(AppDomain.CurrentDomain.GetAssemblies())
            //       .AssignableTo<IJob>()  // 找出所有繼承 IJob 的類別
            //       .AsSelf()              // 直接用類型解析
            //       .AsImplementedInterfaces() // 也可用介面解析
            //       .InstancePerDependency();




            var container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));

            //var quartzService = container.Resolve<IQuartzService>();
            //quartzService.StartAsync().Wait();


            //var quartz = DependencyResolver.Current.GetService<IQuartzService>();
            //quartz.ScheduleAllJobs().Wait();

            //var scheduler =  quartz.GetScheduler();
            //var jobKeys = scheduler.GetJobKeys(GroupMatcher<JobKey>.AnyGroup());
            //foreach (var jk in jobKeys)
            //{
            //    System.Diagnostics.Debug.WriteLine($"已排程 Job: {jk.Name}");
            //}


            //var quartz = DependencyResolver.Current.GetService<IQuartzService>();
            //quartz.ScheduleAllJobs().Wait(); // 自動排程所有 IJob
            // 從 Web.config 自動載入 Job
            //quartzService.LoadJobsFromConfig().Wait();

            // 或從 DB 載入
            // string connStr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            // quartzService.LoadJobsFromDb(connStr).Wait();

        }
        protected void Application_BeginRequest()
        {
            string userName = HttpContext.Current.User?.Identity?.Name ?? "Anonymous";
            userName = Regex.Replace(userName, @"[\\/:*?""<>|]", "_");

            //log4net.LogicalThreadContext.Properties["userName"] = userName;

        }
    }
}
