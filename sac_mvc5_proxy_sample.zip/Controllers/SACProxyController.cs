\
        using System;
        using System.Linq;
        using System.Net;
        using System.Net.Http;
        using System.Threading.Tasks;
        using System.Web;
        using System.Web.Mvc;
        using mvc5.Helpers;

        namespace mvc5.Controllers
        {
            public class SACProxyController : Controller
            {
                private static readonly HttpClient client;

                static SACProxyController()
                {
                    var handler = new HttpClientHandler
                    {
                        AllowAutoRedirect = false,
                        UseCookies = false
                    };
                    client = new HttpClient(handler);
                    client.Timeout = TimeSpan.FromSeconds(60);
                }

                // GET /SACProxy/Load?target=/sap/fpa/ui/tenants/xxxx/bo/story/123ABCDEF
                // Also supports POST forwarding.
                [HttpGet, HttpPost]
                public async Task<ActionResult> Load(string target)
                {
                    if (string.IsNullOrEmpty(target))
                        return new HttpStatusCodeResult(400, "Missing target");

                    string sacBase = "https://mytenant.sapanalytics.cloud";
                    string sacUrl = sacBase + target;

                    // get valid token (auto refresh inside)
                    string jwt = TokenManager.GetValidToken();

                    HttpRequestMessage req;
                    if (Request.HttpMethod.Equals("POST", StringComparison.OrdinalIgnoreCase))
                    {
                        // Forward POST body and content-type to SAC
                        var bodyStream = Request.InputStream;
                        bodyStream.Seek(0, System.IO.SeekOrigin.Begin);
                        var sr = new System.IO.StreamReader(bodyStream);
                        string body = await sr.ReadToEndAsync();

                        req = new HttpRequestMessage(HttpMethod.Post, sacUrl);
                        req.Content = new StringContent(body, System.Text.Encoding.UTF8, Request.ContentType ?? "application/json");
                    }
                    else
                    {
                        req = new HttpRequestMessage(HttpMethod.Get, sacUrl);
                    }

                    req.Headers.Add("Authorization", "Bearer " + jwt);

                    // Forward a subset of headers that are useful but avoid hop-by-hop headers
                    var allowed = new[] { "User-Agent", "Accept", "Accept-Language", "Accept-Encoding", "Referer" };
                    foreach (var h in Request.Headers.AllKeys)
                    {
                        if (allowed.Contains(h, StringComparer.OrdinalIgnoreCase))
                        {
                            var val = Request.Headers[h];
                            if (!req.Headers.Contains(h))
                                req.Headers.TryAddWithoutValidation(h, val);
                        }
                    }

                    HttpResponseMessage resp = await client.SendAsync(req);

                    // If SAC responds with 302 (redirect to login), attempt one retry with force refresh
                    if ((int)resp.StatusCode == 302 || resp.StatusCode == HttpStatusCode.Found || resp.StatusCode == HttpStatusCode.SeeOther)
                    {
                        // refresh token and retry once
                        TokenManager.ForceRefresh();
                        string newJwt = TokenManager.GetValidToken();

                        var retry = new HttpRequestMessage(req.Method, sacUrl);
                        if (req.Content != null)
                        {
                            var s = await req.Content.ReadAsStringAsync();
                            retry.Content = new StringContent(s, System.Text.Encoding.UTF8, req.Content.Headers.ContentType?.MediaType ?? "application/json");
                        }
                        retry.Headers.Add("Authorization", "Bearer " + newJwt);
                        foreach (var h in Request.Headers.AllKeys)
                        {
                            if (allowed.Contains(h, StringComparer.OrdinalIgnoreCase))
                            {
                                var val = Request.Headers[h];
                                if (!retry.Headers.Contains(h))
                                    retry.Headers.TryAddWithoutValidation(h, val);
                            }
                        }

                        resp = await client.SendAsync(retry);

                        if ((int)resp.StatusCode == 302 || resp.StatusCode == HttpStatusCode.Found)
                        {
                            return new HttpStatusCodeResult(401, "Unauthorized or SAC blocked access after retry");
                        }
                    }

                    var content = await resp.Content.ReadAsByteArrayAsync();
                    var contentType = resp.Content.Headers.ContentType?.ToString() ?? "text/html";

                    // Return response bytes preserving content type
                    return File(content, contentType);
                }

                // Simple keepalive endpoint that pings SAC story to keep session alive and returns 200.
                // GET /SACProxy/KeepAlive?target=/sap/...
                [HttpGet]
                public async Task<ActionResult> KeepAlive(string target)
                {
                    if (string.IsNullOrEmpty(target))
                        return new HttpStatusCodeResult(400, "Missing target");

                    string sacBase = "https://mytenant.sapanalytics.cloud";
                    string sacUrl = sacBase + target;

                    string jwt = TokenManager.GetValidToken();
                    var req = new HttpRequestMessage(HttpMethod.Get, sacUrl);
                    req.Headers.Add("Authorization", "Bearer " + jwt);

                    var resp = await client.SendAsync(req);
                    if (resp.IsSuccessStatusCode)
                        return new HttpStatusCodeResult(200, "OK");
                    else
                        return new HttpStatusCodeResult((int)resp.StatusCode, "KeepAlive failed");
                }
            }
        }
