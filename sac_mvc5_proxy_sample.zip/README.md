SAC MVC5 Proxy Sample (2025) - README
====================================

This archive contains a minimal MVC5-compatible proxy + TokenManager + JS SDK to embed SAP Analytics Cloud (SAC)
stories into an iframe with:
  - OAuth JWT support
  - POST forwarding (Smart Filter / Smart Insights)
  - Session KeepAlive endpoint
  - Threaded background token refresh
  - Simple .js SDK to manage iframe loading / loading/error UI
  - Demo HTML

IMPORTANT: This is a sample scaffold. You must fill in your real secrets and adjust paths.
Files of interest:
- Controllers/SACProxyController.cs
- Helpers/TokenManager.cs
- Helpers/JwtTokenHelper.cs
- Helpers/BackgroundTokenRefresher.cs
- Content/sacEmbed.js
- Views/demo.html

How to use:
1. Copy Controllers and Helpers into your MVC5 project.
2. Register BackgroundTokenRefresher on app start (see comments).
3. Configure clientId/clientSecret and SAC URLs.
4. Build and run. Point iframe src to /SACProxy/Load?target=/sap/fpa/...
