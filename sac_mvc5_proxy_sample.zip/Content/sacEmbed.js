\
        // Simple SAC embed SDK for interacting with the MVC5 proxy
        (function(window){
            function createIframe(containerId, options) {
                var container = document.getElementById(containerId);
                if(!container) throw new Error("container not found");

                var iframe = document.createElement('iframe');
                iframe.id = options.iframeId || 'sacFrame';
                iframe.width = options.width || '100%';
                iframe.height = options.height || '800';
                iframe.style.border = '0';
                iframe.src = options.proxyUrl; // e.g. /SACProxy/Load?target=/sap/...
                container.appendChild(iframe);

                var loadingEl = document.createElement('div');
                loadingEl.id = iframe.id + '_loading';
                loadingEl.innerText = options.loadingText || 'Loading SAC...';
                container.appendChild(loadingEl);

                iframe.addEventListener('load', function(){
                    loadingEl.style.display = 'none';
                });

                iframe.addEventListener('error', function(){
                    loadingEl.innerText = options.errorText || 'Failed to load SAC.';
                });

                return {
                    iframe: iframe,
                    setSrc: function(url){ iframe.src = url; loadingEl.style.display = 'block'; loadingEl.innerText = options.loadingText || 'Loading SAC...'; }
                };
            }

            function postToSAC(proxyPath, targetPath, payload){
                // proxyPath e.g. /SACProxy/PostForward
                return fetch(proxyPath + '?target=' + encodeURIComponent(targetPath), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload),
                    credentials: 'same-origin'
                }).then(function(resp){
                    if (!resp.ok) throw new Error('Proxy POST failed: ' + resp.status);
                    return resp.text();
                });
            }

            function keepAlive(proxyKeepAlivePath, targetPath, intervalSec){
                intervalSec = intervalSec || 60;
                setInterval(function(){
                    fetch(proxyKeepAlivePath + '?target=' + encodeURIComponent(targetPath), { method: 'GET', credentials: 'same-origin' })
                    .catch(function(e){ console.warn('KeepAlive failed', e); });
                }, intervalSec * 1000);
            }

            window.SACEmbed = {
                createIframe: createIframe,
                postToSAC: postToSAC,
                keepAlive: keepAlive
            };
        })(window);
