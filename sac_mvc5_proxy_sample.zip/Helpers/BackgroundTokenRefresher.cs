\
        using System;
        using System.Threading;

        namespace mvc5.Helpers
        {
            // Simple background refresher using a Timer.
            public class BackgroundTokenRefresher : IDisposable
            {
                private Timer _timer;
                private readonly int _intervalSeconds;
                private bool _running;

                public BackgroundTokenRefresher(int intervalSeconds = 30)
                {
                    _intervalSeconds = Math.Max(5, intervalSeconds);
                }

                public void Start()
                {
                    if (_running) return;
                    _timer = new Timer(Tick, null, 0, _intervalSeconds * 1000);
                    _running = true;
                }

                public void Stop()
                {
                    _timer?.Dispose();
                    _running = false;
                }

                private void Tick(object state)
                {
                    try
                    {
                        // call TokenManager.GetValidToken to ensure token is refreshed when approaching expiry
                        var t = TokenManager.GetValidToken();
                    }
                    catch
                    {
                        // swallow exceptions; consider logging
                    }
                }

                public void Dispose()
                {
                    Stop();
                }
            }
        }
