\
        using Microsoft.IdentityModel.Tokens;
        using System;
        using System.IdentityModel.Tokens.Jwt;
        using System.Security.Claims;
        using System.Text;

        namespace mvc5.Helpers
        {
            public static class JwtTokenHelper
            {
                // TODO: Replace these with your real values (store secrets securely)
                private static readonly string Issuer = "your-backend";
                private static readonly string Audience = "sac";
                private static readonly string Secret = "REPLACE_WITH_A_256_BIT_SECRET_ABCDEFGHIJKLMNOPQRSTUVWXYZ";

                public static string GenerateToken(int minutes = 15)
                {
                    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Secret));
                    var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

                    var claims = new[]
                    {
                        new Claim("sub", "service-account"),
                        new Claim("email", "your-service-account@company.com"),
                        new Claim("scope", "fpa.read fpa.story.read")
                    };

                    var token = new JwtSecurityToken(
                        issuer: Issuer,
                        audience: Audience,
                        claims: claims,
                        expires: DateTime.UtcNow.AddMinutes(minutes),
                        signingCredentials: credentials
                    );

                    return new JwtSecurityTokenHandler().WriteToken(token);
                }
            }
        }
