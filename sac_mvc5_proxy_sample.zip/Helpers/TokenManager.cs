\
        using System;
        using System.IdentityModel.Tokens.Jwt;
        using System.Threading;

        namespace mvc5.Helpers
        {
            // Thread-safe token cache with background refresh support.
            public static class TokenManager
            {
                private static string _cachedToken;
                private static DateTime _expiresAt = DateTime.MinValue;
                private static readonly object _lock = new object();

                // Optional background refresher instance (can be started at App_Start)
                public static BackgroundTokenRefresher Refresher { get; private set; }

                public static void StartBackgroundRefresh(int refreshIntervalSeconds = 30)
                {
                    if (Refresher == null)
                    {
                        Refresher = new BackgroundTokenRefresher(refreshIntervalSeconds);
                        Refresher.Start();
                    }
                }

                public static void StopBackgroundRefresh()
                {
                    Refresher?.Stop();
                    Refresher = null;
                }

                public static string GetValidToken()
                {
                    lock (_lock)
                    {
                        bool needRefresh =
                            string.IsNullOrEmpty(_cachedToken) ||
                            DateTime.UtcNow >= _expiresAt.AddMinutes(-2); // refresh 2 min before expiry

                        if (needRefresh)
                        {
                            RefreshTokenInternal();
                        }

                        return _cachedToken;
                    }
                }

                public static void ForceRefresh()
                {
                    lock (_lock)
                    {
                        RefreshTokenInternal();
                    }
                }

                private static void RefreshTokenInternal()
                {
                    // Generate a new JWT assertion (signed by your secret/key)
                    string jwt = JwtTokenHelper.GenerateToken();

                    // NOTE: For SAC OAuth JWT Bearer, you normally exchange the JWT assertion
                    // against the authentication server to obtain an access token.
                    // If your SAC setup accepts the JWT assertion directly as a Bearer token,
                    // you may return that. Otherwise, implement the exchange here.
                    //
                    // For this sample we use the JWT as the token that will be presented to SAC.
                    // In real deployment, perform token exchange with sac.authentication.../oauth/token

                    _cachedToken = jwt;

                    // parse expiry from token
                    try
                    {
                        var handler = new JwtSecurityTokenHandler();
                        var t = handler.ReadJwtToken(jwt);
                        _expiresAt = t.ValidTo;
                    }
                    catch
                    {
                        // default expiry if parsing fails
                        _expiresAt = DateTime.UtcNow.AddMinutes(10);
                    }
                }
            }
        }
