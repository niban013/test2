﻿let currentStep = 0;
const totalSteps = $("#wizard-steps li").length;

function loadStep(stepIndex) {
    $.get(`/Wizard/Step?stepIndex=${stepIndex}`, function (html) {
        $("#wizard-content").html(html);
        updateUI();
        attachAutoSave();
    });
}
// 點擊步驟也可跳轉（可選）
$("#wizard-steps li").click(function () {
    const index = $(this).data("step");
    loadStep(index);
});
function updateUI() {
    $("#prevBtn").prop("disabled", currentStep === 0);
    $("#nextBtn").text(currentStep === totalSteps - 1 ? "完成" : "下一步");
    $("#wizard-steps li").removeClass("active");
    $(`#wizard-steps li[data-step=${currentStep}]`).addClass("active");

    let progress = ((currentStep) / (totalSteps - 1)) * 100;
    $("#wizard-progress-bar").css("width", progress + "%");
}

function attachAutoSave() {
    $(".step-input").off("input").on("input", function () {

        const formData = {};
        let valid = true;       // 前端驗證狀態
        let errorMsg = "";       // 錯誤訊息

        $(".step-input").each(function () {
            const name = $(this).attr("name");
            const value = $(this).val().trim();
            formData[name] = value;

            // 前端驗證規則範例
            if (!value) {
                valid = false;
                errorMsg = "欄位 " + name + " 不能為空";
                $(this).addClass("input-error");   // 加上錯誤樣式
            } else {
                $(this).removeClass("input-error");
            }

            // 可加更多規則，例如：
            // if (name === "Email" && !validateEmail(value)) { valid = false; ... }
        });

        // 如果驗證未通過，不送到後端
        if (!valid) {
            console.log("前端驗證失敗: " + errorMsg);
            return;
        }

        // 驗證通過，送去後端 AutoSave
        $.post("/Wizard/AutoSave?stepIndex=" + currentStep, formData);
    });
}

// 範例 Email 驗證函式
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

$(document).ready(function () {
    loadStep(currentStep);

    $("#nextBtn").click(function () {
        const formData = {};
        $(".step-input").each(function () { formData[$(this).attr("name")] = $(this).val(); });
        $.post("/Wizard/ValidateStep?stepIndex=" + currentStep, formData, function (res) {
            if (res.success) {
                $(`#wizard-steps li[data-step=${currentStep}] .step-badge`).show();
                if (currentStep < totalSteps - 1) { currentStep++; loadStep(currentStep); }
                else alert("流程完成!");
            } else alert(res.message);
        });
    });

    $("#prevBtn").click(function () {
        if (currentStep > 0) { currentStep--; loadStep(currentStep); }
    });

    $(".step-badge").hide();
});