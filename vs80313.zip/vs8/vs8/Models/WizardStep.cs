﻿namespace vs8.Models
{
    public class WizardViewModel
    {
        public Dictionary<string, string> Requirement { get; set; } = new();
        public Dictionary<string, string> Design { get; set; } = new();
        public Dictionary<string, string> Development { get; set; } = new();
        public Dictionary<string, string> Testing { get; set; } = new();
        public Dictionary<string, string> Delivery { get; set; } = new();
    }

    public class WizardOptions
    {
        public List<WizardStepOption> Steps { get; set; } = new();
        public bool AllowJumpToCompletedStep { get; set; } = true;
        public bool AutoSave { get; set; } = true;
    }

    public class WizardStepOption
    {
        public string Title { get; set; }
        public string PartialView { get; set; }
        public bool Completed { get; set; } = false;
        public bool Locked { get; set; } = true;
        public int StepIndex { get; set; }
        public Dictionary<string, object> Custom { get; set; } = new();
    }
}
