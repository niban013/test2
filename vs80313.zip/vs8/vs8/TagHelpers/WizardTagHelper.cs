using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic.FileIO;
using System.Diagnostics;
using System.Text.Json;
using vs8.Models;
using FieldType = vs8.Models.FieldType;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Text;

namespace vs8.TagHelpers
{
    [HtmlTargetElement("wizard")]
    public class WizardTagHelper : TagHelper
    {
        public WizardOptions Options { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.SetAttribute("class", "wizard-container");
            output.Attributes.SetAttribute("data-options", JsonSerializer.Serialize(Options));

            var sb = new StringBuilder();
            sb.Append("<ul class='wizard-steps'>");

            foreach (var step in Options.Steps)
            {
                sb.Append($@"
<li class='wizard-step' 
    data-id='{step.Id}'
    data-panel='{step.PanelUrl}'
    data-validate='{step.ValidateUrl ?? ""}'>
    {step.Title}
</li>");
            }

            sb.Append("</ul>");
            sb.Append("<div class='wizard-body'></div>");

            output.Content.SetHtmlContent(sb.ToString());
        }
    }

}
