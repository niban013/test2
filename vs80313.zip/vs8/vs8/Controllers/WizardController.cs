using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using vs8.Models;

namespace vs8.Controllers
{
    public class WizardController : Controller
    {
        private const string SESSION_KEY = "WizardData";

        private static readonly List<WizardStepOption> Steps = new()
        {
            new WizardStepOption { StepIndex = 0, Title = "�ݨD�Q��", PartialView = "_StepRequirement", Locked = false },
            new WizardStepOption { StepIndex = 1, Title = "���~�]�p", PartialView = "_StepDesign" },
            //new WizardStepOption { StepIndex = 2, Title = "�}�o��@", PartialView = "_StepDevelopment" },
            //new WizardStepOption { StepIndex = 3, Title = "�\�����", PartialView = "_StepTesting" },
            //new WizardStepOption { StepIndex = 4, Title = "���u��I", PartialView = "_StepDelivery" },
        };

        private WizardViewModel GetWizardData()
        {
            var json = HttpContext.Session.GetString(SESSION_KEY);
            return json != null ? JsonSerializer.Deserialize<WizardViewModel>(json)! : new WizardViewModel();
        }

        private void SaveWizardData(WizardViewModel data)
        {
            HttpContext.Session.SetString(SESSION_KEY, JsonSerializer.Serialize(data));
        }

        // ����
        public IActionResult Index()
        {
            var wizardData = GetWizardData();
            ViewBag.Steps = Steps;
            ViewBag.WizardData = wizardData;
            return View();
        }

        // ���o�B�J PartialView
        [HttpGet]
        public IActionResult Step(int stepIndex)
        {
            if (stepIndex < 0 || stepIndex >= Steps.Count)
                return BadRequest("Invalid step index");

            var step = Steps[stepIndex];
            var wizardData = GetWizardData();

            object model = stepIndex switch
            {
                0 => wizardData.Requirement,
                1 => wizardData.Design,
                //2 => wizardData.Development,
                //3 => wizardData.Testing,
                //4 => wizardData.Delivery,
                _ => null
            };

            return PartialView(step.PartialView, model);
        }

        // AutoSave API
        [HttpPost]
        public IActionResult AutoSave(int stepIndex, [FromForm] Dictionary<string, string> formData)
        {
            var wizardData = GetWizardData();

            // �������: �C����줣�i��
            foreach (var kv in formData)
            {
                if (string.IsNullOrWhiteSpace(kv.Value))
                    return Json(new { success = false, message = $"��� {kv.Key} ���ର��" });
            }

            // ��s���
            switch (stepIndex)
            {
                case 0: wizardData.Requirement = formData; break;
                case 1: wizardData.Design = formData; break;
                case 2: wizardData.Development = formData; break;
                case 3: wizardData.Testing = formData; break;
                case 4: wizardData.Delivery = formData; break;
            }

            SaveWizardData(wizardData);

            return Json(new { success = true });
        }

        // ���ҨB�J�O�_�i�i�U�@�B
        [HttpPost]
        public IActionResult ValidateStep(int stepIndex, [FromForm] Dictionary<string, string> formData)
        {
            bool valid = formData.Values.All(v => !string.IsNullOrWhiteSpace(v));
            if (!valid)
                return Json(new { success = false, message = "�ж�g��Ƥ~��i�U�@�B" });

            return AutoSave(stepIndex, formData);
        }
    }
}