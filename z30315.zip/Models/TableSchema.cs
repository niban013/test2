﻿namespace vsnet8.Models
{
    public class TableSchema
    {
        public string TableId { get; set; } // Table 的 HTML Id

        public string AjaxUrl { get; set; } // Table 的 HTML Id

        public string FetchMode { get; set; } = "all";// "all" 或 "server"

        public TableFeatures Features { get; set; } = new();// 可選功能
        public TableConfig Config { get; set; } = new();     // 額外設定
        public List<ColumnSchema> Columns { get; set; } = new();// 欄位

        public List<ToolbarButton> ToolbarButtons { get; set; } = new(); // 工具列按鈕

        public bool StateSave { get; set; } = true;// 欄位
    }
    public class TableConfig
    {
        public bool Searching { get; set; } = true;         // DataTables 搜尋欄
        public bool LengthChange { get; set; } = true;      // 顯示每頁筆數選擇
        public bool Ordering { get; set; } = true;          // 欄位排序
        public bool Paging { get; set; } = true;            // 分頁
        public int PageLength { get; set; } = 10;           // 每頁顯示筆數
        public bool Buttons { get; set; } = true;           // 匯出按鈕
        public bool StateSave { get; set; } = true;         // DataTables stateSave
        public string VirtualScrollHeight { get; set; }     // scrollY 高度，如 "500px"
    }
    public class TableFeatures
    {
        public bool Checkbox { get; set; }
        public bool RowSelect { get; set; }
        public bool Export { get; set; }
        public bool ColumnToggle { get; set; }
        public bool SelectAll { get; set; }
        public bool VirtualScroll { get; set; }
        public bool RowButtons { get; set; }
       
        public bool StateSave { get; set; }
        
     
    }

    public class ColumnSchema
    {
        public string Field { get; set; }

        public string Title { get; set; }

        public string Formatter { get; set; }

        public ColumnSchema(string field)
        {
            Field = field;
            Title = field;
        }

        public ColumnSchema(string field, string formatter)
        {
            Field = field;
            Title = field;
            Formatter = formatter;
        }
    }
    public class ToolbarButton
    {
        public string Title { get; set; }

        public string Event { get; set; }

        public string CssClass { get; set; }

        public ToolbarButton(string title, string evt, string css = "btn btn-primary")
        {
            Title = title;
            Event = evt;
            CssClass = css;
        }
    }
}
