﻿var DynamicFormModule = (function () {

    let cache = {};
    let currentRow = null;

    function init(container) {
        container = $(container);

        container.find("[data-panelid]").each(function () {
            let panel = $(this);
            let panelId = panel.data("panelid");
            if (!panelId) return;

            // 普通 select 背景
            panel.find("select:not(.select2)").each(function () {
                let sel = $(this);
                setSelectBackground(sel);
                sel.off("change").on("change", function () {
                    setSelectBackground($(this));
                });
            });

            // select2
            panel.find(".select2").each(function () {
                let sel = $(this);
                sel.select2({
                    width: '100%',
                    templateResult: function (item) {
                        if (!item.id) return item.text;
                        let color = $(item.element).data("color") || "";
                        return $('<div style="background-color:' + color + '; width:100%; padding:4px 6px; box-sizing:border-box;">' + item.text + '</div>');
                    },
                    templateSelection: function (item) {
                        if (!item.id) return item.text;
                        return item.text;
                    }
                });

                function setBackground() {
                    let color = sel.find("option:selected").data("color") || "";
                    sel.next(".select2-container").find(".select2-selection--single")
                        .css("background-color", color);
                }

                setBackground();
                sel.off("change").on("change", setBackground);
            });

            // input / valueInput / dateInput change
            panel.off("input change", ".dynamicInput,.valueInput,.dateInput")
                .on("input change", ".dynamicInput,.valueInput,.dateInput", function () {
                    let fld = $(this);
                    let name = fld.attr("name");
                    if (!cache[panelId]) cache[panelId] = {};
                    if (!cache[panelId].fields) cache[panelId].fields = {};
                    cache[panelId].fields[name] = fld.val();

                    // 更新狀態 icon
                    let row = fld.closest("tr.dynamicCheckRow");
                    if (row.length) {
                        let val = row.find(".valueInput").val();
                        let icon = row.find(".statusCell i");
                        if (icon.length) { // 只有 row 有 statusCell 才更新
                            if (val) {
                                icon.removeClass("bi-x-circle text-danger").addClass("bi-check-circle text-success");
                            } else {
                                icon.removeClass("bi-check-circle text-success").addClass("bi-x-circle text-danger");
                            }
                        }
                    }
                });

            // 綁定上傳按鈕事件，但只綁有 uploadBtn 的 row
            panel.find(".uploadBtn").each(function () {
                $(this).off("click").on("click", function () {
                    currentRow = $(this).closest("tr.dynamicCheckRow");
                    if (currentRow.length) openUploadModal(panelId, currentRow);
                });
            });

            // 回填 cache
            restoreCache(panel);
        });
    }

    function setSelectBackground(select) {
        let color = select.find("option:selected").css("background-color") || "";
        select.css("background-color", color);
    }

    function validate(container) {
        container = $(container);
        let valid = true;
        let firstInvalid = null;

        container.find("[data-panelid]").each(function () {
            let panel = $(this);
            let panelId = panel.data("panelid");

            panel.find(".dynamicInput,.valueInput,.dateInput").each(function () {
                let fld = $(this);
                if (fld.is(":hidden") || fld.prop("readonly")) return;

                let must = fld.data("must");
                let format = fld.data("format");
                let val = fld.val();
                fld.removeClass("is-invalid");

                if (must && (!val || val.trim() === "")) {
                    fld.addClass("is-invalid");
                    if (!firstInvalid) firstInvalid = fld;
                    valid = false;
                } else if (val) {
                    if (format === "date" && isNaN(Date.parse(val))) {
                        fld.addClass("is-invalid");
                        if (!firstInvalid) firstInvalid = fld;
                        valid = false;
                    }
                    if (format === "number" && !$.isNumeric(val)) {
                        fld.addClass("is-invalid");
                        if (!firstInvalid) firstInvalid = fld;
                        valid = false;
                    }
                }
            });
        });

        if (firstInvalid) firstInvalid.focus();
        return valid;
    }

    function getData(container) {
        container = $(container);
        let result = {};
        container.find("[data-panelid]").each(function () {
            let panel = $(this);
            let panelId = panel.data("panelid");
            if (!panelId) return;

            result[panelId] = {};
            panel.find(".dynamicInput,.valueInput,.dateInput").each(function () {
                result[panelId][$(this).attr("name")] = $(this).val();
            });
        });
        return result;
    }

    function fillCache(container) {
        container = $(container);
        container.find("[data-panelid]").each(function () {
            let panel = $(this);
            let panelId = panel.data("panelid");
            if (!panelId) return;
            if (!cache[panelId]) cache[panelId] = {};
            if (!cache[panelId].fields) cache[panelId].fields = {};
            if (!cache[panelId].uploads) cache[panelId].uploads = {};

            panel.find(".dynamicInput,.valueInput,.dateInput").each(function () {
                let fld = $(this);
                cache[panelId].fields[fld.attr("name")] = fld.val();
            });

            // 上傳清單，只存有 uploadBtn 的 row
            panel.find(".uploadBtn").each(function () {
                let row = $(this).closest("tr.dynamicCheckRow");
                if (!row.length) return;
                let key = row.find(".valueInput").attr("name");
                if (!key) return;
                cache[panelId].uploads[key] = row.find(".valueInput").data("uploads") || [];
            });
        });
    }

    function restoreCache(panel) {
        let panelId = panel.data("panelid");
        if (!panelId || !cache[panelId]) return;

        // 回填欄位值
        if (cache[panelId].fields) {
            for (let name in cache[panelId].fields) {
                let fld = panel.find('[name="' + name + '"]');
                if (fld.length) fld.val(cache[panelId].fields[name]).trigger("change");
            }
        }

        // 回填上傳列表
        if (cache[panelId].uploads) {
            panel.find(".uploadBtn").each(function () {
                let row = $(this).closest("tr.dynamicCheckRow");
                if (!row.length) return;
                let key = row.find(".valueInput").attr("name");
                if (!key) return;
                let uploaded = cache[panelId].uploads[key] || [];
                row.find(".valueInput").data("uploads", uploaded);
                if (uploaded.length) {
                    let icon = row.find(".statusCell i");
                    if (icon.length) {
                        icon.removeClass("bi-x-circle text-danger").addClass("bi-check-circle text-success");
                    }
                }
            });
        }
    }

    function openUploadModal(panelId, row) {
        $("#uploadList").empty();

        let key = row.find(".valueInput").attr("name");
        let uploaded = cache[panelId].uploads ? cache[panelId].uploads[key] || [] : [];

        // 假資料
        uploaded.forEach(f => $("#uploadList").append('<li class="list-group-item">' + f + '</li>'));
        $("#uploadList").append('<li class="list-group-item">file1.txt</li>');
        $("#uploadList").append('<li class="list-group-item">file2.txt</li>');

        $("#uploadModal").modal("show");

        $("#uploadModal").off("hidden.bs.modal").on("hidden.bs.modal", function () {
            let newUploads = [];
            $("#uploadList li").each(function () {
                newUploads.push($(this).text());
            });

            if (!cache[panelId].uploads) cache[panelId].uploads = {};
            cache[panelId].uploads[key] = newUploads;

            row.find(".valueInput").data("uploads", newUploads);
            row.find(".valueInput").val(newUploads.length ? "已上傳" : "").trigger("change");
        });
    }

    // Tab 切換
    $(document).on('shown.bs.tab', 'a[data-bs-toggle="tab"]', function (e) {
        let targetPanel = $($(e.target).attr('data-bs-target'));
        if (!targetPanel) return;
        targetPanel.find("[data-panelid]").each(function () {
            restoreCache($(this));
        });
    });

    return {
        init: init,
        validate: validate,
        getData: getData,
        fillCache: fillCache,
        restoreCache: restoreCache
    };

})();