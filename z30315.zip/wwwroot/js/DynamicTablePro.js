﻿var DynamicTablePro = (function () {

    const api = {};
    api.events = {};
    api.tables = {};
    api.formatters = {
        currency: v => "$" + Number(v).toLocaleString()
    };

    // 建立 columns
    function buildColumns(schema) {
        let cols = [];
        let features = schema.Features || {};

        // Checkbox + Select All
        if (schema.Checkbox || features.Checkbox) {
            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                title: features.SelectAll ? '<input type="checkbox" class="dt-select-all">' : "",
                render: () => '<input type="checkbox" class="row-check">'
            });
        }

        // RowButtons
        let rowButtons = schema.RowButtons || (features.RowButtons ? schema.RowButtons : null);
        if (rowButtons) {
            rowButtons.forEach(btn => {
                cols.push({
                    data: null,
                    orderable: false,
                    defaultContent: "",
                    render: row =>
                        `<button class="dt-btn ${btn.CssClass}" 
                                data-event="${btn.Event}" 
                                data-id="${row.Id}">
                            ${btn.Title}
                        </button>`
                });
            });
        }

        // Data Columns
        schema.Columns.forEach(col => {
            let c = {
                data: col.Field,
                title: col.Title
            };
            if (col.Formatter) {
                c.render = v => api.formatters[col.Formatter] ? api.formatters[col.Formatter](v) : v;
            }
            cols.push(c);
        });

        return cols;
    }

    // 建立 Toolbar
    function buildToolbar(schema) {
        if (!schema.ToolbarButtons || schema.ToolbarButtons.length === 0) return;
        let tableId = schema.TableId;
        let toolbar = $(`<div class="dt-toolbar mb-2" id="toolbar_${tableId}"></div>`);
        schema.ToolbarButtons.forEach(btn => {
            let button = $(`
                <button class="${btn.CssClass}"
                        data-event="${btn.Event}"
                        data-table="${tableId}">
                        ${btn.Title}
                </button>
            `);
            toolbar.append(button);
        });
        $("#" + tableId).before(toolbar);
    }

    // render
    api.render = function (opt) {
        let schema = opt.schema;
        let columns = buildColumns(schema);
        let cfg = schema.Config || {};
        let features = schema.Features || {};

        let tableOptions = {
            columns: columns,
            stateSave: cfg.StateSave ?? features.StateSave ?? true,
            responsive: true,
            colReorder: true,
            searching: cfg.Searching ?? features.Searching ?? true,
            lengthChange: cfg.LengthChange ?? features.LengthChange ?? true,
            ordering: cfg.Ordering ?? features.Ordering ?? true,
            paging: cfg.Paging ?? features.Paging ?? true,
            pageLength: cfg.PageLength ?? 10,
            dom: "Bfrtip",
            buttons: (cfg.Buttons !== false || features.Export) ? ["excel"] : [],
            // Virtual Scroll
            scrollY: cfg.VirtualScrollHeight ?? (features.VirtualScroll ? "400px" : ""),
            scrollCollapse: features.VirtualScroll ?? false
        };

        if (schema.FetchMode === "all") {
            tableOptions.ajax = {
                url: schema.AjaxUrl,
                dataSrc: function (json) {
                    api['data_' + schema.TableId] = json.data;
                    return json.data;
                }
            };
        } else {
            tableOptions.serverSide = true;
            tableOptions.processing = true;
            tableOptions.ajax = schema.AjaxUrl;
        }

        let table = $("#" + schema.TableId).DataTable(tableOptions);
        api.tables[schema.TableId] = table;

        buildToolbar(schema);

        // RowButtons event
        $(document).on("click", `#${schema.TableId} .dt-btn`, function () {
            let event = $(this).data("event");
            let id = $(this).data("id");
            let row = table.row($(this).closest("tr")).data();
            if (api.events[event])
                api.events[event](id, row, schema.TableId);
        });

        // Select All 功能
        $(document).on("change", `#${schema.TableId} .dt-select-all`, function () {
            let checked = $(this).is(":checked");
            table.$("input.row-check").prop("checked", checked);
        });

        return table;
    };

    // render all
    api.renderAll = function (tables) {
        tables.forEach(schema => {
            api.render({ table: "#" + schema.TableId, schema: schema });
        });
    };

    // toolbar event
    $(document).on("click", ".dt-toolbar button", function () {
        let event = $(this).data("event");
        let tableId = $(this).data("table");
        if (api.events[event])
            api.events[event](tableId);
    });

    // reload
    api.reload = function (tableId) {
        let table = api.tables[tableId];
        if (table) table.ajax.reload();
    };

    // selected rows
    api.getSelectedRows = function (tableId) {
        let table = api.tables[tableId];
        let rows = [];
        table.$("input.row-check:checked").each(function () {
            let tr = $(this).closest("tr");
            let rowData = table.row(tr).data();
            if (rowData) rows.push(rowData);
        });
        return rows;
    };

    // get all data
    api.getAllData = function (tableId) {
        return api['data_' + tableId] || [];
    };

    return api;

})();