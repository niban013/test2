﻿var DynamicForm = (function () {

    function init(container) {
        // Select2 初始化
        $(container).find(".select2").each(function () {
            let select = $(this);
            select.select2({
                width: '100%',
                templateResult: function (item) {
                    if (!item.id) return item.text;
                    let color = $(item.element).data("color") || "";
                    // 設置 display:block + width:100% + padding
                    return $('<div style="background-color:' + color + '; width:100%; padding:4px 6px; box-sizing:border-box;">' + item.text + '</div>');
                },
                templateSelection: function (item) {
                    if (!item.id) return item.text;
                    return item.text; // 選中框文字
                }
            });

            // 設置選中背景色
            function setSelect2Background() {
                let color = select.find("option:selected").data("color") || "";
                select.next(".select2-container").find(".select2-selection--single").css("background-color", color);
            } 
            setSelect2Background();

            select.off("change").on("change", setSelect2Background);
        });
        // 普通 select 選中背景色
        $(container).find("select:not(.select2)").each(function () {
            let select = $(this);
            setSelectBackground(select);
            select.off("change").on("change", function () {
                setSelectBackground($(this));
            });
        });
    }
    function setSelectBackground(select) {
        let color = select.find("option:selected").css("background-color");
        select.css("background-color", color);
    }
    function validate(container) {
        let valid = true;
        $(container).find(".dynamicInput").each(function () {
            if ($(this).is(":hidden") || $(this).prop("readonly")) return;
            let must = $(this).data("must");
            let format = $(this).data("format");
            let val = $(this).val();
            if (must && (!val || val.trim() === "")) {
                $(this).addClass("is-invalid");
                valid = false;
                return;
            }

            // 進一步格式驗證
            if (val && format === "date") {
                if (isNaN(Date.parse(val))) {
                    isValid = false;
                    $(this).addClass("is-invalid");
                }
            }
            if (format === "number" && val && !$.isNumeric(val)) {
                $(this).addClass("is-invalid");
                valid = false;
                return;
            }
            $(this).removeClass("is-invalid");
        });
        return valid;
    }

    function getData(container) {

        let result = {};

        $(container).find(".dynamicInput").each(function () {

            let name = $(this).attr("name");

            result[name] = $(this).val();

        });

        return result;

    }

    return {

        init: init,

        validate: validate,

        getData: getData

    };

})();