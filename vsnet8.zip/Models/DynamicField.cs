 
namespace vsnet8.Models
{
    public enum FieldType
    {
        Label,
        Textbox,
        Dropdown,
        Select2
    }

    public class DynamicField
    {
        public string Name { get; set; }

        public string Label { get; set; }

        public bool Must { get; set; }

        public FieldType Type { get; set; }

        public string? DefaultValue { get; set; }
        public string Format { get; set; } = "string"; // string / number
        public string? Placeholder { get; set; }

        public bool Readonly { get; set; }

        public bool Hidden { get; set; }

        public int Width { get; set; } = 6; // bootstrap col
        public int Order { get; set; }   // ��ܶ���
        public List<SelectItem>? Options { get; set; }
    }

    public class SelectItem
    {
        public string Value { get; set; }
        public string Color { get; set; }  // �s�W�C��
        public string Text { get; set; }
    }
}
