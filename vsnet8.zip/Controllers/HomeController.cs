using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using vsnet8.Models;

namespace vsnet8.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public IActionResult LoadForm(string type)
        {


            var fields = GenerateFields(type);


            return PartialView("_DynamicForm", fields);
        }
        public IActionResult Index()
        { 
            return View();
        }

        private List<DynamicField> GenerateFields(string type)
        {
            var list = new List<DynamicField>();

            list.Add(new DynamicField
            {
                Name = "Name",
                Label = "�m�W",
                Format = "string",
                Must = false,
                Type = FieldType.Label,
                Width = 3,
                Order = 1
            });
            list.Add(new DynamicField
            {
                Name = "Age",
                Label = "�~��",
                Must = true,
                Type = FieldType.Textbox,
                Placeholder = "�п�J�~��",
                Width = 3,
                Format = "date",
                Order = 2
            });
            if (type == "employee")
            {
                list.Add(new DynamicField
                {
                    Name = "Dept",
                    Label = "����",
                    Must = true,
                    Type = FieldType.Select2,
                    Options = new()
                    {
                       new SelectItem{Value="1",Text="���`",Color="lightgreen"},
        new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
        new SelectItem{Value="3",Text="���`",Color="lightcoral"}
                    }
                });
            }

            if (type == "customer")
            {
                list.Add(new DynamicField
                {
                    Name = "City",
                    Label = "����",
                    Type = FieldType.Select2,
                    Options = new()
            {
                new SelectItem{Value="taipei",Text="�x�_"},
                new SelectItem{Value="hsinchu",Text="�s��"}
            }
                });
            }

            return list;
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
