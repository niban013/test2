﻿using Microsoft.Extensions.Localization;
using System.Globalization;
using System.Text.Json;
namespace vsnet8.Helper
{
    public class JsonStringLocalizerFactory : IStringLocalizerFactory
    {
        private readonly string _resourcesPath = "i18n";

        public IStringLocalizer Create(Type resourceSource)
        {
            return Create();
        }

        public IStringLocalizer Create(string baseName, string location)
        {
            return Create();
        }

        private IStringLocalizer Create()
        {
            var culture = CultureInfo.CurrentUICulture.Name;
            var path = Path.Combine(Directory.GetCurrentDirectory(), _resourcesPath,"Lang", $"{culture}.json");

            return new JsonStringLocalizer(path);
        }
    }
}
