﻿using System.Collections.Concurrent;
using System.Globalization;

namespace vsnet8.Helper
{
    public class I18nMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ConcurrentDictionary<string, string> _langCache;

        public I18nMiddleware(RequestDelegate next, ConcurrentDictionary<string, string> langCache)
        {
            _next = next;
            _langCache = langCache;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            string culture = CultureInfo.CurrentUICulture.Name;

            if (!_langCache.TryGetValue(culture, out var langJson))
            {
                langJson = "{}"; // fallback
            }

            // ⚡ 把 JSON 放到 HttpContext.Items，供 View / Layout 使用
            context.Items["LangJson"] = langJson;

            await _next(context);
        }
    }
}
