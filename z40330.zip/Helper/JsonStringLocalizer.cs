﻿using Microsoft.Extensions.Localization;
using System.Text.Json;
namespace vsnet8.Helper
{
    public class JsonStringLocalizer : IStringLocalizer
    {
        private readonly Dictionary<string, string> _resources;

        public JsonStringLocalizer(string path)
        {
            if (File.Exists(path))
            {
                var json = File.ReadAllText(path);
                _resources = JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                            ?? new Dictionary<string, string>();
            }
            else
            {
                _resources = new Dictionary<string, string>();
            }
        }

        public LocalizedString this[string name]
        {
            get
            {
                var value = _resources.ContainsKey(name) ? _resources[name] : name;
                return new LocalizedString(name, value, resourceNotFound: value == name);
            }
        }

        public LocalizedString this[string name, params object[] arguments]
            => new(name, string.Format(this[name].Value, arguments));

        public IEnumerable<LocalizedString> GetAllStrings(bool includeParentCultures)
            => _resources.Select(r => new LocalizedString(r.Key, r.Value));

        public IStringLocalizer WithCulture(System.Globalization.CultureInfo culture)
            => this;
    }
}
