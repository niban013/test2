﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Collections.Concurrent;
using System.Globalization;

namespace vsnet8.Helper
{
    [HtmlTargetElement("i18n-scripts")]
    public class I18nScriptsTagHelper : TagHelper
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public I18nScriptsTagHelper(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            // 不產生包裹元素
            output.TagName = null;

            var httpContext = _httpContextAccessor.HttpContext;
            var langJson = httpContext?.Items["LangJson"] as string ?? "{}";

            var script = $@"
<script>
(function() {{
    if (!window.I18n) {{
        window.I18n = {langJson};
    }}

    function updateText() {{
        if (!window.I18n) return;
        document.querySelectorAll('[data-i18n]').forEach(el => {{
            const key = el.getAttribute('data-i18n');
            if (key && window.I18n[key] !== undefined) {{
                el.textContent = window.I18n[key];
            }}
        }});
    }}

    function switchCulture(culture) {{
        const cookieValue = `c=${{culture}}|uic=${{culture}}`;
        document.cookie = `.AspNetCore.Culture=${{cookieValue}}; path=/`;

        fetch(`/api/i18n?culture=${{culture}}`)
            .then(res => res.json())
            .then(lang => {{
                window.I18n = lang;
                updateText();
            }})
            .catch(err => console.error('切換語系失敗:', err));
    }}

    window.I18nUtils = {{
        switchCulture,
        updateText
    }};

    updateText();
}})();
</script>
";

            output.Content.SetHtmlContent(script);
        }
    }
}
