﻿using Microsoft.AspNetCore.Mvc;
using vsnet8.Controllers.vsnet8.Models;

namespace vsnet8.Controllers
{
    namespace vsnet8.Models
    {
        public class UploadFile
        {
            public string RowKey { get; set; }

            public string FileName { get; set; }

            public DateTime UploadTime { get; set; }
        }
    }
    public class UploadController : Controller
    {
        
            static Dictionary<string, List<UploadFile>> store = new();

            [HttpGet]
            public IActionResult List(string rowKey)
            {
                if (!store.ContainsKey(rowKey))
                    store[rowKey] = new List<UploadFile>();

                return Json(store[rowKey]);
            }

            [HttpPost]
            public async Task<IActionResult> Upload(string rowKey, IFormFile file)
            {
                if (file == null || file.Length == 0)
                    return BadRequest();

                if (!store.ContainsKey(rowKey))
                    store[rowKey] = new List<UploadFile>();

                store[rowKey].Add(new UploadFile
                {
                    RowKey = rowKey,
                    FileName = file.FileName,
                    UploadTime = DateTime.Now
                });

                return Ok();
            }

            [HttpPost]
            public IActionResult Delete(string rowKey, string fileName)
            {
                if (store.ContainsKey(rowKey))
                {
                    var f = store[rowKey].FirstOrDefault(x => x.FileName == fileName);

                    if (f != null)
                        store[rowKey].Remove(f);
                }

                return Ok();
            }
        }
    
}
