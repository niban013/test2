﻿namespace vsnet8.i18n
{
    public class SharedResource
    {
    }
}
