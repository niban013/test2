﻿

using System.Globalization;
using System.Text.Json;
using System.Collections.Concurrent;

namespace vsnet8.i18n
{
    public class LocalizedKeys
    {
        private readonly ConcurrentDictionary<string, string> _langCache;

        public LocalizedKeys(ConcurrentDictionary<string, string> langCache)
        {
            _langCache = langCache;
        }

        private Dictionary<string, string> GetLang()
        {
            var culture = CultureInfo.CurrentUICulture.Name;

            if (_langCache.TryGetValue(culture, out var json))
            {
                return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                       ?? new Dictionary<string, string>();
            }

            return new Dictionary<string, string>();
        }

        public string Hello => GetLang().GetValueOrDefault("Hello");
        public string Submit => GetLang().GetValueOrDefault("Submit");
        public string Required => GetLang().GetValueOrDefault("Required");
    }
}