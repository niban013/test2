﻿var DynamicTablePro = (function () {
    const api = {};
    api.events = {};
    api.tables = {};
    api.formatters = {
        currency: v => "$" + Number(v).toLocaleString()
    };

    // 建立欄位
    function buildColumns(schema) {
        let cols = [];
        let features = schema.Features || {};

        // Checkbox + Select All
        if (features.Checkbox) {
            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-checkbox-col",
                title: features.SelectAll
                    ? '<input type="checkbox" class="dt-select-all">'
                    : "",
                render: () => '<input type="checkbox" class="row-check">',
                createdCell: function (td) {
                    $(td).css({
                        "white-space": "nowrap",
                        "width": "1%",
                        "text-align": "center"
                    });
                }
            });
        }


        // RowButtons (每列操作)
        if (features.RowButtons && schema.RowButtons?.length > 0) {

            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-row-btn-col",

                createdCell: function (td) {

                    $(td).css({
                        "white-space": "nowrap",
                        "width": "1%",
                        //  "display": "flex",
                        "gap": "6px"   // ⭐ 按鈕間距
                    });

                },

                render: row => {

                    return schema.RowButtons.map(btn => {

                        let iconHtml = btn.Icon
                            ? `<i class="bi ${btn.Icon}" style="margin-right:4px;"></i>`
                            : "";

                        let textHtml = btn.Title
                            ? btn.Title
                            : "";

                        // ⭐ 關鍵：tooltip fallback
                        let tooltip = btn.Tooltip || btn.Title || btn.Event || "";

                        return `
                            <button class="dt-btn ${btn.CssClass}" 
                                    data-event="${btn.Event}" 
                                    data-id="${row.Id}"
                                    title="${tooltip}">
                                ${iconHtml}${textHtml}
                            </button>
                        `;

                    }).join("");

                }
            });
        }

        // 資料欄位
        (schema.Columns || []).forEach(col => {
            let c = { data: col.Field, title: col.Title ?? col.Field };
            if (col.Formatter) c.render = v => api.formatters[col.Formatter] ? api.formatters[col.Formatter](v) : v;

             //Column Filter
            if (features.ColumnFilter) {
               // c.footer = `<input type="text" placeholder="All" class="column-filter form-control form-control-sm" style="width:100%;"/>`;
                c.headerFilter = `<input type="text" placeholder="All" class="column-filter form-control form-control-sm" style="width:100%; margin-top:4px;"/>`;

            }

            cols.push(c);
        });

        return cols;
    }

    $(document).on("click", ".dt-row-btn-col .dt-btn", function () {

        let $table = $(this).closest("table");
        let table = $table.DataTable();

        let event = $(this).data("event");
        let id = $(this).data("id");

        let row = table.row($(this).closest("tr")).data();

        let tableId = $table.attr("id");

        if (api.events[event]) {
            api.events[event](id, row, tableId);
        }
    });
    // Render Table
    api.render = function (opt) {
        let schema = opt.schema;
        let columns = buildColumns(schema);
        let cfg = schema.Config || {};
        let features = schema.Features || {};
        let dtButtons = [];

        if (schema.ToolbarButtons && schema.ToolbarButtons.length > 0) {
            schema.ToolbarButtons.forEach(btn => {
                dtButtons.push({
                    text: `<i class="${btn.Icon}"></i> ${btn.Title}`, // 直接在此注入 Icon
                    attr: {
                        'title': btn.Title,
                        'data-bs-toggle': 'tooltip'
                    },
                    className: btn.CssClass,
                    // 核心修正：強制讓這個按鈕不帶 dt-button 類別
                    init: function (api, node, config) {
                        $(node).removeClass('dt-button');
                    },
                    action: function (e, dt, node, config) {
                        if (api.events[btn.Event]) api.events[btn.Event](schema.TableId);
                    }
                });
            });
        }
        let tableOptions = {
            //autoWidth: true,
            columns: columns,

            stateSave: cfg.StateSave ?? true,
            responsive: true,
            colReorder: true,
            //searching: cfg.Searching ?? true,
            lengthChange: cfg.LengthChange ?? true,
            ordering: cfg.Ordering ?? true,
            paging: cfg.Paging ?? true,
            pageLength: cfg.PageLength ?? 10,
            dom: '<"table-header-right" f B>rt<"table-footer d-flex justify-content-between" ip>',
            buttons: dtButtons,//(cfg.Buttons !== false || features.Export) ? ["excel"] : [],
            scrollY: cfg.ScrollY ?? (features.VirtualScroll ? "400px" : ""),
            scrollCollapse: features.VirtualScroll ?? false,
            deferRender: features.VirtualScroll ?? false,
            scroller: features.VirtualScroll ?? false,
            fixedHeader: features.StickyHeader ?? false,
            // ⭐ 如果 stateSave = true，覆蓋舊的 state
            stateLoadParams: function (settings, data) {
                data.start = 0;                       // 從第一頁開始
                data.length = cfg.PageLength ?? 10;   // 每頁筆數
                return data;
            },
            select: {
                style: 'multi',
                selector: 'td.dt-checkbox-col input.row-check'
            },
            initComplete: function () {
                const apiDt = this.api();
                // ⭐ Column Filter 可開關
                if (features.ColumnFilter) {
                    apiDt.columns().every(function (i) {
                        const col = this;
                        const th = $(col.header());
                        const hf = col.settings()[0].aoColumns[i].headerFilter;
                        if (hf) {
                            const input = $(hf);
                            th.append('<br>').append(input);
                            // ⭐ 同步 stateSave 值
                            input.val(col.search());
                            input.on('keyup change clear', function () {
                                col.search(this.value).draw();
                            });
                        }
                    });
                }
                //const thead = $(api.table().header());
                //if (features.ColumnFilter) {
                //// 假設前 offset 欄位是 RowButtons / Checkbox，需要跳過
                ////const columnOffset = 1; // 如果有 1 欄 RowButtons 或 Checkbox
                //// 如果你有 checkbox + rowbuttons，可以設 2
                //// 自動計算 offset：前幾欄有 class dt-checkbox-col 或 dt-btn-col
                //let columnOffset = 0;
                //api.columns().every(function (i) {
                //    const col = this.header();
                //    if ($(col).hasClass('dt-checkbox-col') || $(col).hasClass('dt-row-btn-col')) {
                //        columnOffset++;
                //    } else {
                //        return false; // 遇到第一個資料欄就停止
                //    }
                //});
                //// 建 filter row
                //let filterRow = $('<tr class="filter-row"></tr>');

                //api.columns().every(function (i) {
                //    if (i < columnOffset) {
                //        // 前幾欄空白
                //        filterRow.append('<th></th>');
                //    } else {
                //        filterRow.append('<th><input type="text" class="form-control form-control-sm column-filter" placeholder="Search"></th>');
                //    }
                //});

                //thead.append(filterRow);

                //// ⭐ 最穩寫法（delegate）
                //thead.on('keyup change clear', '.column-filter', function () {
                //    let colIndex = $(this).closest('th').index();
                //    let value = this.value;

                //    // console.log("filter:", colIndex, value);

                //    api.column(colIndex).search(value).draw();
                //});
                //} else {
                //    // 如果 ColumnFilter = false，確保沒有 filter row
                //    thead.find('.filter-row').remove();
                //}
            }
        };

        // Ajax
        if (schema.FetchMode === 0) {
            tableOptions.ajax = {
                url: schema.AjaxUrl,
                dataSrc: function (json) {
                    api['data_' + schema.TableId] = json.data;
                    return json.data;
                }
            };
            tableOptions.serverSide = false;
        } else {
            tableOptions.serverSide = true;
            tableOptions.processing = true;
            tableOptions.ajax = schema.AjaxUrl;
        }

        let table = $("#" + schema.TableId).DataTable(tableOptions);
        // ⭐ 同步 checkbox UI 與 selected class（跨頁 & stateSave 支援）
        table.rows().every(function () {
            const $rowNode = $(this.node());
            $rowNode.find('.row-check').prop('checked', this.selected());
            $rowNode.toggleClass('table-active', this.selected());
        });


        // ⭐ 同步 header checkbox
        const total = table.rows().count();
        const selected = table.rows({ selected: true }).count();
        $table.find('.dt-select-all').prop('checked', total === selected);





        // ⭐ 1. 全選 / 全消 (包含跨分頁)
        $(document).on('change', '.dt-select-all', function () {
            const isChecked = $(this).prop('checked');

            if (isChecked) {
        // 選取所有 rows (跨頁)
        table.rows().select();
    } else {
        // 取消選取所有 rows
        table.rows().deselect();
    }

    // 同步 checkbox UI 與 selected class
    table.rows().every(function () {
        const $rowNode = $(this.node());
        $rowNode.find('.row-check').prop('checked', this.selected());
        $rowNode.toggleClass('table-active', this.selected());
    });
            //// table.rows().nodes() 會抓到所有分頁的 DOM 節點
            //const allNodes = table.rows().nodes().to$();

            //allNodes.find('.row-check').prop('checked', isChecked);
            //allNodes.toggleClass('table-active', isChecked);
        });

        // ⭐ 2. 單選影響全選框狀態
        $(document).on('change', '.row-check', function () {
            //const allCheckboxes = table.rows().nodes().to$().find('.row-check');
            //const checkedCount = allCheckboxes.filter(':checked').length;

            //// 同步 Header Checkbox
            //$('.dt-select-all').prop('checked', checkedCount === allCheckboxes.length);

            //// 同步該列樣式
            //$(this).closest('tr').toggleClass('table-active', this.checked);

           
           
            const row = table.row($(this).closest('tr'));

            // 選取 / 取消選取 row
            if (this.checked) row.select();
            else row.deselect();

            // 更新 row highlight
            $(this).closest('tr').toggleClass('table-active', this.checked);

            // 同步 header checkbox
            const total = table.rows().count();
            const selected = table.rows({ selected: true }).count();
            $table.find('.dt-select-all').prop('checked', total === selected);
        });

        // ⭐ 3. 翻頁後維持 Header Checkbox 狀態正確
        table.on('draw', function () {
            const allCheckboxes = table.rows().nodes().to$().find('.row-check');
            const isAllChecked = allCheckboxes.length > 0 && allCheckboxes.length === allCheckboxes.filter(':checked').length;
            $('.dt-select-all').prop('checked', isAllChecked);
        });

        api.tables[schema.TableId] = table;

        return table;
    };

    api.renderAll = function (tables) {
        tables.forEach(schema => api.render({ schema }));
    };

    // Toolbar event
    $(document).on("click", ".dataTables_filter button", function () {
        let event = $(this).data("event");
        let tableId = $(this).data("table");
        if (api.events[event]) api.events[event](tableId);
    });

    // Get selected rows
    api.getSelectedRows = function (tableId) {
        let table = api.tables[tableId];
        let rows = [];
        table.$(".row-check:checked").each(function () {
            let tr = $(this).closest("tr");
            let rowData = table.row(tr).data();
            if (rowData) rows.push(rowData);
        });
        return rows;
    };

    // Get all data
    api.getAllData = function (tableId) {
        return api['data_' + tableId] || [];
    };

    // ----------------------
    return api;
})();