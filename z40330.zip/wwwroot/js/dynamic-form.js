﻿var DynamicForm = (function () {

    class DynamicFormInstance {
        constructor(container) {
            this.container = $(container);
            this.asyncCache = {};
            this.asyncTokens = {};

            this.init();
        }

        init() {
            this.initWrapper();
            this.initSelect2();
            this.initDefaultValue();
            this.initStatus();
            this.bindEvents();
        }

        initWrapper() {
            this.container.find(".dynamicInput").each((_, el) => {
                let $el = $(el);
                if (!$el.parent().hasClass("input-with-status")) {
                    $el.wrap('<div class="input-with-status"></div>');
                }
            });
        }

        initSelect2() {
            this.container.find(".select2").each((_, el) => {
                let select = $(el);
                select.select2({
                    width: '100%',
                    templateResult: this.formatOption,
                    templateSelection: this.formatSelection
                });
                this.setSelect2Background(select);

                select.on("select2:select select2:unselect", (e) => {
                    this.setSelect2Background(select);
                    this.validateField(select);
                    select.trigger("change");
                });
            });
        }

        formatOption(item) {
            if (!item.id) return item.text;
            let color = $(item.element).data("color") || "";
            return $('<div style="background:' + color + '; padding:4px 6px;">' + item.text + '</div>');
        }

        formatSelection(item) { return item.text; }

        setSelect2Background(select) {
            let color = select.find("option:selected").data("color") || "";
            select.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }

        initDefaultValue() {
            this.container.find(".dynamicInput").each((_, el) => {
                let $el = $(el);
                let def = $el.data("default");
                if (!$el.val() && def) $el.val(def);
            });
        }

        initStatus() {
            this.container.find(".dynamicInput").each((_, el) => {
                this.clearStatusIcon($(el));
            });
        }

        setStatusIcon($el, status) {
            const $wrapper = $el.parent(".input-with-status");
            this.clearStatusIcon($el);

            let must = $el.data("must");
            let val = $el.val()?.trim() || "";
            if (must && val === "") return;

            let iconHtml = '';
            if (status === 'success') iconHtml = '<i class="bi bi-check-circle text-success"></i>';
            else if (status === 'error') iconHtml = '<i class="bi bi-x-circle text-danger"></i>';
            else if (status === 'processing') iconHtml = '<i class="bi bi-arrow-repeat rotate text-primary"></i>';

            if (iconHtml) {
                const $icon = $('<span class="status-icon">' + iconHtml + '</span>');
                $wrapper.append($icon);
                $wrapper.addClass("has-icon");   // ✅ 出現 icon 時加 class
            }
        }

        clearStatusIcon($el) {
            const $wrapper = $el.parent(".input-with-status");
            $wrapper.find(".status-icon").remove();
            $wrapper.removeClass("has-icon");   // ✅ 清除 icon 時去掉 class
        }

        async validateField(el) {
            let $el = $(el);
            let val = $el.val()?.trim() || "";
            let must = $el.data("must");

            this.clearError($el);
            this.clearStatusIcon($el);

            if (!must && val === "") return true;
            if (must && val === "") { this.setError($el, "必填"); return false; }

            let isValid = true;
            let pattern = $el.data("pattern");
            let minlength = $el.data("minlength");
            let maxlength = $el.data("maxlength");
            let min = $el.attr("min");
            let max = $el.attr("max");
            let conditional = $el.data("conditional");
            let cross = $el.data("cross");
            let asyncUrl = $el.data("async");

            if (pattern && val) { let regex = new RegExp(pattern); if (!regex.test(val)) { this.setError($el, "格式錯誤"); isValid = false; } }
            if (minlength && val.length < minlength) { this.setError($el, `至少${minlength}字`); isValid = false; }
            if (maxlength && val.length > maxlength) { this.setError($el, `最多${maxlength}字`); isValid = false; }
            if (min && val && parseFloat(val) < parseFloat(min)) { this.setError($el, `不可小於${min}`); isValid = false; }
            if (max && val && parseFloat(val) > parseFloat(max)) { this.setError($el, `不可大於${max}`); isValid = false; }

            if (conditional) { let cond = JSON.parse(conditional); if ($(cond.selector).val() && val === "") { this.setError($el, "條件必填"); isValid = false; } }
            if (cross) { let c = JSON.parse(cross); let otherVal = $(c.selector).val(); if (c.op === ">" && val && otherVal && parseFloat(val) <= parseFloat(otherVal)) { this.setError($el, `必須大於${c.selector}`); isValid = false; } }

            if (asyncUrl && val) {
                if (this.asyncCache[val] !== undefined) {
                    if (!this.asyncCache[val]) this.setError($el, "驗證失敗");
                    this.setStatusIcon($el, this.asyncCache[val] ? 'success' : 'error');
                    return this.asyncCache[val];
                }

                if (this.asyncTokens[$el]) this.asyncTokens[$el].abort();

                try {
                    this.setStatusIcon($el, 'processing');
                    let resp = await $.ajax({ url: asyncUrl, data: { value: val } });
                    if ($el.val()?.trim() !== val) return false;

                    this.asyncCache[val] = resp.valid;
                    if (!resp.valid) { this.setError($el, resp.message || "驗證失敗"); this.setStatusIcon($el, 'error'); }
                    else { this.clearError($el); this.setStatusIcon($el, 'success'); }

                    return resp.valid;
                } catch {
                    this.asyncCache[val] = false;
                    this.setError($el, "異步驗證失敗");
                    this.setStatusIcon($el, 'error');
                    return false;
                } finally { this.asyncTokens[$el] = null; }
            } else if (val !== "") {
                this.setStatusIcon($el, isValid ? 'success' : 'error');
            }

            return isValid;
        }

        async validate() {
            let isValid = true;
            let asyncTasks = [];
            this.container.find(".dynamicInput").each((_, el) => {
                asyncTasks.push(this.validateField(el).then(res => { if (!res) isValid = false; }));
            });
            await Promise.all(asyncTasks);
            return isValid;
        }

        setError($el, msg) {
            $el.addClass("is-invalid").css("border", "1px solid red");
            $el.next(".select2-container").find(".select2-selection").css("border", "1px solid red");
            if (msg) $el.attr("title", msg);
        }

        clearError($el) {
            $el.removeClass("is-invalid").css("border", "").attr("title", "");
            $el.next(".select2-container").find(".select2-selection").css("border", "");
        }

        getData() {
            let result = {};
            this.container.find(".dynamicInput").each((_, el) => {
                let $el = $(el);
                result[$el.attr("name")] = $el.val();
            });
            return result;
        }

        bindEvents() {
            const asyncValidateDebounced = this.debounce(async (e) => {
                const $el = $(e.currentTarget);
                await this.validateField($el);
            }, 500);

            // input → typing icon
            this.container.on("input", ".dynamicInput", (e) => {
                const $el = $(e.currentTarget);
                this.clearStatusIcon($el);
                if ($el.val()?.trim() !== "") this.setStatusIcon($el, 'processing');
            });

            // blur/change → validate
            this.container.on("blur change", ".dynamicInput", asyncValidateDebounced);

            this.container.on("change", ".dropdownColor", (e) => {
                let $el = $(e.currentTarget);
                let color = $el.find("option:selected").data("color");
                $el.css("background-color", color);
            });
        }

        debounce(fn, delay = 500) {
            let timer;
            return function (...args) {
                clearTimeout(timer);
                timer = setTimeout(() => fn.apply(this, args), delay);
            };
        }
    }

    return { create: (container) => new DynamicFormInstance(container) };

})();