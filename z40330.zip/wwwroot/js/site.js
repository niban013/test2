﻿
$(document).on("mouseenter", ".tooltip-auto", function () {

    let instance = bootstrap.Tooltip.getInstance(this);

    if (!instance) {
        instance = new bootstrap.Tooltip(this, {
            title: this.dataset.title || "",
            placement: "top",
            trigger: "manual",   // ⭐ 改 manual
            container: "body"
        });
    }

    instance.show(); // ⭐ 直接顯示
});

$(document).on("mouseleave", ".tooltip-auto", function () {
    const instance = bootstrap.Tooltip.getInstance(this);
    if (instance) instance.hide();
});



// Upload Modal Module
// ===========================

let currentRow = null;
let currentKey = null;


// ===========================
// 點擊 Row 的上傳按鈕
// ===========================

$(document).on("click", ".uploadBtn", function () {

    currentRow = $(this).closest("tr");

    currentKey = '9';// currentRow.data("key");

    loadFiles();

    $("#uploadModal").modal("show");

});


// ===========================
// 載入附件清單
// ===========================

function loadFiles() {

    $.get("/Upload/List",
        { rowKey: currentKey },
        function (files) {

            let list = $("#uploadList");

            list.empty();

            if (!files || files.length === 0) {

                list.append(`
                    <li class="list-group-item text-muted">
                        尚未上傳
                    </li>
                `);

                return;
            }

            files.forEach(f => {

                list.append(`
                    <li class="list-group-item d-flex justify-content-between align-items-center">

                        ${f.fileName}

                        <button class="btn btn-sm btn-danger deleteFile"
                                data-name="${f.fileName}">
                            刪除
                        </button>

                    </li>
                `);

            });

        });

}


// ===========================
// 上傳檔案
// ===========================

$(document).on("click", "#btnUpload", function () {

    let file = $("#fileUpload")[0].files[0];

    if (!file) {

        alert("請選擇檔案");

        return;

    }

    let formData = new FormData();

    formData.append("rowKey", currentKey);

    formData.append("file", file);

    $.ajax({

        url: "/Upload/Upload",

        type: "POST",

        data: formData,

        processData: false,

        contentType: false,

        success: function () {

            $("#fileUpload").val("");

            loadFiles();

        }

    });

});


// ===========================
// 刪除檔案
// ===========================

$(document).on("click", ".deleteFile", function () {

    let fileName = $(this).data("name");

    $.post("/Upload/Delete",
        {
            rowKey: currentKey,
            fileName: fileName
        },
        function () {

            loadFiles();

        });

});


// ===========================
// Modal 關閉 → 更新 Row icon
// ===========================

$(document).on("hidden.bs.modal", "#uploadModal", function () {

    if (!currentRow) return;

    $.get("/Upload/List",
        { rowKey: currentKey },
        function (files) {

            let icon = currentRow.find(".statusCell i");

            if (files && files.length > 0) {

                icon.removeClass("bi-x-circle text-danger")
                    .addClass("bi-check-circle text-success");
                // ⭐ 帶值到第一欄
                currentRow.find(".valueInput").val("88").trigger("change");
            }
            else {

                icon.removeClass("bi-check-circle text-success")
                    .addClass("bi-x-circle text-danger");
                currentRow.find(".valueInput").val("99").trigger("change");
            }

        });

});