﻿const { createApp, reactive, ref, onMounted } = Vue;
 
// 🔥 TextInput 元件
const TextInput = {
    props: ['field', 'formData'],
    setup(props) {

        // 使用 panelId_fieldId 做唯一 key
        const key = props.field.uniqueKey;

        const model = Vue.computed({
            get: () => props.formData[key],
            set: val => props.formData[key] = val
        });

        const error = Vue.computed(() => {
            if (props.field.required && !model.value) {
                return '必填欄位';
            }
            return '';
        });

        const visible = Vue.computed(() => {
            if (!props.field.visibleWhen) return true;
            const rule = props.field.visibleWhen;
            const val = props.formData[rule.field];
            if (rule.notEmpty) return !!val;
            return true;
        });

        return { model, error, visible };
    },
    template: `
    <div v-if="visible" class="mb-3">

        <label class="form-label">
            {{field.label}}
            <span v-if="field.required" class="text-danger">*</span>
        </label>

        <input type="text"
               class="form-control"
               :class="{'is-invalid': error}"
               v-model="model" />

        <div class="invalid-feedback">
            {{error}}
        </div>

    </div>
    `
};

// 🔥 Dropdown 元件
const DropdownInput = {
    props: ['field', 'formData'],
    setup(props) {

        // panelId_fieldId 做唯一 key
        const key = props.field.uniqueKey;

        // computed 讀寫 formData
        const model = Vue.computed({
            get: () => props.formData[key],
            set: val => props.formData[key] = val
        });

        // 驗證（可選必填）
        const error = Vue.computed(() => {
            if (props.field.required && !model.value) {
                return '必填欄位';
            }
            return '';
        });

        // visibleWhen 條件顯示
        const visible = Vue.computed(() => {
            if (!props.field.visibleWhen) return true;

            const rule = props.field.visibleWhen;
            const val = props.formData[rule.field];
            if (rule.notEmpty) return !!val;
            return true;
        });

        return { model, error, visible };
    },
    template: `
    <div v-if="visible" class="mb-3">

        <label class="form-label">
            {{field.label}}
            <span v-if="field.required" class="text-danger">*</span>
        </label>

        <select class="form-select"
                :class="{'is-invalid': error}"
                v-model="model">
            <option v-for="opt in field.options" :key="opt.value" :value="opt.value">
                {{opt.text}}
            </option>
        </select>

        <div class="invalid-feedback">
            {{error}}
        </div>

    </div>
    `
};
const normalizeSchema = (schema) => {

    // 沒 tabs → 包一層
    if (!schema.tabs) {
        return {
            tabs: [
                {
                    id: 'default',
                    name: '表單',
                    panels: [
                        {
                            id: 'panel1',
                            title: '',
                            fields: schema.fields || []
                        }
                    ]
                }
            ]
        };
    }

    // 有 tabs → 檢查 panels
    schema.tabs.forEach(tab => {

        if (!tab.panels) {
            tab.panels = [
                {
                    id: tab.id + '_panel',
                    title: '',
                    fields: tab.fields || []
                }
            ];
        }

    });

    return schema;
};
const Tabs = {
    props: ['tabs', 'activeTab'],
    emits: ['update:activeTab'],
    template: `
    <ul class="nav nav-tabs mb-3">
        <li class="nav-item" v-for="tab in tabs" :key="tab.id">
            <button class="nav-link"
                    :class="{active: activeTab === tab.id}"
                    @click="$emit('update:activeTab', tab.id)">
                {{tab.name}}
            </button>
        </li>
    </ul>
    `
};

const Panel = {
    props: ['panel', 'formData'],
    components: { TextInput, DropdownInput },
    setup(props) {
        const getFields = () => props.panel.fields || [];
        return { getFields };
    },
    template: `
    <div class="card mb-3 shadow-sm">
        <div class="card-header" v-if="panel.title">{{panel.title}}</div>
        <div class="card-body">
            <component
                v-for="field in getFields()"
                :key="field.uniqueKey"
                :is="field.type === 'text' ? 'TextInput' : field.type === 'dropdown' ? 'DropdownInput' : 'div'"
                :field="field"
                :formData="formData"
            />
        </div>
    </div>
    `
};

// 🔥 DynamicForm 主元件
const DynamicFormvue = {
    props: ['schema'],
    components: {
        Tabs,
        Panel
    },
    setup(props) {

        const normalized = Vue.ref({ tabs: [] });
        const activeTab = Vue.ref(null);
        const formData = Vue.reactive({}); 

        Vue.watch(() => props.schema, (val) => {

            if (!val) return;

            normalized.value = normalizeSchema(val);

            // 設定預設 tab
            activeTab.value = normalized.value.tabs[0]?.id;

            // 初始化 formData（只做一次或重建）
            normalized.value.tabs.forEach(tab => {
                tab.panels.forEach(panel => {
                    panel.fields.forEach(f => {
                        const key = panel.id + '_' + f.id; // 唯一 key
                        f.uniqueKey = key;
                        if (!(key in formData)) {
                            formData[key] = ''; // text / dropdown 都適用
                        }
                    });
                });
            });

        }, { immediate: true });


        return {
            activeTab,
            formData,
            normalized
        };
    },
    template: `
    <div class="container mt-4">

        <!-- Tabs -->
    <tabs
        v-if="normalized.tabs.length > 1"
        :tabs="normalized.tabs"
        :activeTab="activeTab"
        @update:activeTab="val => activeTab = val"
    />

    <!-- Panels -->
    <div v-for="tab in normalized.tabs"
         v-show="activeTab === tab.id"
         :key="tab.id">
        <panel
            v-for="p in tab.panels"
            :key="p.id"
            :panel="p"
            :formData="formData"
        />
    </div>

    <!-- Debug -->
    <pre class="mt-3">{{formData}}</pre>

    </div>
    `
};

// 🔥 App 啟動
createApp({
    components: { 
        'dynamic-form': DynamicFormvue // ✅ 重點 
    },
    setup() {

        const schema = ref(null);

        // 從 MVC 拿 schema
        onMounted(async () => {
            const res = await fetch('/Home/GetFormSchema');
            schema.value = await res.json();
        });

        return {
            schema
        };
    }
}).mount('#app');