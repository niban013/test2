﻿using auomvc.Models;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;
using System.Text.Json;
namespace auomvc.Helper
{
    public static class ViewHelper
    {
        public static string ResolveValue(string value, string defaultValue)
        {
            return !string.IsNullOrEmpty(value) ? value : (defaultValue ?? "");
        }
        public static IHtmlContent RenderAppConfig(this IHtmlHelper htmlHelper, string sectionName = "FileUploadConfig")
        {
            var config = htmlHelper.ViewContext.HttpContext.RequestServices.GetRequiredService<IConfiguration>();

            // 1. 取得指定的整個區塊 (例如 FrontendConfig)
            var section = config.GetSection(sectionName);

            // 2. 將該區塊轉換為 Dictionary，方便序列化
            var settings = section.AsEnumerable()
                .Where(x => x.Value != null)
                .ToDictionary(x => x.Key.Replace($"{sectionName}:", ""), x => x.Value);

            // 3. 序列化為 JSON (使用 CamelCase 讓 JS 好讀)
            var jsonOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
            var json = System.Text.Json.JsonSerializer.Serialize(settings, jsonOptions);

            return new HtmlString($"<script>window.appConfig = {json};</script>");
        }

        /// <summary>
        /// 取得 Controller_Action
        /// </summary>
        public static string GetPageKey(this IHtmlHelper html)
        {
            var route = html.ViewContext.RouteData.Values;
            var controller = route["controller"]?.ToString();
            var action = route["action"]?.ToString();

            return $"{controller}_{action}";
        }

        /// <summary>
        /// Controller_Action_Tab
        /// </summary>
        public static string GetPageTabKey(this IHtmlHelper html, string tabId)
        {
            var baseKey = html.GetPageKey();
            return $"{baseKey}_{tabId}";
        }

        public static IHtmlContent RenderDynamicFormTypesAuto(this IHtmlHelper html, Dictionary<string, List<DynamicField>> model)
        {
            if (model is not Dictionary<string, List<DynamicField>> dict)
                return HtmlString.Empty;

            var sb = new StringBuilder();

            sb.AppendLine("<script>");
            foreach (var tab in model)
            {
                sb.AppendLine($"/**");
                sb.AppendLine($" * @typedef {{");

                foreach (var field in tab.Value)
                {
                    var type = "string"; // 預設

                    if (field.Type.ToString() == "number" || field.Type.ToString() == "int") type = "number";
                    if (field.Type.ToString() == "date") type = "string"; // date 可改成 string 或 Date
                    sb.AppendLine($" *   {field.Name}: {type};");
                }

                sb.AppendLine($" * }} {tab.Key};");
                sb.AppendLine();
            }

            sb.AppendLine("/// <reference types=\"jquery\" />");
            sb.AppendLine("/** @type {Object.<string, any>} */");
            sb.AppendLine("var vm = vm || {};");
            sb.AppendLine("</script>");

            return new HtmlString(sb.ToString());
        }
    }
}
