﻿using auomvc.Models;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Text;

namespace auomvc.Helper
{
    public static class FieldRenderer
    {
        public static string RenderField(DynamicField f, bool hasLabel = true, string stepKey = "")
        {
            if (f.Hidden)
            {
                var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

                return $@"
<input type='hidden'
       data-field='{f.Name}'
       data-step='{stepKey}'
       value='{val}' />";
            }

            var renderLabel = "";
            int colWidth = hasLabel ? f.Width : 12;

            if (hasLabel)
                renderLabel = RenderLabel(f, hasLabel);

            return $@"
<div class='row align-items-center mb-1'
     data-field-wrapper='{f.Name}'>

    {renderLabel}

    <div class='col-{colWidth}'>
        {RenderControl(f, stepKey)}
    </div>
</div>";
        }

        private static string RenderLabel(DynamicField f, bool hasLabel)
        {
            int colWidth = hasLabel ? 3 : 12;

            return $@"
<label class='col-{colWidth} mb-0 d-flex align-items-center'>
    <span class='star'>{(f.Must ? "*" : "")}</span>
    <span class='label-text tooltip-auto' data-title='{f.Name}'>{f.Name}</span>
</label>";
        }

        public static string RenderControl(DynamicField f, string stepKey)
        {
            return f.Type switch
            {
                FieldType.Label => RenderOnlyLabel(f, stepKey),
                FieldType.Textbox => RenderTextbox(f, stepKey),
                FieldType.Numeric => RenderNumeric(f, stepKey),
                FieldType.Date => RenderDate(f, stepKey),
                FieldType.Textarea => RenderTextarea(f, stepKey),
                FieldType.Dropdown or FieldType.Select2 => RenderDropdown(f, stepKey),
                FieldType.Radio => RenderRadio(f, stepKey),
                FieldType.File => RenderFile(f, stepKey),
                FieldType.Hybrid => RenderHybrid(f, stepKey),
                _ => $"<span>未知控制項 {f.Type}</span>"
            };
        }

        private static string RenderOnlyLabel(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"
<div data-field='{f.Name}'
     data-step='{stepKey}'
     data-type='label'
     class='label-display'>
    {val}
</div>";
        }

        private static string RenderTextbox(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"
<input type='text'
       class='form-control'

       data-field='{f.Name}'
       data-step='{stepKey}'
       data-type='textbox'

       data-must='{f.Must.ToString().ToLower()}'
       data-pattern='{f.Pattern}'
       data-default='{f.DefaultValue}'
       data-async='{f.AsyncUrl}'
       data-target='{f.Target}'
       data-key='{f.GroupKey}'

       value='{val}'
       {(f.Readonly ? "readonly" : "")}
/>";
        }

        private static string RenderNumeric(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"<div class='field-group'>
<div class='field-control'><input type='number'
       class='form-control'

       data-field='{f.Name}'
       data-step='{stepKey}'
       data-type='number'

       value='{val}'
       min='{f.Min}'
       max='{f.Max}'

       data-must='{f.Must.ToString().ToLower()}'

       {(f.Readonly ? "readonly" : "")}
/></div><span class='field-icon'></span>
 <small class='field-msg'></small>
</div>";
        }

        private static string RenderDate(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue)?.Replace("/", "-");

            return $@"
<input type='date'
       class='form-control'

       data-field='{f.Name}'
       data-step='{stepKey}'
       data-type='date'

       value='{val}'

       data-must='{f.Must.ToString().ToLower()}'

       {(f.Readonly ? "readonly" : "")}
/>";
        }

        private static string RenderTextarea(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"
<textarea class='form-control'

          data-field='{f.Name}'
          data-step='{stepKey}'
          data-type='textarea'

          data-must='{f.Must.ToString().ToLower()}'
          data-pattern='{f.Pattern}'
          data-default='{f.DefaultValue}'

          {(f.Readonly ? "readonly" : "")}>
{val}
</textarea>";
        }

        private static string RenderDropdown(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            var sb = new StringBuilder();

            sb.Append($@"
<select class='form-control select2'

        data-field='{f.Name}'
        data-step='{stepKey}'
        data-type='dropdown'

        data-async='{f.AsyncUrl}'
        data-must='{f.Must.ToString().ToLower()}'

        {(f.Readonly ? "disabled" : "")}>");

            sb.Append("<option value=''>請選擇</option>");

            if (f.Options != null)
            {
                foreach (var op in f.Options)
                {
                    var selected = op.Value == val ? "selected" : "";

                    sb.Append($@"
<option value='{op.Value}' {selected}>
    {op.Text}
</option>");
                }
            }

            sb.Append("</select>");
            return sb.ToString();
        }

        private static string RenderRadio(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            var sb = new StringBuilder();

            sb.Append("<div class='radio-group'>");

            foreach (var op in f.Options ?? new())
            {
                var isChecked = op.Value == val;

                sb.Append($@"
<label>
    <input type='radio'
           data-field='{f.Name}'
           data-step='{stepKey}'
           data-type='radio'
           value='{op.Value}'
           {(isChecked ? "checked" : "")}
           data-must='{f.Must.ToString().ToLower()}' />
    {op.Text}
</label>");
            }

            sb.Append("</div>");
            return sb.ToString();
        }

        private static string RenderFile(DynamicField f, string stepKey)
        {
            return $@"
<div class='dynamic-file-input'>

    <input type='file'
           data-field='{f.Name}'
           data-step='{stepKey}'
           data-type='file'
           class='d-none' />

    <label class='btn btn-outline-primary btn-sm'>
        Upload
    </label>

    <span class='filename-label'></span>

</div>";
        }

        private static string RenderHybrid(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var isChecked = !string.IsNullOrEmpty(val?.ToString());

            return $@"
<div class='input-group hybrid-input'>

    <input type='checkbox'
           data-field='chk{f.Name}'
           data-step='{stepKey}'
           data-type='hybrid-checkbox'
           {(isChecked ? "checked" : "")} />

    <input type='text'
           class='form-control'

           data-field='{f.Name}'
           data-step='{stepKey}'
           data-type='hybrid'

           value='{val}'
           {(f.Readonly ? "readonly" : "")} />

</div>";
        }
    }

    [HtmlTargetElement("df-field")]
    public class DfFieldTagHelper : TagHelper
    {
        public DynamicField Field { get; set; }
        public string Name { get; set; }
        public bool hasLabel { get; set; } = true;
        public string groupKey { get; set; } = "";
        public FieldType Type { get; set; } = FieldType.Textbox;
        public bool Must { get; set; } = false;
        public string Placeholder { get; set; } = "";
        public string DefaultValue { get; set; } = "";
        public bool Readonly { get; set; } = false;
        public int? Min { get; set; }
        public int? Max { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if ((Type != FieldType.Numeric) && (Min.HasValue || Max.HasValue))
                throw new InvalidOperationException("Min/Max 只能用在 Number");

            DynamicField fieldToRender;

            if (Field != null)
            {
                Field.GroupKey = groupKey;
                fieldToRender = Field;
            }
            else
            {
                fieldToRender = new DynamicField
                {
                    Name = Name,
                    Type = Type,
                    Must = Must,
                    Placeholder = Placeholder,
                    GroupKey = groupKey,
                    DefaultValue = DefaultValue,
                    Readonly = Readonly,
                    Min = Min?.ToString(),
                    Max = Max?.ToString()
                };
            }

            output.TagName = null;
            output.Content.SetHtmlContent(
                FieldRenderer.RenderField(fieldToRender, hasLabel, groupKey)
            );
        }
    }

    [HtmlTargetElement("df-form")]
    public class DfFormTagHelper : TagHelper
    {
        public List<DynamicField> Fields { get; set; }
        public string Key { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var sb = new StringBuilder();

            foreach (var f in Fields.OrderBy(x => x.Order))
            {
                sb.Append(FieldRenderer.RenderField(f, true, Key));
            }

            output.Content.SetHtmlContent(sb.ToString());
        }
    }
}