﻿ 
window.FieldStatus = (() => {

    const icons = {
        success: '<i class="bi bi-check-circle text-success"></i>',
        error: '<i class="bi bi-x-circle text-danger"></i>',
        processing: '<i class="bi bi-arrow-repeat rotate text-primary"></i>'
    };

    return {

        icons,

        // ✅ 修正①：加 msg 參數
        set(el, state, msg) {

            const group = el.closest(".field-group");
            if (!group) return;

            // ========================
            // ICON
            // ========================
            let icon = group.querySelector(".field-icon");

            //if (!icon) {
            //    icon = document.createElement("span");
            //    icon.className = "field-icon";
            //    group.appendChild(icon);
            //}

            if (!state) {
                group.classList.remove("has-icon");
                icon.innerHTML = "";
            } else {
                group.classList.add("has-icon");
                icon.innerHTML = this.icons[state] || "";
            }

            // ========================
            // MSG
            // ========================
            const msgEl = group.querySelector(".field-msg");

            if (msgEl) {
                msgEl.textContent = msg || "";   // ⭐ 關鍵修正
            }
        },

        batch(updates) {
            requestAnimationFrame(() => {
                updates.forEach(u => this.set(u.el, u.state, u.msg));
            });
        }
    };
})();
window.ValidationCenter = (function () {

    const rules = {};

    return {

        register(stepKey, fieldKey, ruleList) {

            if (!rules[stepKey]) {
                rules[stepKey] = {};
            }

            rules[stepKey][fieldKey] = ruleList;
        },

        get(stepKey, fieldKey) {
            return rules?.[stepKey]?.[fieldKey] || null;
        },

        dump() {
            return rules;
        }
    };

})();