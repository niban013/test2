﻿using Autofac;
using Dapper;
using mvc5.autofac;
using mvc5.Service;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using ws2;
using YourMvcApp.Data;
using static System.Collections.Specialized.BitVector32;

namespace mvc5.Controllers
{
    public class HomeController : Controller
    {
        private readonly IDbService _db; 
        private readonly UserService _userService;
        private readonly ILifetimeScope _scope;
        private readonly IList<string> _stringList;
        private readonly HttpContextBase _httpContext;
        public HomeController(ILifetimeScope scope,IDbService db, IList<string> stringList, HttpContextBase httpContext, UserService userService)
        { 
            _scope = scope;
                _stringList = stringList;
            _httpContext = httpContext;
            _userService = userService;
            _db = db;
            using (var session = _scope.Resolve<IDbSession>())
            {
           
            }
        }
//        using (var session = new DbSession(new OracleConnection(
//    System.Configuration.ConfigurationManager.ConnectionStrings["Oracle_DB1"].ConnectionString)))
//{
//    session.ExecuteProcedure("PROC_UPDATE_USER",
//        new OracleParameter("P_USER_ID", 1),
//        new OracleParameter("P_USER_NAME", "Test"));

//    await session.ExecuteProcedureAsync("PROC_UPDATE_USER",
//        new OracleParameter("P_USER_ID", 2),
//        new OracleParameter("P_USER_NAME", "AsyncTest"));

//    var dt = session.ExecuteProcedureToDataTable("PROC_GET_USERS",
//        new OracleParameter("P_ROLE_ID", 1));

//    var dtAsync = await session.ExecuteProcedureToDataTableAsync("PROC_GET_USERS",
//        new OracleParameter("P_ROLE_ID", 2));
//}

//        using (var session = new DbSession(new SqlConnection(
//    System.Configuration.ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString)))
//{
//    // 同步執行 Procedure
//    session.ExecuteProcedure("usp_UpdateUser",
//        new SqlParameter("@UserId", 1),
//        new SqlParameter("@UserName", "Test"));

//    // 非同步執行 Procedure
//    await session.ExecuteProcedureAsync("usp_UpdateUser",
//        new SqlParameter("@UserId", 2),
//        new SqlParameter("@UserName", "AsyncTest"));

//    // DataTable
//    var dt = session.ExecuteProcedureToDataTable("usp_GetUsers",
//        new SqlParameter("@RoleId", 1));

//    // 非同步 DataTable
//    var dtAsync = await session.ExecuteProcedureToDataTableAsync("usp_GetUsers",
//        new SqlParameter("@RoleId", 2));
//}


//public ActionResult FromSqlServer1()
//{
//    using (var session = _scope.ResolveNamed<IDbSession>("SqlServer_DB1"))
//    {
//        var repo = new UserRepository(session);
//        var users = repo.GetUsersAsync().Result;
//        return Json(users, JsonRequestBehavior.AllowGet);
//    }
//}

//public ActionResult FromOracle()
//{
//    using (var session = _scope.ResolveNamed<IDbSession>("Oracle_DB1"))
//    {
//        var repo = new UserRepository(session);
//        var users = repo.GetUsersAsync().Result;
//        return Json(users, JsonRequestBehavior.AllowGet);
//    }
//}
//public ActionResult GetFromSqlServer()
//{
//    using (var session = _scope.Resolve<IDbSession>(new NamedParameter("dbKey", "SqlServer_DB1")))
//    {
//        var repo = new UserRepository(session);
//        var users = repo.GetUsersAsync().Result;
//        return Json(users, JsonRequestBehavior.AllowGet);
//    }
//}

//public ActionResult GetFromOracle()
//{
//    using (var session = _scope.Resolve<IDbSession>(new NamedParameter("dbKey", "Oracle_DB1")))
//    {
//        var repo = new UserRepository(session);
//        var users = repo.GetUsersAsync().Result;
//        return Json(users, JsonRequestBehavior.AllowGet);
//    }
//}
[ActionName("Index")]
        public async Task<ActionResult> IndexAsync()
        {
            try
            {
                //using (var connection = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;"))
                //{
                //    connection.Open();
                //    var customers = connection.QueryAsync<dynamic>("SELECT * FROM Customers").Result; // 明確寫 dbo
                //    //foreach (var c in customers)
                //    //    Console.WriteLine(c);
                //}
                //using (var conn = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;"))
                //{
                //    var c = await conn.QueryAsync<dynamic>("SELECT * FROM Customers", null);
                //}
                 
                    var d2 = await _db.QueryAsync<dynamic>("delete from Customers where FirstName='Web'");
               
                var d =  _db.Query<dynamic>("SELECT  * FROM Customers where FirstName=@FirstName", new { FirstName = "Web" });
                //DataTable dt = await _db.QueryDataTableAsync("SELECT TOP 5 * FROM Customers");
                //var name = _userService.GetUserName(123);
                //_stringList.Add(new Random().Next(1, 100).ToString());
                LogHelper.Info("This is an information message.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("log4net error: " + ex.Message);
            }
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}