﻿
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.autofac
{
    public class DbSession : IDbSession
    {
        private readonly IDbConnection _connection;
        private IDbTransaction _transaction;

        public DbSession(IDbConnection connection)
        {
            _connection = connection ?? throw new ArgumentNullException(nameof(connection));
            if (_connection.State != ConnectionState.Open)
                _connection.Open();
        }

        public IDbConnection Connection => _connection;
        public IDbTransaction Transaction => _transaction;

        public void BeginTransaction()
        {
            if (_transaction == null)
                _transaction = _connection.BeginTransaction();
        }

        public void Commit()
        {
            _transaction?.Commit();
            _transaction?.Dispose();
            _transaction = null;
        }

        public void Rollback()
        {
            _transaction?.Rollback();
            _transaction?.Dispose();
            _transaction = null;
        }

        public IDbCommand CreateCommand(string sql, CommandType commandType = CommandType.Text)
        {
            var cmd = _connection.CreateCommand();
            cmd.CommandText = sql;
            cmd.CommandType = commandType;
            if (_transaction != null)
                cmd.Transaction = _transaction;
            return cmd;
        }

        private void AddParameters(IDbCommand cmd, IDictionary<string, object> parameters)
        {
            if (parameters == null) return;
            foreach (var p in parameters)
            {
                var param = cmd.CreateParameter();
                param.ParameterName = p.Key;
                param.Value = p.Value ?? DBNull.Value;
                cmd.Parameters.Add(param);
            }
        }

        // ======== 同步 ========
        public int ExecuteNonQuery(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text)
        {
            var cmd = CreateCommand(sql, commandType);
            AddParameters(cmd, parameters);
            return cmd.ExecuteNonQuery();
        }

        public object ExecuteScalar(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text)
        {
            var cmd = CreateCommand(sql, commandType);
            AddParameters(cmd, parameters);
            return cmd.ExecuteScalar();
        }

        public IDataReader ExecuteReader(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text)
        {
            var cmd = CreateCommand(sql, commandType);
            AddParameters(cmd, parameters);
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        // ======== 非同步 ========
        public async Task<int> ExecuteNonQueryAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text)
        {
             var cmd = (DbCommand)CreateCommand(sql, commandType);
            AddParameters(cmd, parameters);
            return await cmd.ExecuteNonQueryAsync();
        }

        public async Task<object> ExecuteScalarAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text)
        {
             var cmd = (DbCommand)CreateCommand(sql, commandType);
            AddParameters(cmd, parameters);
            return await cmd.ExecuteScalarAsync();
        }

        public async Task<IDataReader> ExecuteReaderAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text)
        {
            var cmd = (DbCommand)CreateCommand(sql, commandType);
            AddParameters(cmd, parameters);
            return await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection);
        }
        // ---------------- ExecuteProcedure ----------------
        public int ExecuteProcedure(string procName, params IDbDataParameter[] parameters)
        {
            using (var cmd = CreateCommand(procName, CommandType.StoredProcedure, parameters))
            {
                return cmd.ExecuteNonQuery();
            }
        }
        public async Task<int> ExecuteProcedureAsync(string procName, params IDbDataParameter[] parameters)
        {
             var cmd = CreateCommand(procName, CommandType.StoredProcedure, parameters);
            return await Task.Run(() => cmd.ExecuteNonQuery());
        }

        public async Task<DataTable> ExecuteProcedureToDataTableAsync(string procName, params IDbDataParameter[] parameters)
        {
            if (Connection == null)
                throw new InvalidOperationException("Connection 尚未初始化");

            if (Connection.State != ConnectionState.Open)
                Connection.Open();

            using (var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                if (Transaction != null)
                    cmd.Transaction = Transaction;

                if (parameters != null)
                    foreach (var p in parameters)
                        cmd.Parameters.Add(p);

                IDataAdapter da = null;
                if (cmd is SqlCommand sqlCmd)
                    da = new SqlDataAdapter(sqlCmd);
                else if (cmd is OracleCommand oracleCmd)
                    da = new OracleDataAdapter(oracleCmd);
                else
                    throw new NotSupportedException("不支援的 Command 類型");

                try
                {
                    var ds = new DataSet();
                    await Task.Run(() => da.Fill(ds));
                    return ds.Tables[0];
                }
                finally
                {
                    // IDataAdapter 強制釋放
                    if (da is IDisposable disposable)
                        disposable.Dispose();
                }
            }
        }

        public DataTable ExecuteProcedureToDataTable(string procName, params IDbDataParameter[] parameters)
        {
            if (Connection == null)
                throw new InvalidOperationException("Connection 尚未初始化");

            if (Connection.State != ConnectionState.Open)
                Connection.Open();

            using (var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                if (Transaction != null)
                    cmd.Transaction = Transaction;

                if (parameters != null)
                    foreach (var p in parameters)
                        cmd.Parameters.Add(p);

                IDataAdapter da = null;
                if (cmd is SqlCommand sqlCmd)
                    da = new SqlDataAdapter(sqlCmd);
                else if (cmd is OracleCommand oracleCmd)
                    da = new OracleDataAdapter(oracleCmd);
                else
                    throw new NotSupportedException("不支援的 Command 類型");

                try
                {
                    var ds = new DataSet();
                    da.Fill(ds);
                    return ds.Tables[0];
                }
                finally
                {
                    // IDataAdapter 強制釋放
                    if (da is IDisposable disposable)
                        disposable.Dispose();
                }
            }
        }


        // ---------------- private helpers ----------------
        private IDbCommand CreateCommand(string cmdText, CommandType type, IDbDataParameter[] parameters)
        {
            IDbCommand cmd = Connection.CreateCommand();
            cmd.CommandText = cmdText;
            cmd.CommandType = type;
            if (Transaction != null)
                cmd.Transaction = Transaction;

            if (parameters != null)
            {
                foreach (var p in parameters)
                    cmd.Parameters.Add(p);
            }

            return cmd;
        }
 

        public void Dispose()
        {
            _transaction?.Dispose();
            if (_connection?.State == ConnectionState.Open)
                _connection?.Close();
            _connection?.Dispose();
        }
    }
}
