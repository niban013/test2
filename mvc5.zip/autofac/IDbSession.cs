﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.autofac
{
    public interface IDbSession : IDisposable
    {
        IDbConnection Connection { get; }
        IDbTransaction Transaction { get; }

        void BeginTransaction();
        void Commit();
        void Rollback();

        // 同步
        IDbCommand CreateCommand(string sql, CommandType commandType = CommandType.Text);
        int ExecuteNonQuery(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        object ExecuteScalar(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        IDataReader ExecuteReader(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);

        // 非同步
        Task<int> ExecuteNonQueryAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        Task<object> ExecuteScalarAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        Task<IDataReader> ExecuteReaderAsync(string sql, IDictionary<string, object> parameters = null, CommandType commandType = CommandType.Text);
        // 呼叫儲存程序
        int ExecuteProcedure(string procName, IDbDataParameter[] parameters = null);
        Task<int> ExecuteProcedureAsync(string procName, IDbDataParameter[] parameters = null);

        DataTable ExecuteProcedureToDataTable(string procName, IDbDataParameter[] parameters = null);
        Task<DataTable> ExecuteProcedureToDataTableAsync(string procName, IDbDataParameter[] parameters = null);

    }
}