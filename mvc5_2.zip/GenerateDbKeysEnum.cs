﻿namespace YourMvcApp.Data
{
    /// <summary>
    /// 自動生成 Web.config connectionStrings Enum
    /// </summary>
    public enum DbKeys
    {
        SqlServer_DB1,
        SqlServer_DB2,
        Oracle_DB1,
        DefaultConnection,
    }
}
