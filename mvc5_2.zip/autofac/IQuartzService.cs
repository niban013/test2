﻿using mvc5.Controllers;
using Quartz;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.autofac
{
    public interface IQuartzService
    {
        IScheduler Scheduler { get;}
        //Task<IScheduler> GetScheduler();
        //Task ScheduleAllJobs();
        Task<JobViewModel> GetJobAsync(JobKey jobKey);
        Task NotifyFrontendAsync(string message);
        Task<List<JobViewModel>> GetAllJobsAsync();
        Task StartAsync();
        Task<bool> IsJobRunning(JobKey jobKey);
        Task<DateTimeOffset> AddJob<T>(DateTimeOffset startTime, TimeSpan interval, Dictionary<string, object> jobDataMap) where T : IJob;
        Task<DateTimeOffset> AddJob<T>(string cronTime, string jobData) where T : IJob;
        Task<bool> UpdateTime<T>(TimeSpan interval) where T : IJob;
        Task<bool> UpdateTime<T>(string cronTime) where T : IJob;
        Task<bool> Delete<T>() where T : IJob;
        void PauseAll();
        void ResumeAll();
        Task ShutdownAsync();
        void Shutdown();
    }
}