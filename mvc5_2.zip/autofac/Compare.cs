﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.autofac
{
    public enum MatchMode
    {
        Regex,      // 用正則表達式比對
        List,        // 用字串清單比對 (例如 DB 回傳的值)
        Default            // 之後還可以加 Range, GreaterThan, CustomFunc 等
    }
    public class AdvancedCondition
    {
        public string PropertyName { get; set; }
        public List<string> Patterns { get; set; }   // Regex 模式
        public List<string> Values { get; set; }     // List 模式 (DB 結果)
        public bool Not { get; set; } = true;
        public MatchMode Mode { get; set; } = MatchMode.Regex; // 預設 Regex
        public string message { get; set; } = @"gg{0}";
    }

    public class AdvancedFilterConfig
    {
        public int MaxResults { get; set; } = 10;   // 預設 10
        public List<AdvancedCondition> Conditions { get; set; } = new List<AdvancedCondition>();
    }
    public class Compare
    {
        public static IQueryable<dynamic> DataTableToDynamicQueryable(DataTable dt, string[] columns)
        {
            return dt.AsEnumerable()
                .Select(row =>
                {
                    IDictionary<string, object> expando = new ExpandoObject();
                    foreach (var col in columns)
                        expando[col] = row[col];
                    return (dynamic)expando;
                })
                .AsQueryable();
        }

        // 分批處理，返回每個欄位符合的 Seq 陣列
        // 分批處理，返回每個欄位符合的 Seq 陣列
        public static Dictionary<string, string> GetSeqByColumnInBatches(
            IQueryable<dynamic> query,
            AdvancedFilterConfig config,
            int batchSize = 10000)
        {
            var regexCache = new Dictionary<string, List<Regex>>();
            var valueCache = new Dictionary<string, HashSet<string>>();
            foreach (var cond in config.Conditions)
            {
                if (cond.Mode == MatchMode.Regex && cond.Patterns != null && cond.Patterns.Count > 0)
                {
                    regexCache[cond.PropertyName] = cond.Patterns.Select(p => new Regex(p, RegexOptions.Compiled)).ToList();
                }
                else if (cond.Mode == MatchMode.List && cond.Values != null && cond.Values.Count > 0)
                {
                    valueCache[cond.PropertyName] = new HashSet<string>(cond.Values);
                }
            
            }

            var result = new Dictionary<string, List<int>>();
            foreach (var cond in config.Conditions)
            {
                result[cond.PropertyName] = new List<int>();
            }

            int processed = 0;
            var buffer = new List<dynamic>(batchSize);

            foreach (var item in query)
            {
                buffer.Add(item);
                processed++;

                if (buffer.Count >= batchSize)
                {
                    if (ProcessBatch(buffer, config, regexCache, valueCache, result))
                        break; // 已達到 MaxResults，整體跳出

                    buffer.Clear();
                }
            }

            if (buffer.Count > 0)
            {
                ProcessBatch(buffer, config, regexCache, valueCache, result);
            }
            var resultmsg = new Dictionary<string, string>();
            foreach (var cond in config.Conditions)
            {
                resultmsg[cond.PropertyName] = string.Format(cond.message,string.Join(", ", result[cond.PropertyName].Take(10)));
            }
            return resultmsg;
        }

        /// <summary>
        /// 處理一個 batch，回傳 true = 全部欄位已滿足 MaxResults，可以提早結束
        /// </summary>
        private static bool ProcessBatch(
    List<dynamic> batch,
    AdvancedFilterConfig config,
    Dictionary<string, List<Regex>> regexCache,
    Dictionary<string, HashSet<string>> valueCache,
    Dictionary<string, List<int>> result)
        {
            foreach (var x in batch)
            {
                var dict = (IDictionary<string, object>)x;
                int seq = Convert.ToInt32(dict["Seq"]);

                foreach (var cond in config.Conditions)
                {
                    if (result[cond.PropertyName].Count >= config.MaxResults)
                        continue;

                    var val = dict[cond.PropertyName]?.ToString() ?? "";
                    bool matched = false;

                    switch (cond.Mode)
                    {
                        case MatchMode.Regex:
                            // 先檢查值是否為 null 或空
                            if (string.IsNullOrEmpty(val))
                            {
                                matched = false; // 空值不匹配
                            }
                            else if (regexCache.ContainsKey(cond.PropertyName))
                                matched = regexCache[cond.PropertyName].All(r => r.IsMatch(val));
                            break;

                        case MatchMode.List:
                            // 先檢查值是否為 null 或空
                            if (string.IsNullOrEmpty(val))
                            {
                                matched = false; // 空值不匹配
                            }
                            else if(valueCache.ContainsKey(cond.PropertyName))
                                matched = valueCache[cond.PropertyName].Contains(val);
                            break;
                        default:
                            // 空值或 null 判斷
                            matched = !string.IsNullOrEmpty(val); // 或依需求設定為 true/false
                            break;
                    }

                    if (cond.Not) matched = !matched;

                    if (matched)
                        result[cond.PropertyName].Add(seq);
                }

                // 如果所有欄位都滿 MaxResults，整批結束
                if (config.Conditions.All(c => result[c.PropertyName].Count >= config.MaxResults))
                    return true;
            }
            return false;
        }

    }
}