﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc5.Service
{
    public class JobHub : Hub
    {
        public void Hello() => Clients.All.hello();
        //public void NotifyJobUpdate(string message)
        //{
        //    Clients.All.jobUpdated(message);
        //}
    }
}