using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using vsnet8.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace vsnet8.Controllers
{
    public class EmployeeDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
    }
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public IActionResult LoadForm(string type)
        {


            var fields = GenerateFields(type);


            return PartialView("_DynamicForm", fields);
        }
        public IActionResult Index2()
        {
            return View();
        }
        public IActionResult LoadCheckTable(string type)
        {
            var fields = LoadCheckFields(type);


            return PartialView("_DynamicCheckTable", fields);

        }
        private List<DynamicField> GenerateFields(string type)
        {
            var list = new List<DynamicField>();

            list.Add(new DynamicField
            {
                Name = "Name",
                Label = "�m�W",
                Pattern = "",
                Must = false,
                Type = FieldType.Label,
                Width = 3,
                Order = 1
            });
            list.Add(new DynamicField
            {
                Name = "Age",
                Label = "�~��",
                Must = true,
                Type = FieldType.Numeric,
                Placeholder = "�п�J�~��",
                Width = 3,
                Pattern = "",
                Order = 2
            });
            list.Add(new DynamicField
            {
                Name = "DueDate",
                Label = "�����",
                Must = true,
                Type = FieldType.Date,
                Placeholder = "�п�J�����",
                Width = 3,
                Pattern = "",
                Order = 3
            });
            if (type == "employee")
            {
                list.Add(new DynamicField
                {
                    Name = "Dept",
                    Label = "����",
                    Must = true,
                    Type = FieldType.Select2,
                    Options = new()
                    {
                       new SelectItem{Value="1",Text="���`",Color="lightgreen"},
        new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
        new SelectItem{Value="3",Text="���`",Color="lightcoral"}
                    }
                });
            }

            if (type == "customer")
            {
                list.Add(new DynamicField
                {
                    Name = "City",
                    Label = "����",
                    Type = FieldType.Select2,
                    Options = new()
            {
                new SelectItem{Value="taipei",Text="�x�_"},
                new SelectItem{Value="hsinchu",Text="�s��"}
            }
                });
            }

            return list;
        }
        public List<DynamicField> LoadCheckFields(string type)

        {
            var list = new List<DynamicField>();

            if (type == "equipment")
            {
                list.Add(new DynamicField
                {
                    Must = true,
                    Name = "oil",
                    Label = "�o�q",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Pattern = "",
                });

                list.Add(new DynamicField
                {
                    Name = "checktime",
                    Label = "�ˬd�ɶ�",
                    Width = 3,
                    Type = FieldType.Date,
                    Pattern = "",
                });

                list.Add(new DynamicField
                {
                    Name = "status",
                    Label = "�]�ƪ��A",
                    Type = FieldType.Select2,
                    Width = 3,
                    Pattern = "",
                    DefaultValue = "���`",
                    Options = new List<SelectItem>{
                new SelectItem{Value="1",Text="���`",Color="lightgreen"},
                new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
                new SelectItem{Value="3",Text="���`",Color="red"}
            }
                });
            }

            if (type == "temperature")
            {
                list.Add(new DynamicField
                {
                    Must = true,
                    Name = "temp1",
                    Label = "�J�f�ū�",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Pattern = ""
                });

                list.Add(new DynamicField
                {
                    Name = "temp2",
                    Label = "�X�f�ū�",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Pattern = ""
                });
            }

            return list;
        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Indextb()
        {
            var employeeSchema = new List<TableSchema>
            {
                new()
                {
                    TableId = "EmployeeTable",
                    AjaxUrl = "/Home/GetData/1",
                    FetchMode = FetchMode.All,

                    Features = new TableFeatures
                    {
                        Checkbox = true,
                        Export = true,
                        RowButtons = true,
                        ColumnToggle = true,
                        RowSelect = true,
                        SelectAll = true,
                        VirtualScroll = true,
                        ColumnFilter = true,   // �i��A�C�泣�� filter
                        StickyHeader = true    // �i��A���Y�T�w
                    },

                    Config = new TableConfig
                    {
                        PageLength = 20,
                        VirtualScrollHeight = "500px",
                        Searching = false,
                        Ordering = false,
                        Paging = false,
                        LengthChange = true,
                        StateSave = true
                    },

                    ToolbarButtons =
                    {
                        new("Add", "add","bi-pencil","btn btn-danger" ),
                        new("Delete Selected", "deleteSelected","bi-pencil", "btn btn-danger" ),
                        new("Reload", "reload","bi-pencil", "btn btn-secondary" )
                    },

                    Columns =
                    {
                        new("Name"),
                        new("Age"),
                        new("Salary", "currency")
                    },

                    RowButtons =
                    { new(){ Title="", Event="edit3", CssClass="btn btn-sm btn-primary",Icon="bi-pencil"},
                        new(){ Title="Edit", Event="edit", CssClass="btn btn-sm btn-primary",Icon="bi-pencil"},
                        new(){ Title="Delete", Event="delete", CssClass="btn btn-sm btn-danger"}
                    }
                }
            };

            ViewBag.Tables = employeeSchema;// new List<TableSchema> { employeeSchema };

            return View();
        }
        public IActionResult Index3()
        {
            // �إߤT�ո�ơA��N�b�C�@�ճ��[�J�@�ӦW�� "tgtest" �����
            var sectionConfigs = new Dictionary<string, List<DynamicField>>();

            // �Ĥ@�աG�ӤH���
            sectionConfigs["BasicInfo"] = new List<DynamicField> {
                new() { Name = "Name", Label = "�m�W", Type = FieldType.Label, DefaultValue = "�i�p��", Width = 3, Order = 1 },
                new() { Name = "tgtest", Label = "�������A", Type = FieldType.Textbox, Must = true, Width = 3, Order = 2 },

                              };

            // �ĤG�աG�Ա��]�w
            sectionConfigs["Details"] = new List<DynamicField> {
                new() { Name = "Age", Label = "�~��", DefaultValue="999",Type = FieldType.Numeric, Must = true, Width = 3, Order = 1,  Min = "0",
    Max = "100" },
                new() { Name = "tgtest", Label = "�������B", Type = FieldType.Textbox, Must = true, Width = 3, Order = 2 }
            ,
                 new()
                { Must = true,
                    Name = "status",
                    Label = "�]�ƪ��A",
                    Type = FieldType.Select2,
                    Width = 3,
                    Pattern = "",
                    DefaultValue = "���`",
                    Options = new List<SelectItem>{
                        new SelectItem{Value="1",Text="���`",Color="lightgreen"},
                        new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
                        new SelectItem{Value="3",Text="���`",Color="red"}
                    }
                }

            };

            // �ĤT�աG�t�γ]�w
            sectionConfigs["Settings"] = new List<DynamicField> {
                new() { Name = "DueDate", Label = "�����",DefaultValue="2026-03-13",  Min = DateTime.Now.ToString("yyyy-MM-dd"),Type = FieldType.Date, Must = true, Width = 3, Order = 1 },
                new() { Name = "tgtest", Label = "�������C", Type = FieldType.Textbox, Must = false, Width = 3, Order = 2 },
                new()
                {
                    Name = "status",
                    Label = "�]�ƪ��A",
                    Type = FieldType.Dropdown,
                    Width = 3,
                    Pattern = "",
                    DefaultValue = "���`",
                    Options = new List<SelectItem>{
                        new SelectItem{Value="1",Text="���`",Color="lightgreen"},
                        new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
                        new SelectItem{Value="3",Text="���`",Color="red"}
                    }
                }


            };

            return View(sectionConfigs);
        }



        [HttpPost]
        public IActionResult SaveAll([FromBody] Dictionary<string, Dictionary<string, string>> allData)
        {
            if (allData == null || !allData.Any())
            {
                return Json(new { success = false, message = "�L�Ī���ƶǰe" });
            }

            try
            {
                // 1. ���o�S�w�϶����� (�Ҧp�GBasicInfo ���� tgtest)
                if (allData.ContainsKey("BasicInfo"))
                {
                    var basicTgTest = allData["BasicInfo"].GetValueOrDefault("tgtest");
                    // �B�z BasicInfo �޿�...
                }

                // 2. �M���Ҧ��϶��i��B�z
                foreach (var section in allData)
                {
                    string sectionName = section.Key; // �p "Details"
                    var fields = section.Value;      // �Ӱ϶������Ҧ����r��

                    // �o�̥i�H�g�J��Ʈw�ζi��ӷ~�޿�����
                    Console.WriteLine($"�B�z�϶�: {sectionName}, ����: {fields.Count}");
                }

                return Json(new { success = true, message = "���ư϶��x�s���\�I" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        [HttpGet]
        public JsonResult CheckUsername(string value)
        {
            bool exists = !true;// _db.Users.Any(u => u.UserName == value);
            return Json(new { valid = !exists, message = exists ? "�b���w�s�b" : "" });
        }

        [HttpGet]
        public IActionResult GetData(int id)
        {
            var data = new List<EmployeeDto>
            {
                new EmployeeDto{ Id=1, Name="Tom", Age=30, Salary=5000 },
                new EmployeeDto{ Id=2, Name="Mary", Age=28, Salary=6200 },
                new EmployeeDto{ Id=3, Name="John", Age=35, Salary=7000 }
            };

            return Json(new { data = data });
        }

        // AjaxUrl="/Employee/GetData?mode=all" �� "?mode=page"
        [HttpGet]
        public IActionResult GetData2(string mode)
        {
            // �����
            var allData = new[]
            {
                new { Id = 1, Name = "Tom", Age = 30, Salary = 5000 },
                new { Id = 2, Name = "Mary", Age = 28, Salary = 6200 },
                new { Id = 3, Name = "John", Age = 35, Salary = 7000 },
                new { Id = 4, Name = "Anna", Age = 32, Salary = 5800 },
                new { Id = 5, Name = "Mike", Age = 40, Salary = 7200 },
                new { Id = 6, Name = "Linda", Age = 26, Salary = 4900 },
                new { Id = 7, Name = "Steve", Age = 38, Salary = 6500 },
                new { Id = 8, Name = "Lucy", Age = 31, Salary = 5300 }
            };

            if (mode == "all")
            {
                // ���q�Ҧ��ADataTables �u�n { data: [...] }
                return Json(new { data = allData });
            }
            else
            {
                // �����Ҧ��ADataTables serverSide
                int start = int.Parse(Request.Query["start"].FirstOrDefault() ?? "0");
                int length = int.Parse(Request.Query["length"].FirstOrDefault() ?? "10");
                string searchValue = Request.Query["search[value]"].FirstOrDefault()?.ToLower() ?? "";

                var filtered = allData
                    .Where(d => string.IsNullOrEmpty(searchValue) || d.Name.ToLower().Contains(searchValue))
                    .ToList();

                var paged = filtered.Skip(start).Take(length);

                return Json(new
                {
                    draw = Request.Query["draw"].FirstOrDefault(),
                    recordsTotal = allData.Length,
                    recordsFiltered = filtered.Count,
                    data = paged
                });
            }
        }
    }
}
