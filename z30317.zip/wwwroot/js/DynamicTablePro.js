﻿var DynamicTablePro = (function () {
    const api = {};
    api.events = {};
    api.tables = {};
    api.formatters = {
        currency: v => "$" + Number(v).toLocaleString()
    };

    // 建立欄位
    function buildColumns(schema) {
        let cols = [];
        let features = schema.Features || {};

        // Checkbox + Select All
        if (features.Checkbox) {
            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-checkbox-col",
                title: features.SelectAll ? '<input type="checkbox" class="dt-select-all">' : "",
                render: () => '<input type="checkbox" class="row-check">'
            });
        }

        // RowButtons (每列操作)
        if (features.RowButtons && schema.RowButtons?.length > 0) {
            schema.RowButtons.forEach(btn => {
                cols.push({
                    data: null,
                    orderable: false,
                    defaultContent: "",
                    className: "dt-row-btn-col text-center", // 置中
                    
                    render: row =>
                        `<button class="dt-btn ${btn.CssClass}" 
                                 data-event="${btn.Event}" 
                                 data-id="${row.Id}"
                                 style="white-space: nowrap; margin:0 2px; padding:2px 6px;">
                            ${btn.Title}
                        </button>`
                });
            });
        }

        // 資料欄位
        (schema.Columns || []).forEach(col => {
            let c = { data: col.Field, title: col.Title ?? col.Field };
            if (col.Formatter) c.render = v => api.formatters[col.Formatter] ? api.formatters[col.Formatter](v) : v;

            // Column Filter
            if (features.ColumnFilter) {
                c.footer = `<input type="text" placeholder="Filter ${c.title}" class="column-filter"/>`;
            }

            cols.push(c);
        });

        return cols;
    }

    // Render Table
    api.render = function (opt) {
        let schema = opt.schema;
        let columns = buildColumns(schema);
        let cfg = schema.Config || {};
        let features = schema.Features || {};
        let dtButtons = [];

        if (schema.ToolbarButtons && schema.ToolbarButtons.length > 0) {
            schema.ToolbarButtons.forEach(btn => {
                dtButtons.push({
                    text: btn.Title,
                    className: btn.CssClass,
                    action: function (e, dt, node, config) {
                        if (api.events[btn.Event]) api.events[btn.Event](schema.TableId);
                    }
                });
            });
        }
        let tableOptions = {
            autoWidth: true,
            columns: columns,
            stateSave: cfg.StateSave ?? true,
            responsive: true,
            colReorder: true,
            searching: cfg.Searching ?? true,
            lengthChange: cfg.LengthChange ?? true,
            ordering: cfg.Ordering ?? true,
            paging: cfg.Paging ?? true,
            pageLength: cfg.PageLength ?? 10,
            dom: "frBtip",
            buttons: dtButtons,//(cfg.Buttons !== false || features.Export) ? ["excel"] : [],
            scrollY: cfg.ScrollY ?? (features.VirtualScroll ? "400px" : ""),
            scrollCollapse: features.VirtualScroll ?? false,
            deferRender: features.VirtualScroll ?? false,
            scroller: features.VirtualScroll ?? false,
            fixedHeader: features.StickyHeader ?? false,
            initComplete: function () {
                // **穩定方式：把 Buttons 放搜尋列右側**

                // ToolbarButtons 放到搜尋列右側
                //if (schema.ToolbarButtons && schema.ToolbarButtons.length > 0) {
                //    let filterContainer = $("#" + schema.TableId + "_filter");
                //    if (filterContainer.length) {
                //        let btnsContainer = apiTable.buttons().container();

                //        // 把搜尋框和 Buttons 放到同一個 flex 容器
                //        filterContainer.css({
                //            display: 'flex',
                //            'align-items': 'center',
                //            'justify-content': 'space-between'
                //        });

                //        // 把 Buttons 放到右邊
                //        btnsContainer.css({ margin: 0 });
                //        filterContainer.append(btnsContainer);
                //    }
                //}

                //if (dtButtons.length > 0) {
                //    // DataTables 自動給搜尋容器 ID
                //    let filterContainer = $("#" + schema.TableId + "_filter");
                //    if (filterContainer.length) {
                //        // 把 buttons 容器移過去
                //        let btnsContainer = apiTable.buttons().container();
                //        filterContainer.append(btnsContainer);
                //        btnsContainer.css({ display: "inline-block", "margin-left": "10px" });
                //    }
                //}
                 
                // Column Filter
                //if (features.ColumnFilter) {
                //    apiTable.columns().every(function () {
                //        var column = this;
                //        $('input.column-filter', this.footer()).on('keyup change clear', function () {
                //            if (column.search() !== this.value) column.search(this.value).draw();
                //        });
                //    });
                //}
            }
        };

        // Ajax
        if (schema.FetchMode === 0) {
            tableOptions.ajax = {
                url: schema.AjaxUrl,
                dataSrc: function (json) {
                    api['data_' + schema.TableId] = json.data;
                    return json.data;
                }
            };
        } else {
            tableOptions.serverSide = true;
            tableOptions.processing = true;
            tableOptions.ajax = schema.AjaxUrl;
        }

        let table = $("#" + schema.TableId).DataTable(tableOptions);
        // 強制欄位自動調整
        //table.on('draw', function () {
        //    table.columns.adjust().draw(false);
        //});
        // 等 DataTable 完全初始化後再移動 Buttons
        table.on('init.dt', function () {
            let container = $(table.table().container());
            let filterContainer = container.find(".dataTables_filter");

            if (filterContainer.length) {
                let btnsContainer = table.buttons().container();
                btnsContainer.css({ margin: 0 });

                // 以 flex 排列搜尋 + buttons
                filterContainer.css({
                    display: 'flex',
                    'align-items': 'center',
                    'justify-content': 'space-between'
                });

                filterContainer.append(btnsContainer);
            } else {
                console.warn("找不到 .dataTables_filter");
            }
        });

        api.tables[schema.TableId] = table;

        // RowButtons event (每列 Edit / Delete)
        $(document).on("click", `#${schema.TableId} .dt-row-btn-col .dt-btn`, function () {
            let event = $(this).data("event");
            let id = $(this).data("id");
            let row = table.row($(this).closest("tr")).data();
            if (api.events[event]) api.events[event](id, row, schema.TableId);
        });

        // Row Checkbox & Select All
        $(document).on("change", `#${schema.TableId} .row-check`, function () {
            if (!features.SelectAll) return;
            let total = table.$(".row-check").length;
            let checked = table.$(".row-check:checked").length;
            $(`#${schema.TableId} .dt-select-all`).prop("checked", total === checked);
        });
        $(document).on("change", `#${schema.TableId} .dt-select-all`, function () {
            let checked = $(this).is(":checked");
            table.$(".row-check").prop("checked", checked);
        });

        // Column Filter
        if (features.ColumnFilter) {
            table.columns().every(function () {
                var column = this;
                $('input.column-filter', this.footer()).on('keyup change clear', function () {
                    if (column.search() !== this.value) column.search(this.value).draw();
                });
            });
        }
 
        // 插入 ToolbarButtons 到搜尋列右側
        //if (schema.ToolbarButtons && schema.ToolbarButtons.length > 0) {
        //    let container = $("#" + schema.TableId).closest(".dataTables_wrapper");
        //    let searchBox = container.find(".dataTables_filter label");

        //    if (searchBox.length > 0) {
        //        // 建立一個包裹按鈕的 div
        //        let btnContainer = $('<div class="toolbar-btns"></div>');
        //        schema.ToolbarButtons.forEach(btn => {
        //            let button = $(`<button class="${btn.CssClass}" data-event="${btn.Event}" data-table="${schema.TableId}">${btn.Title}</button>`);
        //            btnContainer.append(button);
        //        });

        //        // 把按鈕 div 加到搜尋框父元素
        //        searchBox.parent().append(btnContainer);
        //    }
        //}

        return table;
    };

    api.renderAll = function (tables) {
        tables.forEach(schema => api.render({ schema }));
    };

    // Toolbar event
    $(document).on("click", ".dataTables_filter button", function () {
        let event = $(this).data("event");
        let tableId = $(this).data("table");
        if (api.events[event]) api.events[event](tableId);
    });

    // Get selected rows
    api.getSelectedRows = function (tableId) {
        let table = api.tables[tableId];
        let rows = [];
        table.$(".row-check:checked").each(function () {
            let tr = $(this).closest("tr");
            let rowData = table.row(tr).data();
            if (rowData) rows.push(rowData);
        });
        return rows;
    };

    // Get all data
    api.getAllData = function (tableId) {
        return api['data_' + tableId] || [];
    };

    return api;
})();