﻿using auomvc.Models;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace auomvc.Helper
{
    public abstract class BaseFieldTagHelper : TagHelper
    {
        public DynamicField Field { get; set; }

        protected string RawValue => ViewHelper.ResolveValue(Field?.Value, Field?.DefaultValue);

        protected string GetId()
        {
            var prefix = Field?.Type switch
            {
                FieldType.Textbox => "ttb",
                FieldType.Numeric => "num",
                FieldType.Date => "dtp",
                FieldType.Dropdown => "ddl",
                FieldType.Select2 => "s2",
                FieldType.Textarea => "txt",
                FieldType.File => "file",
                FieldType.ShowFile => "show",
                FieldType.Radio => "rdo",
                _ => "fld"
            };
            return $"{prefix}{Field?.Name}";
        }

        protected string MustAttr => Field?.Must == true ? "true" : "false";
    }
}
