﻿using auomvc.Models;

namespace auomvc.Helper
{
    public class FieldRule
    {
        private readonly List<string> _rules = new();

        public void Add(string rule)
        {
            if (!string.IsNullOrWhiteSpace(rule))
                _rules.Add(rule);
        }

        public override string ToString()
        {
            return string.Join("|", _rules);
        }
    }
    public interface IFieldRuleStrategy
    {
        void Apply(DynamicField field, FieldRule rule);
    }
    public abstract class BaseFieldRuleStrategy : IFieldRuleStrategy
    {
        public void Apply(DynamicField field, FieldRule rule)
        {
            // 共用
            if (field.Must)
                rule.Add("required");

            ApplyInternal(field, rule);

            // async（統一）
            if (!string.IsNullOrEmpty(field.AsyncUrl))
                rule.Add("remote");
        }

        protected abstract void ApplyInternal(DynamicField field, FieldRule rule);
    }
    public class NumberRuleStrategy : BaseFieldRuleStrategy
    {
        protected override void ApplyInternal(DynamicField f, FieldRule r)
        {
            if (!string.IsNullOrEmpty(f.Min))
                r.Add($"min:{f.Min}");

            if (!string.IsNullOrEmpty(f.Max))
                r.Add($"max:{f.Max}");
        }
    }
    public class TextRuleStrategy : BaseFieldRuleStrategy
    {
        protected override void ApplyInternal(DynamicField f, FieldRule r)
        {
            if (!string.IsNullOrEmpty(f.Pattern))
                r.Add("pattern"); // ⚠ 不帶 regex
        }
    }
    public class DateRuleStrategy : BaseFieldRuleStrategy
    {
        protected override void ApplyInternal(DynamicField f, FieldRule r)
        {
            r.Add("date");

            if (!string.IsNullOrEmpty(f.Min))
                r.Add($"min:{f.Min}");

            if (!string.IsNullOrEmpty(f.Max))
                r.Add($"max:{f.Max}");
        }
    }
    public class SelectRuleStrategy : BaseFieldRuleStrategy
    {
        protected override void ApplyInternal(DynamicField f, FieldRule r)
        {
            // required 已由 base 處理
        }
    }
    public class CheckboxRuleStrategy : BaseFieldRuleStrategy
    {
        protected override void ApplyInternal(DynamicField f, FieldRule r)
        {
            if (f.Must)
                r.Add("required");
        }
    }
    public static class FieldRuleStrategyFactory
    {
        private static readonly Dictionary<FieldType, IFieldRuleStrategy> _map
            = new()
        {
        { FieldType.Numeric, new NumberRuleStrategy() },
        { FieldType.Textbox, new TextRuleStrategy() },
        { FieldType.Date, new DateRuleStrategy() },
        { FieldType.Dropdown, new SelectRuleStrategy() },
        //{ FieldType.Checkbox, new CheckboxRuleStrategy() }
        };

        public static IFieldRuleStrategy Get(FieldType type)
        {
            if (_map.TryGetValue(type, out var strategy))
                return strategy;

            throw new NotImplementedException($"No strategy for {type}");
        }


    }
    public static class RuleBuilder
    {
        public static string Build(DynamicField field)
        {
            var rule = new FieldRule();

            var strategy = FieldRuleStrategyFactory.Get(field.Type);
            strategy.Apply(field, rule);

            return rule.ToString();
        }
    }
}