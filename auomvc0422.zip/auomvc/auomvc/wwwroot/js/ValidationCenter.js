﻿// =========================
// ✅ FormStore（修正版）
// =========================
window.FormStore = (() => {

	const state = Vue.reactive({ steps: {} });
	const errors = Vue.reactive({ steps: {} });
	const status = Vue.reactive({ steps: {} });
	const dirty = Vue.reactive({ steps: {} });

	const submitState = {};
	const touched = {};

	const ensure = (step) => {
		state.steps[step] ||= {};
		errors.steps[step] ||= {};
		status.steps[step] ||= {};
		dirty.steps[step] ||= new Set();
		touched[step] ||= new Set();
		// ⭐ version container
		state.steps[step].__version ||= {};
		state.steps[step].__readonly ||= [];
		state.steps[step].__token ||= {};
	};

	return {

		markStepSubmitted(step) {
			submitState[step] = true;
		},

		isStepSubmitted(step) {
			return !!submitState[step];
		},

		getStep(step) {
			ensure(step);
			return state.steps[step];
		},

		get(step, key) {
			ensure(step);
			return state.steps[step][key];
		},
		// =========================
		// 🔥 唯一寫入入口
		// =========================
		safeSet(step, key, val, meta = {}) {

			ensure(step);

			const stepObj = state.steps[step];

			// =========================
			// ❌ whitelist
			// =========================
			//if (!Object.prototype.hasOwnProperty.call(stepObj, key)) {
			//	return;
			//}

			// =========================
			// ❌ readonly
			// =========================
			if (stepObj.__readonly?.includes?.(key)) return;

			// =========================
			// 🔥 token race protection（關鍵）
			// =========================
			// =========================
			// 🚫 token guard ONLY for async write
			// =========================
			const isAsyncWrite = meta.isAsync === true;

			// =========================
			// 🚫 只限制 async response
			// =========================
			if (isAsyncWrite) {

				const lastToken = stepObj.__token?.[key];

				if (lastToken && meta.token !== lastToken) {
					return;
				}

				stepObj.__token[key] = meta.token;
			}

			// =========================
			// 💾 write token
			// =========================
			stepObj.__token ||= {};
			stepObj.__token[key] = meta.token;

			// =========================
			// write value
			// =========================
			const old = stepObj[key];
			stepObj[key] = val;

			if (old !== val) {
				dirty.steps[step].add(key);
			}
		},
		//safeSet(step, key, val) {
		//	ensure(step);

		//	const old = state.steps[step][key];
		//	state.steps[step][key] = val;

		//	if (old !== val) {
		//		dirty.steps[step].add(key);
		//	}
		//},

		setError(step, key, val) {
			ensure(step);
			errors.steps[step][key] = val;
		},

		clearError(step, key) {
			ensure(step);
			errors.steps[step][key] = null;
		},

		getError(step, key) {
			return errors.steps?.[step]?.[key];
		},
		isStepValid(step) { ensure(step); return Object.values(errors.steps[step]).every(x => !x); },

		setStatus(step, key, val) {
			ensure(step);
			status.steps[step][key] = val;
		},

		getStatus(step, key) {
			return status.steps?.[step]?.[key];
		},

		setTouched(step, key) {
			ensure(step);
			touched[step].add(key);
		},

		isTouched(step, key) {
			return touched?.[step]?.has(key);
		}
	};

})();

window.ValidationRules = {

	required: (val) =>
		(val === null || val === undefined || val === "") ? "必填" : true,

	min: (val, ctx) => {
		if (val == null || val === "") return true;
		return parseFloat(val) >= parseFloat(ctx.arg) || `不可小於${ctx.arg}`;
	},

	max: (val, ctx) => {
		if (val == null || val === "") return true;
		return parseFloat(val) <= parseFloat(ctx.arg) || `不可大於${ctx.arg}`;
	},


	// =========================
	// 🔥 async validator（統一版本）
	// =========================
	async: async (val, ctx) => {

		if (!val) return true;

		const res = await fetch(ctx.url, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				value: val,
				stepKey: ctx.stepKey,
				field: ctx.field
			}),
			signal: ctx.signal   // ⭐ 必加

		});

		const data = await res.json();

		if (data.valid === false) {
			return data.message || "驗證失敗";
		}

		return {
			valid: true,
			data: data.data || {},
			message: data.message || ""
		};
	}
};
// =========================
// ✅ FormValidation（唯一引擎）
// =========================
//window.FormValidation = (() => {

//	const store = () => AppBootstrap.get("FormStore");

//	function parseRules(ruleStr) {
//		if (!ruleStr) return [];

//		return ruleStr.split("|").map(r => {
//			const [name, arg] = r.split(":");
//			return { name, arg };
//		});
//	}

//	function run(stepKey, field, val, el) {

//		const s = store();

//		// 🔵 Graph（優先）
//		const nodes = ValidationGraph.getNodes(stepKey, field);

//		for (const node of nodes) {

//		    const result = node.run({ val, stepKey, field });

//		    if (result !== true) {
//		        s.setError(stepKey, field, result);
//		        s.setStatus(stepKey, field, "error");
//		        return false;
//		    }
//		}

//		// 🔵 data-rules
//		//const rules = parseRules(el.dataset.rules);

//		//for (const r of rules) {

//		//	const fn = ValidationRules[r.name];
//		//	if (!fn) continue;

//		//	const result = fn(val, { arg: r.arg });

//		//	if (result !== true) {
//		//		s.setError(stepKey, field, result);
//		//		s.setStatus(stepKey, field, "error");
//		//		return false;
//		//	}
//		//}

//		// 🟢 success
//		s.clearError(stepKey, field);
//		s.setStatus(stepKey, field, "success");

//		return true;
//	}

//	return { run };

//})();

// =========================
// ✅ FieldBinder（初始化✔ + UX 正確）
// =========================
window.FieldBinder = (() => {
	const timers = new Map();
	function bindFields(container, stepKey) {

		const store = AppBootstrap.get("FormStore");
		const engine = AppBootstrap.get("FormValidation");

		container.querySelectorAll("[data-field]").forEach(el => {

			if (el.dataset.bound) return;
			el.dataset.bound = "1";

			const key = el.dataset.field;

			registerValidationRules(el, stepKey)

			// 🔥 init validate
			const initVal = store.get(stepKey, key);
			//const token = Symbol(`${stepKey}.${key}`);
			Graph.trigger(stepKey, key);
			const update = (e) => {

				const target = e?.target || el;

				let val;

				if (target.type === "checkbox") val = target.checked;

				else if (target.type === "radio") {

					const checked = container.querySelector(
						`input[data-field='${key}']:checked`
					);

					val = checked ? checked.value : null;

				}

				else if (target.type === "number") {
					const v = target.value;
					val = v === "" ? null : Number(v);
				}

				else val = target.value;
				const token = Symbol(`${stepKey}.${key}`);

				// ⭐ 1. store
				store.safeSet(stepKey, key, val, { token });

				// ⭐ 2. 立即 processing（UI有反應）
				store.setStatus(stepKey, key, "processing");

				// ⭐ 3. touched（避免 UI 卡死）
				store.setTouched(stepKey, key);

				// ⭐ 4. Graph trigger
				Graph.trigger(stepKey, key, { token });

				// ⭐ 4. validation（可保留或未來移除）
				//engine.run(stepKey, key, val, target); 

				// =========================
				// 🔥 per-field debounce
				// =========================
				//const oldTimer = timers.get(key);
				//if (oldTimer) clearTimeout(oldTimer);

				//timers.set(
				//	key,
				//	setTimeout(async () => {
				//		await engine.run(stepKey, key, val, target);
				//	}, 150)
				//);

			};
			// =========================
			// 🔥 Select2 支援
			// =========================
			if (el.tagName === "SELECT") {

				const $el = $(el);

				if ($el.data("select2")) {

					$el.on("select2:select select2:clear change", function () {
						update({ target: el });
					});

				} else {
					el.addEventListener("change", update);
				}

				return;
			}
			el.addEventListener("input", update);
			//el.addEventListener("change", update);

			el.addEventListener("blur", () => {
				store.setTouched(stepKey, key);
			});

			Vue.watch(
				() => [
					store.getError(stepKey, key),
					store.getStatus(stepKey, key),
					store.isTouched(stepKey, key),
					store.isStepSubmitted(stepKey)
				],
				([error, status, touched, submitted]) => {

					const showError = touched || submitted;

					if (!showError) {

						// ⭐ 但 success 可以顯示
						if (status === "success") {
							FieldStatus.set(el, "success", "");
						} else {
							if (error) {
								FieldStatus.set(el, "error", "");
							}
							else {
								FieldStatus.clear(el);
								 
							}  
						}
						return;
					}

					// 🔥 priority 1
					if (status === "processing") {
						FieldStatus.set(el, "processing", "");
						return;
					}

					// 🔥 priority 2
					if (error) {
						FieldStatus.set(el, "error", error);
						return;
					}

					// 🔥 priority 3
					if (status === "success") {
						FieldStatus.set(el, "success", "");
					}
				},
				{ immediate: true, deep: true }
			);
		});
	}

	return { bindFields };

})();

window.FieldStatus = (() => {

	const icons = {
		success: '<i class="bi bi-check-circle text-success"></i>',
		error: '<i class="bi bi-x-circle text-danger"></i>',
		processing: '<i class="bi bi-arrow-repeat rotate text-primary"></i>'
	};

	return {

		set(el, state, msg = "") {

			const field = el.closest(".field");
			if (!field) return;

			const icon = field.querySelector(".field-icon");
			const msgEl = field.querySelector(".field-msg");

			if (msgEl) msgEl.textContent = msg || "";

			el.classList.remove("is-valid", "is-invalid");

			if (!state) {
				field.classList.remove("has-icon");
				if (icon) icon.innerHTML = "";
				return;
			}

			field.classList.add("has-icon");

			if (state === "error") el.classList.add("is-invalid");
			if (state === "success") el.classList.add("is-valid");
			console.log("FIELD CLASS:", field.className); console.log(el.closest(".field"));
			if (icon) icon.innerHTML = icons[state] || "";
		},

		clear(el) {

			const field = el.closest(".field");
			if (!field) return;

			const icon = field.querySelector(".field-icon");
			const msgEl = field.querySelector(".field-msg");

			if (msgEl) msgEl.textContent = "";

			el.classList.remove("is-valid", "is-invalid");

			field.classList.remove("has-icon");

			if (icon) {
				icon.innerHTML = "";
				icon.style.opacity = "0";
			}
		}
	};
})();

window.RuleFactory = (() => {

	// 🔥 防止重複註冊
	const registry = new Set();

	function buildId(stepKey, field, name) {
		return `${stepKey}.${field}.${name}`;
	}

	function registerOnce({ stepKey, field, name, handler }) {

		const id = buildId(stepKey, field, name);

		// ❌ 已註冊 → 不再重複
		if (registry.has(id)) return;

		registry.add(id);

		ValidationGraph.register({
			id,
			stepKey,
			field,

			run: ({ val, stepKey }) => {

				// 🔥 可擴展（未來支援跨欄位）
				const data = FormStore.getStep(stepKey);

				return handler({
					val,
					stepKey,
					field,
					data
				});
			}
		});
	}

	return {
		registerOnce
	};

})();
window.Graph = (() => {

	const nodes = [];
	const registry = new Set();
	const timers = {};
	const controllers = {};

	// =========================
	// ⭐ token registry（核心）
	// =========================
	const activeToken = {};

	function isValidField(store, stepKey, key) {
		const step = store.getStep(stepKey);
		return step && Object.prototype.hasOwnProperty.call(step, key);
	}

	function buildId(n) {
		return n.id || `${n.type}.${n.stepKey}.${n.target || n.deps.join(",")}`;
	}

	function register(node) {

		const id = buildId(node);
		if (registry.has(id)) return;

		registry.add(id);

		nodes.push({
			debounce: 150,
			mapping: null,
			...node
		});
	}

	function resolvePath(obj, path) {
		return path.split(".").reduce((acc, k) => acc?.[k], obj);
	}

	// =========================
	// ⭐ token guard
	// =========================
	function isLatestToken(stepKey, key, token) {
		return activeToken[`${stepKey}.${key}`] === token;
	}

	async function trigger(stepKey, changedField, meta = {}) {

		const timerKey = `${stepKey}:${changedField}`;
		clearTimeout(timers[timerKey]);

		timers[timerKey] = setTimeout(async () => {

			const store = AppBootstrap.get("FormStore");
			const data = store.getStep(stepKey);

			const validationNodes = [];
			const effectNodes = [];

			for (const n of nodes) {

				if (n.stepKey !== stepKey) continue;
				if (!n.deps.includes(changedField)) continue;

				if (n.type === "validation") validationNodes.push(n);
				else effectNodes.push(n);
			}

			// ======================================================
			// 🔴 VALIDATION PIPELINE
			// ======================================================
			for (const n of validationNodes) {

				const token = Symbol(`${stepKey}.${n.target}`);

				// ⭐ 記錄最新 token
				const nodeKey = `${stepKey}.${n.target}.${n.type}`;
				activeToken[nodeKey] = token;

				if (activeToken[nodeKey] !== token) continue;

				const reqKey = `${stepKey}.${n.target}`;

				if (controllers[reqKey]) {
					controllers[reqKey].abort();
				}

				const controller = new AbortController();
				controllers[reqKey] = controller;

				const result = await n.run({
					stepKey,
					data,
					token,
					signal: controller.signal
				});

				if (result && typeof result === "object") {

					if (result.valid === false) {
						store.setError(stepKey, n.target, result.message || "驗證失敗");
						store.setStatus(stepKey, n.target, "error");
						continue;
					}

					store.clearError(stepKey, n.target);
					store.setStatus(stepKey, n.target, "success");

					if (result.data) {

						const mapping = result.__mapping;

						// =========================
						// ⭐ mapping mode
						// =========================
						if (mapping) {

							for (const [targetKey, sourcePath] of Object.entries(mapping)) {

								if (!isValidField(store, stepKey, targetKey)) continue;
								 
								const value = resolvePath(result.data, sourcePath);
								if (value === undefined) continue;

								store.safeSet(stepKey, targetKey, value, { token });
							}
						}

						// =========================
						// ⭐ fallback mode
						// =========================
						else {

							for (const [k, v] of Object.entries(result.data)) {

								if (!isValidField(store, stepKey, k)) continue; 

								store.safeSet(stepKey, k, v, { token });
							}
						}
					}

					continue;
				}

				if (result !== true) {
					store.setError(stepKey, n.target, result);
					store.setStatus(stepKey, n.target, "error");
				}
			}

			// ======================================================
			// 🔵 EFFECT / COMPUTED PIPELINE
			// ======================================================
			for (const n of effectNodes) {

				const token = Symbol(`${stepKey}.${n.target}`);

				// ⭐ 記錄最新 token
				const nodeKey = `${stepKey}.${n.target}.${n.type}`;
				activeToken[nodeKey] = token;

				if (activeToken[nodeKey] !== token) continue;

				if (n.target) {
					store.setStatus(stepKey, n.target, "processing");
				}

				try {

					const result = await n.run({
						stepKey,
						data,
						token
					});

					if (!n.target) continue;

					if (typeof result === "object") {

						const mapping = result.__mapping;

						if (mapping) {

							for (const [targetKey, sourcePath] of Object.entries(mapping)) {

								if (!isValidField(store, stepKey, targetKey)) continue;
								 
								const value = resolvePath(result.data, sourcePath);
								if (value === undefined) continue;

								store.safeSet(stepKey, targetKey, value, { token });
							}

						} else if (result.data) {

							for (const [k, v] of Object.entries(result.data)) {

								if (!isValidField(store, stepKey, k)) continue; 

								store.safeSet(stepKey, k, v, { token });
							}

						} else if (result.patch) {

							for (const [k, v] of Object.entries(result.patch)) {

								if (!isValidField(store, stepKey, k)) continue; 
								store.safeSet(stepKey, k, v, { token });
							}

						} else {

							for (const [k, v] of Object.entries(result)) {

								if (k === "valid" || k === "message") continue;
								if (!isValidField(store, stepKey, k)) continue; 

								store.safeSet(stepKey, k, v, { token });
							}
						}
					}

					store.setStatus(stepKey, n.target, "success");

				} catch (e) {

					if (e.name === "AbortError") return;

					store.setError(stepKey, n.target, "處理失敗");
					store.setStatus(stepKey, n.target, "error");
				}
			}

		}, 150);
	}

	return { register, trigger };

})();
function parseRule(ruleStr) {

	if (!ruleStr) {
		return { validators: [], async: null, mapping: null };
	}

	const parts = ruleStr.split("|");

	const validators = [];
	let async = null;
	let mapping = null;

	for (const p of parts) {

		// =========================
		// async:/api
		// =========================
		if (p.startsWith("async:")) {
			async = p.replace("async:", "").trim();
			continue;
		}

		// =========================
		// map:a=b,c=d
		// =========================
		if (p.startsWith("map:")) {

			mapping = {};

			const raw = p.replace("map:", "").split(",");

			for (const item of raw) {

				const [target, source] = item.split("=");

				if (!target || !source) continue;

				mapping[target.trim()] = source.trim();
			}

			continue;
		}

		// =========================
		// sync validators
		// =========================
		validators.push(p);
	}

	return { validators, async, mapping };
}
function registerValidationRules(el, stepKey) {

	const field = el.dataset.field;
	const parsed = parseRule(el.dataset.rule);

	// =========================
	// 1️⃣ sync validators
	// =========================
	parsed.validators.forEach((r, i) => {

		const [name, arg] = r.split(":");
		const fn = ValidationRules[name];
		if (!fn) return;

		Graph.register({
			type: "validation",
			stepKey,
			deps: [field],
			target: field,
			id: `${stepKey}.${field}.${name}.${i}`,

			run: ({ data }) => fn(data[field], { arg })
		});
	});

	// =========================
	// 2️⃣ async validator
	// =========================
	if (parsed.async) {

		Graph.register({
			type: "validation",
			stepKey,
			deps: [field],
			target: field, 
			id: `${stepKey}.${field}.async`,

			run: async ({ data, stepKey }) => {

				const currentVal = data[field];  // ⭐ 記住當下值

				const result = await ValidationRules.async(currentVal, {
					url: parsed.async,
					stepKey,
					field
				});

				// ⭐ 帶回版本資訊（關鍵）
				return {
					...result,
					__val: currentVal,
					__mapping: parsed.mapping
				};
			}
		});
	}
	 
}