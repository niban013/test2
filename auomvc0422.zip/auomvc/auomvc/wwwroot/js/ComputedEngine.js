﻿window.ComputedEngine = (() => {

    const store = () => AppBootstrap.get("FormStore");

    const defs = [
        {
            field: "isAdult",
            step: "step2",
            deps: ["Age"],
            get: (data) => data.Age >= 18
        }
    ];

    function init() {

        defs.forEach(def => {

            def.deps.forEach(dep => {

                Vue.watch(
                    () => store().get(def.step, dep),
                    () => {

                        const data = store().getStep(def.step);
                        const newVal = def.get(data);

                        store().set(def.step, def.field, newVal, { silent: true });
                    }
                );

            });

        });
    }

    return { init };

})();

//window.ComputedRegistry = (() => {

//    const defs = {

//        "step2.isAdult": {
//            deps: ["Age"],
//            get: (data) => data.Age >= 18
//        }

//        // 👉 之後全部只加這裡
//        // "step1.fullName": {
//        //     deps: ["firstName", "lastName"],
//        //     get: d => d.firstName + " " + d.lastName
//        // }
//    };

//    return {
//        getAll: () => defs,
//        add: (key, def) => defs[key] = def
//    };

//})();

//window.ComputedEngine = (() => {

//    let enabled = false;
//    let initialized = false;

//    function init() {

//        if (initialized) return;
//        initialized = true;

//        const store = AppBootstrap.get("FormStore");
//        const defs = ComputedRegistry.getAll();

//        Object.entries(defs).forEach(([fullKey, def]) => {

//            const [stepKey, field] = fullKey.split(".");

//            Vue.watch(
//                () => JSON.stringify(def.deps.map(dep => store.getStep(stepKey)?.[dep])),
//                () => {

//                    if (!enabled) return;

//                    const data = store.getStep(stepKey);
//                    const newVal = def.get(data);
//                    const oldVal = store.get(stepKey, field);

//                    if (newVal === oldVal) return;

//                    store.set(stepKey, field, newVal, { silent: true });
//                }
//            );

//        });
//    }

//    function enable() {
//        enabled = true;
//    }

//    return {
//        init,
//        enable
//    };

//})();