﻿window.FieldBinder = (() => {

    function bindValidation(el, stepKey) {

        const key = el.dataset.field;
        const store = AppBootstrap.get("FormStore");

        const engine = AppBootstrap.get("ValidationEngine");

        // 🔥 1. watch（未來變化）
        //Vue.watch(
        //    () => store.get(stepKey, key),
        //    async (val) => {

        //        if (!engine) return;
        //        await engine.run(stepKey, key, val, el);
        //    }
        //);

        // 🔥 2. 初始化補跑（關鍵）
        const initVal = store.get(stepKey, key);
        if (engine) {
            engine.run(stepKey, key, initVal, el);
        }
    }

    function bindFields(container, stepKey) {
        const store = AppBootstrap.get("FormStore");
        container
            .querySelectorAll("input[data-field], select[data-field], textarea[data-field]")
            .forEach(el => {

            if (el.dataset.bound) return;
            el.dataset.bound = "1";

            const key = el.dataset.field;

            bindValidation(el, stepKey);

            const update = async (e) => {

                const target = e?.target || el;

                let val;

                if (target.type === "checkbox") val = target.checked;

                else if (target.type === "radio") {

                    const checked = container.querySelector(
                        `input[data-field='${key}']:checked`
                    );

                    val = checked ? checked.value : null;

                }

                else if (target.type === "number") {
                    val = target.value ? Number(target.value) : null;
                }

                else val = target.value;

                store.set(stepKey, key, val);
                const engine = AppBootstrap.get("ValidationEngine");
                await engine.run(stepKey, key, val, target);
                //ComputedEngine.run(stepKey);
            };

            // =========================
            // 🔥 Select2 支援
            // =========================
            if (el.tagName === "SELECT") {

                const $el = $(el);

                if ($el.data("select2")) {

                    $el.on("select2:select select2:clear change", function () {
                        update({ target: el });
                    });

                } else {
                    el.addEventListener("change", update);
                }

                return;
            }

            // =========================
            // 🔥 一般 input
            // =========================
            el.addEventListener("input", update);
            el.addEventListener("change", update);
            el.addEventListener("blur", () => {
                store.setTouched(stepKey, key);
            });
            // =========================
            // 🔥 UI 狀態（錯誤 / success）
            // =========================
            Vue.watch(
                () => store.get(stepKey, key + ".__status"),
                (state) => {
                    const msg = store.getError(stepKey, key);
                    const showError =
                        store.isTouched(stepKey, key) ||
                        store.isStepSubmitted(stepKey);

                    if (!showError) {
                        FieldStatus.clear(el); // 或 set(null)
                        return;
                    }
                    FieldStatus.set(el, state, msg);
                }
            );
        });
    }

    return {
        bindFields
    };

})();