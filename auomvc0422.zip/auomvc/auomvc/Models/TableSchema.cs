﻿namespace auomvc.Models
{ 
    /// <summary>
    /// DataTable 結構定義，用於描述前端 DataTable 的所有設定
    /// </summary>
    public class TableSchema
    {
        /// <summary>
        /// Table 的 HTML Id
        /// </summary>
        public string TableId { get; set; }

        /// <summary>
        /// Ajax 資料來源 URL
        /// </summary>
        public string AjaxUrl { get; set; }

        /// <summary>
        /// 資料取得模式
        /// </summary>
        public FetchMode FetchMode { get; set; } = FetchMode.All;

        /// <summary>
        /// DataTable 行為設定
        /// </summary>
        public TableConfig Config { get; set; } = new();

        /// <summary>
        /// DataTable 額外 UI 功能
        /// </summary>
        public TableFeatures Features { get; set; } = new();

        /// <summary>
        /// Table 欄位定義
        /// </summary>
        public List<ColumnSchema> Columns { get; set; } = new();

        /// <summary>
        /// Table 工具列按鈕
        /// </summary>
        public List<ToolbarButton> ToolbarButtons { get; set; } = new();

        /// <summary>
        /// 每列操作按鈕
        /// </summary>
        public List<RowAction> RowButtons { get; set; } = new();  // <-- 統一命名

        /// <summary>
        /// 查詢篩選條件
        /// </summary>
        public List<TableFilter> Filters { get; set; } = new();

        /// <summary>
        /// Ajax 請求額外參數
        /// </summary>
        public object AjaxParams { get; set; }

        
        public string Message { get; set; }
    }
    /// <summary>
    /// DataTable 基本行為設定
    /// </summary>
    public class TableConfig
    {
        /// <summary>
        /// 是否顯示搜尋欄
        /// </summary>
        public bool Searching { get; set; } = true;

        /// <summary>
        /// 是否允許欄位排序
        /// </summary>
        public bool Ordering { get; set; } = true;

        /// <summary>
        /// 是否啟用分頁
        /// </summary>
        public bool Paging { get; set; } = true;

        /// <summary>
        /// 是否允許切換每頁顯示筆數
        /// </summary>
        public bool LengthChange { get; set; } = true;

        /// <summary>
        /// 每頁顯示資料筆數
        /// </summary>
        public int PageLength { get; set; } = 10;

        /// <summary>
        /// 是否保存表格狀態（排序、搜尋條件、頁碼）
        /// </summary>
        public bool StateSave { get; set; } = true;

        /// <summary>
        /// 虛擬滾動高度（px）
        /// </summary>
        public string? VirtualScrollHeight { get; set; }  // ex: "500px"
    }
    /// <summary>
    /// DataTable 資料取得模式
    /// </summary>
    public enum FetchMode
    {
        /// <summary>
        /// 一次取得全部資料（Client-side DataTable）
        /// </summary>
        All,

        /// <summary>
        /// Server-side processing
        /// </summary>
        Server
    }
    /// <summary>
    /// DataTable UI 功能設定
    /// </summary>
    public class TableFeatures
    {
        /// <summary>
        /// 顯示多選 Checkbox 欄位
        /// </summary>
        public bool Checkbox { get; set; }

        /// <summary>
        /// 啟用整列選取
        /// </summary>
        public bool RowSelect { get; set; }

        /// <summary>
        /// 啟用資料匯出功能（Excel / CSV / PDF）
        /// </summary>
        public bool Export { get; set; }

        /// <summary>
        /// 欄位顯示切換
        /// </summary>
        public bool ColumnToggle { get; set; }

        /// <summary>
        /// 顯示全選 Checkbox
        /// </summary>
        public bool SelectAll { get; set; }

        /// <summary>
        /// 啟用虛擬滾動（大量資料優化）
        /// </summary>
        public bool VirtualScroll { get; set; }
        // <summary>
        /// 啟用虛擬滾動（大量資料優化）
        /// </summary>
        public bool RowButtons { get; set; }      // 每列操作按鈕
        // <summary>
        /// 啟用虛擬滾動（大量資料優化）
        /// </summary>
        public bool ColumnFilter { get; set; }    // 每欄篩選
        // <summary>
        /// 啟用虛擬滾動（大量資料優化）
        /// </summary>
        public bool StickyHeader { get; set; }    // 固定表頭
    }
    /// <summary>
    /// DataTable 欄位定義
    /// </summary>
    public class ColumnSchema
    {
        /// <summary>
        /// 對應 JSON 欄位名稱
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// 欄位顯示標題
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// JavaScript Formatter 函式名稱
        /// </summary>
        public string Formatter { get; set; }

        /// <summary>
        /// 是否允許排序
        /// </summary>
        public bool Sortable { get; set; } = true;

        /// <summary>
        /// 是否允許搜尋
        /// </summary>
        public bool Searchable { get; set; } = true;

        /// <summary>
        /// 欄位寬度
        /// </summary>
        public string Width { get; set; }

        /// <summary>
        /// CSS Class
        /// </summary>
        public string CssClass { get; set; }

        /// <summary>
        /// 是否顯示此欄位
        /// </summary>
        public bool Visible { get; set; } = true;

        /// <summary>
        /// 建立欄位（標題預設為欄位名稱）
        /// </summary>
        public ColumnSchema(string field)
        {
            Field = field;
            Title = field;
        }

        /// <summary>
        /// 建立欄位並指定 Formatter
        /// </summary>
        public ColumnSchema(string field, string formatter)
        {
            Field = field;
            Title = field;
            Formatter = formatter;
        }
    }
    /// <summary>
    /// DataTable 工具列按鈕
    /// </summary>
    public class ToolbarButton
    {
        /// <summary>
        /// 按鈕顯示文字
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 前端 JavaScript 事件名稱
        /// </summary>
        public string Event { get; set; }

        /// <summary>
        /// CSS 樣式
        /// </summary>
        public string CssClass { get; set; }

        /// <summary>
        /// 按鈕 Icon
        /// </summary>
        public string Icon { get; set; }

        /// <summary>
        /// 建立工具列按鈕
        /// </summary>
        public ToolbarButton(string title, string evt, string icon, string css = "btn btn-primary")
        {
            Title = title;
            Event = evt;
            CssClass = css;
            Icon = icon;
        }
    }

    /// <summary>
    /// 每列資料操作按鈕
    /// </summary>
    public class RowAction
    {
        /// <summary>
        /// 按鈕文字
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// JavaScript 事件名稱
        /// </summary>
        public string Event { get; set; }

        /// <summary>
        /// Icon
        /// </summary>
        public string Icon { get; set; }

        /// <summary>
        /// CSS 樣式
        /// </summary>
        public string CssClass { get; set; } = "btn btn-sm btn-primary";
    }

    /// <summary>
    /// DataTable 查詢篩選條件
    /// </summary>
    public class TableFilter
    {
        /// <summary>
        /// 欄位名稱
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// 顯示標題
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 篩選類型
        /// </summary>
        public FilterType Type { get; set; }

        /// <summary>
        /// Select 選項
        /// </summary>
        public List<SelectOption> Options { get; set; }
    }

    /// <summary>
    /// 篩選器類型
    /// </summary>
    public enum FilterType
    {
        /// <summary>
        /// 文字輸入
        /// </summary>
        Text,

        /// <summary>
        /// 下拉選單
        /// </summary>
        Select,

        /// <summary>
        /// 日期
        /// </summary>
        Date,

        /// <summary>
        /// 數字
        /// </summary>
        Number
    }

    /// <summary>
    /// Select 選項
    /// </summary>
    public class SelectOption
    {
        /// <summary>
        /// 值
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// 顯示文字
        /// </summary>
        public string Text { get; set; }
    }
}
