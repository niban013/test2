using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using vsnet8.Models;

namespace vsnet8.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public IActionResult LoadForm(string type)
        {


            var fields = GenerateFields(type);


            return PartialView("_DynamicForm", fields);
        }
        public IActionResult Index()
        { 
            return View();
        }
        public IActionResult LoadCheckTable(string type)
        {
            var fields = LoadCheckFields(type);


            return PartialView("_DynamicCheckTable", fields);

        }
        private List<DynamicField> GenerateFields(string type)
        {
            var list = new List<DynamicField>();

            list.Add(new DynamicField
            {
                Name = "Name",
                Label = "�m�W",
                Format = "string",
                Must = false,
                Type = FieldType.Label,
                Width = 3,
                Order = 1
            });
            list.Add(new DynamicField
            {
                Name = "Age",
                Label = "�~��",
                Must = true,
                Type = FieldType.Numeric,
                Placeholder = "�п�J�~��",
                Width = 3,
                Format = "number",
                Order = 2
            });
            list.Add(new DynamicField
            {
                Name = "DueDate",
                Label = "�����",
                Must = true,
                Type = FieldType.Date,
                Placeholder = "�п�J�����",
                Width = 3,
                Format = "yyyy/mm/dd",
                Order = 3
            });
            if (type == "employee")
            {
                list.Add(new DynamicField
                {
                    Name = "Dept",
                    Label = "����",
                    Must = true,
                    Type = FieldType.Select2,
                    Options = new()
                    {
                       new SelectItem{Value="1",Text="���`",Color="lightgreen"},
        new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
        new SelectItem{Value="3",Text="���`",Color="lightcoral"}
                    }
                });
            }

            if (type == "customer")
            {
                list.Add(new DynamicField
                {
                    Name = "City",
                    Label = "����",
                    Type = FieldType.Select2,
                    Options = new()
            {
                new SelectItem{Value="taipei",Text="�x�_"},
                new SelectItem{Value="hsinchu",Text="�s��"}
            }
                });
            }

            return list;
        }
        public List<DynamicField> LoadCheckFields(string type)
     
        {
            var list = new List<DynamicField>();

            if (type == "equipment")
            {
                list.Add(new DynamicField
                {
                    Must = true,
                    Name = "oil",
                    Label = "�o�q",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Format = "number"
                });

                list.Add(new DynamicField
                {
                    Name = "checktime",
                    Label = "�ˬd�ɶ�",
                    Width = 3,
                    Type = FieldType.Date,
                    Format = "yyyy/mm/dd",
                });

                list.Add(new DynamicField
                {
                    Name = "status",
                    Label = "�]�ƪ��A",
                    Type = FieldType.Select2,
                    Width = 3,
                    Format = "string",
                    DefaultValue= "���`",
                    Options = new List<SelectItem>{
                new SelectItem{Value="1",Text="���`",Color="lightgreen"},
                new SelectItem{Value="2",Text="ĵ�i",Color="yellow"},
                new SelectItem{Value="3",Text="���`",Color="red"}
            }
                });
            }

            if (type == "temperature")
            {
                list.Add(new DynamicField
                {
                    Must = true,
                    Name = "temp1",
                    Label = "�J�f�ū�",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Format = "number"
                });

                list.Add(new DynamicField
                {
                    Name = "temp2",
                    Label = "�X�f�ū�",
                    Width = 3,
                    Type = FieldType.Numeric,
                    Format = "number"
                });
            }

            return list;
        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
