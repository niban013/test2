﻿var DynamicForm = (function () {

    function init(container) {

        // Select2 初始化
        $(container).find(".select2").each(function () {
            let select = $(this);

            // 初始化 Select2
            select.select2({
                width: '100%',
                templateResult: function (item) {
                    if (!item.id) return item.text;
                    let color = $(item.element).data("color") || "";
                    return $('<div style="background-color:' + color + '; width:100%; padding:4px 6px; box-sizing:border-box;">' + item.text + '</div>');
                },
                templateSelection: function (item) {
                    if (!item.id) return item.text;
                    return item.text;
                }
            });

            // 設置選中背景色的函數
            function setSelect2Background() {
                // 找到選中的 <option> 元素
                let color = select.find("option:selected").data("color") || "";
                // 設定 Select2 顯示框背景色
                select.next(".select2-container")
                    .find(".select2-selection--single")
                    .css("background-color", color);
            }

            // 初始化背景色
            setSelect2Background();

            // 綁定 Select2 選中事件
            select.off("select2:select").on("select2:select", function (e) {
                setSelect2Background();
            });

            // 可選：也綁定取消事件，避免多選時背景錯誤
            select.off("select2:unselect").on("select2:unselect", function (e) {
                setSelect2Background();
            });
        });


        // 普通 select 選中背景色
        //$(container).find("select:not(.select2)").each(function () {

        //    let select = $(this);

        //    setSelectBackground(select);

        //    select.off("change").on("change", function () {

        //        setSelectBackground($(this));

        //    });

        //});


        // CheckRow 狀態初始化
        $(container).find(".dynamicCheckRow").each(function () {

            updateStatus($(this));

        });

    }


    function setSelectBackground(select) {

        let color = select.find("option:selected").css("background-color");

        select.css("background-color", color);

    }


    // 驗證
    function validate(container) {

        let valid = true;

        $(container).find(".dynamicInput").each(function () {

            if ($(this).is(":hidden") || $(this).prop("readonly")) return;

            let must = $(this).data("must");

            let format = $(this).data("format");

            let val = $(this).val();

            if (must && (!val || val.trim() === "")) {

                $(this).addClass("is-invalid");

                valid = false;

                return;

            }

            // date 驗證
            if (val && format === "yyyy/mm/dd") {

                if (isNaN(Date.parse(val))) {

                    valid = false;

                    $(this).addClass("is-invalid");

                }

            }

            // number 驗證
            if (format === "number" && val && !$.isNumeric(val)) {

                $(this).addClass("is-invalid");

                valid = false;

                return;

            }

            $(this).removeClass("is-invalid");

        });

        return valid;

    }


    // 取得資料
    function getData(container) {

        let result = {};

        $(container).find(".dynamicInput").each(function () {

            let name = $(this).attr("name");

            result[name] = $(this).val();

        });

        return result;

    }


    // 狀態 icon
    function updateStatus(row) {

        let val = row.find(".valueInput:enabled").val();
        let icon = row.find(".statusCell i");

        if (val) {

            icon.removeClass("bi-x-circle text-danger")
                .addClass("bi-check-circle text-success");
            row.find(".valueInput:enabled").focus()
        } else {

            icon.removeClass("bi-check-circle text-success")
                .addClass("bi-x-circle text-danger");

        }
        //let time = row.find(".dateInput").val();

        //if (val !== "" && val != null) { 
        //    row.find(".statusCell").html(
        //        '<i class="bi bi-check-circle text-success"></i>'
        //    );

        //} else {

        //    row.find(".statusCell").html(
        //        '<i class="bi bi-x-circle text-danger"></i>'
        //    );

        //}

    }


    // value / time change
    $(document).on("input change", ".valueInput,.dynamicInput,.dateInput", function () {

        let row = $(this).closest("tr");

        updateStatus(row);

    });


    // dropdown color (table)
    $(document).on("change", ".dropdownColor", function () {

        let color = $(this).find("option:selected").data("color");

        $(this).css("background-color", color);

    });


    // upload modal
   


    return {

        init: init,

        validate: validate,

        getData: getData

    };

})();