﻿using Dapper;
using mvc5.Service;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using ws2;

namespace mvc5.Controllers
{
    public class HomeController : Controller
    {
        private readonly IDbService _db; 
        private readonly UserService _userService;
      
        private readonly IList<string> _stringList;
        private readonly HttpContextBase _httpContext;
        public HomeController(IDbService db, IList<string> stringList, HttpContextBase httpContext, UserService userService)
        {
            _stringList = stringList;
            _httpContext = httpContext;
            _userService = userService;
            _db = db;
        }
        [ActionName("Index")]
        public async Task<ActionResult> IndexAsync()
        {
            try
            {
                //using (var connection = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;"))
                //{
                //    connection.Open();
                //    var customers = connection.QueryAsync<dynamic>("SELECT * FROM Customers").Result; // 明確寫 dbo
                //    //foreach (var c in customers)
                //    //    Console.WriteLine(c);
                //}
                //using (var conn = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;"))
                //{
                //    var c = await conn.QueryAsync<dynamic>("SELECT * FROM Customers", null);
                //}
                 
                    var d2 = await _db.QueryAsync<dynamic>("delete from Customers where FirstName='Web'");
               
                var d =  _db.Query<dynamic>("SELECT  * FROM Customers where FirstName=@FirstName", new { FirstName = "Web" });
                //DataTable dt = await _db.QueryDataTableAsync("SELECT TOP 5 * FROM Customers");
                //var name = _userService.GetUserName(123);
                //_stringList.Add(new Random().Next(1, 100).ToString());
                LogHelper.Info("This is an information message.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("log4net error: " + ex.Message);
            }
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}