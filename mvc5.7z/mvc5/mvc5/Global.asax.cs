﻿using Autofac.Integration.Mvc;
using Autofac;
using mvc5.AutoFac;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace mvc5
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var log4netConfigFile = new FileInfo(Server.MapPath("~/log4net.config"));
            log4net.Config.XmlConfigurator.Configure(log4netConfigFile);
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            var builder = new ContainerBuilder();
            builder.RegisterControllers(typeof(MvcApplication).Assembly);
            // 註冊 HttpContextBase
            builder.RegisterModule<AutofacWebTypesModule>();
            builder.RegisterModule(new AutoFacModule());


            // 註冊 DbService，依照 ConnectionString 名稱
            builder.RegisterType<DbService>()
                   .As<IDbService>()
                   .WithParameter("connectionName", "DefaultConnection")
                   .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(typeof(MvcApplication).Assembly)
           .Where(t => t.Name.EndsWith("Service"))   // 類別名稱結尾是 Service
                .AsSelf() // 註冊成自己
                                                     .AsImplementedInterfaces()                // 依照介面注入，例如 UserService → IUserService

           .InstancePerLifetimeScope();              // MVC/WebApi 常用 Scope
            var container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));
        }
        protected void Application_BeginRequest()
        {
            string userName = HttpContext.Current.User?.Identity?.Name ?? "Anonymous";
            userName = Regex.Replace(userName, @"[\\/:*?""<>|]", "_");

            log4net.LogicalThreadContext.Properties["userName"] = userName;

        }
    }
}
