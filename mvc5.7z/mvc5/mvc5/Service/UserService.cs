﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc5.Service
{
    public class UserService
    {
        public string GetUserName(int userId)
        {
            // 模擬資料存取
            return $"User_{userId}";
        }
    }
}