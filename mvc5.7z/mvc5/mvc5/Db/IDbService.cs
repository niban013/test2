﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5
{
    public interface IDbService
    {
        IEnumerable<T> Query<T>(string sql, object param = null, CommandType commandType = CommandType.Text);
        Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, CommandType commandType = CommandType.Text);
        Task<T> QueryFirstOrDefaultAsync<T>(string sql, object param = null, CommandType commandType = CommandType.Text);
        Task<int> ExecuteAsync(string sql, object param = null, CommandType commandType = CommandType.Text);
        Task<DataTable> QueryDataTableAsync(string sql, object param = null, CommandType commandType = CommandType.Text);
    }
}