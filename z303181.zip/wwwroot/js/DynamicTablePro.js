﻿var DynamicTablePro = (function () {
    const api = {};
    api.events = {};
    api.tables = {};
    api.formatters = {
        currency: v => "$" + Number(v).toLocaleString()
    };

    // 建立欄位
    function buildColumns(schema) {
        let cols = [];
        let features = schema.Features || {};

        // Checkbox + Select All
        if (features.Checkbox) {
            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-checkbox-col",
                title: features.SelectAll ? '<input type="checkbox" class="dt-select-all">' : "",
                render: () => '<input type="checkbox" class="row-check">'
            });
        }

        // RowButtons (每列操作)
        if (features.RowButtons && schema.RowButtons?.length > 0) {

            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-row-btn-col",

                createdCell: function (td) {

                    $(td).css({
                        "white-space": "nowrap",
                        "width": "1%",
                      //  "display": "flex",
                        "gap": "6px"   // ⭐ 按鈕間距
                    });

                },

                render: row => {

                    return schema.RowButtons.map(btn => {

                        let iconHtml = btn.Icon
                            ? `<i class="bi ${btn.Icon}" style="margin-right:4px;"></i>`
                            : "";

                        let textHtml = btn.Title
                            ? btn.Title
                            : "";

                        // ⭐ 關鍵：tooltip fallback
                        let tooltip = btn.Tooltip || btn.Title || btn.Event || "";

                        return `
                            <button class="dt-btn ${btn.CssClass}" 
                                    data-event="${btn.Event}" 
                                    data-id="${row.Id}"
                                    title="${tooltip}">
                                ${iconHtml}${textHtml}
                            </button>
                        `;

                    }).join("");

                }
            });
        }

        // 資料欄位
        (schema.Columns || []).forEach(col => {
            let c = { data: col.Field, title: col.Title ?? col.Field };
            if (col.Formatter) c.render = v => api.formatters[col.Formatter] ? api.formatters[col.Formatter](v) : v;

            // Column Filter
            if (features.ColumnFilter) {
               // c.footer = `<input type="text" placeholder="All" class="column-filter form-control form-control-sm" style="width:100%;"/>`;
                c.headerFilter = `<input type="text" placeholder="All" class="column-filter form-control form-control-sm" style="width:100%; margin-top:4px;"/>`;

            }

            cols.push(c);
        });

        return cols;
    }

    // Render Table
    api.render = function (opt) {
        let schema = opt.schema;
        let columns = buildColumns(schema);
        let cfg = schema.Config || {};
        let features = schema.Features || {};
        let dtButtons = [];

        if (schema.ToolbarButtons && schema.ToolbarButtons.length > 0) {
            schema.ToolbarButtons.forEach(btn => {
                dtButtons.push({
                    text: `<i class="${btn.Icon}"></i> ${btn.Title}`, // 直接在此注入 Icon
                    attr: {
                        'title': btn.Title,
                        'data-bs-toggle': 'tooltip'
                    },
                    className: btn.CssClass,
                    // 核心修正：強制讓這個按鈕不帶 dt-button 類別
                    init: function (api, node, config) {
                        $(node).removeClass('dt-button');
                    },
                    action: function (e, dt, node, config) {
                        if (api.events[btn.Event]) api.events[btn.Event](schema.TableId);
                    }
                });
            });
        }
        let tableOptions = {
            //autoWidth: true,
            columns: columns,
         
            stateSave: cfg.StateSave ?? true,
            responsive: true,
            colReorder: true,
            searching: cfg.Searching ?? true,
            lengthChange: cfg.LengthChange ?? true,
            ordering: cfg.Ordering ?? true,
            paging: cfg.Paging ?? true,
            pageLength: cfg.PageLength ?? 10,
            dom: '<"table-header-right" f B>rtip',
            buttons: dtButtons,//(cfg.Buttons !== false || features.Export) ? ["excel"] : [],
            scrollY: cfg.ScrollY ?? (features.VirtualScroll ? "400px" : ""),
            scrollCollapse: features.VirtualScroll ?? false,
            deferRender: features.VirtualScroll ?? false,
            scroller: features.VirtualScroll ?? false,
            fixedHeader: features.StickyHeader ?? false,
            // ⭐ 如果 stateSave = true，覆蓋舊的 state
            stateLoadParams: function (settings, data) {
                data.start = 0;                       // 從第一頁開始
                data.length = cfg.PageLength ?? 10;   // 每頁筆數
                return data;
            },
            initComplete: function () {
                const table = api.tables[schema.TableId];
                const $thead = $(table.table().header());

                if (features.ColumnFilter) {

                    // 建立 filter row
                    let $filterRow = $('<tr class="filter-row"></tr>');
                    table.columns().every(function (i) {
                        $filterRow.append('<th><input type="text" class="column-filter form-control form-control-sm" placeholder="All"></th>');
                    });

                    // 放到 thead 最後一列
                    $thead.append($filterRow);

                    // 綁定事件
                    table.columns().every(function (i) {
                        const column = this;

                        // 注意：要直接從 $filterRow 找 input
                        $('input', $filterRow.find('th').eq(i)).on('keyup change clear', function () {
                            column.search(this.value, false, false).draw();
                        });
                    });
                }
            }
        };

        // Ajax
        if (schema.FetchMode === 0) {
            tableOptions.ajax = {
                url: schema.AjaxUrl,
                dataSrc: function (json) {
                    api['data_' + schema.TableId] = json.data;
                    return json.data;
                }
            };
            tableOptions.serverSide = false; 
        } else {
            tableOptions.serverSide = true;
            tableOptions.processing = true;
            tableOptions.ajax = schema.AjaxUrl;
        }

        let table = $("#" + schema.TableId).DataTable(tableOptions);
        api.tables[schema.TableId] = table;

        // RowButtons event (每列 Edit / Delete)
        $(document).on("click", `#${schema.TableId} .dt-row-btn-col .dt-btn`, function () {
            let event = $(this).data("event");
            let id = $(this).data("id");
            let row = table.row($(this).closest("tr")).data();
            if (api.events[event]) api.events[event](id, row, schema.TableId);
        });

        // Row Checkbox & Select All
        $(document).on("change", `#${schema.TableId} .row-check`, function () {
            if (!features.SelectAll) return;
            let total = table.$(".row-check").length;
            let checked = table.$(".row-check:checked").length;
            $(`#${schema.TableId} .dt-select-all`).prop("checked", total === checked);
        });
        $(document).on("change", `#${schema.TableId} .dt-select-all`, function () {
            let checked = $(this).is(":checked");
            table.$(".row-check").prop("checked", checked);
        });

        //// Column Filter
        //if (features.ColumnFilter) {
        //    table.columns().every(function () {
        //        var column = this;
        //        $('input.column-filter', this.footer()).on('keyup change clear', function () {
        //            if (column.search() !== this.value) column.search(this.value).draw();
        //        });
        //    });
        //}
  
        return table;
    };

    api.renderAll = function (tables) {
        tables.forEach(schema => api.render({ schema }));
    };

    // Toolbar event
    $(document).on("click", ".dataTables_filter button", function () {
        let event = $(this).data("event");
        let tableId = $(this).data("table");
        if (api.events[event]) api.events[event](tableId);
    });

    // Get selected rows
    api.getSelectedRows = function (tableId) {
        let table = api.tables[tableId];
        let rows = [];
        table.$(".row-check:checked").each(function () {
            let tr = $(this).closest("tr");
            let rowData = table.row(tr).data();
            if (rowData) rows.push(rowData);
        });
        return rows;
    };

    // Get all data
    api.getAllData = function (tableId) {
        return api['data_' + tableId] || [];
    };

    return api;
})();