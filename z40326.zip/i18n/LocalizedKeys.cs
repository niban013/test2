﻿
using Microsoft.Extensions.Localization;

namespace vsnet8.i18n
{
    public class LocalizedKeys
    {
        private readonly IStringLocalizer<SharedResource> _localizer;

        public LocalizedKeys(IStringLocalizer<SharedResource> localizer)
        {
            _localizer = localizer;
        }

        public string Hello => _localizer["Hello"];
        public string Submit => _localizer["Submit"];
        public string Required => _localizer["Required"];
    }
}