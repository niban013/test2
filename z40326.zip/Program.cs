﻿using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Localization;
using System.Collections.Concurrent;
using System.Globalization;
using vsnet8.Helper;

var builder = WebApplication.CreateBuilder(args);
// 註冊 LocalizedKeys，讓它可以注入
// 建立全域 JSON 緩存
var langCache = new ConcurrentDictionary<string, string>();
var langPath = Path.Combine(Directory.GetCurrentDirectory(), "i18n", "Lang");
foreach (var file in Directory.GetFiles(langPath, "*.json"))
{
    var culture = Path.GetFileNameWithoutExtension(file); // zh-TW / en-US
    var content = File.ReadAllText(file);
    langCache[culture] = content;
}

// DI
builder.Services.AddSingleton(langCache);

builder.Services.AddLocalization();
builder.Services.AddSingleton<IStringLocalizerFactory, JsonStringLocalizerFactory>();
builder.Services.AddSingleton(typeof(IStringLocalizer<>), typeof(StringLocalizer<>));

builder.Services.AddScoped<vsnet8.i18n.LocalizedKeys>();
// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = null;
    });
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
// 3️⃣ 設定本地化
var supportedCultures = new[]
{
    new CultureInfo("zh-TW"),
    new CultureInfo("en-US")
};

var localizationOptions = new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("zh-TW"), // ⚡ 預設中文
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
};

// 可加上 QueryStringProvider 支援 ?culture=en-US
localizationOptions.RequestCultureProviders.Insert(0, new QueryStringRequestCultureProvider());

app.UseRequestLocalization(localizationOptions);
app.UseRouting();

// ⚡ 注入 Middleware
app.UseMiddleware<I18nMiddleware>();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Indextw}/{id?}");

app.Run();
