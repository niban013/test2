﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc5
{
	public class PermissionService
	{
        //private static readonly Dictionary<string, string[]> _rolePages = new()
        //{
        //    { "Admin", new[] { "/Report", "/Home" } },
        //    { "User",  new[] { "/Home" } }
        //};

        //public static bool HasAccess(string username, string path)
        //{
        //    // 這裡可以改成查資料庫
        //    var roles = new[] { "User" }; // 預設角色
        //    if (username == "john.doe") roles = new[] { "Admin" };

        //    foreach (var role in roles)
        //    {
        //        if (_rolePages.TryGetValue(role, out var pages))
        //        {
        //            if (pages.Any(p => path.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
        //                return true;
        //        }
        //    }

        //    return false;
        //}
    }
}