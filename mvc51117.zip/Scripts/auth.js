async function ensureTokenExists() {
    let token = localStorage.getItem("jwtToken");
    let refreshToken = localStorage.getItem("refreshToken");

    if (!token) {
        console.log("⚠ 沒有 Token → 申請中...");
        ({ token, refreshToken } = await requestInitialToken());
    }

    return token;
}

// 取得初始 Token
async function requestInitialToken() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: "/Auth/GetToken",
            method: "GET",
            xhrFields: { withCredentials: true },
            success: function (res, status, xhr) {
                if (res.token && res.refreshToken) {
                    localStorage.setItem("jwtToken", res.token);
                    localStorage.setItem("refreshToken", res.refreshToken);
                    console.log("🎉 取得 AccessToken + RefreshToken 成功");
                    resolve({ token: res.token, refreshToken: res.refreshToken });
                } else {
                    reject("No token returned");
                }
            },
            error: function () {
                reject("取得 Token 失敗");
            }
        });
    });
}


// 判斷 Access Token 是否過期
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('')
            .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
            .join(''));
        return JSON.parse(jsonPayload);
    } catch {
        return null;
    }
}

function isJwtExpired(token) {
    const payload = parseJwt(token);
    if (!payload || !payload.exp) return true;
    const now = Math.floor(Date.now() / 1000);
    return payload.exp < now;
}

// 使用 Refresh Token 自動刷新 Access Token
async function refreshTokenIfNeeded() {
    return new Promise(async function (resolve, reject) {
        let token = localStorage.getItem('jwtToken');
        let refreshToken = localStorage.getItem('refreshToken');

        if (!token || isJwtExpired(token)) {
            if (!refreshToken) {
                console.warn("❌ 沒有 Refresh Token → 需要重新登入");
                resolve(null);
                return;
            }

            // 用 Refresh Token 呼叫後端刷新 Access Token
            $.ajax({
                url: '/auth/GetToken',
                method: 'GET',
                xhrFields: { withCredentials: true },
                headers: {
                    'X-Refresh-Token': refreshToken
                },
                success: function (data, status, xhr) {
                    const newToken = data?.token;
                    const newRefreshToken = xhr.getResponseHeader("X-Refresh-Token") || refreshToken;

                    if (newToken) {
                        localStorage.setItem('jwtToken', newToken);
                        localStorage.setItem('refreshToken', newRefreshToken);
                        console.log("🔄 Access Token 已刷新並儲存");
                        resolve(newToken);
                    } else {
                        console.warn("❌ 刷新失敗 → 需重新登入");
                        resolve(null);
                    }
                },
                error: function () {
                    console.warn("❌ 刷新失敗 → 需重新登入");
                    resolve(null);
                }
            });
        } else {
            resolve(token);
        }
    });
}

/**
 * @param {string} url - API URL
 * @param {string} method - HTTP Method, GET/POST
 * @param {object|null} data - 參數或 body
 * @param {object|null} loading - 可傳入 { show: function, hide: function }
 */
function ajaxFetch(url, method = 'GET', data = null, loading = null) {
    return new Promise(async function (resolve, reject) {
        const token = await refreshTokenIfNeeded();

        $.ajax({
            url: url,
            method: method,
            data: method.toUpperCase() === 'GET' ? data : JSON.stringify(data),
            contentType: method.toUpperCase() === 'GET' ? undefined : 'application/json',
            headers: {
                'Authorization': 'Bearer ' + token,
                'X-Refresh-Token': localStorage.getItem("refreshToken"),
                'X-CSRF-TOKEN': Cookies.get("CSRF-TOKEN")
            },
            xhrFields: { withCredentials: true },
            beforeSend: function () {
                if (loading && typeof loading.show === 'function') {
                    loading.show();
                }
            },
            complete: function (xhr) {
                const newToken = xhr.getResponseHeader("jwtToken");
                const newRefreshToken = xhr.getResponseHeader("X-Refreshed-Token");

                if (newToken) {
                    localStorage.setItem("jwtToken", newToken);
                    console.log("🔄 Access Token 已刷新並儲存");
                }
                if (newRefreshToken) {
                    localStorage.setItem("refreshToken", newRefreshToken);
                    console.log("🔄 Refresh Token 已更新");
                }

                if (loading && typeof loading.hide === 'function') {
                    loading.hide();
                }
            },
            success: function (res) {
                resolve(res);
            },
            error: function (xhr) {
                reject(xhr);
            }
        });
    });
}

const myLoading = {
    show: function () {
        $('#loadingOverlay').show();
    },
    hide: function () {
        $('#loadingOverlay').hide();
    }
};
