﻿
using Microsoft.CodeDom.Providers.DotNetCompilerPlatform;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;

namespace mvc5.autofac
{
    public static class DbEnumGenerator
    {
        public static Type GenerateEnum()
        {
            var enumName = "DbKeys";
            var namespaceName = "YourMvcApp.Data.Generated";

            var connectionStrings = ConfigurationManager.ConnectionStrings;

            // 生成 enum 的 C# 程式碼
            var code = new System.Text.StringBuilder();
            code.AppendLine("using System;");
            code.AppendLine($"namespace {namespaceName} {{");
            code.AppendLine($"    public enum {enumName} {{");
            foreach (ConnectionStringSettings cs in connectionStrings)
            {
                var name = cs.Name.Replace("-", "_").Replace(" ", "_");
                code.AppendLine($"        {name},");
            }
            code.AppendLine("    }");
            code.AppendLine("}");

            // 編譯成 Assembly
            var provider = new CSharpCodeProvider();
            var parameters = new CompilerParameters
            {
                GenerateInMemory = true,
                GenerateExecutable = false
            };
            parameters.ReferencedAssemblies.Add("System.dll");
            parameters.ReferencedAssemblies.Add(Assembly.GetExecutingAssembly().Location);

            var results = provider.CompileAssemblyFromSource(parameters, code.ToString());
            if (results.Errors.HasErrors)
            {
                var err = string.Join(Environment.NewLine, results.Errors);
                throw new Exception("Enum 生成錯誤: " + err);
            }

            // 取得 enum Type
            var enumType = results.CompiledAssembly.GetType($"{namespaceName}.{enumName}");
            return enumType;
        }
    }
}