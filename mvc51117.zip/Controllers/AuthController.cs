﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class AuthController : Controller
    {
        [HttpGet]
        [AllowAnonymous]
        public ActionResult GetToken()
        {  // 這裡可以從 User.Identity 取得使用者名稱，這裡測試先固定 "test"
            var username = User?.Identity?.Name ?? "test";

            // 生成 Access Token
            var accessToken = JwtTokenHelper.GenerateToken(username, expireMinutes: 30); // 30 分鐘有效
            // 生成 Refresh Token
            var refreshToken = JwtTokenHelper.GenerateRefreshToken(username, expireMinutes: 1440); // 1 天有效
            string csrfToken = CsrfTokenHelper.GenerateCsrfToken();

            // CSRF Token：放到 Cookie（不可 HttpOnly）
            Response.Cookies.Add(new HttpCookie("CSRF-TOKEN", csrfToken)
            {
                HttpOnly = false,
                Secure = false, // 若你用 https -> 設 true
                Path = "/"
            });
            // 同時在 Header 回傳 Refresh Token
            Response.AddHeader("X-Refresh-Token", refreshToken);

            // 回傳 JSON 給前端
            return Json(new
            {
                token = accessToken,
                refreshToken = refreshToken
            }, JsonRequestBehavior.AllowGet);
            //var username = User?.Identity?.Name;
            //username = "qqq";// User.Identity?.Name;
            //if (string.IsNullOrEmpty(username))
            //    return new HttpStatusCodeResult(401, "Not authenticated");

            //string newToken = string.Empty; 
            //newToken = (string)Session["JwtToken"];
            //if (Session["JwtToken"] == null)
            //{
            //    // 產生新的 token
            //    newToken = JwtTokenHelper.GenerateToken(username);
            //}
            ////Session["JwtToken"] = newToken;
            //return Json(new { token = newToken }, JsonRequestBehavior.AllowGet);
        }
    }
}