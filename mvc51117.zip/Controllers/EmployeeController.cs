﻿
using ClosedXML.Excel;
using Microsoft.AspNet.SignalR; 
using MiniExcelLibs;
using mvc5.autofac;
using mvc5.Service;
using Newtonsoft.Json;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using Quartz;
using Quartz.Impl.Matchers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using static mvc5.Controllers.EmployeeController;
using static Quartz.Logging.OperationName;
using HttpGetAttribute = System.Web.Mvc.HttpGetAttribute;
using HttpPostAttribute = System.Web.Mvc.HttpPostAttribute;

namespace mvc5.Controllers
{
    public static class NpoiHelper
    {
        public static void WriteDataTableToSheet(XSSFWorkbook workbook, ISheet sheet, DataTable dt, bool includeHeader = true)
        {
            int rowIndex = 0;
            // Header 樣式
            ICellStyle headerStyle = workbook.CreateCellStyle();
            headerStyle.Alignment = HorizontalAlignment.Center;
            headerStyle.VerticalAlignment = VerticalAlignment.Center;
            IFont headerFont = workbook.CreateFont();
            headerFont.IsBold = true;
            headerStyle.SetFont(headerFont);

            // 文字樣式
            ICellStyle textStyle = workbook.CreateCellStyle();
            textStyle.Alignment = HorizontalAlignment.Left;
            textStyle.VerticalAlignment = VerticalAlignment.Center;

            // 數值樣式
            ICellStyle numberStyle = workbook.CreateCellStyle();
            numberStyle.Alignment = HorizontalAlignment.Right;
            numberStyle.VerticalAlignment = VerticalAlignment.Center;

            // 日期時間樣式
            ICellStyle dateStyle = workbook.CreateCellStyle();
            dateStyle.Alignment = HorizontalAlignment.Center;
            dateStyle.VerticalAlignment = VerticalAlignment.Center;
            IDataFormat format = workbook.CreateDataFormat();
            dateStyle.DataFormat = format.GetFormat("yyyy/MM/dd HH:mm:ss");

            // 寫入表頭
            if (includeHeader)
            { 
                IRow headerRow = sheet.CreateRow(rowIndex++);
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    var cell = headerRow.CreateCell(i);
                    cell.SetCellValue(dt.Columns[i].ColumnName);
                    cell.CellStyle = headerStyle; 
                }
            }

            // 寫入資料列
            // 填入資料
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                var row = sheet.CreateRow(i + 1);
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    var cell = row.CreateCell(j);
                    var value = dt.Rows[i][j];

                    if (value is int || value is double || value is decimal || value is float)
                    {
                        cell.SetCellValue(Convert.ToDouble(value));
                        cell.CellStyle = numberStyle;
                    }
                    else if (value is DateTime dtValue)
                    {
                        cell.SetCellValue(dtValue);
                        cell.CellStyle = dateStyle;
                    }
                    else
                    {
                        cell.SetCellValue(value?.ToString() ?? "");
                        cell.CellStyle = textStyle;
                    }
                }
            }

            // 自動調整欄寬
            for (int i = 0; i < dt.Columns.Count; i++)
                sheet.AutoSizeColumn(i);
        }
    }
    // 動態查詢模型
    public class DynamicFilter
    {
        public string TableName { get; set; } = "";
        public Dictionary<string, object> Conditions { get; set; } = new Dictionary<string, object>();
    }

    // JobViewModel 可根據需要動態產生欄位
    public class Field
    {
        public string Id { get; set; }
        public string Label { get; set; }
        public string Url { get; set; }
        public string Type { get; set; } // select, text, checkbox
        //public List<string> Options { get; set; } = new List<string>();
        public string DefaultValue { get; set; }
    }
    public class EmployeeController : Controller
    {
         
          
        // GET /Export?tableName=Customers
        [HttpGet]
        public ActionResult Export(string tableName)
        {
            if (string.IsNullOrEmpty(tableName))
                return new HttpStatusCodeResult(400, "請提供 tableName");
            try
            {
                ExcelExportService d = new ExcelExportService();
             

                var fileBytes = d.ExportCustomers(tableName);
            return File(fileBytes,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "Customers.xlsx");
            }
            catch (System.ArgumentException ex)
            {
                // 返回 400 Bad Request
                return new HttpStatusCodeResult(400, ex.Message);
            }

        }

        [HttpPost]
        public ActionResult Import(HttpPostedFileBase file)
        {
            if (file == null || file.ContentLength == 0)
            {
                ViewBag.Message = "請上傳 Excel 檔案";
                return View();
            }

            try
            {
                using (var stream = file.InputStream)
                {
                    // 每 5000 行寫入一次，可根據記憶體調整
                    //_importService.ImportCustomers(stream, batchSize: 5000);
                }
                ViewBag.Message = "匯入成功";
            }
            catch (Exception ex)
            {
                ViewBag.Message = "匯入失敗：" + ex.Message;
            }

            return View();
        }
        public ActionResult Index()
        {
          
            return View();
        }
        // 取得前端要生成的動態欄位
        public JsonResult GetUsers2()
        {
            var allUsers = Enumerable.Range(1, 100)
                   .Select(i => new { Id = i, Name = "User " + i })
                   .ToList();
            return Json(allUsers, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetUsers(string q = "", int page = 1, int pageSize = 10)
        {
            // 模擬資料來源（真實情況可以來自 DB）
            var allUsers = Enumerable.Range(1, 100)
                .Select(i => new { Id = i, Name = "User " + i })
                .ToList();

            // 模糊搜尋
            var filtered = string.IsNullOrEmpty(q)
                ? allUsers
                : allUsers.Where(u => u.Name.Contains(q)).ToList();

            // 分頁
            var paged = filtered.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            var result = new
            {
                items = paged.Select(u => new { id = u.Id, text = u.Name }),
                totalCount = filtered.Count,
                pageSize = pageSize
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetFields(string tableName)
        {
            // 範例: 根據 tableName 回傳不同欄位
            var fields = new List<Field>();

            if (tableName == "Employees")
            {
                fields.Add(new Field { Id = "Department", Label = "部門", Type = "select",Url= "/Employee/GetUsers2", DefaultValue = "User 96" } );
                fields.Add(new Field { Id = "Active", Label = "狀態", Type = "checkbox", DefaultValue = "true" });
                fields.Add(new Field { Id = "Name", Label = "姓名", Type = "text" , DefaultValue = "qq" });
            }
            else if (tableName == "Departments")
            {
                fields.Add(new Field { Id = "Location", Label = "地點", Type = "select" });
                fields.Add(new Field { Id = "Manager", Label = "經理", Type = "text" });
            }

            return Json(fields, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetSearchFields()
        {
            // 後端決定哪些欄位要顯示
            var fields = new List<object>
        {
            new { Type = "select", Id = "department", Label = "部門", Options = new[] { "HR", "IT", "Sales" }  },
            new { Type = "text", Id = "name", Label = "姓名" },
            new { Type = "checkbox", Id = "active", Label = "包含離職員工" }
        };

            return Json(fields, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetTableDefinition()
        {
            // 後端決定 DataTable 欄位
            var columns = new[]
            {
            new { data = "Id", title = "編號" },
            new { data = "Name", title = "姓名" },
            new { data = "Department", title = "部門" },
            new { data = "Active", title = "狀態" },
            new { data = "HireDate", title = "到職日" }
        };
            return Json(columns, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetDepartments()
        {
            var list = new[] { "HR", "IT", "Sales", "Finance", "Admin" };
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        Dictionary<string, string> auto = new Dictionary<string, string>();
        // ✅ 模擬資料來源 (實務上可改為資料庫查詢)
        private DataTable GetMockData()
        {
            auto["Department"] = "D";
            auto["Active"] = "C";
            auto["Name"] = "T";
            var dt = new DataTable();
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Department", typeof(string));
            dt.Columns.Add("Active", typeof(bool));
            dt.Columns.Add("HireDate", typeof(DateTime));
            //dt.Columns.Add("Auto", typeof(bool));

            dt.Rows.Add(1, "John", "HR", true, DateTime.Now.AddYears(-3));
            dt.Rows.Add(2, "Mary", "IT", true, DateTime.Now.AddYears(-1));
            dt.Rows.Add(3, "Tom", "Sales", false, DateTime.Now.AddYears(-5));
            dt.Rows.Add(4, "Jane", "IT", true, DateTime.Now.AddYears(-2));
            dt.Rows.Add(5, "Kevin", "Sales", false, DateTime.Now.AddYears(-4));

            return dt;
        }

        // ✅ DataTables AJAX 端點
        [HttpPost]
        public JsonResult SearchEmployees(EmployeeFilter filter)
        {
            var dt = GetMockData();
            dt.TableName = "test";
            var query = dt.AsEnumerable();

            // 模擬篩選條件
            if (!string.IsNullOrEmpty(filter.Department))
                query = query.Where(r => r.Field<string>("Department") == filter.Department);

            if (!string.IsNullOrEmpty(filter.Keyword))
                query = query.Where(r => r.Field<string>("Name").Contains(filter.Keyword));

            if (!filter.IncludeInactive)
                query = query.Where(r => r.Field<bool>("Active"));

            var result = query.Select(r => new
            {
                Id = r.Field<int>("Id"),
                Name = r.Field<string>("Name"),
                Department = r.Field<string>("Department"),
                Active = r.Field<bool>("Active") ? "Active" : "Inactive",
                HireDate = r.Field<DateTime>("HireDate").ToString("yyyy-MM-dd")
            }).ToList();

            return Json(new { data = result }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ExportExcel(EmployeeFilter filter)
        {
            var dt = GetMockData();
            // 取得資料
            //DataTable dt = GetEmployeeData(filter);
            dt.TableName = "test";
            var workbook = new XSSFWorkbook();
            var sheet = workbook.CreateSheet(dt.TableName);

            // 寫入 DataTable
            //WriteDataTableToSheet(sheet, dt);



          

            NpoiHelper.WriteDataTableToSheet(workbook,sheet, dt, includeHeader: true);

            // 輸出成檔案
            //using (var fs = new FileStream("output.xlsx", FileMode.Create, FileAccess.Write))
            //{
            //    workbook.Write(fs);
            //}


            using (var ms = new MemoryStream())
            {
                workbook.Write(ms);
                byte[] fileBytes = ms.ToArray();
                return File(fileBytes,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            string.Format("{0}.xlsx", dt.TableName));
            }
        }
        // 動態查詢
        [HttpPost]
        public JsonResult Search([Microsoft.AspNetCore.Mvc.FromBody] DynamicFilter filter)
        {
            if (string.IsNullOrEmpty(filter.TableName))
                return Json(new { data = new List<object>() });
            var dt = GetMockData();
            // 2. 計算總筆數（未過濾）
            var recordsTotal = dt.Rows.Count;
            if (filter.Conditions.ContainsKey("#mode"))
            {
                if (filter.Conditions["#mode"].ToString() == "columns")
                {
                    string[] columns = dt.Columns.Cast<DataColumn>()
                                    .Select(x => x.ColumnName)
                                    .ToArray();
                    return Json(new
                    {
                        draw = 0,  // DataTable 用 draw 控制刷新
                        recordsTotal = 0,
                        recordsFiltered = 0,
                        data = columns
                    }, JsonRequestBehavior.AllowGet);
                    //return Json(new { columns });
                }
                else if (filter.Conditions["#mode"].ToString() == "export")
                {
                  
                    return Json(new
                    {
                        draw = 0,  // DataTable 用 draw 控制刷新
                        recordsTotal = 0,
                        recordsFiltered = 0,
                        data = new string[0] { }
                    }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var query = dt.AsEnumerable();

                    foreach (var kv in filter.Conditions)
                    {
                        //if (kv.Value is string str && str.Contains("%"))
                        //    whereClauses.Add($"{kv.Key} LIKE @{kv.Key}");
                        //else
                        ////////query = query.Where(r => r.Field<string>(kv.Key) == kv.Value.ToString());
                        //    ////whereClauses.Add($"{kv.Key} = @{kv.Key}");
                    }
                    query = query.Where(r => r.Field<string>("Name") == "John");

                    //// 模擬篩選條件
                    //if (!string.IsNullOrEmpty(filter.Department))
                    //    query = query.Where(r => r.Field<string>("Department") == filter.Department);

                    //if (!string.IsNullOrEmpty(filter.Keyword))
                    //    query = query.Where(r => r.Field<string>("Name").Contains(filter.Keyword));

                    //if (!filter.IncludeInactive)
                    //    query = query.Where(r => r.Field<bool>("Active"));

                    var result = query.Select(r => new
                    {
                        Id = r.Field<int>("Id"),
                        Name = r.Field<string>("Name"),
                        Department = r.Field<string>("Department"),
                        Active = r.Field<bool>("Active") ? "Active" : "Inactive",
                        HireDate = r.Field<DateTime>("HireDate").ToString("yyyy-MM-dd")
                    }).ToList();
                    var recordsFiltered = result.Count();
                    var take = Convert.ToInt32(filter.Conditions["#length"].ToString()) <= 0 ? recordsFiltered : Convert.ToInt32(filter.Conditions["#length"].ToString());
                    var data = result.Skip(Convert.ToInt32(filter.Conditions["#start"].ToString())).Take(take).ToList();

                    //result = result
                    //  .Skip(Convert.ToInt32(filter.Conditions["#start"].ToString()))
                    //  .Take(Convert.ToInt32(filter.Conditions["#length"].ToString()))
                    //  .ToList();
                    ////string sql = BuildDynamicSql(filter);

                    ////using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
                    ////using (var cmd = new SqlCommand(sql, conn))
                    ////{
                    ////    foreach (var kv in filter.Conditions)
                    ////        cmd.Parameters.AddWithValue("@" + kv.Key, kv.Value ?? DBNull.Value);

                    ////    var da = new SqlDataAdapter(cmd);
                    ////    da.Fill(dt);
                    ////}
                    ///

                    return Json(new
                    {
                        draw = Convert.ToInt32(filter.Conditions["#draw"]),  // DataTable 用 draw 控制刷新
                        recordsTotal = recordsTotal,
                        recordsFiltered = recordsFiltered,
                        data = data
                    }, JsonRequestBehavior.AllowGet);
                    // return Json(new { data = result }, JsonRequestBehavior.AllowGet);

                }
            }
            else 
            { 
                return Json(new {});
            }
        }

        private string BuildDynamicSql(DynamicFilter filter)
        {
            var whereClauses = new List<string>();

            foreach (var kv in filter.Conditions)
            {
                if (kv.Value is string str && str.Contains("%"))
                    whereClauses.Add($"{kv.Key} LIKE @{kv.Key}");
                else
                    whereClauses.Add($"{kv.Key} = @{kv.Key}");
            }

            string whereSql = whereClauses.Any() ? "WHERE " + string.Join(" AND ", whereClauses) : "";
            string sql = $"SELECT * FROM {filter.TableName} {whereSql}";
            return sql;
        }
    }
    public class EmployeeFilter
    {
        public string Department { get; set; }
        public string Keyword { get; set; }
        public bool IncludeInactive { get; set; }
    }
}
