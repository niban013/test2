﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class FrameGuardAttribute : ActionFilterAttribute
    {/// <summary>
     /// 允許的來源 (可設定 'self' 或特定網域)
     /// </summary>

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            var response = filterContext.HttpContext.Response;

            response.Headers["X-Frame-Options"] = "SAMEORIGIN";
            response.Headers["Content-Security-Policy"] = "frame-ancestors 'self'";

            // 自訂 Header（外部呼叫者可讀）
            response.Headers["X-Policy-Status"] = "blocked-if-framed";
            response.Headers["X-Blocked-Reason"] = "Frame-Ancestors Policy Violation";
            response.Headers["X-Allowed-Domains"] = "self";

            base.OnResultExecuted(filterContext);
        }

        public override void OnActionExecuting(ActionExecutingContext ctx)
        {
            var req = ctx.HttpContext.Request;
            var referer = req.UrlReferrer;

            // 若是外域→回 403 + JSON
            if (referer != null && referer.Host != req.Url.Host)
            {
                ctx.HttpContext.Response.StatusCode = 403;
                ctx.HttpContext.Response.Headers["X-Policy-Status"] = "blocked";
                ctx.HttpContext.Response.Headers["X-Blocked-Reason"] = "cross-domain iframe violation";
                ctx.Result = new JsonResult
                {
                    Data = new
                    {
                        message = "This site cannot be framed by external domains.",
                        status = "blocked",
                        allowed = "self"
                    },
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
        }
    }

}