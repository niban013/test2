﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class CsrfProtectAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var req = filterContext.HttpContext.Request;

            string csrfFromHeader = req.Headers["X-CSRF-TOKEN"];
            string csrfFromCookie = req.Cookies["CSRF-TOKEN"]?.Value;

            if (string.IsNullOrEmpty(csrfFromHeader) ||
                string.IsNullOrEmpty(csrfFromCookie) ||
                csrfFromHeader != csrfFromCookie)
            {
                filterContext.Result = new HttpStatusCodeResult(403, "CSRF failed");
                return;
            }

            base.OnActionExecuting(filterContext);
        }
    }
}
