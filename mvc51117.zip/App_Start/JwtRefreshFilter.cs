﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class JwtRefreshFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var ctx = filterContext.HttpContext;

            string jwt = ctx.Session["JWT"] as string;

            // 如果 Session 沒 token → 重新產
            if (string.IsNullOrEmpty(jwt))
            {
                string username = "test";// ctx.User.Identity.Name;
                jwt = JwtTokenHelper.GenerateToken(username);
                ctx.Session["JWT"] = jwt;
                return;
            }

            // 檢查 Expire
            DateTime? expire = JwtTokenHelper.GetExpireTime(jwt);
            if (expire == null)
                return;

            // 若剩 < 10 分鐘，自動刷新
            if (expire.Value < DateTime.UtcNow.AddMinutes(10))
            {
                string username = "test";// ctx.User.Identity.Name;
                string newJwt = JwtTokenHelper.GenerateToken(username);
                ctx.Session["JWT"] = newJwt;
            }
        }
    }

}