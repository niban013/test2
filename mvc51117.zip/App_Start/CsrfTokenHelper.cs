﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Web;

namespace mvc5
{
    public static class CsrfTokenHelper
    {
        public static string GenerateCsrfToken()
        {
            return Guid.NewGuid().ToString("N"); // 32 chars
        }
    }
}
