﻿using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //filters.Add(new CorsFilter()); 
            //filters.Add(new FrameGuardAttribute());
            filters.Add(new HandleErrorAttribute());
            //filters.Add(new JwtRefreshFilter());   // ← 自動刷新 Token
            filters.Add(new JwtAuthAttribute());
            filters.Add(new SSOAuthorizeAttribute()); // 全域授權攔截
        }
    }
}
