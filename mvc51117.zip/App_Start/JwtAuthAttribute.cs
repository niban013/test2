﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace mvc5
{
    public class JwtAuthAttribute : ActionFilterAttribute
    {
        private const string Secret = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456";
        private const string Issuer = "my-issuer";
        private const string Audience = "my-client";

        // AccessToken 剩下不到 5 分鐘就刷新
        private const int AccessTokenRefreshThresholdSeconds = 300;

        // AccessToken 過期時間（分鐘）
        private const int AccessTokenExpireMinutes = 30;

        // RefreshToken 過期時間（分鐘）
        private const int RefreshTokenExpireMinutes = 1440; // 1 天

        // Server 端暫存 RefreshToken（實務可用 DB）
        private static ConcurrentDictionary<string, RefreshTokenInfo> RefreshTokenStore = new ConcurrentDictionary<string, RefreshTokenInfo>();

        // Refresh Token 結構
        public class RefreshTokenInfo
        {
            public string Username { get; set; }
            public DateTime ExpireAt { get; set; }
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // AllowAnonymous 不驗證
            if (filterContext.ActionDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true) ||
                filterContext.ActionDescriptor.ControllerDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true))
            {
                return;
            }

            var request = filterContext.HttpContext.Request;
            var auth = request.Headers["Authorization"];
            var refreshToken = request.Headers["X-Refresh-Token"];

            var handler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(Secret);

            // 1️⃣ 先嘗試驗證 AccessToken
            if (!string.IsNullOrEmpty(auth) && auth.StartsWith("Bearer "))
            {
                var token = auth.Substring("Bearer ".Length);
                try
                {
                    handler.ValidateToken(token, new TokenValidationParameters
                    {
                        ValidIssuer = Issuer,
                        ValidAudience = Audience,
                        IssuerSigningKey = new SymmetricSecurityKey(key),
                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.Zero
                    }, out SecurityToken validatedToken);

                    var jwt = (JwtSecurityToken)validatedToken;
                    var identity = new GenericIdentity(jwt.Subject);
                    filterContext.HttpContext.User = new GenericPrincipal(identity, null);

                    filterContext.HttpContext.Items["JwtToken"] = jwt;
                    return;
                }
                catch(Exception ex)
                {
                    // AccessToken 過期或無效，繼續檢查 Refresh Token
                }
            }

            // 2️⃣ 嘗試使用 Refresh Token
            if (!string.IsNullOrEmpty(refreshToken) && RefreshTokenStore.TryGetValue(refreshToken, out var info))
            {
                if (info.ExpireAt > DateTime.UtcNow)
                {
                    // 有效 → 生成新 AccessToken
                    var claims = new[] { new System.Security.Claims.Claim("sub", info.Username) };
                    var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

                    var newJwt = new JwtSecurityToken(
                        issuer: Issuer,
                        audience: Audience,
                        claims: claims,
                        expires: DateTime.UtcNow.AddMinutes(AccessTokenExpireMinutes),
                        signingCredentials: creds
                    );

                    var newToken = handler.WriteToken(newJwt);

                    // 設定 User.Identity
                    filterContext.HttpContext.User = new GenericPrincipal(new GenericIdentity(info.Username), null);

                    // 回傳新 AccessToken
                    filterContext.HttpContext.Response.AddHeader("X-Refreshed-Token", newToken);

                    // 放入 HttpContext.Items 方便 OnActionExecuted 使用
                    filterContext.HttpContext.Items["JwtToken"] = newJwt;

                    return;
                }
                else
                {
                    // RefreshToken 過期 → 移除
                    RefreshTokenStore.TryRemove(refreshToken, out _);
                }
            }

            // 3️⃣ 都沒有有效 Token → 401
            filterContext.Result = new HttpUnauthorizedResult();
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var jwt = filterContext.HttpContext.Items["JwtToken"] as JwtSecurityToken;
            if (jwt == null) return;

            var response = filterContext.HttpContext.Response;
            var now = DateTime.UtcNow;
            var expires = jwt.ValidTo.ToUniversalTime();

            // AccessToken 剩餘時間少於 threshold → 自動刷新
            if ((expires - now).TotalSeconds <= AccessTokenRefreshThresholdSeconds)
            {
                var key = Encoding.UTF8.GetBytes(Secret);
                var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

                var newJwt = new JwtSecurityToken(
                    issuer: Issuer,
                    audience: Audience,
                    claims: jwt.Claims,
                    expires: DateTime.UtcNow.AddMinutes(AccessTokenExpireMinutes),
                    signingCredentials: creds
                );

                var newToken = new JwtSecurityTokenHandler().WriteToken(newJwt);

                // 回傳新 AccessToken
                response.AddHeader("X-Refreshed-Token", newToken);

                // 同時產生新的 RefreshToken
                var newRefreshToken = Guid.NewGuid().ToString("N");
                RefreshTokenStore[newRefreshToken] = new RefreshTokenInfo
                {
                    Username = jwt.Subject,
                    ExpireAt = DateTime.UtcNow.AddMinutes(RefreshTokenExpireMinutes)
                };

                response.AddHeader("X-Refresh-Token", newRefreshToken);
            }
        }
    }
}
