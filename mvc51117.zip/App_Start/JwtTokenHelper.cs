﻿using DocumentFormat.OpenXml.Bibliography;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Web;

namespace mvc5
{
    public static class JwtTokenHelper
    {
        private static readonly string secret = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456";
        private const string Issuer = "my-issuer";
        private const string Audience = "my-client";
        // Server 端暫存 RefreshToken
        private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, RefreshTokenInfo> RefreshTokenStore
            = new System.Collections.Concurrent.ConcurrentDictionary<string, RefreshTokenInfo>();

        public class RefreshTokenInfo
        {
            public string Username { get; set; }
            public DateTime ExpireAt { get; set; }
        }

        // -------------------- AccessToken --------------------
        public static string GenerateToken(string username, int expireMinutes = 60)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(secret);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]{
                      new Claim(JwtRegisteredClaimNames.Sub, username),   // ← ★ 加這行
                    new Claim(ClaimTypes.Name, username)
                }),

                Expires = DateTime.UtcNow.AddMinutes(expireMinutes),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature
                ),
                Issuer = Issuer,
                Audience = Audience,
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        // -------------------- RefreshToken --------------------
        public static string GenerateRefreshToken(string username, int expireMinutes = 1440)
        {
            // 隨機 GUID 當作 RefreshToken
            var refreshToken = Guid.NewGuid().ToString("N");

            // 儲存到 Server 端
            RefreshTokenStore[refreshToken] = new RefreshTokenInfo
            {
                Username = username,
                ExpireAt = DateTime.UtcNow.AddMinutes(expireMinutes)
            };

            return refreshToken;
        }

        public static bool ValidateRefreshToken(string refreshToken, out string username)
        {
            username = null;
            if (string.IsNullOrEmpty(refreshToken)) return false;

            if (RefreshTokenStore.TryGetValue(refreshToken, out var info))
            {
                if (info.ExpireAt > DateTime.UtcNow)
                {
                    username = info.Username;
                    return true;
                }
                else
                {
                    // 過期自動移除
                    RefreshTokenStore.TryRemove(refreshToken, out _);
                }
            }

            return false;
        }

        // -------------------- 取得 AccessToken 過期時間 --------------------
        public static DateTime? GetExpireTime(string jwt)
        {
            var token = new JwtSecurityTokenHandler().ReadJwtToken(jwt);
            return token.ValidTo;
        }
    }
}
