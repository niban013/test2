﻿using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

public class CorsFilter : ActionFilterAttribute
{
    
    //{ "http://localhost:8000", "https://yourdomain.com" };
    private readonly string[] allowedOrigins;

    public CorsFilter()
    {
        // 從 Web.config 讀白名單
        var origins = ConfigurationManager.AppSettings["CorsAllowedOrigins"];
        allowedOrigins = !string.IsNullOrEmpty(origins)
            ? origins.Split(',').Select(o => o.Trim()).ToArray()
            : new string[0];
    }
    public override void OnActionExecuting(ActionExecutingContext filterContext)
    {
        var request = filterContext.HttpContext.Request;
        var response = filterContext.HttpContext.Response;

        // 如果是 Preflight (OPTIONS)
        if (request.HttpMethod == "OPTIONS")
        {
            ApplyCorsHeaders(request, response);
            filterContext.Result = new EmptyResult();
            return;
        }

        base.OnActionExecuting(filterContext);
    }

    public override void OnActionExecuted(ActionExecutedContext filterContext)
    {
        var request = filterContext.HttpContext.Request;
        var response = filterContext.HttpContext.Response;

        ApplyCorsHeaders(request, response);
        base.OnActionExecuted(filterContext);
    }

    private void ApplyCorsHeaders(HttpRequestBase request, HttpResponseBase response)
    {
        string origin = request.Headers["Origin"];

        if (string.IsNullOrEmpty(origin))
            return;

        if (!allowedOrigins.Contains(origin))
            return;

        // Methods
        string allowedMethods = ConfigurationManager.AppSettings["CorsAllowedMethods"] ?? "GET, POST, OPTIONS";

        // Headers
        string allowedHeaders = ConfigurationManager.AppSettings["CorsAllowedHeaders"] ?? "Content-Type, Authorization, X-Requested-With";

        // Credentials
        string allowCredentials = ConfigurationManager.AppSettings["CorsAllowCredentials"] ?? "true";

        // 設定 CORS header
        response.Headers.Set("Access-Control-Allow-Origin", origin);
        response.Headers.Set("Access-Control-Allow-Credentials", allowCredentials);
        response.Headers.Set("Access-Control-Allow-Methods", allowedMethods);
        response.Headers.Set("Access-Control-Allow-Headers", allowedHeaders);
         
    }
}
