﻿using log4net.Appender;
using log4net.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace mvc5.Logging
{
    public class TestAppender : log4net.Appender.RollingFileAppender
    {
        public TestAppender()
        {
            // 預設暫存檔，避免建構子失敗
            var logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            if (!Directory.Exists(logDir)) Directory.CreateDirectory(logDir);

            this.File = Path.Combine(logDir, "temp.log");
            this.AppendToFile = true;
            this.RollingStyle = RollingFileAppender.RollingMode.Date;
            this.DatePattern = "yyyyMMdd'.log'";
            this.Layout = new log4net.Layout.PatternLayout("%date %-5level %logger - %message%newline");
            base.ActivateOptions();
        }
        protected override void Append(LoggingEvent loggingEvent)
        {
            System.Diagnostics.Debug.WriteLine(loggingEvent.RenderedMessage);
        }
    }
    public class UserRollingFileAppenderDebug : RollingFileAppender
    {
        public UserRollingFileAppenderDebug() 
        {
            // 預設暫存檔，避免建構子失敗
            var logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            if (!Directory.Exists(logDir)) Directory.CreateDirectory(logDir);

            this.File = Path.Combine(logDir, "temp.log");
            this.AppendToFile = true;
            this.RollingStyle = RollingFileAppender.RollingMode.Date;
            this.DatePattern = "yyyyMMdd'.log'";
            this.Layout = new log4net.Layout.PatternLayout("%date %-5level %logger - %message%newline");
            base.ActivateOptions();
        }
        protected override void Append(LoggingEvent loggingEvent)
        {
            try
            {
                // 1️⃣ 從 HttpContext 取得使用者
                string userName = "Anonymous";
                var context = HttpContext.Current;
                if (context?.User?.Identity?.IsAuthenticated == true)
                    userName = context.User.Identity.Name;

                // 2️⃣ 從 ThreadContext 取得使用者 (可以對照)
                var threadUser = loggingEvent.LookupProperty("userName") as string;

                // 避免非法檔名字元
                userName = Regex.Replace(userName, @"[\\/:*?""<>|]", "_");

                // 3️⃣ 設定 Logs 資料夾
                string logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
                if (!Directory.Exists(logDir))
                    Directory.CreateDirectory(logDir);

                // 4️⃣ 動態檔名
                string filePath = Path.Combine(logDir, $"{userName}_{DateTime.Now:yyyyMMdd}.log");

                // 5️⃣ 只在檔名變化時 ActivateOptions
                if (!string.Equals(this.File, filePath, StringComparison.InvariantCultureIgnoreCase))
                {
                    this.File = filePath;
                    base.ActivateOptions();
                }

                // 6️⃣ Debug 輸出
                System.Diagnostics.Debug.WriteLine($"[UserRollingFileAppenderDebug] Append called");
                System.Diagnostics.Debug.WriteLine($"   HttpContext userName: {userName}");
                System.Diagnostics.Debug.WriteLine($"   ThreadContext userName: {threadUser}");
                System.Diagnostics.Debug.WriteLine($"   File path: {this.File}");

                // 7️⃣ 寫入 log
                base.Append(loggingEvent);
            }
            catch (Exception ex)
            {
                // 防止 log 寫入異常造成應用程式錯誤
                System.Diagnostics.Debug.WriteLine($"[UserRollingFileAppenderDebug] Exception: {ex}");
            }
        }
    }
    public class UserRollingFileAppender : RollingFileAppender
    {
        protected override void OnClose()
        {
            System.Diagnostics.Debug.WriteLine("Appender OnClose called");
            base.OnClose();
        }
        protected override void Append(LoggingEvent loggingEvent)
        {
            string userName = "Anonymous";

            var context = System.Web.HttpContext.Current;
            if (context?.User?.Identity?.IsAuthenticated == true)
                userName = context.User.Identity.Name;

            userName = Regex.Replace(userName, @"[\\/:*?""<>|]", "_");

            string logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            string filePath = Path.Combine(logDir, $"{userName}_{DateTime.Now:yyyyMMdd}.log");
            if (!string.Equals(this.File, filePath, StringComparison.InvariantCultureIgnoreCase))
            {
                this.File = filePath;
                base.ActivateOptions();
            }

            base.Append(loggingEvent);
        }
    }
}