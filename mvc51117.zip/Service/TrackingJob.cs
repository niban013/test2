﻿using Quartz;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace mvc5.Service
{
    public abstract class TrackingJob : IJob
    {
        // 記錄每個 Job 的執行資訊
        public static ConcurrentDictionary<string, JobStatus> JobTracker = new ConcurrentDictionary<string, JobStatus>();

        public async Task Execute(IJobExecutionContext context)
        {
            string jobName = context.JobDetail.Key.Name;

            // 初始化 JobStatus
            JobTracker.AddOrUpdate(jobName,
                new JobStatus { LastRun = DateTime.UtcNow, RunCount = 1, IsRunning = true },
                (key, old) =>
                {
                    old.LastRun = DateTime.UtcNow;
                    old.RunCount++;
                    old.IsRunning = true;
                    old.LastError = null;
                    return old;
                });

            try
            {
                await Run(context);
                // 完成後標記為 idle
                JobTracker[jobName].IsRunning = false;
            }
            catch (Exception ex)
            {
                JobTracker[jobName].IsRunning = false;
                JobTracker[jobName].LastError = ex.Message;
                throw;
            }
        }

        // 實作 Job 的業務邏輯
        public abstract Task Run(IJobExecutionContext context);
    }

    public class JobStatus
    {
        public int RunCount { get; set; }
        public DateTime LastRun { get; set; }
        public bool IsRunning { get; set; }
        public string LastError { get; set; }
    }
}