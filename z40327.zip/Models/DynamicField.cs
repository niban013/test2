 
namespace vsnet8.Models
{
    public enum FieldType
    {
        Label,
        Textbox,
        Dropdown,
        Select2,
        Numeric,
        Date,
        Textarea,
        File
    }

    public class DynamicField
    {
        public string Name { get; set; }

        public string Label { get; set; }

        public bool Must { get; set; }

        public FieldType Type { get; set; }
        public string Min { get; set; } // �ϥ� string �H�ۮe�Ʀr(0)�P���(2024-01-01)
        public string Max { get; set; }
        public string? DefaultValue { get; set; }
        public string Pattern { get; set; } = ""; // string / number /yyyy/mm/dd
        public string? Placeholder { get; set; }

        public bool Readonly { get; set; }

        public bool Hidden { get; set; }

        public int Width { get; set; } = 6; // bootstrap col
        public int Order { get; set; }   // ��ܶ���
        public List<SelectItem>? Options { get; set; }
    }

    public class SelectItem
    {
        public string Value { get; set; }
        public string Color { get; set; }  // �s�W�C��
        public string Text { get; set; }
    }

    

    
}
