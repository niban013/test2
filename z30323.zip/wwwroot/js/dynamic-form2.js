﻿var DynamicForm = (function () {

    // =========================
    // ⭐ PageVM（內建）
    // =========================
    class PageVM {
        constructor() {
            this.forms = [];

            // ⭐ 以 tabKey 分隔 scope
            this._scopedData = {};      // { tabKey: { fieldName: value } }
            this._watchers = {};        // { tabKey: { fieldName: [fn,...] } }
            this._computed = {};        // { tabKey: { fieldName: fn } }
            this._computedCache = {};   // { tabKey: { fieldName: value } }
            this._dirty = {};           // { tabKey: Set }
        }

        register(form) {
            this.forms.push(form);
            const key = form.key;

            // ⭐ 初始化 tab scope
            if (!this._scopedData[key]) this._scopedData[key] = {};
            if (!this._dirty[key]) this._dirty[key] = new Set();
            if (!this._watchers[key]) this._watchers[key] = {};
            if (!this._computed[key]) this._computed[key] = {};
            if (!this._computedCache[key]) this._computedCache[key] = {};

            // ⭐ 初始化欄位值
            Object.entries(form.fieldCache).forEach(([k, v]) => {
                if (this._scopedData[key][k] === undefined) {
                    this._scopedData[key][k] = v;
                }
            });

            // ⭐ 建立 tab 專屬 proxy
            const proxy = new Proxy(this._scopedData[key], {
                set: (target, name, value) => {
                    const old = target[name];
                    if (old === value) return true;

                    target[name] = value;

                    // ⭐ dirty
                    this._dirty[key].add(name);

                    // ⭐ 更新當前 form
                    form.updateField(name, value, true);

                    // ⭐ watch
                    if (this._watchers[key][name]) {
                        this._watchers[key][name].forEach(fn => fn(value, old));
                    }

                    // ⭐ computed cache 清掉
                    this._computedCache[key] = {};

                    return true;
                },
                get: (target, name) => {
                    if (this._computed[key][name]) {
                        if (this._computedCache[key][name] === undefined) {
                            this._computedCache[key][name] = this._computed[key][name].call(proxy);
                        }
                        return this._computedCache[key][name];
                    }
                    return target[name];
                }
            });

            // ⭐ 原本 form.proxy
            form.proxy = proxy;

            // ⭐ 直接掛到 VM 物件上
            this[key] = proxy;
        }

        // ========= API =========
        $watch(tabKey, name, fn) {
            if (!this._watchers[tabKey][name]) this._watchers[tabKey][name] = [];
            this._watchers[tabKey][name].push(fn);
        }

        $computed(tabKey, name, fn) {
            this._computed[tabKey][name] = fn;
        }

        $dirty(tabKey) {
            const result = {};
            this._dirty[tabKey].forEach(k => result[k] = this._scopedData[tabKey][k]);
            return result;
        }

        $resetDirty(tabKey) {
            this._dirty[tabKey].clear();
        }

        cache() {
            this.forms.forEach(f => f.cache());
        }

        restore() {
            this.forms.forEach(f => f.restore());
        }

        async validate() {
            const results = await Promise.all(this.forms.map(f => f.validateAll()));
            return results.every(r => r);
        }

        showCache() {
            this.forms.forEach(f => {
                console.log(`Cache for ${f.key}:`, f.fieldCache);
            });
        }
    }

    // =========================
    // ⭐ Form Instance
    // =========================
    class DynamicFormInstance {
        constructor(container, vm) {
            this.container = $(container);
            this.inputs = this.container.find(".dynamicInput");
            this.vm = vm;

            this.key = this.container.data("df"); // ⭐ 每個 tab 的 key
            this.fieldCache = {};
            this.asyncCache = {};
            this.asyncTokens = {};
            this.data = {};

            this.proxyData = new Proxy(this.data, {
                set: (target, key, value) => {
                    target[key] = value;
                    this.updateField(key, value, false);
                    return true;
                }
            });

            this.init();

            // ⭐ 自動註冊到 VM
            this.vm.register(this);
        }

        init() {
            this.inputs.each((_, el) => {
                const $el = $(el);
                const name = $el.attr("name");

                if (!$el.parent().hasClass("input-with-status")) {
                    $el.wrap('<div class="input-with-status"></div>');
                }

                const def = $el.data("default") || "";
                if (!$el.val() && def) $el.val(def);

                // ⭐ tab 專屬 vm
                (this.vm._scopedData[this.key] ||= {})[name] = $el.val() || "";
                this.proxyData[name] = $el.val() || "";
                this.fieldCache[name] = $el.val() || "";

                if ($el.hasClass("select2")) this.initSelect2($el);

                this.clearStatusIcon($el);
            });

            this.bindEvents();
        }

        initSelect2($el) {
            $el.select2({
                width: '100%',
                templateResult: item =>
                    item.id
                        ? $(`<div style="background:${$(item.element).data("color") || ''};padding:4px 6px;">${item.text}</div>`)
                        : item.text,
                templateSelection: item => item.text
            }).on("select2:select select2:unselect change", () => {
                this.updateSelect2Background($el);
                const name = $el.attr("name");
                this.proxyData[name] = $el.val();
                this.validateField($el);
            });

            this.updateSelect2Background($el);
        }

        updateSelect2Background($el) {
            const color = $el.find("option:selected").data("color") || "";
            $el.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }

        updateField(name, value, validate = true) {
            const $el = this.inputs.filter(`[name="${name}"]`);
            if (!$el.length) return;

            // ⭐ 避免無限 loop
            if ($el.val() == value) return;

            if ($el.hasClass("select2")) {
                $el.val(value).trigger("change.select2");
            } else {
                $el.val(value);
            }

            if (validate) this.validateField($el);

            // ⭐ 更新本地 fieldCache
            this.fieldCache[name] = value;

            // ⭐ 更新 proxyData
            this.proxyData[name] = value;

            // ⭐ 同步到 tab 專屬 VM scope
            if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};
            this.vm._scopedData[this.key][name] = value;
        }

        setStatusIcon($el, status) {
            const $w = $el.parent(".input-with-status");
            this.clearStatusIcon($el);

            const val = $el.val()?.trim() || "";
            if ($el.data("must") && val === "") return;

            const icons = {
                success: '<i class="bi bi-check-circle text-success"></i>',
                error: '<i class="bi bi-x-circle text-danger"></i>',
                processing: '<i class="bi bi-arrow-repeat rotate text-primary"></i>'
            };

            if (icons[status]) {
                $w.append(`<span class="status-icon">${icons[status]}</span>`).addClass("has-icon");
            }
        }

        clearStatusIcon($el) {
            $el.parent(".input-with-status").find(".status-icon").remove().end().removeClass("has-icon");
        }

        setError($el, msg) {
            $el.addClass("is-invalid").css("border", "1px solid red").attr("title", msg || "");
            $el.next(".select2-container").find(".select2-selection").css("border", "1px solid red");
        }

        clearError($el) {
            $el.removeClass("is-invalid").css("border", "").attr("title", "");
            $el.next(".select2-container").find(".select2-selection").css("border", "");
        }

        async validateField(el) {
            const $el = $(el);
            const val = $el.val()?.trim() || "";
            const must = $el.data("must");
            const name = $el.attr("name");

            this.clearError($el);
            this.clearStatusIcon($el);

            if (!must && val === "") return true;
            if (must && val === "") { this.setError($el, "必填"); return false; }

            let isValid = true;
            const pattern = $el.data("pattern");
            const minlength = $el.data("minlength");
            const maxlength = $el.data("maxlength");
            const min = $el.attr("min");
            const max = $el.attr("max");
            const conditional = $el.data("conditional");
            const cross = $el.data("cross");
            const asyncUrl = $el.data("async");

            if (pattern && val && !(new RegExp(pattern)).test(val)) {
                this.setError($el, "格式錯誤");
                isValid = false;
            }
            if (minlength && val.length < minlength) { this.setError($el, `至少${minlength}字`); isValid = false; }
            if (maxlength && val.length > maxlength) { this.setError($el, `最多${maxlength}字`); isValid = false; }
            if (min && val && parseFloat(val) < parseFloat(min)) { this.setError($el, `不可小於${min}`); isValid = false; }
            if (max && val && parseFloat(val) > parseFloat(max)) { this.setError($el, `不可大於${max}`); isValid = false; }

            if (conditional) { let cond = JSON.parse(conditional); if ($(cond.selector).val() && val === "") { this.setError($el, "條件必填"); isValid = false; } }
            if (cross) { let c = JSON.parse(cross); let otherVal = $(c.selector).val(); if (c.op === ">" && val && otherVal && parseFloat(val) <= parseFloat(otherVal)) { this.setError($el, `必須大於${c.selector}`); isValid = false; } }

             
            if (asyncUrl && val) {
                if (this.asyncCache[val] !== undefined) {
                    this.setStatusIcon($el, this.asyncCache[val] ? 'success' : 'error');
                    return this.asyncCache[val];
                }
                if (this.asyncTokens[$el]) this.asyncTokens[$el].abort();
                try {
                    this.setStatusIcon($el, 'processing');
                    const resp = await $.ajax({ url: asyncUrl, data: { value: val } });
                    if ($el.val()?.trim() !== val) return false;
                    this.asyncCache[val] = resp.valid;
                    if (!resp.valid) {
                        this.setError($el, resp.message || "驗證失敗");
                        this.setStatusIcon($el, 'error');
                    }
                    else {
                        this.clearError($el);
                        this.setStatusIcon($el, 'success');
                    } 
                    return resp.valid;
                } catch {
                    this.asyncCache[val] = false;
                    this.setError($el, "異步驗證失敗");
                    this.setStatusIcon($el, 'error');
                    return false;
                } finally { this.asyncTokens[$el] = null; }
            }

            if (val !== "") this.setStatusIcon($el, isValid ? 'success' : 'error');

            this.fieldCache[name] = val;
            this.proxyData[name] = val;

            return isValid;
        }

        async validateAll() {
            const results = await Promise.all(
                this.inputs.map((_, el) => this.validateField(el)).get()
            );
            return results.every(r => r);
        }

        cache() {
            this.inputs.each((_, el) => {
                const $el = $(el);
                this.fieldCache[$el.attr("name")] = $el.val();
            });
        }

        restore() {
            Object.entries(this.fieldCache).forEach(([k, v]) => {
                this.proxyData[k] = v;
            });
        }

        bindEvents() {
            const debounced = this.debounce(e => this.validateField(e.currentTarget), 500);
            this.container.on("input", ".dynamicInput", e => {
                const $el = $(e.currentTarget);
                if ($el.val()?.trim() !== "") this.setStatusIcon($el, 'processing');

                // ⭐ 同步到 tab 專屬 VM scope
                if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};
                this.vm._scopedData[this.key][$el.attr("name")] = $el.val();

                // ⭐ 同步到 proxyData & fieldCache
                const name = $el.attr("name");
                this.proxyData[name] = $el.val();
                this.fieldCache[name] = $el.val();
            });
            this.container.on("blur change", ".dynamicInput", debounced);
            this.container.on("change", ".dropdownColor", (e) => {
                let $el = $(e.currentTarget);
                let color = $el.find("option:selected").data("color");
                $el.css("background-color", color);
            });
        }

        debounce(fn, delay = 500) {
            let timer;
            return function (...args) { clearTimeout(timer); timer = setTimeout(() => fn.apply(this, args), delay); };
        }
    }

    // =========================
    // ⭐ 初始化 + VM 建立
    // =========================
    function initAll() {
        const vm = new PageVM();
        window.vm = vm;

        $("[data-df]").each(function () {
            const $el = $(this);
            if ($el.data("df-initialized")) return;

            const form = new DynamicFormInstance(this, vm);
            form.key = $el.data("df");

            $el.data("df-initialized", true);
            $el.data("form", form);
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initAll);
    } else {
        initAll();
    }

    return {};
})();