﻿var builder = WebApplication.CreateBuilder(args);
builder.Services.AddAutoMapper(config => { }, typeof(Program).Assembly);
// Add services to the container. 
builder.Services.AddControllersWithViews(options =>
{
    // ⭐ 將全域過濾器加入集合
    //options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
}).AddNewtonsoftJson(options =>
{
    // 這行很關鍵：確保 JSON 輸出名稱與 [JsonProperty] 定義完全一致
    // 而不會被自動轉成小駝峰 (CamelCase)
    options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Supplier}/{action=Index}/{id?}");

app.Run();
