﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using newauo.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;
using System.Data;
using System.Linq.Expressions;
using System.Reflection;

namespace newauo.Helper
{

    public class ColumnList<T> : System.Collections.IEnumerable
    {
        public List<ColumnSchema> AllColumns = new();

        // 支援 Lambda: 會自動對應到 { x => x.Prop }
        public void Add(System.Linq.Expressions.Expression<Func<T, object>> expr)
        {
            string pName = ExtendTool.GetPropertyName(expr);
            string jName = ExtendTool.GetJsonName(typeof(T), pName);
            AllColumns.Add(new ColumnSchema(jName, pName));
        }

        // 支援字串: 會自動對應到 { "City" }
        public void Add(string propertyName)
        {
            string jName = ExtendTool.GetJsonName(typeof(T), propertyName);
            AllColumns.Add(new ColumnSchema(jName, propertyName));
        }

        // 必須實作 IEnumerable 才能使用初始化器語法糖
        public System.Collections.IEnumerator GetEnumerator() => AllColumns.GetEnumerator();
    }

    public static class ExtendTool
    {
        // 快取緩存：Key 是 "類別全名.屬性名"，Value 是 "Json ID"
        private static readonly ConcurrentDictionary<string, string> _nameCache = new();

        //public static string GetPropertyName(LambdaExpression expr)
        //{
        //    MemberExpression member = expr.Body as MemberExpression;
        //    if (member == null && expr.Body is UnaryExpression unary)
        //        member = unary.Operand as MemberExpression;

        //    return member?.Member.Name ?? throw new ArgumentException("無效的表達式");
        //}


        /// <summary>
        /// 方法 1：將 Lambda 表達式 (x => x.MakerCode) 轉為字串 "MakerCode"
        /// </summary>
        public static string GetPropertyName(LambdaExpression propertySelector)
        {
            MemberExpression member = propertySelector.Body as MemberExpression;

            // 處理 Boxing 情況 (例如 int 轉 object 會產生 UnaryExpression)
            if (member == null && propertySelector.Body is UnaryExpression unary)
            {
                member = unary.Operand as MemberExpression;
            }

            if (member == null)
                throw new ArgumentException($"表達式 {propertySelector} 不是有效的屬性存取。");

            return member.Member.Name;
        }

        /// <summary>
        /// 方法 2：取得屬性上的 [JsonProperty] 名稱，若無則回傳原名 (泛型版)
        /// </summary>
        public static string GetJsonName<T>(string propertyName)
        {
            return GetJsonName(typeof(T), propertyName);
        }

        /// <summary>
        /// 方法 2 的實作：支援 Type 物件傳入
        /// </summary>
        public static string GetJsonName(Type type, string propertyName)
        {
            string cacheKey = $"{type.FullName}.{propertyName}";

            return _nameCache.GetOrAdd(cacheKey, _ =>
            {
                PropertyInfo prop = type.GetProperty(propertyName);
                if (prop == null) return propertyName;

                // 取得 Newtonsoft.Json 的 JsonPropertyAttribute
                var attr = prop.GetCustomAttribute<JsonPropertyAttribute>();

                // 如果有定義 PropertyName 則回傳，否則回傳 C# 屬性原名
                return attr?.PropertyName ?? propertyName;
            });
        }


        public static List<T> ToList<T>(this DataTable dt) where T : new()
        {
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var obj = new T();
                foreach (var prop in properties)
                {
                    // 比對欄位名稱是否存在且有值
                    if (dt.Columns.Contains(prop.Name) && row[prop.Name] != DBNull.Value)
                    {
                        prop.SetValue(obj, Convert.ChangeType(row[prop.Name], prop.PropertyType));
                    }
                }
                return obj;
            }).ToList();
        }

        /// <summary>
        /// 自動根據目前的 Partial View 檔名產生 data-section 屬性字串
        /// </summary>
        public static IHtmlContent GetPartialSection(this IHtmlHelper htmlHelper, object suffix = null)
        {
            var viewPath = htmlHelper.ViewContext.ExecutingFilePath;
            if (string.IsNullOrEmpty(viewPath)) return HtmlString.Empty;

            string fileNameOnly = Path.GetFileNameWithoutExtension(viewPath);

            // 如果有傳入後綴（如 ID 或 Index），就接在檔名後面
            string finalSectionId = suffix != null
                ? $"{fileNameOnly}_{suffix}"
                : fileNameOnly;

            return new HtmlString($"data-section=\"{finalSectionId}\"");
        }


        public static string GetString(this Dictionary<string, object>? dict, string key)
        {
            if (dict == null) return "";
            return dict.ContainsKey(key) ? dict[key]?.ToString() : null;
        }

        public static List<string> GetList(this Dictionary<string, object> dict, string key)
        {
            if (dict == null) return new List<string>();

            if (!dict.ContainsKey(key)) return new List<string>();

            var arr = dict[key] as JArray;
            return arr?.ToObject<List<string>>();
        }

        public static T GetObject<T>(this Dictionary<string, object> dict, string key)
        {
            if (!dict.ContainsKey(key)) return default;

            var obj = dict[key] as JObject;
            return obj != null ? obj.ToObject<T>() : default;
        }


        public static T ToModel<T>(this IDictionary<string, string> dict)
        {
            return JObject.FromObject(dict).ToObject<T>();
        }
    }
}
