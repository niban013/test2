﻿using newauo.Models;
using System.Reflection;
using static newauo.Helper.AutoMapper;

namespace newauo.Helper
{
    public class DynamicFieldService
    {
        public void FillSchemaWithModel<T>(Dictionary<string, List<BaseDynamicField>> schema, T model)
        {
            if (model == null) return;

            // 1. 獲取 Model 的所有屬性資訊，並建立一個快速查找表
            // Key 是 DbColumn 或屬性名，Value 是該屬性的當前數值
            var modelValues = typeof(T).GetProperties()
                .Select(p => new
                {
                    Key = p.GetCustomAttribute<DynamicFieldAttribute>()?.DbColumn ?? p.Name,
                    Value = p.GetValue(model)?.ToString()
                })
                .ToDictionary(x => x.Key, x => x.Value, StringComparer.OrdinalIgnoreCase);

            // 2. 遍歷 schema，把值塞進對應的欄位
            foreach (var section in schema.Values)
            {
                foreach (var field in section)
                {
                    // 假設設定表裡的 field.FieldName 存的是 DB 欄位名 (如 USER_NM)
                    if (modelValues.TryGetValue(field.ColId, out var val))
                    {
                        field.ColValue = val;
                    }
                }
            }
        }
    }
}
