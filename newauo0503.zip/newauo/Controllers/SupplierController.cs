﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using newauo.Models;
using Newtonsoft.Json;
using static newauo.Models.Wizard;
namespace newauo.Controllers
{
    public class StepPayload
    {
        public string Type { get; set; }

        public Dictionary<string, object>? Data { get; set; }
    }
    public class StepRequest
    {
        public int StepIndex { get; set; }
        public Dictionary<string, StepPayload>? FlowData { get; set; }
    }
    public class SupplierController : Controller
    {
        private static readonly List<WizardStepOption> Steps = new()
        {
            new WizardStepOption { StepIndex = 1, Title = "Apply New Supplier", PartialView = "Supplier/_StepApplyNewSupplier", Locked = false },
            new WizardStepOption { StepIndex = 2, Title = "Supplier Information", PartialView = "Supplier/_StepSupplierInformation" },
            new WizardStepOption { StepIndex = 3, Title = "File List", PartialView = "Supplier/_StepFileList" }
        };

        //private readonly DynamicFieldService _dynamicFieldService;
        private readonly IMapper _mapper;
        public SupplierController(IMapper mapper)//, DynamicFieldService dynamicFieldService)
        {

            // _dynamicFieldService = dynamicFieldService;
            _mapper = mapper;
        }


        public async Task<IActionResult> Index()
        {
            // byte[] fileBytes = System.IO.File.ReadAllBytes(@"D:\Web\flowerstatus.png");
            //  var d = await _oneSupplierFLMService.UploadFileToFLM(fileBytes, "aaa.pdf", "onesupplier001", "Echo.Lee");
            //var d= await _oneSupplierFLMService.GetFileAsync("283b009b-1ed6-47b7-ad61-0fbaea74f0ce", "aaa.pdf", "Echo.Lee");

            //var d = await _oneSupplierFLMService.CheckFileIDByFileId("283b009b-1ed6-47b7-ad61-0fbaea74f0ce");

            return View(Steps);
        }
        //[HttpPost]
        //public IActionResult Step([FromBody] StepRequest req)
        //{
        //    if (req == null)
        //        return BadRequest("body is null");

        //    var stepIndex = req.stepIndex;
        //    var stepKey = "step" + stepIndex;

        //    string? decision = null;

        //    // 1️⃣ flowData 是 string
        //    if (!string.IsNullOrEmpty(req.flowData))
        //    {
        //        using var doc = JsonDocument.Parse(req.flowData);

        //        var root = doc.RootElement;

        //        if (root.ValueKind == JsonValueKind.Object &&
        //            root.TryGetProperty(stepKey, out var step))
        //        {
        //            decision = step.ToString();
        //        }
        //    }
        //    Console.WriteLine("🔥 HIT Step2");
        //    return Ok();
        //}

        [HttpPost]
        public async Task<IActionResult> Step([FromBody] StepRequest req)
        {
            var stepIndex = req.StepIndex;

            if (stepIndex < 1 || stepIndex > Steps.Count)
                return BadRequest("Invalid step index");


            var stepKey = "step" + req.StepIndex;
            var step = req.FlowData?[stepKey];

            var type = step?.Type;
            var decision = step?.Data;



            var stepInfo = Steps[stepIndex - 1];

            object model = stepIndex switch
            {
                1 => await GenerateStep(stepIndex),
                2 => await GenerateStep(stepIndex, type, decision),
                3 => await GenerateStep(stepIndex, type),
                _ => null
            };
            ViewBag.Title = stepInfo.Title;
            return PartialView(stepInfo.PartialView, model);
        }

        async Task<IStepViewModel> GenerateStep(int stepIndex, string type = "", Dictionary<string, object>? SendData = null)
        {

            IStepViewModel? model = null;
            Dictionary<string, object>? redirectData = new Dictionary<string, object>();
            //if (!string.IsNullOrEmpty(type))
            //{
            //    redirectData = JsonConvert.DeserializeObject<Dictionary<string, object>>(type);
            //}
            switch (stepIndex)
            {
                case 1:
                    Dictionary<string, List<TableSchema>> dic = new Dictionary<string, List<TableSchema>>();
                    var maker = new List<TableSchema>
                    {
                         new()
                        {
                            TableId = "tbMaker1",
                            AjaxUrl = "/Supplier/GetMakerData",
                            FetchMode = FetchMode.All,
                            Message="* Existed in the company",
                            //AjaxParams  = new
                            //{
                            //    makername = "MITSUI",
                            //    companyid = "2"
                            //},
                    
                            Features = new TableFeatures
                            {
                                Checkbox = false,
                                Export = true,
                                RowButtons = true,
                                ColumnToggle = true,
                                RowSelect = true,
                                SelectAll = true,
                                VirtualScroll = true,
                                ColumnFilter = false,   // 可選，每欄都有 filter
                                StickyHeader = true    // 可選，表頭固定
                            },

                            Config = new TableConfig
                            {
                                PageLength = 2,
                                VirtualScrollHeight = "500px",
                                Searching = false,
                                Ordering = false,
                                Paging = true,
                                LengthChange = false,
                                StateSave = true
                            },

                            //ToolbarButtons =
                            //{
                            //    new("Add", "add"),
                            //    new("Delete Selected", "deleteSelected", "btn btn-danger"),
                            //    new("Reload", "reload", "btn btn-secondary")
                            //},

                            Columns =  TableSchema.Create<vmMakerDetail>(new()
                            {
                                x => x.MakerCode,       // 自動轉為 "maker_code"
                                x => x.MakerLocalName,  // 自動轉為 "maker_local_name"
                                x => x.MakerEngName,
                                x => x.MakerShortName,
                                x => x.MakerEngName,
                                "Country",              // 自動轉為 "country"
                                "City",                 // 自動轉為 "city"
                                x => x.FacilityAddress,
                            }).Columns,


                            RowButtons =
                            {
                                new(){ Title="Add Another Maker Type", Event="addMakerType", Icon="bi-pencil"},
                                new(){ Title="Add New Site", Event="addNewSite", Icon="bi-pencil"}
                            }
                        }
                        ,new()
                        {
                            TableId = "tbMaker2",
                            AjaxUrl = "",
                            FetchMode = FetchMode.All,
                            Message="* Existed in the group companyd(excluding itself)",
                            Features = new TableFeatures
                            {
                                Checkbox = false,
                                Export = true,
                                RowButtons = true,
                                ColumnToggle = true,
                                RowSelect = true,
                                SelectAll = true,
                                VirtualScroll = true,
                                ColumnFilter = false,   // 可選，每欄都有 filter
                                StickyHeader = true    // 可選，表頭固定
                            },

                            Config = new TableConfig
                            {
                                PageLength = 20,
                                VirtualScrollHeight = "500px",
                                Searching = false,
                                Ordering = false,
                                Paging = false,
                                LengthChange = false,
                                StateSave = true
                            },

                            //ToolbarButtons =
                            //{
                            //    new("Add", "add"),
                            //    new("Delete Selected", "deleteSelected", "btn btn-danger"),
                            //    new("Reload", "reload", "btn btn-secondary")
                            //},
                            Columns =  TableSchema.Create<vmMakerDetail>(new()
                            {
                                x => x.MakerCode,       // 自動轉為 "maker_code"
                                x => x.MakerLocalName,  // 自動轉為 "maker_local_name"
                                x => x.MakerEngName,
                                x => x.MakerShortName,
                                x => x.MakerEngName,
                                "Country",              // 自動轉為 "country"
                                 "City",                 // 自動轉為 "city"
                                x => x.FacilityAddress,
                                x => x.MakerStatus,
                            }).Columns,
                            //Columns =
                            //{ 
                            //    new("MakerCode"),
                            //    new("MakerLocalName"),
                            //    new("MakerEngName"),
                            //    new("MakerShortName"),
                            //    new("Country"),
                            //    new("City"),
                            //    new("FacilityAddress"),
                            //    new("MakerStatus"),
                            //    //new("MakerType",visible:true)
                            //},

                            RowButtons =
                            {
                                new(){ Title="Copy Maker", Event="cpMaker", Icon="bi-pencil"},
                                //new(){ Title="Copy Maker", Event="cpMaker", Icon="bi-pencil"}
                            }
                        }
                    };
                    var vendor = new List<TableSchema>
                    {
                        new()
                        {
                              TableId = "tbVendor",
                              AjaxUrl = "/Supplier/GetVendorData",
                              FetchMode = FetchMode.All,

                              Features = new TableFeatures
                              {
                                  Checkbox = false,
                                  Export = true,
                                  RowButtons = true,
                                  ColumnToggle = true,
                                  RowSelect = true,
                                  SelectAll = true,
                                  VirtualScroll = true,
                                  ColumnFilter = false,   // 可選，每欄都有 filter
                                  StickyHeader = true    // 可選，表頭固定
                              },

                              Config = new TableConfig
                              {
                                  PageLength = 20,
                                  VirtualScrollHeight = "500px",
                                  Searching = false,
                                  Ordering = false,
                                  Paging = false,
                                  LengthChange = false,
                                  StateSave = true
                              },

                              //ToolbarButtons =
                              //{
                              //    new("Add", "add"),
                              //    new("Delete Selected", "deleteSelected", "btn btn-danger"),
                              //    new("Reload", "reload", "btn btn-secondary")
                              //},
                              Columns =  TableSchema.Create<vmVendorDetail>(new()
                              {
                                    x => x.OUSite,
                                    x => x.Inactive,
                                    x => x.GroupName,
                                    x => x.GroupCode,
                                    x => x.VendorName,
                                    "VandorNameAlt",
                                        "VandorCode",
                                    x => x.SSRName,
                                    x => x.TaxRegistration,
                                    x => x.SupplierType,
                              }).Columns,
                              //Columns =
                              //{
                              //      new("OUSite"),
                              //      new("Inactive"),
                              //      new("GroupName"),
                              //      new("GroupCode"),
                              //      new("VendorName"),
                              //      new("VandorNameAlt"),
                              //      new("VandorCode"),
                              //      new("SSRName"),
                              //      new("TaxRegistration"),
                              //      new("SupplierType"),
                              //  }, 
                                //RowButtons =
                                //{
                                //    new(){ Title="Edit", Event="edit", Icon="bi-pencil"},
                                //    new(){ Title="Delete", Event="delete", Icon="bi-trash", CssClass="btn btn-sm btn-danger"}
                                //}
                        }
                    };
                    dic["maker"] = maker;
                    dic["vendor"] = vendor;
                    model = new StepViewModel<TableSchema>
                    {
                        StepIndex = stepIndex,
                        Title = "第一頁",
                        Data = dic
                    };

                    break;
                case 2:
                    //先找CONFIG
                    Dictionary<string, List<BaseDynamicField>> dic2 = new Dictionary<string, List<BaseDynamicField>>();
                    string[] sections = ["Supplier Information", "Vendor Subrange", "Company Profile"];
                    ////string[] sections = ["Supplier Information"];
                    //foreach (var item in sections)
                    //{
                    //    dic2[item.Replace(" ","")] = await _supplierService.GetConfigFieldAsync(item, redirectData);
                    //} 
                    //var userFromDb = new UserProfile { CompanyCode = "Johnny", MakerType = "Normal", RequestReason = "test@me.com" };

                    //_dynamicFieldService.FillSchemaWithModel(dic2, userFromDb);
                    var json5 = """
{
  "SupplierInformation": [
    {
      "ColId": "maker_code",
      "ColName": "Maker Code",
      "ColValue": "aaa",
      "Must": false,
      "EnumTypeStr": "Label",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": false,
      "Width": 3,
      "Order": 0,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "maker_local_name",
      "ColName": "Maker Local Name",
      "ColValue": "zzz",
      "Must": false,
      "EnumTypeStr":  "Label",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 0,
      "OptionStr": ",", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "maker_english_name",
      "ColName": "Maker English Name",
      "ColValue": "bbbbb",
      "Must": false,
      "EnumTypeStr":  "Label",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 0,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
     
    {
      "ColId": "business_type",
      "ColName": "Business Type",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Dropdown",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 3,
      "OptionStr": "China Car,china_car^Global Car,global_car", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "vendor_class",
      "ColName": "Vendor Class",
      "ColValue": "",
      "Must": true,
      "EnumTypeStr": "Dropdown",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 4,
      "OptionStr":"VC1,VC1^VC2,VC2^VC3,VC3^VC4,VC4^VC5,VC5^VCL,VCL", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": true,
      "InverseSelect": false
    },
    {
      "ColId": "vendor_group_code",
      "ColName": "Vendor Group Code",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Select2",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 5,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "maker_group_code",
      "ColName": "Maker Group Code",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Select2",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 6,
      "OptionStr": ",", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "technology",
      "ColName": "Technology",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Select2",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": false,
      "Width": 3,
      "Order": 7,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "upload_ssaaf",
      "ColName": "Upload SSAAF",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "File",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 9,
      "OptionStr": ",", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    }
  ]
}
""";
                    var json4 = """
{
  "SupplierInformation": [
    {
      "ColId": "maker_code",
      "ColName": "Maker Code",
      "ColValue": "aaa",
      "Must": false,
      "EnumTypeStr": "Label",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": false,
      "Width": 3,
      "Order": 0,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "maker_local_name",
      "ColName": "Maker Local Name",
      "ColValue": "zzz",
      "Must": false,
      "EnumTypeStr":  "Label",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 0,
      "OptionStr": ",", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "maker_english_name",
      "ColName": "Maker English Name",
      "ColValue": "bbbbb",
      "Must": false,
      "EnumTypeStr":  "Label",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 0,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "company_code",
      "ColName": "AMSC Company",
      "ColValue": "ccccc",
      "Must": false,
      "EnumTypeStr":"Dropdown",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 1,
      "OptionStr": "AMSCTW,AMSCTW^AMSCXM,AMSCXM", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "business_type",
      "ColName": "Business Type",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Dropdown",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 3,
      "OptionStr": "China Car,china_car^Global Car,global_car", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "vendor_class",
      "ColName": "Vendor Class",
      "ColValue": "",
      "Must": true,
      "EnumTypeStr": "Dropdown",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 4,
      "OptionStr":"VC1,VC1^VC2,VC2^VC3,VC3^VC4,VC4^VC5,VC5^VCL,VCL", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": true,
      "InverseSelect": false
    },
    {
      "ColId": "vendor_group_code",
      "ColName": "Vendor Group Code",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Select2",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 5,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "maker_group_code",
      "ColName": "Maker Group Code",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Select2",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 6,
      "OptionStr": ",", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "technology",
      "ColName": "Technology",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "Select2",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": false,
      "Width": 3,
      "Order": 7,
      "OptionStr": ",",
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    },
    {
      "ColId": "upload_ssaaf",
      "ColName": "Upload SSAAF",
      "ColValue": "",
      "Must": false,
      "EnumTypeStr": "File",
      "Section": "Supplier Information",
      "Min": null,
      "Max": null,
      "DefaultValue": "",
      "Pattern": "",
      "Placeholder": "",
      "Readonly": false,
      "IsDisplay": true,
      "Width": 3,
      "Order": 9,
      "OptionStr": ",", 
      "SheetName": "NA",
      "SheetColumn": "NA",
      "Position": "",
      "ColumnDesc": "",
      "IsRedirect": false,
      "InverseSelect": false
    }
  ]
}
""";
                    if (SendData["EventName"].ToString() == "addMakerType")
                    {
                        dic2 = JsonConvert.DeserializeObject<Dictionary<string, List<BaseDynamicField>>>(json4);// await _supplierService.GetMakerDataInternalAsync(makername);


                    }
                    if (SendData["EventName"].ToString() == "addNewSite")
                    {
                        dic2 = JsonConvert.DeserializeObject<Dictionary<string, List<BaseDynamicField>>>(json5);// await _supplierService.GetMakerDataInternalAsync(makername);


                    }

                    model = new StepViewModel<BaseDynamicField>
                    {
                        StepIndex = stepIndex,
                        Title = "第二頁",
                        Data = dic2
                        //SendData == null ? dic2 : await _supplierService.MappingSendData(dic2, SendData)
                    };
                    break;
                case 3:
                    Dictionary<string, List<BaseDynamicField>> dic3 = new Dictionary<string, List<BaseDynamicField>>();


                    var list2 = new List<BaseDynamicField>();

                    list2.Add(new BaseDynamicField(FieldType.Textbox)
                    {
                        ColName = "Name",
                        ColId = "Name",
                        Pattern = "",
                        Must = false,
                        // AsyncUrl = "/Home/GetUser",
                        //EnumTypeStr = FieldType.Textbox.ToString() ,
                        //   Target = "userName,email",
                        Width = 3,
                        Order = 1
                    });

                    dic3["Step" + (stepIndex).ToString()] = list2;



                    model = new StepViewModel<BaseDynamicField>
                    {
                        Title = "第三頁",
                        Data = dic3//SendData == null ? dic2 : await _supplierService.MappingSendData(dic2, SendData)
                    };
                    break;
                    //case 3:
                    //    //Dictionary<string, List<DynamicSupplierFileField>> dic3 = new Dictionary<string, List<DynamicSupplierFileField>>(); 
                    //    //dic3["SupplierVC"] = await _supplierService.GetConfigFileListAsync(redirectData);
                    //    //model = new StepViewModel<DynamicSupplierFileField>
                    //    //{
                    //    //    StepIndex = stepIndex,
                    //    //    Title = "第三頁",
                    //    //    Data = dic3
                    //    //};
                    //    break;
            }
            return model;
        }

        [HttpPost]
        public IActionResult Save([FromBody] Dictionary<string, string> finalPayload)
        {
            // 檢查是否有資料
            if (finalPayload == null || !finalPayload.Any())
            {
                return BadRequest("未收到有效的 JSON 資料");
            }

            // 1. 這裡可以直接看到您的資料結構，例如：
            // var userName = finalPayload["BasicSection"]["UserName"];

            // 2. 接著執行您之前設定好的 AutoMapper 轉換
            // var userProfile = _mapper.Map<UserProfile>(finalPayload);

            // var userProfile = _mapper.Map<UserProfile>(rawData);
            //  var dbData = userProfile.ToDbParameters();

            //_supplierService.Save(finalPayload);
            // 3. 執行 DB 儲存邏輯...

            return Ok(new { success = true, message = "已成功接收並轉換" });
        }

        [HttpGet]
        public async Task<IActionResult> GetMakerData(string makername, string companyid)
        {
            if (string.IsNullOrEmpty(makername))
            {
                return Json(new
                {
                    success = true,
                    tbMaker1 = new List<vmMakerDetail>(), // 給第一個表的資料
                    tbMaker2 = new List<vmMakerDetail>()       // 給第二個表的資料
                });
            }


            var json2 = """
[{"MakerSn":9098,"maker_code":"M00058","maker_local_name":"台灣三井化學股份有限公司","maker_english_name":"TAIWAN MITSUI CHEMICALS, INC.","country":"","city":"","facility_address":"","companyid":1,"companyname":"AUO","maker_short_name":"Taiwan Mitsui Chemicals","maker_type":"Normal","maker_group_code":"D0048"},{"MakerSn":9247,"maker_code":"M00235","maker_local_name":"台灣特格股份有限公司MEM","maker_english_name":"MITSUI ELECTRONIC MATERIALS CO., LTD.","country":"","city":"","facility_address":"","companyid":1,"companyname":"AUO","maker_short_name":"MEM","maker_type":"Normal","maker_group_code":"D0293"},{"MakerSn":5674,"maker_code":"M01129","maker_local_name":"三井化學株式會社","maker_english_name":"Mitsui Chemicals Tohcello Inc.","country":"JAPAN","city":"東京都(Tokyo)","facility_address":"Ichigayabuilding 2-6, Kudan-kita 4-Choume, Chiyoda-Ku","companyid":1,"companyname":"AUO","maker_short_name":"Mitsui","maker_type":"Normal","maker_group_code":"D0470"},{"MakerSn":4893,"maker_code":"M01311","maker_local_name":"三井物?","maker_english_name":"MITSUI & CO., LTD. ","country":"JAPAN","city":"東京都(Tokyo)","facility_address":"日本東京都 ","companyid":1,"companyname":"AUO","maker_short_name":"三井物?","maker_type":"Normal","maker_group_code":null},{"MakerSn":9651,"maker_code":"M01680","maker_local_name":"MITSUBISHI MATERIAL CORPORATION","maker_english_name":"mitsuibishi material","country":"JAPAN","city":"東京都(Tokyo)","facility_address":"KFC Bldg. 8F, 1-6-1, YOKOAMI SUMIDA-KU, TOKYO 130-0015, JAPAN","companyid":1,"companyname":"AUO","maker_short_name":"mitsuibishi material","maker_type":"Normal","maker_group_code":""},{"MakerSn":6100,"maker_code":"M01708","maker_local_name":"MC Tohcello (Malaysia) SDN BHD","maker_english_name":"MC Tohcello (Malaysia) SDN BHD","country":"MALAYSIA","city":"","facility_address":"A-07-06 , Empire Tower , Empire Subang ,Jalan SS16/1 , 47500,Subang Jaya, Selangor","companyid":1,"companyname":"AUO","maker_short_name":"Mitsui","maker_type":"Normal","maker_group_code":"D0470"}]

""";
            var lsvwMaker1 = JsonConvert.DeserializeObject<List<vmMakerDetail>>(json2);//await _supplierService.GetMakerDataFromGroupAsync(makername, companyid);

            if (lsvwMaker1.Count == 0)
            {
                return NotFound(new { message = "找不到供應商資料" });
            }
            var json3 = """
[{"MakerSn":9098,"maker_code":"M00058","maker_local_name":"台灣三井化學股份有限公司","maker_english_name":"TAIWAN MITSUI CHEMICALS, INC.","maker_short_name":"Taiwan Mitsui Chemicals","country":"","city":"","maker_short_name1":"Taiwan Mitsui Chemicals","companyid":2,"facility_address":"","maker_status":"active","maker_type":"Normal"},{"MakerSn":9247,"maker_code":"M00235","maker_local_name":"台灣特格股份有限公司MEM","maker_english_name":"MITSUI ELECTRONIC MATERIALS CO., LTD.","maker_short_name":"MEM","country":"","city":"","maker_short_name1":"MEM","companyid":2,"facility_address":"","maker_status":"active","maker_type":"Normal"}]

""";
            var lsvwMaker2 = JsonConvert.DeserializeObject<List<vmMakerDetail>>(json2);// await _supplierService.GetMakerDataInternalAsync(makername);

            if (lsvwMaker2.Count == 0)
            {
                return NotFound(new { message = "找不到供應商資料" });
            }



            return Json(new
            {
                success = true,
                tbMaker1 = lsvwMaker1,  // 這裡的 Key 就是前端 <table id="SupplierGrid">
                tbMaker2 = lsvwMaker2     // 這裡的 Key 就是前端 <table id="OrderGrid"> 
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetVendorData(string vendorname)
        {
            if (string.IsNullOrEmpty(vendorname))
            {
                return Json(new
                {
                    success = true,
                    tbVendor = new List<vmVendorDetail>(),
                });
            }
            var json1 = """
[{"Supplier_Type":"VC5","ORG":"1000","Group_Name":"NON GROUP","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"VRD 27.1 SRL","Vendor_Name_alt":" ","Vendor_id":"1600002049","Vendor_Code":"1600002049","Vendor_Site_Code":"OA45D_25th_0_DDP","Vendor_Site_Id":"EUR001","Vat_Registration_Num":"000000","Inactive":" ","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null},{"Supplier_Type":" ","ORG":"1000","Group_Name":"TEST","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"Test20251226","Vendor_Name_alt":"Test20251226","Vendor_id":"1600004140","Vendor_Code":"1600004140","Vendor_Site_Code":"SSR Desc","Vendor_Site_Id":"TWD001","Vat_Registration_Num":"12345879","Inactive":"X","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null},{"Supplier_Type":"VC5","ORG":"1000","Group_Name":"NON GROUP","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"0429029陳一誠","Vendor_Name_alt":" ","Vendor_id":"1600001905","Vendor_Code":"1600001905","Vendor_Site_Code":"TT_0_DDP","Vendor_Site_Id":"TWD001","Vat_Registration_Num":"000000","Inactive":" ","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null},{"Supplier_Type":"VC5","ORG":"1000","Group_Name":"NON GROUP","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"25 HOURS LLC","Vendor_Name_alt":" ","Vendor_id":"1600001661","Vendor_Code":"1600001661","Vendor_Site_Code":"OA120D_25th_0_DDP","Vendor_Site_Id":"USD001","Vat_Registration_Num":"83-1945572 (EIN)","Inactive":" ","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null},{"Supplier_Type":"VC5","ORG":"1000","Group_Name":"NON GROUP","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"臺灣銀行新竹分行友達420億元聯貸專戶","Vendor_Name_alt":" ","Vendor_id":"1600000242","Vendor_Code":"1600000242","Vendor_Site_Code":"TT_0_DDP","Vendor_Site_Id":"TWD001","Vat_Registration_Num":"000000","Inactive":" ","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null},{"Supplier_Type":"VC5","ORG":"1300","Group_Name":"NONE GROUP","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"Leave Life 21 Co., Ltd","Vendor_Name_alt":" ","Vendor_id":"1600003411","Vendor_Code":"1600003411","Vendor_Site_Code":"OA7D_25th_0_DDP","Vendor_Site_Id":"JPY001","Vat_Registration_Num":"1020001016439","Inactive":" ","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null},{"Supplier_Type":"VC5","ORG":"1000","Group_Name":"NONE GROUP","Group_Code":null,"vender_subsidiary":null,"Vendor_Name":"0207169 張庭瑞","Vendor_Name_alt":" ","Vendor_id":"1600002602","Vendor_Code":"1600002602","Vendor_Site_Code":"TT_0_DDP","Vendor_Site_Id":"TWD001","Vat_Registration_Num":" ","Inactive":" ","created_by":null,"dept":null,"VENDOR_SITE_CODE_ALT":null,"blacklist_date":null}]

""";
            var lsvmVender = JsonConvert.DeserializeObject<List<vmVendorDetail>>(json1);//await _supplierService.GetVendorInfoAsync(vendorname);

            if (lsvmVender.Count == 0)
            {
                return NotFound(new { message = "找不到供應商資料" });
            }
            return Json(new
            {
                success = true,
                tbVendor = lsvmVender,  // 這裡的 Key 就是前端 <table id="SupplierGrid"> 
            });
        }



    }
}
