using Microsoft.AspNetCore.Mvc;
namespace newauo.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        {


        }


        public async Task<IActionResult> Index()
        {
            // byte[] fileBytes = System.IO.File.ReadAllBytes(@"D:\Web\flowerstatus.png");
            //  var d = await _oneSupplierFLMService.UploadFileToFLM(fileBytes, "aaa.pdf", "onesupplier001", "Echo.Lee");
            //var d= await _oneSupplierFLMService.GetFileAsync("283b009b-1ed6-47b7-ad61-0fbaea74f0ce", "aaa.pdf", "Echo.Lee");

            //var d = await _oneSupplierFLMService.CheckFileIDByFileId("283b009b-1ed6-47b7-ad61-0fbaea74f0ce");

            return View();
        }
    }
}