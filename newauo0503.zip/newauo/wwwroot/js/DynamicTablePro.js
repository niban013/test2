﻿var DynamicTablePro = (function () {
    const api = {};
    api.events = {};
    api.tables = {};
    api.formatters = {
        currency: v => "$" + Number(v).toLocaleString()
    };

    // 建立欄位
    function buildColumns(schema) {
        let cols = [];
        let features = schema.Features || {};

        // Checkbox + Select All
        if (features.Checkbox) {
            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-checkbox-col",
                title: features.SelectAll ? '<input type="checkbox" class="dt-select-all">' : "",
                render: () => '<input type="checkbox" class="row-check">',
                createdCell: function (td) {
                    $(td).css({
                        "white-space": "nowrap",
                        "width": "1%",
                        "text-align": "center"  // 可選：讓 checkbox 置中
                    });
                }
            });
        }

        // RowButtons (每列操作)
        if (features.RowButtons && schema.RowButtons?.length > 0) {

            cols.push({
                data: null,
                orderable: false,
                defaultContent: "",
                className: "dt-row-btn-col",

                createdCell: function (td) {

                    $(td).css({
                        "white-space": "nowrap",
                        "width": "1%",
                        //  "display": "flex",
                        "gap": "6px"   // ⭐ 按鈕間距
                    });

                },

                render: row => {

                    return schema.RowButtons.map(btn => {

                        let iconHtml = btn.Icon
                            ? `<i class="bi ${btn.Icon}" style="margin-right:4px;"></i>`
                            : "";

                        let textHtml = btn.Title
                            ? btn.Title
                            : "";

                        // ⭐ 關鍵：tooltip fallback
                        let tooltip = btn.Tooltip || btn.Title || btn.Event || "";

                        return `
                            <button class="dt-btn ${btn.CssClass}" 
                                    data-event="${btn.Event}" 
                                    data-id="${row.id}"
                                    title="${tooltip}">
                                ${iconHtml}${textHtml}
                            </button>
                        `;

                    }).join("");

                }
            });
        }

        // 資料欄位
        (schema.Columns || []).forEach(col => {
            let c = { data: col.Field, title: col.Title ?? col.Field };
            if (col.Formatter) c.render = v => api.formatters[col.Formatter] ? api.formatters[col.Formatter](v) : v;

            // Column Filter
            if (features.ColumnFilter) {
                // c.footer = `<input type="text" placeholder="All" class="column-filter form-control form-control-sm" style="width:100%;"/>`;
                c.headerFilter = `<input type="text" placeholder="All" class="column-filter form-control form-control-sm" style="width:100%; margin-top:4px;"/>`;

            }

            cols.push(c);
        });

        return cols;
    }

    // Render Table
    api.render = function (opt) {
        let schema = opt.schema;
        let columns = buildColumns(schema);
        let cfg = schema.Config || {};
        let features = schema.Features || {};
        let dtButtons = [];

        if (schema.ToolbarButtons && schema.ToolbarButtons.length > 0) {
            schema.ToolbarButtons.forEach(btn => {
                dtButtons.push({
                    text: `<i class="${btn.Icon}"></i> ${btn.Title}`, // 直接在此注入 Icon
                    attr: {
                        'title': btn.Title,
                        'data-bs-toggle': 'tooltip'
                    },
                    className: btn.CssClass,
                    // 核心修正：強制讓這個按鈕不帶 dt-button 類別
                    init: function (api, node, config) {
                        $(node).removeClass('dt-button');
                    },
                    action: function (e, dt, node, config) {
                        const handler = api._handler || {};

                        if (handler[btn.Event]) {
                            handler[btn.Event](schema.TableId);
                        }
                        else if (api.events[btn.Event]) {
                            api.events[btn.Event](schema.TableId);
                        }
                    }
                });
            });
        }
        let tableOptions = {
            autoWidth: false,

            columns: columns,
            scrollX: true,
            stateSave: cfg.StateSave ?? true,
            responsive: true,
            colReorder: true,
            searching: cfg.Searching ?? true,
            lengthChange: cfg.LengthChange ?? true,
            ordering: cfg.Ordering ?? true,
            paging: cfg.Paging ?? true,
            pageLength: cfg.PageLength ?? 10,
            dom: '<"table-header-right" f B>rt<"table-footer d-flex justify-content-between" ip>',
            buttons: dtButtons,//(cfg.Buttons !== false || features.Export) ? ["excel"] : [],
            scrollY: cfg.ScrollY ?? (features.VirtualScroll ? "400px" : ""),
            scrollCollapse: features.VirtualScroll ?? false,
            deferRender: features.VirtualScroll ?? false,
            scroller: features.VirtualScroll ?? false,
            fixedHeader: features.StickyHeader ?? false,
            // ⭐ 如果 stateSave = true，覆蓋舊的 state
            stateLoadParams: function (settings, data) {
                data.start = 0;                       // 從第一頁開始
                data.length = cfg.PageLength ?? 10;   // 每頁筆數
                return data;
            },
            initComplete: function () {
                const api = this.api();
                const thead = $(api.table().header());
                // 假設前 offset 欄位是 RowButtons / Checkbox，需要跳過
                //const columnOffset = 1; // 如果有 1 欄 RowButtons 或 Checkbox
                // 如果你有 checkbox + rowbuttons，可以設 2
                // 自動計算 offset：前幾欄有 class dt-checkbox-col 或 dt-btn-col

                if (features.ColumnFilter) {
                    let columnOffset = 0;
                    api.columns().every(function (i) {
                        const col = this.header();
                        if ($(col).hasClass('dt-checkbox-col') || $(col).hasClass('dt-row-btn-col')) {
                            columnOffset++;
                        } else {
                            return false; // 遇到第一個資料欄就停止
                        }
                    });
                    // 建 filter row
                    let filterRow = $('<tr class="filter-row"></tr>');
                    api.columns().every(function (i) {
                        if (i < columnOffset) {
                            // 前幾欄空白
                            filterRow.append('<th></th>');
                        } else {
                            filterRow.append('<th><input type="text" class="form-control form-control-sm column-filter" placeholder="Search"></th>');
                        }
                    });
                    thead.append(filterRow);
                    // ⭐ 最穩寫法（delegate）
                    thead.on('keyup change clear', '.column-filter', function () {
                        let colIndex = $(this).closest('th').index();
                        let value = this.value;
                        // console.log("filter:", colIndex, value); 
                        api.column(colIndex).search(value).draw();
                    });
                }
            }
        };

        // Ajax
        if (schema.FetchMode === 0) {
            if (schema.AjaxUrl && schema.AutoLoad !== false) {
                // 有 URL 才設定 Ajax 模式
                tableOptions.ajax = {
                    url: schema.AjaxUrl,
                    // --- 新增：將後端傳來的 AjaxParams 帶入請求 ---
                    data: function (d) {
                        if (schema.AjaxParams) {
                            // 將 schema.AjaxParams 物件屬性合併到 DataTables 請求參數 d 中
                            $.extend(d, schema.AjaxParams);
                        }
                        return d;
                    },
                    dataSrc: function (json) {
                        // 1. 檢查後端回傳的 success 標記
                        if (json.success === false) {
                            console.error(schema.TableId + " 載入失敗");
                            return [];
                        }
                        // 2. 根據 TableId 抓取對應的資料集 (例如 json["MainGrid"])
                        let rows = json['data'] || [];
                        // 3. 存入快取 (選配，供後續邏輯判斷使用)
                        api['data_' + schema.TableId] = rows;

                        return rows;
                    }
                };
            } else {
                tableOptions.data = [];
            }
            tableOptions.serverSide = false;
        } else {
            tableOptions.serverSide = true;
            tableOptions.processing = true;
            tableOptions.ajax = schema.AjaxUrl;
            if (schema.AutoLoad === false) {
                tableOptions.deferLoading = 0; // 設定初始資料筆數為 0，阻止第一次請求
            }
        }

        let table = $("#" + schema.TableId).DataTable(tableOptions);
        api.tables[schema.TableId] = table;
        api._handler = api._handler || {};
        // RowButtons event (每列 Edit / Delete)
        // 🟢 ⭐ 改版：統一 handler injection（v4核心）
        $(document).off("click", `#${schema.TableId} .dt-row-btn-col .dt-btn`);
        $(document).on("click", `#${schema.TableId} .dt-row-btn-col .dt-btn`, function () {

            let event = $(this).data("event");
            let id = $(this).data("id");
            let row = table.row($(this).closest("tr")).data();

            // 🟢 ⭐ handler 優先（StepPage 注入）
            const handler = api._handler || {};

            if (handler[event]) {
                handler[event](id, row, schema.TableId);
            }
            // 🟡 fallback（舊系統）
            else if (api.events[event]) {
                api.events[event](id, row, schema.TableId);
            }
        });

        // Row Checkbox & Select All
        $(document).off("change", `#${schema.TableId} .row-check`);
        $(document).on("change", `#${schema.TableId} .row-check`, function () {
            if (!features.SelectAll) return;
            let total = table.$(".row-check").length;
            let checked = table.$(".row-check:checked").length;
            $(`#${schema.TableId} .dt-select-all`).prop("checked", total === checked);
        });
        $(document).off("change", `#${schema.TableId} .dt-select-all`);
        $(document).on("change", `#${schema.TableId} .dt-select-all`, function () {
            let checked = $(this).is(":checked");
            table.$(".row-check").prop("checked", checked);
        });

        //// Column Filter
        //if (features.ColumnFilter) {
        //    table.columns().every(function () {
        //        var column = this;
        //        $('input.column-filter', this.footer()).on('keyup change clear', function () {
        //            if (column.search() !== this.value) column.search(this.value).draw();
        //        });
        //    });
        //}

        return table;
    };

    api.renderAll = function (tables, handler) {
        if (handler) {
            api._handler = handler;
        }
        tables.forEach(schema => api.render({ schema }));
    };
    //api.renderAll = function (tables) {
    //    tables.forEach(schema => api.render({ schema }));
    //};

    api.reload = function (target, url, params, callbacks) {
        api._handler = api._handler || {};
        const success = callbacks?.success || (() => { });
        const error = callbacks?.error || ((...args) => console.error("Reload Error:", ...args));
        const final = callbacks?.finally || callbacks?.final || (() => { });

        const regex = /[,，]/;
        const isSingle = !regex.test(target);
        if (isSingle) {
            // 單表模式：直接清除該表
            if (api.tables[target]) api.tables[target].clear().draw();
        } else {
            // 多表模式：清除 target 物件中定義的所有 tableId
            var _target = target.split(',').reduce((acc, cur) => {
                acc[cur.trim()] = cur.trim();
                return acc;
            }, {});
            const mapping = _target || {}; // 如果 target 為 null 則不執行清除，由 success 邏輯處理
            Object.keys(mapping).forEach(tableId => {
                if (api.tables[tableId]) api.tables[tableId].clear().draw();
            });
        }

        return $.get(url, params)
            .done(function (res) {
                if (res.success === false) return error("伺服器回傳失敗");

                if (isSingle) {
                    const table = api.tables[target];
                    const data = res[target] || res.data || (Array.isArray(res) ? res : []);
                    if (table) {
                        // ⭐ 這裡直接 add 並 draw (前面已經 clear 過了)
                        table.rows.add(data).draw();
                    } else {
                        return error(`找不到表格: ${target}`);
                    }
                } else {
                    // 多表或自動模式
                    var _target = target.split(',').reduce((acc, cur) => {
                        acc[cur.trim()] = cur.trim();
                        return acc;
                    }, {});
                    const mapping = _target || res;
                    Object.keys(mapping).forEach(key => {
                        if (key === "success") return;
                        const tableId = key;
                        const table = api.tables[tableId];
                        const data = res[tableId];
                        if (table && Array.isArray(data)) {
                            table.rows.add(data).draw();
                        }
                    });
                }
                success(res);
            })
            .fail(function (xhr, status, err) {
                // ⭐ 3. 錯誤處理 (安全讀取 responseJSON)
                const errorMessage = xhr.responseJSON?.message || err || status || "Network Error";
                error(errorMessage, xhr);
            })
            .always(function () {
                final();
            });
    };


    // Toolbar event
    $(document).off("click", `.dataTables_filter button`);
    $(document).on("click", ".dataTables_filter button", function () {
        let event = $(this).data("event");
        let tableId = $(this).data("table");
        if (api.events[event]) api.events[event](tableId);
    });

    // Get selected rows
    api.getSelectedRows = function (tableId) {
        let table = api.tables[tableId];
        let rows = [];
        table.$(".row-check:checked").each(function () {
            let tr = $(this).closest("tr");
            let rowData = table.row(tr).data();
            if (rowData) rows.push(rowData);
        });
        return rows;
    };

    // 取得該表格是否有資料 (回傳 boolean)
    api.hasData = function (tableId) {
        let table = api.tables[tableId];
        return table ? table.data().any() : false;
    };

    // 取得當前總筆數
    api.getRowCount = function (tableId) {
        let table = api.tables[tableId];
        return table ? table.rows().count() : 0;
    };

    // 清除指定表格的所有資料列
    api.clearData = function (tableId) {
        let table = api.tables[tableId];
        if (table) {
            // clear() 清除資料，draw() 更新 UI
            table.clear().draw();
        }
    };

    // 如果你想連「搜尋框、分頁狀態」都重置，可以使用這個擴充版本
    api.resetTable = function (tableId) {
        let table = api.tables[tableId];
        if (table) {
            // 清除資料 + 重置搜尋 + 回到第一頁
            table.clear().search("").column().search("").page("first").draw();
        }
    };

    // Get all data
    api.getAllData = function (tableId) {
        return api['data_' + tableId] || [];
    };

    return api;
})();

