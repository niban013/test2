﻿ 
window.StepRegistry = (() => {

    const modules = {};
    const waiters = {};

    return {

        register(name, module) {

            modules[name] = module;

            if (waiters[name]) {
                waiters[name].forEach(fn => fn(module));
                delete waiters[name];
            }
        },

        get(name) {
            return modules[name];
        },

        wait(name) {
            return new Promise(resolve => {

                if (modules[name]) {
                    resolve(modules[name]);
                    return;
                }

                waiters[name] ||= [];
                waiters[name].push(resolve);
            });
        },

        // ⭐ 新增（很重要）
        clear(name) {
            delete modules[name];
        }
    };

})();
window.StepLoader = (() => { 
    function injectHtmlWithScripts(container, html) {

        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");

        // 先塞 HTML（不含 script）
        container.innerHTML = "";

        doc.body.childNodes.forEach(node => {

            if (node.tagName === "SCRIPT") return;

            container.appendChild(node.cloneNode(true));
        });
        
        // 再執行 script
        doc.querySelectorAll("script").forEach(oldScript => {

            const s = document.createElement("script");

            if (oldScript.src) {
                s.src = oldScript.src;
            } else {
                s.textContent = oldScript.textContent;
            }

            document.body.appendChild(s);
        });
    }
    async function load(stepIndex, ctx) {

        const storeKey = "decision";
        const store = AppBootstrap.get("FlowStore");

        const prevStep = stepIndex > 1 ? stepIndex - 1 : stepIndex;

        const extraData = store.get(`step${prevStep}`, storeKey);

        const payload = {
            stepIndex,
            flowData: extraData
                ? {
                    [`step${stepIndex}`]: {
                        type: extraData.type,
                        data: JSON.parse(JSON.stringify(extraData.value))
                    }
                }
                : null
        };

        const res = await fetch(`/Supplier/Step`, {
            method: "post",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });

        const html = await res.text();

        const container = document.getElementById("step-container");

        // ⭐ 先 destroy 舊頁
        ctx.currentPage?.destroy?.(container);

        injectHtmlWithScripts(container, html);

        const key = `step${stepIndex}`;

        // ⭐ 先 clear
        if (window.StepRegistry.clear) {
            window.StepRegistry.clear(key);
        }

        // ⭐ 再 inject（讓 register 發生）
        injectHtmlWithScripts(container, html);

        // ⭐ 再 wait
        const module = await window.StepRegistry.wait(key);

        // ⭐ 設定當前 page
        ctx.currentPage = module;

        // ⭐ init
        module?.init?.(container, {
            formData: AppBootstrap.get("FlowStore"), 
            currentStep: ctx.currentStep
        });

        return container;
    }

    return { load };

})();