﻿window.PreviewModule = (() => {

    // =========================
    // STATE（原封不動）
    // =========================
    let PreviewState = {
        version: 0,
        type: null,
        payload: null
    };

    const $panel = () => $("#previewPanel");

    // =========================
    // 原 function（全部保留簽名）
    // =========================

    function clearPreview() {
        const $p = $panel();

        const iframe = $p.find("iframe");
        if (iframe.length) {
            iframe.attr("src", "about:blank");
            iframe.remove();
        }

        $p.empty();
        $p.removeData("file-name");
        $p.html(`<div class="empty">Select file</div>`);
    }

    function flushPreview() {

        const $p = $panel();

        const prevIframe = $p.find("iframe");
        if (prevIframe.length) {
            prevIframe.attr("src", "about:blank");
            prevIframe.remove();
        }

        $p.empty();

        if (!PreviewState.type) {
            $p.html(`<div class="empty">Select file</div>`);
            return;
        }

        if (PreviewState.type === "pdf") {

            const iframe = document.createElement("iframe");
            iframe.src = PreviewState.payload;
            iframe.style.cssText = "width:100%;height:100%;border:0;";

            $p.append(iframe);
            return;
        }

        if (PreviewState.type === "image") {

            const bitmap = PreviewState.payload;

            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");

            canvas.width = bitmap.width;
            canvas.height = bitmap.height;

            ctx.drawImage(bitmap, 0, 0);

            canvas.style.cssText = "max-width:100%;max-height:100%;object-fit:contain;";

            $p.append(canvas);

            bitmap.close?.();
            return;
        }

        if (PreviewState.type === "error") {
            $p.html(PreviewState.payload);
        }
    }

    function renderImage(bitmap, version) {

        if (version !== PreviewState.version) {
            bitmap.close?.();
            return;
        }

        PreviewState.type = "image";
        PreviewState.payload = bitmap;

        flushPreview();
    }

    function renderPdf(url, version) {

        if (version !== PreviewState.version) {
            URL.revokeObjectURL(url);
            return;
        }

        if (PreviewState.type === "pdf" && PreviewState.payload) {
            URL.revokeObjectURL(PreviewState.payload);
        }

        PreviewState.type = "pdf";
        PreviewState.payload = url;

        flushPreview();
    }

    function forceDownload(blob, fileName) {

        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = fileName || "download";

        document.body.appendChild(a);
        a.click();
        a.remove();

        setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    function showUnsupported(blob, message = "", fileName = "download", version) {

        if (version !== PreviewState.version) return;

        PreviewState.type = "error";
        PreviewState.payload = `
            <div class="empty text-center">
                ⚠ 無法預覽此檔案<br>
                ${message ? `<small>${message}</small><br>` : ""}
                ${blob
                ? `<button class="btn-download">下載</button>`
                : `<div>無法下載</div>`
            }
            </div>
        `;

        flushPreview();

        if (blob) {
            $(".btn-download").off("click").on("click", () => {
                forceDownload(blob, fileName);
            });
        }
    }

    async function removeFile(stepKey, key, fileName) {

        const current = FileRuntime.getStore().get(stepKey, key) || [];
        const file = current.find(f => f.name === fileName);

        if (file?.id && !file.isNew) {
            await fetch(`/api/file/${file.id}`, { method: "DELETE" });
        }

        const next = current.filter(f => f.name !== fileName);

        FileRuntime.getStore().safeSet(stepKey, key, next);
        GraphV2.notify(stepKey, key, next);
    }

    // =========================
    // Worker（不變）
    // =========================
    const PreviewWorker = (() => {

        let worker = null;
        let url = null;

        function getWorker() {

            if (worker) return worker;

            const code = `
                self.onmessage = async function (e) {
                    const { blob, type } = e.data;
                    try {
                        if (type.startsWith("image/")) {
                            const bitmap = await createImageBitmap(blob);
                            self.postMessage({ bitmap }, [bitmap]);
                        } else {
                            self.postMessage({ blob });
                        }
                    } catch (err) {
                        self.postMessage({ error: err.message });
                    }
                };
            `;

            const blob = new Blob([code], { type: "application/javascript" });
            url = URL.createObjectURL(blob);

            worker = new Worker(url);
            return worker;
        }

        function destroy() {
            if (worker) worker.terminate();
            if (url) URL.revokeObjectURL(url);
            worker = null;
            url = null;
        }

        return { getWorker, destroy };

    })();

    // =========================
    // PreviewService（不變但私有）
    // =========================
    const PreviewService = {

        open: async function (stepKey, key, file) {

            const $p = $panel();

            $p.data("file-name", file.name);
            $p.html(`<div class="empty">⏳ 載入中...</div>`);

            const version = ++PreviewState.version;

            let realFile;

            try {
                realFile = await FileRuntime.ensureFileObject(file, stepKey, key);
            } catch {
                if (version !== PreviewState.version) return;
                showUnsupported(null, "載入失敗", file.name, version);
                return;
            }

            const blob = realFile instanceof File ? realFile : realFile?.file;

            if (!blob) {
                showUnsupported(null, "無內容", file.name, version);
                return;
            }

            let handled = false;

            const worker = PreviewWorker.getWorker();

            worker.onmessage = (e) => {

                handled = true;

                if (version !== PreviewState.version) return;

                if (e.data.error) {
                    showUnsupported(blob, "預覽失敗", file.name, version);
                    return;
                }

                const type = (file.type || blob.type || "").toLowerCase();

                if (e.data.bitmap && type.startsWith("image/")) {
                    createImageBitmap(e.data.bitmap)
                        .then(bitmap => renderImage(bitmap, version));
                    return;
                }

                if (type === "application/pdf") {
                    const url = URL.createObjectURL(blob);
                    renderPdf(url, version);
                    return;
                }

                showUnsupported(blob, "不支援預覽", file.name, version);
            };

            worker.onerror = () => {
                showUnsupported(blob, "worker error", file.name, version);
            };

            worker.postMessage({ blob, type: file.type || blob.type || "" });

            setTimeout(() => {
                if (!handled && version === PreviewState.version) {
                    showUnsupported(blob, "逾時", file.name, version);
                }
            }, 5000);
        }
    };

    // =========================
    // PUBLIC API（只開這些）
    // =========================

    function resetPreview() {

        PreviewState.version++;

        if (PreviewState.type === "pdf" && PreviewState.payload) {
            URL.revokeObjectURL(PreviewState.payload);
        }

        PreviewState.type = null;
        PreviewState.payload = null;

        flushPreview();
        PreviewWorker.destroy();
    }
    function setUploadMode(mode) {

        const isSingle = mode === "single";

        // 左側清單（multi only）
        $(".multi-only").toggleClass("d-none", isSingle);

        // 右側 preview panel（single / multi 都要）
        $(".single-only").toggleClass("d-none", !isSingle);

        // optional：可以加 class 控制 layout
        $("#uploadModal").toggleClass("single-mode", isSingle);
    }
    function buildTooltip(file, extra = "") {

        const sizeKB = file.size ? Math.round(file.size / 1024) : 0;
        const time = file.lastModified
            ? new Date(file.lastModified).toLocaleString()
            : (file.uploadTime || "");

        return `
        <div style="text-align:left">
            <b>${file.name || "unknown"}</b><br>
            Size: ${sizeKB} KB<br>
            Time: ${time}
            ${extra ? `<br><span style="color:#dc3545">${extra}</span>` : ""}
        </div>
    `;
    }
    function getFileIcon(file) {

        const type = (file.type || "").toLowerCase();
        const name = (file.name || "").toLowerCase();

        // =========================
        // 圖片
        // =========================
        if (type.startsWith("image/")) {
            return "🖼️";
        }

        // =========================
        // PDF
        // =========================
        if (type === "application/pdf" || name.endsWith(".pdf")) {
            return "📕";
        }

        // =========================
        // Excel
        // =========================
        if (
            type.includes("spreadsheet") ||
            name.endsWith(".xls") ||
            name.endsWith(".xlsx")
        ) {
            return "📊";
        }

        // =========================
        // Word
        // =========================
        if (
            type.includes("word") ||
            name.endsWith(".doc") ||
            name.endsWith(".docx")
        ) {
            return "📄";
        }

        // =========================
        // 壓縮檔
        // =========================
        if (
            name.endsWith(".zip") ||
            name.endsWith(".rar") ||
            name.endsWith(".7z")
        ) {
            return "🗜️";
        }

        // =========================
        // 可執行 / DLL
        // =========================
        if (
            name.endsWith(".exe") ||
            name.endsWith(".dll")
        ) {
            return "⚙️";
        }

        // =========================
        // 預設
        // =========================
        return "📎";
    }
    function render(stepKey, key, files) {

        const $list = $("#uploadList");
        $list.empty();

        files.forEach(file => {
            const icon = getFileIcon(file);
            const tooltip = buildTooltip(file);

            const $item = $(`
        <li class="drive-item">

           <div class="drive-name"  data-bs-toggle="tooltip"
     data-bs-html="true"
      title='${tooltip}'>

    <span class="drive-icon">${icon}</span>

    <span class="drive-scroll">
        <span class="drive-text">${file.name}</span>
    </span>

</div>

            <div class="drive-actions">
                <button class="btn btn-sm btn-outline-primary btn-view">View</button>
                <button class="btn btn-sm btn-outline-danger btn-del">Del</button>
            </div>

        </li>
        `);

            $item.find(".btn-view,.drive-name").click(async () => {
                $(".drive-item").removeClass("active");
                $item.addClass("active");
                await PreviewService.open(stepKey, key, file);
            });

            $item.find(".btn-del").click(async (e) => {
                e.stopPropagation();
                //const ctx = UploadContext.get();

                // ⭐ 用目前 preview 的 file（從 DOM 推不準 → 改用 preview panel）
                const previewName = $("#previewPanel").data("file-name");


                await removeFile(stepKey, key, file.name);

                $item.fadeOut(150, function () {
                    $(this).remove();
                });

                if (previewName === file.name) {

                    resetPreview();
                }
            });

            $list.append($item);
        });

        setTimeout(() => {
            $('[data-bs-toggle="tooltip"]').tooltip({
                container: 'body',
                html: true
            });
        });
    }
    function refreshList(stepKey, key, files) {
        render(stepKey, key, files);
    }
    function loadFiles(ctx) { 

        let files = FileRuntime.getStore().get(ctx.stepKey, ctx.key) || [];

        //if (!files || files.length === 0) {

        //    files = [
        //        { id: "f001", name: "demo-image.png", type: "image/png", lazy: true },
        //        { id: "f002", name: "report.pdf", type: "application/pdf", lazy: true },
        //        { id: "f003", name: "data.xlsx", type: "application/vnd", lazy: true }
        //    ];

        //    store().safeSet(ctx.stepKey, key, files);
        //}

        render(ctx.stepKey, ctx.key, files);
    }
    function openUploadModal(ctx) {

        let controller = new UploadController(ctx);
        resetPreview();

        const store = window.FileRuntime.getStore();
        const file = store.get(ctx.stepKey, ctx.key);

        //UploadContext.open(ctx);

        const isMulti = ctx.mode;
        setUploadMode(isMulti ? "multi" : "single");

        $("#uploadModal").modal("show");

        $("#uploadModal").one("shown.bs.modal", async () => {

            if (isMulti) {

                loadFiles(ctx);
                $panel().html(`<div class="empty">Select file</div>`);

            } else if (file) {

                $("#uploadList").empty();
                await PreviewService.open(ctx.stepKey, ctx.key, file);
            }
        });
    }

    // =========================
    // 外部只拿這些
    // =========================
    return {
        openUploadModal,
        resetPreview,
        refreshList

    };

})();


class UploadController {
    constructor(ctxProvider) {

        this.ctxProvider = ctxProvider;

        this.$modal = $("#uploadModal");

        this.$fileInput = $("<input type='file' multiple style='display:none'>");
        $("body").append(this.$fileInput);

        this.bind();
    }

    bind() {

        // 選檔
        this.$modal.on("click", "#btnSelectFile", () => {
            this.$fileInput.trigger("click");
        });

        this.$fileInput.on("change", (e) => {
            this.handleFiles(e.target.files);
            e.target.value = "";
        });

        // drag
        this.$modal.on("dragover", e => e.preventDefault());

        this.$modal.on("drop", (e) => {
            e.preventDefault();
            this.handleFiles(e.originalEvent.dataTransfer.files);
        });
    }

    handleFiles(files) {

        const ctx = this.ctxProvider ;
        const key = ctx.key;// FileRuntime.buildKey(ctx.stepKey, ctx.key);

        const store = FileRuntime.getStore();
        const current = store.get(ctx.stepKey, key) || [];

        const merged = [...current];

        Array.from(files).forEach(f => {
            if (!merged.some(x => x.name === f.name)) {
                merged.push(f);
            }
        });

        store.safeSet(ctx.stepKey, key, merged);
        GraphV2.notify(ctx.stepKey, key, merged);
        PreviewModule.refreshList(ctx.stepKey, key, merged)

    }
}


window.FileRuntime = (() => {

    const inflightMap = new Map();
    // =========================
    // ⭐ LRU Cache (File Object)
    // =========================
    const fileCache = new Map(); // file.id → File
    const MAX_CACHE = 30;

    function touchCache(fileId, fileObj) {

        if (fileCache.has(fileId)) {
            fileCache.delete(fileId);
        }

        fileCache.set(fileId, {
            file: fileObj,
            ts: Date.now()
        });

        // LRU cleanup
        if (fileCache.size > MAX_CACHE) {

            const oldest = [...fileCache.entries()]
                .sort((a, b) => a[1].ts - b[1].ts)[0];

            if (oldest) {
                fileCache.delete(oldest[0]);
            }
        }
    }

    function getCache(fileId) {
        const hit = fileCache.get(fileId);
        if (!hit) return null;

        hit.ts = Date.now(); // refresh
        return hit.file;
    }
    function getStore() {
        return AppBootstrap.get("FlowStore"); //AppBootstrap.get("FormStore");
    }

    //function buildKey(stepKey, field, col) {
    //    return col ? `${field}.${col}` : field;
    //}

    // =========================
    // ⭐ 共用下載（in-flight + cache + abort）
    // =========================
    async function ensureFileObject(file, stepKey, key) {

        if (file instanceof File) return file;
        if (file.file instanceof File) return file.file;
        if (!file.lazy) return file;

        const cached = getCache(file.id);
        if (cached) return cached;

        if (inflightMap.has(file.id)) {
            const prev = inflightMap.get(file.id);
            prev.controller.abort();
        }

        const controller = new AbortController();

        const promise = (async () => {
            try {

                const res = await fetch(`/api/file/${file.id}`, {
                    signal: controller.signal
                });

                if (!res.ok) throw new Error(`下載失敗: ${res.status}`);

                const blob = await res.blob();
                if (!blob || blob.size === 0) throw new Error("空檔案");

                const realFile = new File(
                    [blob],
                    file.name,
                    { type: blob.type || "application/octet-stream" }
                );

                file.file = realFile;
                file.lazy = false;
                // 👉 ⭐ 放這裡
                touchCache(file.id, realFile);
                const store = getStore();
                const current = store.get(stepKey, key) || [];

                store.safeSet(stepKey, key,
                    current.map(f => f.id === file.id ? file : f)
                );

                return realFile;

            } catch (err) {

                if (err.name === "AbortError") return;

                console.error(err);

                file.lazy = true;
                throw err;

            } finally {
                inflightMap.delete(file.id);
            }
        })();

        inflightMap.set(file.id, { controller, promise });

        return promise;
    }

    return {
        ensureFileObject,
        //buildKey,
        getStore
    };

})();

//window.UploadContext = {

//    open({ stepKey, field, col, $row }) {
//        $("#currentStepKey").val(stepKey);
//        $("#currentField").val(field);
//        $("#currentCol").val(col || "");
//        this.$row = $row;
//    },

//    get() {
//        return {
//            stepKey: $("#currentStepKey").val(),
//            field: $("#currentField").val(),
//            col: $("#currentCol").val(),
//            $row: this.$row
//        };
//    }
//};
window.FilePlugin = {
    setFileUI(wrapper, file) {
        const input = wrapper.querySelector(".file-input");
        const nameEl = wrapper.querySelector(".file-name");
        const actions = wrapper.querySelector(".file-actions");

        const hasFile = !!file;

        if (hasFile) {

            // input 隱藏
            input.classList.add("d-none");

            // 顯示檔名
            nameEl.classList.remove("d-none");
            nameEl.textContent = file.name;

            // 顯示操作
            actions.classList.remove("d-none");

            const lineEl = wrapper.querySelector(".file-line");
            if (lineEl)
                lineEl.dataset.title = file.name;

        } else {

            // input 顯示
            input.classList.remove("d-none");

            // 清空 + 隱藏 name
            nameEl.textContent = "";
            nameEl.classList.add("d-none");

            // 隱藏 actions
            actions.classList.add("d-none");
        }
    },
    init(el, ctx) {
        const setFileUI = FilePlugin.setFileUI;
        if (!(el instanceof HTMLInputElement) || el.type !== "file") {
            return;
        }

        const wrapper = el.closest(".file-wrapper");

        if (!wrapper) {
            console.warn("FilePlugin: missing wrapper", el);
            return;
        }


        const store = FileRuntime.getStore();

        el.addEventListener("change", () => {

            const files = el.multiple
                ? Array.from(el.files || [])
                : el.files?.[0] || null;

            store.setTouched(ctx.stepKey, ctx.key);
            store.safeSet(ctx.stepKey, ctx.key, files);

            store.setStatus(ctx.stepKey, ctx.key, files ? "processing" : "idle");

            GraphV2.notify(ctx.stepKey, ctx.key, files);
            setFileUI(wrapper, files);
            //this.render(wrapper, files);
        });

        // =========================
        // ⭐ FIX：wrapper safe check
        // =========================


        wrapper.addEventListener("click", async (e) => {

            // =========================
            // preview button ONLY
            // =========================
            const previewBtn = e.target.closest(".file-preview-btn");
            if (previewBtn) {

                PreviewModule.openUploadModal({
                    stepKey: ctx.stepKey,
                    key: ctx.key,
                    mode: false // ⭐ single
                });

                return;
            }

            // =========================
            // remove button ONLY
            // =========================
            const removeBtn = e.target.closest(".file-remove");
            if (removeBtn) {

                el.value = "";

                store.safeSet(ctx.stepKey, ctx.key, null);
                store.setStatus(ctx.stepKey, ctx.key, "idle");

                GraphV2.notify(ctx.stepKey, ctx.key, null);
                setFileUI(wrapper, null);
                //this.render(wrapper, null);
                return;
            }
        });
        setFileUI(wrapper, store.get(ctx.stepKey, ctx.key));
        //this.render(wrapper, store.get(ctx.stepKey, ctx.key));
    },
    render(wrapper, files) {

        const actions = wrapper.querySelector(".file-actions");
        const name = wrapper.querySelector(".file-name");
        const lineEl = wrapper.querySelector(".file-line");
        if (lineEl)
            lineEl.dataset.title = file.name;
        const hasFile = files && (Array.isArray(files) ? files.length > 0 : true);

        // =========================
        // ⭐ 控制顯示/隱藏
        // =========================
        if (actions) {
            actions.classList.toggle("d-none", !hasFile);
        }

        if (name) {
            name.textContent = hasFile
                ? (Array.isArray(files) ? files[0].name : files.name)
                : "";
        }
    }

};


$(function () {
    $(document).on("click", ".btn-upload", function () {

        PreviewModule.openUploadModal({
            stepKey: $(this).data("step"),
            key: $(this).data("field") + "." + $(this).data("col"),
            mode: true // multi
        });
    });
});

$(document).on("hidden.bs.modal", "#uploadModal", function () {
    PreviewModule.resetPreview();
});