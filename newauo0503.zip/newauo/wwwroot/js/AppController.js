﻿window.Helpers = window.Helpers || {};

Helpers.stepNextWithConfirm = async function ({
    stepKey = "step1",
    nextStep = 2,
    storeKey = "decision",
    value,
    type
}) {

    const store = AppBootstrap.get("FlowStore");

    // 1️⃣ old / new compare
    const oldValue = store.get(stepKey, storeKey);

    const payload =
        oldValue
            ? {
                ...(oldValue.value ?? {}),
                ...(oldValue.type ? { type: oldValue.type } : {})
            }
            : undefined;
    const isFirstTime = typeof payload === "undefined";
    const mergedValue = {
        ...value,
        type
    };

    const isSame =
        JSON.stringify(payload ?? null) ===
        JSON.stringify(mergedValue ?? null);

    // 2️⃣ 如果不同 → confirm
    let forceReload = false;

    if (!isSame && !isFirstTime) {

        const ok = confirm("條件已改變，是否要重新載入下一步？");

        if (ok) {
            forceReload = true;
        }
    }

    // 3️⃣ 存新值
    store.safeSet(stepKey, storeKey, { type:type,value:value});

    // 4️⃣ goTo next step
    await window.AppController.goTo(nextStep);

    // 5️⃣ reload control（關鍵）
    if (forceReload) {
        await window.AppController.load?.();
    }

    return {
        isSame,
        forceReload
    };
};
window.FingerprintRegistry = (() => {

    const rules = {};

    return {

        register(stepKey, fn) {
            rules[stepKey] = fn;
        },

        build(stepKey) {

            const store = AppBootstrap.get("FlowStore");

            const ctx = {
                get: (key) => store.getStep(key),

                json: (key) => {
                    const v = store.getStep(key);
                    try { return JSON.parse(v); } catch { return v; }
                },

                currentStep: stepKey
            };

            if (rules[stepKey]) {
                return rules[stepKey](ctx);
            }

            return "{}";
        }
    };

})();

const FormStore = (() => {

    const state = Vue.reactive({ steps: {} });
    const errors = Vue.reactive({ steps: {} });
    const status = Vue.reactive({ steps: {} });

    const touched = {};
    const submitState = Vue.reactive({});
    const ensure = (step) => {

        state.steps[step] ||= {};
        errors.steps[step] ||= {};
        status.steps[step] ||= {};

        state.steps[step].__version ||= {};
        touched[step] ||= new Set();
    };

    return {
        markStepSubmitted(step) {
            submitState[step] = true;
        },

        unmarkStepSubmitted(step) {
            submitState[step] = false;
        },

        isStepSubmitted(step) {
            return !!submitState[step];
        },
        getStep(step) {
            ensure(step);
            return state.steps[step];
        },

        get(step, key) {
            ensure(step);
            return state.steps[step][key];
        },
        isStepValid(step) { ensure(step); return Object.values(errors.steps[step]).every(x => !x); },

        // =========================
        // 🚀 safe write (version aware)
        // =========================
        safeSet(step, key, val, meta = {}) {

            ensure(step);

            const stepObj = state.steps[step];

            const current = stepObj.__version[key] || 0;

            if (meta.version != null && meta.version < current) return;

            stepObj.__version[key] = current + 1;
            console.log("🔥 BEFORE SET:", step, key, stepObj);

            stepObj[key] = val;
            console.log("🔥 AFTER SET:", stepObj);

        },

        setError(step, key, val) {
            ensure(step);
            errors.steps[step][key] = val;
        },

        clearError(step, key) {
            ensure(step);
            errors.steps[step][key] = null;
        },

        getError(step, key) {
            return errors.steps?.[step]?.[key];
        },

        setStatus(step, key, val) {
            ensure(step);
            status.steps[step][key] = val;
        },

        getStatus(step, key) {
            return status.steps?.[step]?.[key];
        },

        setTouched(step, key) {
            ensure(step);
            touched[step].add(key);
        },

        isTouched(step, key) {
            return touched?.[step]?.has(key);
        },
        deleteField(step, key) {
            ensure(step);

            delete state.steps[step][key];
            delete errors.steps[step][key];
            delete status.steps[step][key];
            delete state.steps[step].__version[key];

            touched[step]?.delete(key);
        },

        clearStep(step) {
            state.steps[step] = { __version: {} };
            errors.steps[step] = {};
            status.steps[step] = {};
            touched[step] = new Set();
        },

        resetField(step, key) {
            ensure(step);

            state.steps[step][key] = null;
            errors.steps[step][key] = null;
            status.steps[step][key] = null;

            touched[step]?.delete(key);
        }
    };

})();
window.FlowStore = (() => {

    const toStepKey = (stepKey) => {
        let state = window.AppController.getState();
        if (!stepKey) return stepKey;

        const prefix = state.flowId + ".";

        if (stepKey.startsWith(prefix)) {
            return stepKey;
        }

        if (stepKey.includes(".")) {
            console.warn("⚠️ stepKey already has prefix:", stepKey);
            return stepKey;
        }

        return prefix + stepKey;
    };

    return {

        get(stepKey, key) {
            return FormStore.get(toStepKey(stepKey), key);
        },

        getStep(stepKey) {
            return FormStore.getStep(toStepKey(stepKey));
        },

        safeSet(stepKey, key, val, meta) {
            return FormStore.safeSet(toStepKey(stepKey), key, val, meta);
        },

        setError(stepKey, key, val) {
            return FormStore.setError(toStepKey(stepKey), key, val);
        },
        setStatus(stepKey, key, val) {
            return FormStore.setStatus(toStepKey(stepKey), key, val);
        },
        getStatus(stepKey, key) {
            return FormStore.getStatus(toStepKey(stepKey), key);
        },
        getError(stepKey, key) {
            return FormStore.getError(toStepKey(stepKey), key);
        },
        clearError(stepKey, key) {
            return FormStore.clearError(toStepKey(stepKey), key);
        },
        isTouched(stepKey, key) {
            return FormStore.isTouched(toStepKey(stepKey), key);
        },
        isStepValid(stepKey) {
            return FormStore.isStepValid(toStepKey(stepKey));
        },
        isStepSubmitted(stepKey) {
            return FormStore.isStepSubmitted(toStepKey(stepKey));
        },
        setTouched(stepKey, key) {
            return FormStore.setTouched(toStepKey(stepKey), key);
        },
        markStepSubmitted(stepKey) {
            return FormStore.markStepSubmitted(toStepKey(stepKey));
        },
        deleteField(stepKey, key) {
            return FormStore.deleteField(toStepKey(stepKey), key);
        },

        clearStep(stepKey) {
            return FormStore.clearStep(toStepKey(stepKey));
        },

        resetField(stepKey, key) {
            return FormStore.resetField(toStepKey(stepKey), key);
        }

    };

})();


window.AppController = (() => {

    const state = {
        flowId: "default", 
        stepsRef: null,
        currentStep: null,
        setStep: null,
        currentPage: null, 
        loading: false,
        _beforeHooks: []
    };
     
    function initSelect2(container) {
        function setSelect2Background(select) {
            let color = select.find("option:selected").data("color") || "";
            select.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }
        function formatOption(item) {
            if (!item.id) return item.text;
            let color = $(item.element).data("color") || "";
            return $('<div style="background:' + color + '; padding:4px 6px;">' + item.text + '</div>');
        }

        function formatSelection(item) { return item.text; }

        $(container).find("select.select2").each(function () {

            const $el = $(this);

            if ($el.data("select2")) return;

            $el.select2({
                width: "100%",
                placeholder: $el.attr("placeholder") || "請選擇",
                allowClear: true,
                templateResult: formatOption,
                templateSelection: formatSelection
            });
            setTimeout(() => {
                setSelect2Background($el);
            }, 0);
            $el.on("select2:select select2:clear", function () {
                setSelect2Background($el);
                // 🔥 強制同步 value
                const value = $el.val();

                // 🔥 直接用原生 dispatch（比 trigger 穩）
                $el[0].dispatchEvent(new Event("change", { bubbles: true }));
            });

            $el.trigger("change.select2");
        });
    }

    function getStepKey() {
        return `step${state.currentStep.value || 1}`;
    }
    async function runBeforeHooks(targetStep) {

        for (const hook of state._beforeHooks) {

            const ok = await hook({
                currentStep: state.currentStep.value,
                targetStep,
                state
            });

            if (!ok) return false;
        }

        return true;
    }
    async function init({ steps, currentStep, setStep }) {

        state.flowId = window.__FLOW_ID__ || "default";
        state.stepsRef = steps;
        state.currentStep = currentStep;
        state.setStep = setStep;
        await registerModules();
        //initInternalHooks();
        await load();

       
        const ribbon = document.querySelector('.wizard-ribbon');
        if (ribbon) {
            ribbon.style.setProperty('--total', steps.value.length);
        }
    }
    async function registerModules() {

        /*//AppBootstrap.register("FormStore", FormStore);*/
        AppBootstrap.register("StepLoader", StepLoader);
        AppBootstrap.register("FlowStore", FlowStore);
        //AppBootstrap.register("FormValidation", FormValidation);
        AppBootstrap.register("FilePlugin", FilePlugin);
        AppBootstrap.register("FieldBinder", FieldBinder);
        //AppBootstrap.register("ComputedRegistry", ComputedRegistry);
        //AppBootstrap.register("ComputedEngine", ComputedEngine);
        //if (window.FieldBinder)
        //    AppBootstrap.register("FieldBinder", FieldBinder);
        // 如果你有這些
        //if (window.FieldStatus)
        //    AppBootstrap.register("FieldStatus", FieldStatus);

        //if (window.ValidationCenter)
        //    AppBootstrap.register("ValidationCenter", ValidationCenter);

        await AppBootstrap.wait(); // 🔥 等全部 ready

        //const computed = AppBootstrap.get("ComputedEngine");
        //computed.init();
        //computed.enable();

    }

    function initInternalHooks() {

        state._beforeHooks.push(async ({ currentStep, targetStep }) => {

            // 👉 只處理 forward
            if (targetStep <= currentStep) return true;

            const stepKey = `step${targetStep}`;

            const newFp = FingerprintRegistry.build(stepKey);
            const oldFp = Helpers.getFp(stepKey);

            if (oldFp && oldFp !== newFp) {

                const ok = confirm("條件已變更，後續資料將清除，是否繼續？");

                if (!ok) return false;

                //clearAfter(currentStep);
            }

            Helpers.setFp(stepKey, newFp);

            return true;
        });
    }
     
     

    async function load() {

        if (state.loading) return;
        state.loading = true;

        try {


            const StepLoader = AppBootstrap.get("StepLoader");
            const stepIndex = state.currentStep.value;
            const stepKey = `step${stepIndex}`;  
            const container = await StepLoader.load(stepIndex, state); 
            state.currentPage = window.StepPages?.[stepKey]; 
            initSelect2(container)
            hydrateFields(container, stepKey); 

            const fieldBinder = AppBootstrap.get("FieldBinder");
            fieldBinder.bindFields(container, stepKey);
            return container;

        } finally {
            state.loading = false;
        }
    }
    function hydrateFields(container, stepKey) {
        //const store = AppBootstrap.get("FormStore");
        const store = AppBootstrap.get("FlowStore");
        container
            .querySelectorAll("input[data-field], select[data-field], textarea[data-field]")
            .forEach(el => {


                const rawCol = el.dataset.col;
                const col = rawCol && rawCol.trim() ? rawCol.trim() : null;
                const key = makeKey(el.dataset.field, col);

                const storeVal = store.get(stepKey, key);

                // 🟢 Store 優先
                if (storeVal !== undefined && storeVal !== null) {

                    if (el.type === "checkbox") {
                        el.checked = storeVal;

                    } else if (el.type === "radio") {
                        el.checked = (el.value === storeVal);

                    }
                    else if (el.type === "file") {

                        // ❌ 永遠不要回填 file input value

                        // ✅ 改成更新 UI 顯示區
                        const file = storeVal;

                        const wrapper = el.closest(".file-wrapper");

                        if (wrapper) {

                            const nameEl = wrapper.querySelector(".file-name");

                            if (file instanceof File) {
                                nameEl.textContent = file.name;
                                const lineEl = wrapper.querySelector(".file-line");
                                if (lineEl)
                                    lineEl.dataset.title = file.name;
                            }
                            else if (Array.isArray(file)) {
                                nameEl.textContent = file.length
                                    ? file.map(f => f.name).join(", ")
                                    : "";
                            }
                            else if (file?.name) {
                                nameEl.textContent = file.name;
                            }
                            else {
                                nameEl.textContent = "";
                            }
                        }
                    }
                    else {
                        el.value = storeVal;
                    }

                } else {

                    // 🔵 UI 補 Store（只做一次）
                    let val;

                    if (el.type === "checkbox") {
                        val = el.checked;

                    } else if (el.type === "radio") {

                        const checked = container.querySelector(
                            `input[data-field='${key}']:checked`
                        );

                        val = checked ? checked.value : null;

                    } else {
                        val = el.value;
                    }

                    if (val !== undefined && val !== null && val !== "") {
                        /*  const token = Symbol(`${stepKey}.${key}`);*/
                        store.safeSet(stepKey, key, val);
                    }
                }
            });
    }
    async function next() {

        const stepKey = getStepKey();
        //const store = AppBootstrap.get("FormStore");
        if (!store.isStepValid(stepKey)) {
            alert("請修正錯誤");
            return;
        }
       
        state.setStep(state.currentStep.value + 1);
        await load();
    }

    async function prev() {
        state.setStep(state.currentStep.value - 1);
        await load();
    }

    async function goTo(i) {
        const target = Number(i);

        // 🔥 先跑 hook
        const ok = await runBeforeHooks(target);

        if (!ok) return;

        state.setStep(target);
        await load();
    }

    async function finish() {
        //const store = AppBootstrap.get("FormStore");
        const payload = {};
        state.stepsRef.value.forEach(s => {
            payload[`step${s.StepIndex}`] = store.getDirty(`step${s.StepIndex}`);
            store.markStepSubmitted(`step${s.StepIndex}`);
        });

        console.log("FINAL:", payload);

        await fetch("/Home/Save", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
    }

    return {
        init,
        next,
        prev,
        goTo,
        finish,
        getState: () => state,
    };

})();