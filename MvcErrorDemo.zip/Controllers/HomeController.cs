using System.Web.Mvc;

namespace MvcErrorDemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ThrowError()
        {
            throw new System.Exception("模擬例外");
        }
    }
}
