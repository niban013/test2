using System.Web.Mvc;

namespace MvcErrorDemo.Controllers
{
    public class ErrorController : Controller
    {
        public ActionResult GenericError()
        {
            Response.StatusCode = 500;
            return View();
        }

        public ActionResult NotFound()
        {
            Response.StatusCode = 404;
            return View();
        }
    }
}
