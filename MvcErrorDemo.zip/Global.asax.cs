using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace MvcErrorDemo
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Application_Error()
        {
            Exception ex = Server.GetLastError();
            LogError(ex);

            var httpEx = ex as HttpException;
            int httpCode = httpEx?.GetHttpCode() ?? 500;

            Server.ClearError();
            Response.Clear();

            string redirectUrl = "~/Error/GenericError";
            if (httpCode == 404)
                redirectUrl = "~/Error/NotFound";

            Response.Redirect(redirectUrl);
        }

        private void LogError(Exception ex)
        {
            System.IO.File.AppendAllText(Server.MapPath("~/App_Data/error.log"),
                $"[{DateTime.Now}] {ex}\n");
        }
    }
}
