using System;
using System.Web.Mvc;

namespace MvcErrorDemo.Filters
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            if (context.ExceptionHandled)
                return;

            Exception ex = context.Exception;
            LogError(ex);

            context.ExceptionHandled = true;
            context.Result = new ViewResult
            {
                ViewName = "~/Views/Error/GenericError.cshtml"
            };
        }

        private void LogError(Exception ex)
        {
            System.IO.File.AppendAllText(
                System.Web.HttpContext.Current.Server.MapPath("~/App_Data/error.log"),
                $"[{DateTime.Now}] {ex}\n"
            );
        }
    }
}
