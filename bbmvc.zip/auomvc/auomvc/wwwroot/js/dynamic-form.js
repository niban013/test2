﻿
function buildContext($el, val, vm, form, key, name) {
    return {
        val,
        el: $el,
        vm,
        form,
        tabKey: key,
        field: name,

        type: resolveType($el),

        must: $el.data("must"),
        pattern: $el.data("pattern"),
        minlength: $el.data("minlength"),
        maxlength: $el.data("maxlength"),
        min: $el.attr("min"),
        max: $el.attr("max"),
        conditional: $el.data("conditional"),
        cross: $el.data("cross"),
        asyncUrl: $el.data("async")
    };
}

const ControlRuleMap = {

    text: ["required", "pattern", "minlength", "maxlength"],
    textarea: ["required", "minlength", "maxlength"],

    number: ["required", "min", "max"],

    date: ["required", "min", "max"],

    select: ["required"],

    checkbox: ["required"],

    file: [] // ⭐ 完全跳過（或只留 required 看需求）
};
const ValidatorRules = {

    required: {
        validate: (val, ctx) => {
            if (ctx.must && (val === "" || val == null)) return "必填";
            return true;
        }
    },

    pattern: {
        validate: (val, ctx) => {
            if (!ctx.pattern || !val) return true;
            return new RegExp(ctx.pattern).test(val) || "格式錯誤";
        }
    },

    minlength: {
        validate: (val, ctx) => {
            if (!ctx.minlength || !val) return true;
            return val.length >= ctx.minlength || `至少${ctx.minlength}字`;
        }
    },

    maxlength: {
        validate: (val, ctx) => {
            if (!ctx.maxlength || !val) return true;
            return val.length <= ctx.maxlength || `最多${ctx.maxlength}字`;
        }
    },

    min: {
        validate: (val, ctx) => {
            if (!ctx.min || !val) return true;

            // ⭐ 日期 or 數字
            if (ctx.type === "date") {
                return new Date(val) >= new Date(ctx.min) || `不可小於${ctx.min}`;
            }

            return parseFloat(val) >= parseFloat(ctx.min) || `不可小於${ctx.min}`;
        }
    },

    max: {
        validate: (val, ctx) => {
            if (!ctx.max || !val) return true;

            if (ctx.type === "date") {
                return new Date(val) <= new Date(ctx.max) || `不可大於${ctx.max}`;
            }

            return parseFloat(val) <= parseFloat(ctx.max) || `不可大於${ctx.max}`;
        }
    },

    conditional: {
        validate: (val, ctx) => {
            if (!ctx.conditional) return true;

            let cond = JSON.parse(ctx.conditional);
            if ($(cond.selector).val() && val === "") {
                return "條件必填";
            }
            return true;
        }
    },

    cross: {
        validate: (val, ctx) => {
            if (!ctx.cross) return true;

            let c = JSON.parse(ctx.cross);
            let otherVal = $(c.selector).val();

            if (c.op === ">" && val && otherVal) {
                return parseFloat(val) > parseFloat(otherVal) || `必須大於${c.selector}`;
            }
            return true;
        }
    }

};

 
function setSelect2ByValue($el, value) {
    const url = $el.data("async");

    $.ajax({
        url: url,
        data: { id: value }
    }).then(function (data) {
        if (data.items && data.items.length > 0) {
            const item = data.items[0];

            const option = new Option(item.text, item.id, true, true);
            $el.append(option).trigger('change');
        }
    });
}

var DynamicForm = (function () {

    class PageVM {
        constructor() {
            this.forms = [];

            // ⭐ 以 tabKey 分隔 scope
            this._scopedData = {};      // { tabKey: { fieldName: value } }
            this._watchers = {};        // { tabKey: { fieldName: [fn,...] } }
            this._computed = {};        // { tabKey: { fieldName: fn } }
            this._computedCache = {};   // { tabKey: { fieldName: value } }
            this._dirty = {};           // { tabKey: Set }
            this._validators = {}; // ⭐ NEW
            this._customData = {};  // 任何你想存的資料
            this._fileData = {}; // { tabKey: { fieldName: File } }
            this._pagePath = window.location.pathname; // 標記這台 VM 屬於哪一頁
        }

        register(form) {
            this.forms = this.forms.filter(f => f.key !== form.key);
            this.forms.push(form);
            const key = form.key;

            // ⭐ 初始化 tab scope
            if (!this._scopedData[key]) this._scopedData[key] = {};
            if (!this._dirty[key]) this._dirty[key] = new Set();
            if (!this._watchers[key]) this._watchers[key] = {};
            if (!this._computed[key]) this._computed[key] = {};
            if (!this._computedCache[key]) this._computedCache[key] = {};

            // ⭐ 初始化欄位值
            Object.entries(form.fieldCache).forEach(([k, v]) => {
                if (this._scopedData[key][k] === undefined) {
                    this._scopedData[key][k] = v;
                }
            });

            // ⭐ 建立 tab 專屬 proxy
            const proxy = new Proxy(this._scopedData[key], {
                set: (target, name, value) => {
                    const old = target[name];
                    if (old === value) return true;

                    target[name] = value;

                    // ⭐ dirty
                    this._dirty[key].add(name);

                    if (typeof value === "object") {
                        return true;
                    }
                    // ⭐ 更新當前 form
                    setTimeout(() => {
                        const $el = form.fieldMap[name];
                        if ($el) {
                            form.validateField($el[0]).catch(console.error);
                        }
                    }, 0);

                    // ⭐ watch
                    if (this._watchers[key][name]) {
                        this._watchers[key][name].forEach(fn => fn(value, old));
                    }

                    // ⭐ computed cache 清掉
                    this._computedCache[key] = {};

                    return true;
                },
                get: (target, name) => {
                    if (this._computed[key][name]) {
                        if (this._computedCache[key][name] === undefined) {
                            this._computedCache[key][name] = this._computed[key][name].call(proxy);
                        }
                        return this._computedCache[key][name];
                    }
                    return target[name];
                }
            });

            // ⭐ 原本 form.proxy
            form.proxy = proxy;

            // ⭐ 直接掛到 VM 物件上
            this[key] = proxy;
        }

        // ========= API =========
        $watch(tabKey, name, fn) {
            if (!this._watchers[tabKey][name]) this._watchers[tabKey][name] = [];
            this._watchers[tabKey][name].push(fn);
        }

        $computed(tabKey, name, fn) {
            this._computed[tabKey][name] = fn;
        }

        $dirty(tabKey) {
            const result = {};
            this._dirty[tabKey].forEach(k => result[k] = this._scopedData[tabKey][k]);
            return result;
        }

        $resetDirty(tabKey) {
            this._dirty[tabKey].clear();
        }

        cache() {
            this.forms.forEach(f => f.cache());
        }

        restore() {
            this.forms.forEach(f => f.restore());
        }

        async validate() {
            const results = await Promise.all(this.forms.map(f => f.validateAll()));
            return results.every(r => r);
        }

        async getJsonString() {
            this.cache();

            let finalPayload = {};
            const isValid = await this.validate();

            if (isValid) {
                this.forms.forEach(f => {

                    const data = { ...this._scopedData[f.key] };

                    // ⭐🔥 過濾 File → 只留檔名
                    Object.keys(data).forEach(k => {
                        if (data[k] instanceof File) {
                            data[k] = data[k].filename;
                        }
                    });

                    finalPayload[f.key] = data;
                });
            }

            return JSON.stringify(finalPayload, null, 4);
        }

        showCache() {
            this.forms.forEach(f => {
                console.log(`Cache for ${f.key}:`, f.fieldCache);
            });
        }
        // ⭐ NEW：註冊自訂驗證
        $validator(tabKey, field, fn) {
            if (!this._validators[tabKey]) this._validators[tabKey] = {};
            if (!this._validators[tabKey][field]) this._validators[tabKey][field] = [];

            this._validators[tabKey][field].push(fn);
        }
        setCustom(tabKey, key, value) {
            if (!this._customData[tabKey]) this._customData[tabKey] = {};
            this._customData[tabKey][key] = value;
        }

        getCustom(tabKey, key) {
            return this._customData[tabKey]?.[key];
        }




        // ⭐ 設定檔案
        setFile(tabKey, field, file, options = {}) {
            //if (!this._fileData[tabKey]) this._fileData[tabKey] = {};

            //if (!this._fileData[tabKey][field]) {
            //    this._fileData[tabKey][field] = [];
            //}

            if (!this._scopedData[tabKey]) this._scopedData[tabKey] = {};

            if (!this._scopedData[tabKey][field]) {
                this._scopedData[tabKey][field] = [];
            }
          

            // 非同步驗證
            if (options.validate) {
                const { maxSizeMB, allowedTypes } = options;

                if (maxSizeMB && file.size > maxSizeMB * 1024 * 1024) {
                    throw new Error(`檔案超過 ${maxSizeMB} MB`);
                }

                if (allowedTypes && !allowedTypes.includes(file.file.type)) {
                    throw new Error(`檔案類型不允許: ${file.type}`);
                }
            }
            this._scopedData[tabKey][field].push(file);
        }

        // ⭐ 刪除特定檔案
        removeFile(tabKey, field, identifier) {
            const files = this._scopedData[tabKey]?.[field];
            if (!files) return;

            if (typeof identifier === 'number') {
                // 💡 如果 identifier 是數字，按索引刪除
                if (Array.isArray(files)) {
                    files.splice(identifier, 1);
                } else {
                    delete this._scopedData[tabKey][field];
                }
            } else if (typeof identifier === 'string') {
                // 💡 如果 identifier 是字串，按檔名刪除
                if (Array.isArray(files)) {
                    this._scopedData[tabKey][field] = files.filter(f => f.filename !== identifier);
                } else if (files.filename === identifier) {
                    delete this._scopedData[tabKey][field];
                }
            }

            // 💡 小優化：如果刪完後陣列空了，就把該欄位清掉
            if (Array.isArray(this._scopedData[tabKey][field]) && this._scopedData[tabKey][field].length === 0) {
                delete this._scopedData[tabKey][field];
            }
        }
        clearFiles(tabKey, field) {
            if (this._scopedData[tabKey]) delete this._scopedData[tabKey][field];
        }
        // ⭐ 取得檔案
        async getFilesByField(tabKey, field) {
            // 先看本地是否已有
            let file = this._scopedData[tabKey]?.[field];
            if (file) return file;

            // ⭐ 後端抓檔案方法
            const fetchBackendFile = async (tabKey, field) => {
                const res = await fetch(`/api/file/${tabKey}/${field}`);
                if (!res.ok) throw new Error(`Fetch failed: ${res.status}`);
                const blob = await res.blob();
                return {
                    name: `${field}.pdf`, // 或從 headers/後端傳回真實檔名
                    type: blob.type,
                    byteArray: new Uint8Array(await blob.arrayBuffer())
                };
            };

            try {
                const backendFile = await fetchBackendFile(tabKey, field);
                if (!this._scopedData[tabKey]) this._scopedData[tabKey] = {};
                const newFile = new File([backendFile.byteArray], backendFile.name, { type: backendFile.type });
                this._scopedData[tabKey][field] = newFile;
            } catch (err) {
                console.error("從後端抓檔案失敗", err);
                return this._scopedData[tabKey]?.[field] || [];
                /*                throw err;*/
            }

            return this._scopedData[tabKey]?.[field] || [];
        }

        getFilename(tabKey, field) {
            return this._scopedData[tabKey]?.[field]?.filename || "";
        }
        // ⭐ 取得整個 tab 的檔案集合
        getFiles(tabKey) {
            return this._scopedData[tabKey] || [];
        }
        // inline file preview
        async previewFile(tabKey, file) {

            if (file instanceof File) {

            } else if (typeof file === "string") {

                file = { name: file, lazy: true };
            }

            if (!file) return;

            const win = window.open("", "_blank", "width=1000,height=700");
            if (!win) {
                alert("請允許彈出視窗");
                return;
            }

            // ⭐ lazy load
            if (file?.lazy) {
                const realFile = await this.getFilesByField(tabKey, file.name);
                if (!realFile) {
                    win.close();
                    alert("下載失敗");
                    return;
                }
                file = realFile[0].file;
            }

            const url = URL.createObjectURL(file);

            // ===== 內部專用 helper: 圖片/PDF互動 =====
            const _initPreviewInteraction = (type, targetId, sliderId, options = {}) => {
                const el = win.document.getElementById(targetId);
                const slider = win.document.getElementById(sliderId);
                if (!el || !slider) return;

                let scale = 1;
                let translateX = 0, translateY = 0;
                let isDragging = false;
                let startX, startY;

                const minScale = options.minScale || 0.5;
                const maxScale = options.maxScale || 5;
                const step = options.step || 0.01;

                const applyTransform = () => {
                    if (type === "image") {
                        el.style.transform = `scale(${scale}) translate(${translateX}px, ${translateY}px)`;
                    } else if (type === "pdf") {
                        el.style.transformOrigin = "top left";
                        el.style.transform = `scale(${scale})`;
                    }
                };

                slider.min = minScale;
                slider.max = maxScale;
                slider.step = step;
                slider.value = scale;

                slider.oninput = e => {
                    scale = parseFloat(e.target.value);
                    applyTransform();
                };

                if (type === "image") {
                    el.style.cursor = "grab";
                    el.onwheel = e => {
                        e.preventDefault();
                        scale += e.deltaY * -0.001;
                        scale = Math.min(Math.max(minScale, scale), maxScale);
                        applyTransform();
                        slider.value = scale;
                    };
                    el.onmousedown = e => {
                        isDragging = true;
                        startX = e.clientX - translateX;
                        startY = e.clientY - translateY;
                        el.style.cursor = "grabbing";
                    };
                    win.document.onmouseup = () => {
                        isDragging = false;
                        el.style.cursor = "grab";
                    };
                    win.document.onmousemove = e => {
                        if (!isDragging) return;
                        translateX = e.clientX - startX;
                        translateY = e.clientY - startY;
                        applyTransform();
                    };
                }

                if (type === "pdf" && options.zoomInId && options.zoomOutId) {
                    const zoomInBtn = win.document.getElementById(options.zoomInId);
                    const zoomOutBtn = win.document.getElementById(options.zoomOutId);
                    if (zoomInBtn) zoomInBtn.onclick = () => { scale = Math.min(scale + 0.1, maxScale); applyTransform(); slider.value = scale; };
                    if (zoomOutBtn) zoomOutBtn.onclick = () => { scale = Math.max(scale - 0.1, minScale); applyTransform(); slider.value = scale; };
                }
            };

            // ===== 決定內容 =====
            let content = "";
            if (file.type.startsWith("image/")) {
                content = `
        <div style="display:flex; flex-direction:column; align-items:center; width:100%; height:100%;">
            <img id="previewImg" src="${url}" 
                 style="max-width:100%; max-height:80%; cursor:grab; transform:scale(1);" />
            <input type="range" id="imgZoom" min="0.5" max="5" step="0.01" value="1" style="width:80%; margin-top:5px;">
        </div>`;
            } else if (file.type === "application/pdf") {
                content = `
        <div style="display:flex; flex-direction:column; height:100%; width:100%;">
            <div style="display:flex; gap:5px; padding:5px; align-items:center;">
                <button id="pdfZoomIn">+</button>
                <button id="pdfZoomOut">-</button>
                <input type="range" id="pdfZoomSlider" min="0.5" max="3" step="0.01" value="1" style="flex:1;">
            </div>
            <iframe id="pdfFrame" src="${url}" style="width:100%; flex:1; border:none;"></iframe>
        </div>`;
            } else {
                // fallback: 下載
                const a = document.createElement("a");
                a.href = url;
                a.download = file.name;
                a.click();
                URL.revokeObjectURL(url);
                return;
            }

            // ===== render =====
            win.document.body.style.margin = "0";
            win.document.body.innerHTML = `
    <div style="height:100%; display:flex; flex-direction:column;">
        <div style="padding:5px; background:#f1f1f1;">${file.name}</div>
        <div id="content" style="flex:1; display:flex; justify-content:center; align-items:center;">
            ${content}
        </div>
    </div>`;

            // ===== 初始化互動 =====
            if (file.type.startsWith("image/")) {
                _initPreviewInteraction("image", "previewImg", "imgZoom");
            } else if (file.type === "application/pdf") {
                _initPreviewInteraction("pdf", "pdfFrame", "pdfZoomSlider", {
                    minScale: 0.5,
                    maxScale: 3,
                    step: 0.01,
                    zoomInId: "pdfZoomIn",
                    zoomOutId: "pdfZoomOut"
                });
            }

            // ===== 清理 ObjectURL =====
            win.addEventListener("beforeunload", () => URL.revokeObjectURL(url));
        }

        // ⭐ 處理檔案輸入（inline / modal 共用）
        async handleFileInput(tabKey, field, file, options) {
            if (!file?.lazy) {
                this.setFile(tabKey, field, file);
            }


            if (options.inline) {
                const $group = options.$group;
                const $previewBtn = $group.find(".preview-btn");
                const $deleteBtn = $group.find(".delete-btn");
                const $filenameLabel = $group.find(".filename-label");
                const $input = options.$input;

                $filenameLabel.text(file.name);
                $previewBtn.show();
                $deleteBtn.show();

                $deleteBtn.off("click").on("click", () => {
                    $input.val(null);
                    $filenameLabel.text("未選檔案");
                    $previewBtn.hide();
                    $deleteBtn.hide();
                    this.removeFile(tabKey, field);
                });

                $previewBtn.off("click").on("click", async () => {

                    await this.previewFile(tabKey, file);
                });
            }
            else if (options.modal) {
                const $fileList = options.$fileList;
                const $li = $(`
                    <li class="list-group-item d-flex justify-content-between align-items-center flex-column align-items-start">
                        <div class="d-flex justify-content-between w-100 align-items-center">
                            <span>${file.name} (${Math.round(file.size / 1024)} KB)</span>
                            <button type="button" class="btn btn-sm btn-danger btn-delete">刪除</button>
                        </div>
                        <div class="file-preview mt-2"></div>
                    </li>
                `);
                $fileList.append($li);

                $li.find(".btn-delete").click(() => {
                    $li.remove();
                    this.removeFile(tabKey, field);
                });
            }
        }



    }
    // =========================
    // ⭐ Form Instance
    // =========================
    class DynamicFormInstance {
        constructor(container, sharedVm) {
            this.container = $(container);
            this.fields = this.container.find("[vmodel]");
            //this.fields = this.container.find("[vmodel]").filter(function () {
            //    const $el = $(this);
            //    return $el.is(":visible") || resolveType($el);
            //});
            this.vm = sharedVm; // 使用傳入的共用 VM  
            this.key = this.container.data("df"); // ⭐ 每個 tab 的 key
            this.fieldCache = {};
            this.asyncCache = {};
            this.asyncTokens = {};
            this.data = {};
            this.fieldMap = {};

            this.proxyData = new Proxy(this.data, {
                set: (target, key, value) => {
                    if (target[key] === value) return true;
                    target[key] = value;
                    this.updateField(key, value, false);
                    return true;
                }
            });

            this.init();

            // ⭐ 自動註冊到 VM
            this.vm.register(this);
            this.container.data("df-initialized", true);
            //this.bindFileInputs();
            this.restoreFiles();
        }



        init() {
            this.fields.each((_, el) => {

                const $el = $(el);
                const name = $el.attr("id") || $el.attr("name");
                if (!name) return;

               
                const isInput = $el.is("input, select, textarea");
                /*let isFile = resolveType($el) === "file";*/

                // ⭐ NEW：判斷 hybrid
                const $hybrid = $el.closest(".hybrid-input");
                const isHybridChild = $hybrid.length > 0;

                // =========================================
                // ⭐ ① Hybrid 優先處理（直接跳過原流程🔥）
                // =========================================
                if (isHybridChild) {

                    const fieldName = $hybrid.data("field") || name;
                    if (!this.fieldMap[fieldName]) {

                        const $txt = $hybrid.find('[data-hybrid-role="textbox"]');

                        // 🔥【關鍵】統一註冊
                        this.fieldMap[fieldName] = $txt;
                    }
                    const hybridVal = this.vm._scopedData?.[this.key]?.[fieldName];

                    const $chk = $hybrid.find('[data-hybrid-role="checkbox"]');
                    const $txt = $hybrid.find('[data-hybrid-role="textbox"]');
                    this.fieldMap[name] = $txt; 
                    const fieldSuffix = fieldName; // 用於內部 VM key 命名

                    if (hybridVal) {
                        // ⭐ restore
                        $chk.prop("checked", hybridVal.enabled);
                        $txt.val(hybridVal.value || "");
                        $txt.prop("disabled", !hybridVal.enabled);

                        console.log(`[Hybrid Restore] ${fieldName}`, hybridVal);
                    } else {
                        // ⭐ 初始化 VM
                        const initVal = {
                            enabled: $chk.is(":checked"),
                            value: $txt.val() || ""
                        };

                        (this.vm._scopedData[this.key] ||= {})[fieldName] = initVal;

                        // 同步 UI
                        $txt.prop("disabled", !initVal["chk" + fieldSuffix]);

                        console.log(`[Hybrid Init] ${fieldName}`, initVal);
                    }

                    return; // ⭐🔥 完全跳過原本 input 流程
                }

                // =========================================
                // ⭐ ② 一般欄位（原本邏輯，簡化版）
                // =========================================
                if (isInput) {

                   
                    if (!$el.parent().hasClass("input-with-status") && !(resolveType($el) === "file")) {
                        $el.wrap('<div class="input-with-status"></div>');
                    }
                    if ($el.hasClass("select2")) {
                        if (!$el.hasClass("select2-hidden-accessible")) {
                            this.initSelect2($el);
                        }
                    }
                    const savedValue = (this.vm._scopedData[this.key] || {})[name];

                  

                    if (savedValue !== undefined && savedValue !== null && savedValue !== "") {

                        if (resolveType($el) === "file") {

                            // ⭐⭐⭐ file 不能用 val → 改用 UI restore
                            const fileObj = {
                                name: savedValue[0].filename,
                                lazy: true // ⭐ 讓 preview 時再抓
                            };

                            const $group = $el.closest(".dynamic-file");

                            ValueHandler.set($el, fileObj, {
                                vm: this.vm,
                                tabKey: this.key,
                                field: name,
                                inline: true
                            });

                            console.log(`[${this.key}] Restore FILE ${name}:`, savedValue);

                        } else {
                            if (resolveType($el) === "select2") {
                                setSelect2ByValue($el, savedValue);
                            }
                            else { 
                                // ⭐ 一般欄位
                                $el.val(savedValue);
                            } 
                            console.log(`[${this.key}] Restore ${name}:`, savedValue);
                        }

                    } else {

                        if ($el.hasClass("dropdownColor")) {
                            let color = $el.find("option:selected").data("color");
                            $el.css("background-color", color);
                        }

                        const currentVal = ValueHandler.get($el);

                        (this.vm._scopedData[this.key] ||= {})[name] = currentVal;

                        console.log(`[${this.key}] Init ${name}:`, currentVal);
                    }
                }

                // =========================================
                // ⭐ ③ 共用收尾（不動）
                // =========================================
                this.fieldMap[name] = $el;
                this.clearStatusIcon($el);

                const finalVal = ValueHandler.get($el);
                this.fieldCache[name] = finalVal;
                this.proxyData[name] = finalVal;

              

                this.clearStatusIcon($el);

                if (!(resolveType($el) === "file") && finalVal.length > 0) {
                    this.setStatusIcon($el, 'success');
                }
            });

            this.bindEvents();
            this.bindHybridControls(); // ⭐ 保留
        }

        // ====================
        // ⭐ 檔案綁定
        // ====================
        bindFileInputs() {
            const self = this;

            //this.container.on("click", ".uploadBtn", e => {
            //    const $btn = $(e.currentTarget);
            //    const colId = $btn.data("name");
            //    const tabKey = this.key; // 這裡的 this.key 就是 tabKey (如 SupplierVCSection)

            //    // 將值填入 Modal 的隱藏欄位
            //    $('#currentField').val(colId);
            //    $('#currentTabKey').val(tabKey);

            //    // 💡 呼叫全域的 renderFileList 來顯示該欄位已有的檔案
            //    //if (typeof window.renderFileList === "function") {
            //    //    window.renderFileList(tabKey, colId);
            //    //}

            //    // 顯示 Modal
            //    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('uploadModal'));
            //    modal.show();
            //});


            //this.container.on("change", 'input[type="file"]', function () {
            //    const $input = $(this);
            //    const field = $input.attr("name");
            //    let files = Array.from(this.files);

            //    // 非同步可客製驗證，例如大小、類型
            //    const maxSizeMB = $input.data("maxsize") || 5;
            //    const acceptTypes = ($input.attr("accept") || "").split(",");

            //    files = files.filter(f => {
            //        if (f.size / 1024 / 1024 > maxSizeMB) {
            //            alert(`${f.name} 超過 ${maxSizeMB}MB`);
            //            return false;
            //        }
            //        if (acceptTypes.length && !acceptTypes.includes(f.type)) {
            //            alert(`${f.name} 類型不符`);
            //            return false;
            //        }
            //        return true;
            //    });

            //    self.vm.setFile(self.key, field, files);
            //    self.showFilePreview($input, files);
            //});

            //// 刪除檔案
            //this.container.on("click", ".file-remove-btn", function () {
            //    const $btn = $(this);
            //    const $wrapper = $btn.closest(".file-item");
            //    const field = $wrapper.data("field");
            //    const fileName = $wrapper.data("filename");
            //    self.vm.removeFile(self.key, field, fileName);
            //    $wrapper.remove();
            //});

            //// ⭐ 拖拉上傳效果
            //this.container.on("dragover", ".dropzone", function (e) {
            //    e.preventDefault(); e.stopPropagation();
            //    $(this).addClass("dragover");
            //});
            //this.container.on("dragleave drop", ".dropzone", function (e) {
            //    e.preventDefault(); e.stopPropagation();
            //    $(this).removeClass("dragover");
            //});
            //this.container.on("drop", ".dropzone", function (e) {
            //    const dt = e.originalEvent.dataTransfer;
            //    const files = Array.from(dt.files);
            //    const $input = $(this).find('input[type="file"]');
            //    $input[0].files = e.originalEvent.dataTransfer.files;
            //    $input.trigger("change");
            //});
        }

        //showFilePreview($input, files) {
        //    const $container = $input.closest(".input-with-status");
        //    $container.find(".file-list").remove();
        //    const $list = $('<div class="file-list"></div>');

        //    files.forEach(f => {
        //        const ext = f.name.split('.').pop().toLowerCase();
        //        let preview = '';

        //        if (['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) {
        //            const reader = new FileReader();
        //            reader.onload = e => {
        //                const imgHtml = `<img src="${e.target.result}" class="file-thumb" style="max-width:80px; max-height:80px; margin-right:5px;">`;
        //                $list.append(`<div class="file-item" data-field="${$input.attr("name")}" data-filename="${f.name}">${imgHtml}<span>${f.name}</span><button type="button" class="file-remove-btn btn btn-sm btn-danger">刪除</button></div>`);
        //            };
        //            reader.readAsDataURL(f);
        //        } else {
        //            $list.append(`<div class="file-item" data-field="${$input.attr("name")}" data-filename="${f.name}"><span>${f.name}</span><button type="button" class="file-remove-btn btn btn-sm btn-danger">刪除</button></div>`);
        //        }
        //    });

        //    $container.append($list);
        //}

        restoreFiles() {
            const tabData = this.vm._scopedData[this.key] || {};

            // 💡 改為：遍歷容器內「所有的上傳按鈕」
            this.container.find('.uploadBtn').each((index, el) => {
                const $btn = $(el);
                const field = $btn.data('name'); // 取得欄位名稱
                const files = tabData[field] || []; // 如果 tabData 沒這欄位，就給空陣列

                // 定位到狀態格 (Status TD)
                const $statusTd = $btn.closest('td').next('td');

                if (files.length > 0) {
                    // ⭐ 狀態 A：有檔案 (顯示成功圖示 + 數量)
                    $statusTd.html(`
                <i class="bi bi-check-circle-fill text-success"></i>
                <span class="badge rounded-pill bg-success ms-1">${files.length}</span>
            `);
                } else {
                    // ⭐ 狀態 B：無檔案 (清空 Badge 並還原為紅色叉叉)
                    // 這樣即便 tabData 是空的，也會因為跑遍所有按鈕而把舊的狀態刷掉
                    $statusTd.html(`<i class="bi bi-x-circle text-danger"></i>`);
                }
            });
            //Object.entries(tabData).forEach(([field, files]) => {
            //    // 1. 找到該欄位的「上傳按鈕」
            //    const $uploadBtn = this.container.find(`.uploadBtn[data-name="${field}"]`);

            //    if ($uploadBtn.length) {
            //        // 2. 定位到「下一個單元格」 (Status TD)
            //        const $statusTd = $uploadBtn.closest('td').next('td');

            //        if (files && files.length > 0) {
            //            // ⭐ 狀態 A：有檔案 (更換為成功圖示 + Badge)
            //            $statusTd.html(`<i class="bi bi-check-circle-fill text-success"></i>
            //                            <span class="badge rounded-pill bg-success ms-1">${files.length}</span>
            //                        `);
            //        } else {
            //            // ⭐ 狀態 B：無檔案 (還原為原本的失敗圖示)
            //            $statusTd.html(`<i class="bi bi-x-circle text-danger"></i>`);
            //        }
            //    }
            //});
        }


        restoreFilesbk() {
            Object.entries(this.vm._scopedData[this.key] || {}).forEach(([field, files]) => {
                const $el = this.container.find(`[name="${field}"]`);
                if ($el.length && files && files.length) this.showFilePreview($el, files);
            });
        }

        initSelect2($el) {
            const url = $el.data("async");
            const placeholder = $el.data("placeholder");
            $el.select2({
                width: '100%',
                placeholder: placeholder,
                minimumInputLength: 0,
                ajax: {
                    url: url,   // MVC Action
                    dataType: 'json',
                    delay: 300,
                    data: function (params) {
                        return {
                            term: params.term,   // 使用者輸入
                            page: params.page || 1
                        };
                    },
                    processResults: function (data, params) {
                        params.page = params.page || 1;

                        return {
                            results: data.items,
                            pagination: {
                                more: data.hasMore   // ⭐ 關鍵：是否還有下一頁
                            }
                        };
                    },
                    cache: true
                }
                ,


                templateResult: item =>
                    item.id
                        ? $(`<div style="background:${$(item.element).data("color") || ''};padding:4px 6px;">${item.text}</div>`)
                        : item.text,
                templateSelection: item => item.text
            }).on("select2:select select2:unselect change", () => {
                this.updateSelect2Background($el);
                const name = $el.attr("id") || $el.attr("name");
                this.proxyData[name] = ValueHandler.get($el);
                this.validateField($el);
            });

            this.updateSelect2Background($el);
        }

        updateSelect2Background($el) {
            const color = $el.find("option:selected").data("color") || "";
            $el.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }
        updateLocalData(name, value) {
            this.fieldCache[name] = value;
            // ⚠️ 不要再寫 proxyData，避免觸發 Proxy
            // this.proxyData[name] = value;
            if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};
            this.vm._scopedData[this.key][name] = value;
        }

        updateField(name, value, validate = true) {
            const $el = this.fieldMap[name];
            if (!$el) return;

            const current = ValueHandler.get($el);

            if (JSON.stringify(current) === JSON.stringify(value)) return;

            const isFileDisplay = $el.closest(".dynamic-file-show").length > 0;

            if (isFileDisplay && value) {

                const file = typeof value === "object"
                    ? value
                    : {
                        name: value,
                        lazy: true
                    };

                ValueHandler.set($el, file, {
                    silent: !validate,
                    vm: this.vm,
                    tabKey: this.key,
                    field: name
                });
            }
            else {
                // ⭐ 一般欄位（統一入口）
                ValueHandler.set($el, value, { silent: !validate });
            }

            //if (!this.isEditableField($el)) {

            //    $el.text(value);


            //    const $group = $el.closest(".dynamic-file-show");
            //    if ($group.length > 0) {
            //        const file = {
            //            name: "example.pdf",
            //            size: 1024 * 200,  // 200 KB
            //            id: "abc123",      // 後端識別用
            //            blob: null,         // 目前沒載入 byte
            //            lazy: true
            //        };
            //        this.vm.handleFileInput(this.key, name, file, { inline: true, $group, $input: $el });

            //    }
            //}

            if (validate) {
                this.validateField($el).catch(err => {
                    console.error("validate error:", err);
                });
            }

            this.updateLocalData(name, value);
        }

        //setStatusIcon($el, status, msg = "") {


        //    if ($el.is(":radio")) {
        //        $el = $el.closest(".radio-group");
        //    }

        //    const $w = $el.hasClass("radio-group")
        //        ? $el
        //        : $el.parent(".input-with-status");

        //    $w.find(".status-icon").remove();
        //    this.clearStatusIcon($el);
        //    this.clearError($el);

        //    const icons = {
        //        success: '<i class="bi bi-check-circle text-success"></i>',
        //        error: '<i class="bi bi-x-circle text-danger"></i>',
        //        processing: '<i class="bi bi-arrow-repeat rotate text-primary"></i>'
        //    };

        //    if (status) $w.append(`<span class="status-icon">${icons[status]}</span>`).addClass("has-icon");
        //    if (msg) this.showFieldError($el, msg);
        //}
        setStatusIcon($el, status) {
            if ($el.is(":radio")) {
                $el = $el.closest(".radio-group");
            }

            const $w = $el.hasClass("radio-group")
                ? $el
                : $el.parent(".input-with-status");

            $w.find(".status-icon").remove();
            this.clearStatusIcon($el);
            this.clearError($el);

            const val = ValueHandler.get($el);
            if ($el.data("must") && val === "") return;

            const icons = {
                success: '<i class="bi bi-check-circle text-success"></i>',
                error: '<i class="bi bi-x-circle text-danger"></i>',
                processing: '<i class="bi bi-arrow-repeat rotate text-primary"></i>'
            };

            if (icons[status]) {
                $w.append(`<span class="status-icon">${icons[status]}</span>`).addClass("has-icon");
            }
        }
        clearStatusIcon($el) {
            if ($el.is(":radio")) {
                $el = $el.closest(".radio-group");
            }

            const $w = $el.hasClass("radio-group")
                ? $el
                : $el.parent(".input-with-status");

            $w.find(".status-icon").remove().end().removeClass("has-icon");
        }
        //clearStatusIcon($el) {
        //    $el.parent(".input-with-status").find(".status-icon").remove().end().removeClass("has-icon");
        //}

        setError($el, msg) {
            $el.addClass("is-invalid").css("border", "1px solid red").attr("title", msg || "");
            $el.next(".select2-container").find(".select2-selection").css("border", "1px solid red");
        }

        clearError($el) {
            $el.removeClass("is-invalid").css("border", "").attr("title", "");
            $el.next(".select2-container").find(".select2-selection").css("border", "");
        }
        isEditableField($el) {
            if (!$el.is("input,textarea,select")) return false;
            if ($el.is(":disabled") || $el.prop("readonly")) return false;

            // 如果 display:none / hidden / hidden by parent
            if (!$el.is(":visible")) return false;

            return true;
        }

        async validateField(el) {

            const $el = $(el);
            let val = ValueHandler.get($el);
            if (val !== "") this.setStatusIcon($el, 'processing'); 
            const name = $el.attr("id") || $el.attr("name");
            const hybridVal = this.vm._scopedData?.[this.key]?.[name];

            if (hybridVal && typeof hybridVal === "object" && "enabled" in hybridVal) {
                val = hybridVal.enabled ? hybridVal.value : "";
            }
            this.clearError($el);
            this.clearStatusIcon($el);

            // ⭐ file 直接略過（你原本邏輯）
            if (resolveType($el) === "file") return true;

            const ctx = buildContext($el, val, this.vm, this, this.key, name);

            // ⭐ 空值快速通過
            if (!ctx.must && val === "") return true;

            // =========================
            // ⭐ 根據控件取得規則
            // =========================
            const rules = [...(ControlRuleMap[ctx.type] || [])];
            // ⭐ 額外規則（可混用 data-*）
            if (ctx.conditional) rules.push("conditional");
            if (ctx.cross) rules.push("cross");

            // =========================
            // ⭐ 同步驗證
            // =========================
            for (let r of rules) {

                const rule = ValidatorRules[r];
                if (!rule) continue;

                const result = await rule.validate(val, ctx);

                if (result !== true) {
                    this.setError($el, result);
                    this.setStatusIcon($el, 'error', result);
                    return false;
                }
            }

            // =========================
            // ⭐ 自訂驗證
            // =========================
            const customValidators = this.vm._validators?.[this.key]?.[name];

            if (customValidators?.length) {
                for (let fn of customValidators) {

                    let result = await fn(val, ctx);

                    if (result !== true) {
                        this.setError($el, result || "驗證失敗");
                        this.setStatusIcon($el, 'error');
                        return false;
                    }
                }
            }

            // =========================
            // ⭐ async 驗證（原樣保留）
            // =========================
            if (ctx.asyncUrl && val && ctx.type != 'select2') {

                const cacheKey = `${this.key}_${name}_${val}`;
                const token = Symbol();
                this.asyncTokens[cacheKey] = token;

                this.setStatusIcon($el, 'processing');

                try {
                    const resp = await $.ajax({
                        url: ctx.asyncUrl,
                        data: { value: val }
                    });

                    if (this.asyncTokens[cacheKey] !== token) return false;

                    this.asyncCache[cacheKey] = resp.valid;

                    if (!resp.valid) {
                        this.setError($el, resp.message || "驗證失敗");
                        this.setStatusIcon($el, 'error');
                    } else {

                        // ⭐⭐⭐ 新增：自動填值（核心）
                        if (resp.data) {
                            Object.keys(resp.data).forEach(targetField => {

                                const value = resp.data[targetField];

                                if (this.fieldMap[targetField]) {
                                    // ⭐ 更新 VM
                                    this.vm._scopedData[this.key][targetField] = value;

                                    // ⭐ 更新 UI
                                    const $target = this.container.find(`[name='${targetField}'], #${targetField}`);
                                    if ($target.length) {
                                        ValueHandler.set($target, value);
                                        $target.trigger("change");
                                    } 
                                    this.setStatusIcon(this.fieldMap[targetField], 'success');
                                } 
                            });
                        }

                        this.setStatusIcon($el, 'success');
                    }
                    this.setStatusIcon($el, 'success');
                    if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};
                    this.vm._scopedData[this.key][$el.attr("id") || $el.attr("name")] = val;
                    this.fieldCache[name] = val;
                    this.proxyData[name] = val; 
                    return resp.valid;

                } catch {
                    if (this.asyncTokens[cacheKey] !== token) return false;

                    this.setError($el, "異步驗證失敗");
                    this.setStatusIcon($el, 'error');
                    return false;
                }
            }
            else
            {
                // =========================
                // ⭐ 成功
                // =========================
                this.setStatusIcon($el, 'success');
                if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};
                this.vm._scopedData[this.key][$el.attr("id") || $el.attr("name")] = val;
                this.fieldCache[name] = val;
                this.proxyData[name] = val; 
                return true;
            }  
        }

        async validateAll() {
            const results = [];

            for (const name in this.fieldMap) {
                const $el = this.fieldMap[name];

                try {
                    const valid = await this.validateField($el[0]); // ⭐ 注意這裡
                    results.push(valid);
                } catch (err) {
                    console.error("validateAll error:", name, err);
                    results.push(false);
                }
            }

            return results.every(r => r);
        }

        cache() {
            for (const name in this.fieldMap) {
                const $el = this.fieldMap[name];
                if (resolveType($el) === "file") {
                    const file = $el.data("file");
                    this.fieldCache[name] = file ? file.name : null;
                } else {
                    this.fieldCache[name] = ValueHandler.get($el);
                }
            }
        }
        getJsonData() {
            // 確保快取是最新的
            this.cache();
            // 直接回傳 fieldCache 物件（這在 JS 中就是 JSON 格式的物件）
            return this.fieldCache;
        }

        getJsonString() {
            this.cache();
            return JSON.stringify(this.fieldCache);
        }

        restore() {
            Object.entries(this.fieldCache).forEach(([k, v]) => {
                this.proxyData[k] = v;
            });
        }

        bindEvents() {
            const eventName = "change.validate";

            if (!this.debouncedValidate) {
                this.debouncedValidate = this.debounce(async e => {
                    try {
                        await this.validateField(e.currentTarget);
                    } catch (err) {
                        console.error("validate error:", err);
                    }
                }, 500);
            }

            //this.container.on("input", "[vmodel]", e => {
            //    const $el = $(e.currentTarget);
            //    if ($el.closest(".hybrid-input").length) return;
            //    if (resolveType($el) === "file") return;
            //    if (ValueHandler.get($el) !== "") this.setStatusIcon($el, 'processing');

            //    // ⭐ 同步到 tab 專屬 VM scope
            //    if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};
            //    this.vm._scopedData[this.key][$el.attr("id") || $el.attr("name")] = ValueHandler.get($el);
            //    debounced(e);
            //    // ⭐ 同步到 proxyData & fieldCache
            //    const name = $el.attr("id") || $el.attr("name");
            //    this.proxyData[name] = ValueHandler.get($el);
            //    this.fieldCache[name] = ValueHandler.get($el);
            //});

            this.container.off(eventName, "[vmodel]");
            this.container.on(eventName, "[vmodel]", e => {  
                const $el = $(e.currentTarget);
                if ($el.closest(".hybrid-input").length) return;
                // ⭐ 排除 file（關鍵🔥）
                if (resolveType($el) === "file") return; 
                this.debouncedValidate(e);
            });

            this.container.on("change", "input[type=file][vmodel]", e => {

                const $el = $(e.currentTarget);
                const name = $el.attr("id") || $el.attr("name");
                const file = e.currentTarget.files[0];

                if (!file) return;

                // ===== 驗證 =====
                const maxSizeMB = $el.data("maxsize");

                if (maxSizeMB && file.size > maxSizeMB * 1024 * 1024) {
                    this.setError($el, `檔案不可超過 ${maxSizeMB} MB`);
                    $el.val("");
                    ValueHandler.set($el, null, { silent: true });
                    return;
                }

                this.clearError($el);
              
                //// ===== 資料 =====
                this.vm.clearFiles(this.key, name); // 清掉舊檔
                this.vm.setFile(this.key, name, {
                    file: file,        // File 物件
                    filename: file.name // 檔名方便 UI 顯示或 JSON
                }); // 設定新檔
                //this.vm._scopedData[this.key][name] = file.name;

                //if (!this.vm._scopedData[this.key]) this.vm._scopedData[this.key] = {};

                //// 直接覆蓋原本檔案
                //this.vm._scopedData[this.key][name] = {
                //    file: file,        // File 物件
                //    filename: file.name // 檔名方便 UI 顯示或 JSON
                //};
                $el.data("file", file);
                // ===== UI + 行為 =====
                ValueHandler.set($el, file, {
                    silent: true,
                    vm: this.vm,
                    tabKey: this.key,
                    field: name,
                    inline : true
                });

             
 

            });


            this.container.on("change", ".dropdownColor", (e) => {
                let $el = $(e.currentTarget);
                let color = $el.find("option:selected").data("color");
                $el.css("background-color", color);
            });
        }

        //bindFileInputs() {
        //    this.container.on("change", 'input[type="file"]', e => {
        //        const $el = $(e.currentTarget);
        //        const name = $el.attr("name");
        //        const files = $el[0].files;

        //        // ⭐ 存到 PageVM
        //        this.vm.setFile(this.key, name, Array.from(files));

        //        // ⭐ 顯示檔名
        //        this.showFileNames($el, Array.from(files));
        //    });

        //    // ⭐ 刪除檔案按鈕
        //    this.container.on("click", ".file-remove-btn", e => {
        //        const $btn = $(e.currentTarget);
        //        const $wrapper = $btn.closest(".file-item");
        //        const field = $wrapper.data("field");
        //        const fileName = $wrapper.data("filename");

        //        // 刪除 cache
        //        this.vm.removeFile(this.key, field, fileName);

        //        // 移除畫面
        //        $wrapper.remove();
        //    });
        //}

        //showFileNames($input, files) {
        //    const $container = $input.closest(".input-with-status");
        //    $container.find(".file-list").remove();

        //    const $list = $('<div class="file-list"></div>');
        //    files.forEach(f => {
        //        $list.append(`
        //        <div class="file-item" data-field="${$input.attr("name")}" data-filename="${f.name}">
        //            <span class="file-name-text">${f.name}</span>
        //            <button type="button" class="file-remove-btn btn btn-sm btn-danger">刪除</button>
        //        </div>
        //    `);
        //    });
        //    $container.append($list);
        //}

        //// ⭐ 回復檔案顯示（restore）
        //restoreFiles() {
        //    Object.entries(this.vm._fileData[this.key] || {}).forEach(([field, files]) => {
        //        const $el = this.container.find(`[name="${field}"]`);
        //        if ($el.length && files && files.length) {
        //            this.showFileNames($el, files);
        //        }
        //    });
        //}

        debounce(fn, delay = 500) {
            let timer;
            return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
        }
    }
     
    // ================================
    // ⭐ HYBRID 修改處（修正版）
    // ================================
    DynamicFormInstance.prototype.bindHybridControls = function () {
        const self = this;

        this.container.find(".hybrid-input").each((_, el) => {
            const $group = $(el);
            const fieldName = $group.data("field");
            if (!fieldName) return;

            const $chk = $group.find('[data-hybrid-role="checkbox"]');
            const $txt = $group.find('[data-hybrid-role="textbox"]');

            // ---------- 1️⃣ 初始化 VM ----------
            if (!self.vm._scopedData[self.key]?.[fieldName]) {
                const initVal = {
                    enabled: $chk.is(":checked"),
                    value: $txt.val() || ""
                };

                (self.vm._scopedData[self.key] ||= {})[fieldName] = initVal;
            }

            // ---------- 2️⃣ 從 VM 回填控件 ----------
            const vmVal = self.vm._scopedData[self.key][fieldName];

            $chk.prop("checked", vmVal.enabled);
            $txt.val(vmVal.value)
                .prop("disabled", !vmVal.enabled);

            // ---------- 3️⃣ checkbox 控制 textbox ----------
            $chk.off("change").on("change", function () {
                const checked = this.checked;

                $txt.prop("disabled", !checked);

                self.vm._scopedData[self.key][fieldName].enabled = checked;

                if (!checked) {
                    self.vm._scopedData[self.key][fieldName].value = "";
                    $txt.val("");
                }

                if (self.validateField) {
                    self.validateField($txt[0]).catch(console.error);
                }
            });

            // ---------- 4️⃣ textbox → VM ----------
            $txt.off("input").on("input", function () {

                // ⭐ 修正這行🔥
                if (!self.vm._scopedData[self.key][fieldName].enabled) return;

                self.vm._scopedData[self.key][fieldName].value = $(this).val();

                if (self.validateField) {
                    self.validateField(this).catch(console.error);
                }
            });
        });
    };

    return {

        init: function () {
            const currentPath = window.location.pathname;

            // 1. 檢查全域 VM 是否存在或是否換頁
            if (!window.vm || window.vm._pagePath !== currentPath) {
                window.vm = new PageVM();
                // 開放門戶給隨後載入的 PartialView 呼叫
                window.CurrentPageContext = { init: () => this.init() };
            }

            // 2. 掃描所有尚未初始化的 [data-df]
            $("[data-df]:not([data-df-initialized])").each(function () {
                const formInstance = new DynamicFormInstance(this, window.vm);
                window.activeForm = formInstance;
                console.log("Tab 自動註冊成功:", $(this).data("df"));
            });
        }
    };

})();