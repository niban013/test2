﻿const WizardHook = Object.freeze({
    BEFORE_NEXT: "beforeNext",
    BEFORE_PREV: "beforePrev",
    AFTER_LOAD: "afterLoad",
    ON_LEAVE: "onLeave"
});
class FormWizard {
    constructor(options) {
        // 配置參數
        this.containerId = options.containerId || "#wizard-content";
        this.stepsId = options.stepsId || "#wizard-steps";
        this.nextBtnId = options.nextBtnId || "#nextBtn";
        this.prevBtnId = options.prevBtnId || "#prevBtn";
        this.progressBarId = options.progressBarId || "#wizard-progress-bar";
        this.baseUrl = options.baseUrl || "/Wizard";
        this.stepRedirect = {}; // ⭐ 新增：記錄每一步 pageredirect
        this.isBack = false;    // ⭐ 新增：是否為 backward
        // 狀態變數 (封裝在執行個體內)
        this.currentStep = 1;
        this.totalSteps = $(`${this.stepsId} li`).length;
        this.stepTypes = {}; 
        this.stepHooks = {}; // { stepIndex: { beforeNext: [], afterLoad: [], ... } }
        this.plugins = [];

        // ⭐ 初始化私有事件表
        this._handlers = {};
        this.init();
    }
    //use(plugin) {
    //    if (plugin) this.plugins.push(plugin);
    //}
    useStep(stepIndex, hooks) {
        if (!this.stepHooks[stepIndex]) this.stepHooks[stepIndex] = {};
        Object.keys(hooks).forEach(hookName => {
            if (!this.stepHooks[stepIndex][hookName]) this.stepHooks[stepIndex][hookName] = [];
            this.stepHooks[stepIndex][hookName].push(hooks[hookName]);
        });
    }
    async _runHandlers(hookEnum, payload = {}, options = {}) {
        let result = true;
        const ctx = {
            ...payload,
            step: this.currentStep,
            direction: options.direction || null,
            wizard: this,
            setResult: (val) => result = val
        };

        // 1️⃣ step-local hooks
        const stepLocal = this.stepHooks[this.currentStep]?.[hookEnum] || [];
        for (const fn of stepLocal) {
            const res = await fn(ctx);
            if (res === false) return false; // 阻止繼續
        }

        // 2️⃣ plugins 原有 hook
        for (const plugin of this.plugins) {
            if (plugin[hookEnum]) {
                const res = await plugin[hookEnum](ctx);
                if (res === false) result = false;
            }
        }

        // 3️⃣ 全域 handlers
        const handlers = this._handlers[hookEnum] || [];
        for (const fn of handlers) {
            const res = await fn(ctx);
            if (res === false) result = false;
        }

        return result;
    }
    // 外部簡化調用
    beforeNext(fn) { return this._on(WizardHook.BEFORE_NEXT, fn); }
    beforePrev(fn) { return this._on(WizardHook.BEFORE_PREV, fn); }
    afterLoad(fn) { return this._on(WizardHook.AFTER_LOAD, fn); }
    onLeave(fn) { return this._on(WizardHook.ON_LEAVE, fn); }

    // ⭐ 私有事件綁定
    _on(hookEnum, handler) {
        if (!this._handlers[hookEnum]) this._handlers[hookEnum] = [];
        this._handlers[hookEnum].push(handler);
    }

    // ⭐ 私有事件觸發
    //async _runHandlers(hookEnum, payload = {}, options = {}) {
    //    let result = true;
    //    const ctx = {
    //        ...payload,
    //        step: this.currentStep,
    //        direction: options.direction || null,
    //        setResult: (val) => result = val
    //    };

    //    // 1️⃣ 先跑插件
    //    for (const plugin of this.plugins) {
    //        if (plugin[hookEnum]) {
    //            const res = await plugin[hookEnum](ctx);
    //            if (res === false) result = false;
    //        }
    //    }

    //    // 2️⃣ 再跑 this._handlers
    //    const handlers = this._handlers[hookEnum] || [];
    //    for (const fn of handlers) {
    //        const res = await fn(ctx);
    //        if (res === false) result = false;
    //    }

    //    return result;
    //}
    init() {
        const self = this;
        // 載入第一步
        this.loadStep(this.currentStep);

        // 綁定「下一步」
        $(this.nextBtnId).off("click").on("click", function () { self.next(); });

        // 綁定「上一步」
        $(this.prevBtnId).off("click").on("click", function () { self.prev(); });

        // 綁定步驟點擊
        $(`${this.stepsId} li`).off("click").on("click", function () {
            const index = $(this).data("step");
            if (index === undefined || index === self.currentStep) return;

            // 判斷方向：後退為 backward
            self.isBack = index < self.currentStep;
            self.currentStep = index;
            const type = self.isBack ? "" : self.stepTypes[self.currentStep - 1] || "";
            self.loadStep(self.currentStep, type);
        });

        $(`${this.stepsId} .step-badge`).hide();


        
    }
    bindTestButtons() {
        const self = this;

        $("#testBtn1").off("click").on("click", function () {

            // ⭐ 設定條件1
            $(`${self.containerId} [name="customerId"]`).val("1001");
            $(`${self.containerId} [name="type"]`).val("A");

            // ⭐ 觸發 change（避免 select2 / validation 問題）
            $(`${self.containerId} [name="type"]`).trigger("change");

            // ⭐ 模擬下一步
            self.next();
        });

        $("#testBtn2").off("click").on("click", function () {

            // ⭐ 設定條件2
            $(`${self.containerId} [name="customerId"]`).val("2002");
            $(`${self.containerId} [name="type"]`).val("B");

            $(`${self.containerId} [name="type"]`).trigger("change");

            self.next();
        });
    }
    async runHook(hookEnum, payload = {}, options = {}) {
        return await this._runHandlers(hookEnum, payload, options);
    }

    //async runHook(hookEnum, payload = {}, options = {}) {
    //    let result = true;

    //    const ctx = {
    //        ...payload,
    //        step: this.currentStep,
    //        direction: options.direction || null,
    //        setResult: (val) => result = val
    //    };

    //    const eventName = `wizard:${hookEnum}`; // ⭐ enum 自動轉事件名
    //    const res = await $(this.containerId).triggerHandler(eventName, ctx);

    //    if (res === false) result = false;

    //    return result;
    //}
    static bindHook(containerSelector, hookEnum, handler) {

        const $container = $(containerSelector);
        if (!$container.length) {
            console.warn("bindWizardHook: container not found", containerSelector);
            return;
        }

        const eventName = `wizard:${hookEnum}`;

        $container.off(eventName).on(eventName, function (e, ctx) {
            const res = handler(ctx);

            // ⭐ 支援 return false 或 Promise
            if (res === false) return false;
        });
    }
    async loadStep(stepIndex, type, extraData = null, callback = null) {
        const self = this; 
        $(this.nextBtnId).prop("disabled", true);
        const query = new URLSearchParams({ stepIndex, Type: type || '' }); 
        if (extraData) {
            query.append("SendData", JSON.stringify(extraData));
        }
        try {
            const resp = await fetch(`${this.baseUrl}/Step?${query.toString()}`);
            const html = await resp.text();
            $(self.containerId).html(html);

            self.redirectFields = $(self.containerId).find('.pageredirect[name]');
         
            self.updateUI();
            self.bindTestButtons();
            await self.runHook(WizardHook.AFTER_LOAD);
            const stepKey = "Step" + stepIndex;
            // 刪除不存在的欄位
            self.cleanupVMFields(stepKey);
            if (!self.isBack) {
                // restore pageVM 並以 pageredirect 為主
                self.restorePageVMWithRedirect(stepKey);
            }
            for (let i = 1; i <= self.totalSteps; i++) {
                self.updateStepBadge(i);
            } 
        } catch (err) {
            console.error("Load step error:", err);
        } finally {
            $(self.nextBtnId).prop("disabled", false);
            self.isBack = false;
            if (typeof callback === "function") callback();
        }
    }

    restorePageVMWithRedirect(stepKey) {
        const vmData = window.vm?._scopedData?.[stepKey];
        if (!vmData) return;

        const prevRedirect = this.stepRedirect[this.currentStep - 1] || {};

        // 取得當前畫面所有欄位
        const currentFields = new Set();
        $(`${this.containerId} [vmodel]`).each(function () {
            const name = $(this).attr("name");
            if (name) currentFields.add(name);
        });

        // 遍歷 pageVM
        Object.keys(vmData).forEach(key => {

            // 保留 pageredirect
            if (key === "pageredirect") return;

            // ❌ 不在畫面上 → 刪掉
            if (!currentFields.has(key)) {
                delete vmData[key];
                return;
            }

            // ✅ 在畫面上 → 判斷 pageredirect 是否有值
            const $el = $(`${this.containerId} [name="${key}"]`);
            if (!$el.length) return;

            const redirectVal = prevRedirect[key];

            // ⭐ 沒有 pageredirect → 完全略過（保留 VM）
            if (redirectVal === undefined || redirectVal === null || redirectVal === "") {
                return;
            }
            const currentVal = vmData[key];
            if (this.isSameValue(currentVal, redirectVal)) {
               /* return;*/
            } 

            ValueHandler.set($el, redirectVal, {
                silent: true,     // 避免 trigger input（避免 loop）
                vm: window.vm,
                tabKey: stepKey,
                field: key,
                inline: true      // ⭐ file 顯示用
            });
            //if ($el.is(":checkbox")) {
            //    $el.prop("checked", Array.isArray(redirectVal) && redirectVal.includes($el.val()));
            //} else if ($el.is(":radio")) {
            //    $el.prop("checked", $el.val() === redirectVal);
            //} else if ($el.is("[type='file']")) {
            //    // ⭐ File input 特別處理
            //    const vmFile = vmData[key]; // VM 已有 File 物件或檔名
            //    if (vmFile) {
            //        // 這裡只能顯示檔名，File 物件無法直接設定到 input
            //        const $fileLabel = $el.siblings(".file-label"); // 假設有 label 顯示
            //        if ($fileLabel.length) $fileLabel.text(vmFile.name || vmFile);
            //    }
            //} else {
            //    $el.val(redirectVal);
            //}

            // ⭐ 同步回 VM
            vmData[key] = redirectVal;
        });
    }
    cleanupVMFields(stepKey) {
        const vmData = window.vm?._scopedData?.[stepKey];
        if (!vmData) return;

        // ⭐ 取得目前畫面所有欄位
        const currentFields = new Set();

        $(`${this.containerId} [vmodel]`).each(function () {
            const name = $(this).attr("name");
            if (name) currentFields.add(name);
        });

        // ⭐ 刪除不存在的欄位
        Object.keys(vmData).forEach(key => {

            // 保留 pageredirect（如果你有用）
            if (key === "pageredirect") return;

            if (!currentFields.has(key)) {
                delete vmData[key];
            }
        });
    }
    getRedirectData() {
        const result = {};

        this.redirectFields.each(function () {
            const $el = $(this);
            const name = $el.attr("name");
            if (!name) return;

            let val;

            if ($el.is(":checkbox")) {
                if (!result[name]) result[name] = [];
                if ($el.prop("checked")) {
                    result[name].push($el.val());
                }
                return;
            }

            if ($el.is(":radio")) {
                if ($el.prop("checked")) {
                    result[name] = $el.val();
                }
                return;
            }

            val = $el.val();

            if ($el.is("select[multiple]")) {
                result[name] = val || [];
            } else {
                result[name] = val;
            }
        });

        return result;
    }
    isSameRedirectData(a, b) {
        return JSON.stringify(a) === JSON.stringify(b);
    }
    async next(extraData = null, callback = null) {
        if (!await this.runGuards("next")) return;
        const val = this.getRedirectData(); // ⭐ 改這裡
        const oldVal = this.stepRedirect[this.currentStep];

        // ⭐ 比對整包條件
        if (!this.isBack && oldVal && !this.isSameRedirectData(oldVal, val)) {
            const ok = confirm("條件已改變，是否繼續？");
            if (!ok) return;
        }

        // ⭐ 記錄條件
        this.stepRedirect[this.currentStep] = JSON.parse(JSON.stringify(val));

        this.stepTypes[this.currentStep] = val;
        this.updateStepBadge(this.currentStep);


        if (this.currentStep < this.totalSteps) {
            this.isBack = false;
            this.currentStep++;

            // ⭐ 傳整包 JSON 給後端
            this.loadStep(this.currentStep, JSON.stringify(val), extraData, callback);
        } else {
            alert("流程完成!");
        }
    }
    updateStepBadge(stepIndex) {
        const $badge = $(`${this.stepsId} li[data-step=${stepIndex}] .step-badge`);

        const stepKey = "Step" + stepIndex;
        const vmData = window.vm?._scopedData?.[stepKey];

        if (!vmData) {
            $badge.removeClass("done partial").addClass("empty").text(stepIndex);
            return;
        }

        let total = 0;
        let filled = 0;

        Object.keys(vmData).forEach(key => {
            if (key === "pageredirect") return;

            total++;
            const val = vmData[key];

            if (val !== null && val !== undefined && val !== "" &&
                !(Array.isArray(val) && val.length === 0)) {
                filled++;
            }
        });

        if (filled === 0) {
            // 🔴 未填
            $badge.removeClass("done partial").addClass("empty").text(stepIndex);
        } else if (filled < total) {
            // 🟡 部分完成
            $badge.removeClass("done empty").addClass("partial").text(stepIndex);
        } else {
            // 🟢 完成 ✔
            $badge.removeClass("partial empty").addClass("done").html("✔");
        }

        $badge.show();
    }

    async runGuards(type) {

        if (type === "next") {
            if (!await this.runHook(WizardHook.BEFORE_NEXT)) return false;
            if (!await this.runHook(WizardHook.ON_LEAVE, {}, { direction: "forward" })) return false;
        }

        if (type === "prev") {
            if (!await this.runHook(WizardHook.BEFORE_PREV)) return false;
            if (!await this.runHook(WizardHook.ON_LEAVE, {}, { direction: "backward" })) return false;
        }

        return true;
    }
    async prev() {
        if (!await this.runGuards("prev")) return;

        if (this.currentStep > 1) {
            this.currentStep--;
            this.isBack = true; // ⭐ backward 不比對 pageredirect
            // ⭐ backward 不帶條件
            this.loadStep(this.currentStep, "");
        }
    }

    updateUI() {
        const self = this;
        //$(this.prevBtnId).prop("disabled", this.currentStep === 0);
        $(this.prevBtnId).css("visibility", self.currentStep === 1 ? "hidden" : "visible");
        $(this.nextBtnId).text(self.currentStep === self.totalSteps ? "完成" : "下一步");

        $(`${this.stepsId} li`).removeClass("active");
        $(`${this.stepsId} li[data-step=${self.currentStep}]`).addClass("active");

        let progress = (self.currentStep / self.totalSteps) * 100;
        $(this.progressBarId).css("width", progress + "%");
    }
    getStepValue(stepIndex, fieldName) {
        const stepData = window.vm?._scopedData?.["Step" + stepIndex];
        return stepData?.[fieldName] ?? null;
    }
    isSameValue(a, b) {
        // ⭐ 完全相等（string / number / boolean）
        if (a === b) return true;

        // ⭐ array 比較
        if (Array.isArray(a) && Array.isArray(b)) {
            if (a.length !== b.length) return false;
            return a.every((v, i) => v === b[i]);
        }

        // ⭐ File 比較（只比 name + size + lastModified）
        if (a instanceof File && b instanceof File) {
            return a.name === b.name &&
                a.size === b.size &&
                a.lastModified === b.lastModified;
        }

        return false;
    }
}
