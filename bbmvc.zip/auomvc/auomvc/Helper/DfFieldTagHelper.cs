﻿using auomvc.Models;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Text;

namespace auomvc.Helper
{
    public static class FieldRenderer
    {
        public static string RenderField(DynamicField f)
        {
            if (f.Hidden)
            {
                var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
                return $"<input type='hidden' name='{f.Name}' value='{val}' vmodel />";
            }

            return $@" <div class='row align-items-center mb-1'>
                            {RenderLabel(f)}
                            <div class='col-{f.Width}'>
                                {RenderControl(f)}
                            </div>
                        </div>";
        }

        // ========================
        // Label（左側）
        // ========================
        private static string RenderLabel(DynamicField f)
        {
            return $@"
                    <label class='col-3 mb-0 d-flex align-items-center'>
                        <span class='star'>{(f.Must ? "*" : "")}</span>
                        <span class='label-text tooltip-auto' data-title='{f.Name}'>{f.Name}</span>
                    </label>";
        }

        // ========================
        // 控制項核心🔥
        // ========================
        public static string RenderControl(DynamicField f)
        {
            return f.Type switch
            {
                FieldType.Label => RenderOnlyLabel(f),
                FieldType.Textbox => RenderTextbox(f),
                FieldType.Numeric => RenderNumeric(f),
                FieldType.Date => RenderDate(f),
                FieldType.Textarea => RenderTextarea(f),
                FieldType.Dropdown or FieldType.Select2 => RenderDropdown(f),
                FieldType.Radio => RenderRadio(f),
                FieldType.File => RenderFile(f),
                FieldType.ShowFile => RenderShowFile(f),
                FieldType.Hybrid => RenderHybrid(f),
                _ => $"<span>未知控制項 {f.Type}</span>"
            };
        }

        // ========================
        // Label（右側顯示值）
        // ========================
        private static string RenderOnlyLabel(DynamicField f)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"
                    <label class='mb-0 d-flex align-items-center tooltip-auto'
                           id='{f.Name}'
                           name='{f.Name}'
                           data-title='{f.Name}'
                           vmodel>
                        <span class='label-text'
                              style='display:block; width:100%; padding:0 12px; height:32px; line-height:32px;'>
                            {val}
                        </span>
                    </label>";
        }

        // ========================
        // Textbox
        // ========================
        private static string RenderTextbox(DynamicField f)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"
                    <input type='text' class='form-control' vmodel
                           name='{f.Name}'
                           placeholder='{f.Placeholder}'
                           data-must='{f.Must.ToString().ToLower()}'
                           data-pattern='{f.Pattern}'
                           data-default='{f.DefaultValue}'
                           data-async='{f.AsyncUrl}'
                           data-target='{f.Target}'
                           value='{val}'
                           {(f.Readonly ? "readonly" : "")} />";
        }
        private static string RenderHybrid(DynamicField f)
        {
            // 取得初始值
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            // 初始 checkbox 狀態
            var isChecked = val != null && val.ToString() != "" ? "checked" : "";
            var disabled = string.IsNullOrEmpty(isChecked) ? "disabled" : "";

            return $@"
        <div class='input-group hybrid-input' data-field='{f.Name}'>
            <div class='input-group-text'>
                <input type='checkbox' class='hybrid-checkbox' 
                  data-hybrid-role='checkbox'
                  data-hybrid-key='chk{f.Name}'
                  id='{f.Name}_chk' {isChecked} />
            </div>
            <input type='text' class='form-control hybrid-textbox'
                   data-hybrid-role='textbox'
                   data-hybrid-key='txt{f.Name}' vmodel
                   id='{f.Name}_txt'
                   name='{f.Name}'
                   placeholder='{f.Placeholder}'
                   data-must='{f.Must.ToString().ToLower()}'
                   data-pattern='{f.Pattern}'
                   data-default='{f.DefaultValue}'
                   value='{val}'
                   {disabled}
                   {(f.Readonly ? "readonly" : "")} />
        </div> 
    ";
        }
        // ========================
        // Numeric🔥
        // ========================
        private static string RenderNumeric(DynamicField f)
        {
            var raw = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var value = raw;

            if (decimal.TryParse(raw, out var num))
            {
                if (decimal.TryParse(f.Min, out var min) && num < min) value = "";
                if (decimal.TryParse(f.Max, out var max) && num > max) value = "";
            }

            var oninput = !string.IsNullOrEmpty(f.Max)
                ? "if(this.max && parseFloat(this.value) > parseFloat(this.max)) this.value = this.max;"
                : "";

            var onblur = @"
if(!this.value){ this.value = this.dataset.default || ''; }
else if(this.min && parseFloat(this.value) < parseFloat(this.min)){ this.value = this.min; }
else if(this.max && parseFloat(this.value) > parseFloat(this.max)){ this.value = this.max; }";

            return $@"
                    <input type='number' class='form-control' vmodel
                           name='{f.Name}'
                           value='{value}'
                            
                           placeholder='{f.Placeholder}'
                           data-must='{f.Must.ToString().ToLower()}'
                           data-pattern='{f.Pattern}'
                           data-default='{f.DefaultValue}'
                           {(string.IsNullOrEmpty(f.Min) ? "" : $"min='{f.Min}'")}
                           {(string.IsNullOrEmpty(f.Max) ? "" : $"max='{f.Max}'")}
                           oninput=""{oninput}""
                           onblur=""{onblur}""
                           {(f.Readonly ? "readonly" : "")} />";
        }

        // ========================
        // Date🔥
        // ========================
        private static string RenderDate(DynamicField f)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue)?.Replace("/", "-");

            bool hasMin = DateTime.TryParse(f.Min, out var minDate);
            bool hasMax = DateTime.TryParse(f.Max, out var maxDate);

            if (DateTime.TryParse(val, out var d))
            {
                if ((hasMin && d < minDate) || (hasMax && d > maxDate))
                    val = "";
            }

            var onblur = @"
if(!this.value){ this.value = this.dataset.default || ''; }
else{
    if(this.min && this.value < this.min){ this.value = this.min; }
    if(this.max && this.value > this.max){ this.value = this.max; }
}";

            return $@"
<input type='date' class='form-control datepicker' vmodel
       name='{f.Name}'
       value='{val}' 
       placeholder='{f.Placeholder}'
       data-must='{f.Must.ToString().ToLower()}'
       data-pattern='{f.Pattern}'
       data-default='{f.DefaultValue}'
       {(hasMin ? $"min='{minDate:yyyy-MM-dd}'" : "")}
       {(hasMax ? $"max='{maxDate:yyyy-MM-dd}'" : "")}
       onblur=""{onblur}""
       {(f.Readonly ? "readonly" : "")} />";
        }

        // ========================
        // Textarea
        // ========================
        private static string RenderTextarea(DynamicField f)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);

            return $@"
                    <textarea class='form-control' vmodel
                                name='{f.Name}'
                                placeholder='{f.Placeholder}'
                                data-must='{f.Must.ToString().ToLower()}'
                                data-pattern='{f.Pattern}'
                                data-default='{f.DefaultValue}'
                                {(f.Readonly ? "readonly" : "")}>{val}</textarea>";
        }

        // ========================
        // Dropdown🔥
        // ========================
        private static string RenderDropdown(DynamicField f)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var cls = f.Type == FieldType.Select2 ? "form-control select2-container--default select2" : "form-control valueInput dropdownColor";

            var sb = new StringBuilder();

            sb.Append($@"<select class='{cls}' vmodel
                        name='{f.Name}'
                        data-default='{f.DefaultValue}'
 data-placeholder='{f.Placeholder}'
                        data-async='{f.AsyncUrl}'
                        data-must='{f.Must.ToString().ToLower()}'
                        {(f.Readonly ? "disabled" : "")}>");

            sb.Append("<option value='' data-color='white' style='background-color:white'>請選擇</option>");

            if (f.Options != null)
            {
                foreach (var op in f.Options)
                {
                    var selected = op.Value == val ? "selected" : "";
                    var color = string.IsNullOrEmpty(op.Color) ? "white" : op.Color;

                    sb.Append($@"<option value='{op.Value}' data-color='{color}' style='background-color:{color}' {selected}>{op.Text}</option>");
                }
            }

            sb.Append("</select>");
            return sb.ToString();
        }

        // ========================
        // Radio
        // ========================
        private static string RenderRadio(DynamicField f)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var sb = new StringBuilder();

            sb.Append("<div class='radio-group input-with-status'>");

            foreach (var op in f.Options ?? new())
            {
                var isInverse = f.InverseSelect;

                var isChecked = !isInverse
                    ? (op.Value == val)
                    : (op.Value != val);

                var isDisabled = isInverse && op.Value == val;


                sb.Append($@"
                    <label class='radio-inline {(isDisabled ? "disabled-option" : "")}'>
                        <input type='radio' name='{f.Name}' value='{op.Value}'
                        {(isChecked ? "checked" : "")} 
                        {(isDisabled ? "disabled" : "")}
                        data-must='{f.Must.ToString().ToLower()}' 
                        vmodel />
                        {op.Text}
                    </label>");
            }

            sb.Append("</div>");
            return sb.ToString();
        }

        // ========================
        // File
        // ========================
        private static string RenderFile(DynamicField f)
        {
            return $@"
                    <div class='dynamic-file-input dynamic-file'>
                        <input type='file' id='{f.Name}' name='{f.Name}' class='form-control d-none' vmodel />
                         <label class='btn btn-outline-primary btn-sm tooltip-auto' for='{f.Name}' style='cursor:pointer;' data-title='上傳檔案'>
                            <i class='bi bi-upload'></i>
                        </label>

                        <!-- 中間：文字太長會自動變 ... -->
                        <span class='filename-label'>
        
                        </span>

                        <!-- 右側：永遠靠右 -->
                        <div class='btn-group'>
                            <button type='button' class='btn btn-outline-secondary btn-sm preview-btn tooltip-auto' style='display:none;' data-title='預覽'>
                                <i class='bi bi-eye'></i>
                            </button>
                            <button type='button' class='btn btn-outline-danger btn-sm delete-btn tooltip-auto' style='display:none;' data-title='刪除'>
                                <i class='bi bi-trash'></i>
                            </button>
                        </div>
                    </div>";
        }

        private static string RenderShowFile(DynamicField f)
        {
            return $@" <div class='dynamic-file-show dynamic-file'> 
                            <!-- 中間：文字太長會自動變 ... -->
                            <span class='filename-label' id='{f.Id}' name='{f.Name}' vmodel>
                                 {f.Value}
                            </span>

                            <!-- 右側：永遠靠右 -->
                            <div class='btn-group'>
                                <button type='button' class='btn btn-outline-secondary btn-sm preview-btn tooltip-auto' data-title='預覽'>
                                    <i class='bi bi-eye'></i>
                                </button>
                            </div>
                        </div>";
        }
    }
    [HtmlTargetElement("df-field")]
    public class DfFieldTagHelper : TagHelper
    {
        public DynamicField Field { get; set; }
        // 單個屬性方式

        public string Name { get; set; }
        public FieldType Type { get; set; } = FieldType.Textbox;
        public bool Must { get; set; } = false;
        public string Placeholder { get; set; } = "";
        public string DefaultValue { get; set; } = "";
        public bool Readonly { get; set; } = false;
        public int? Min { get; set; }
        public int? Max { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if ((Type != FieldType.Numeric) && (Min.HasValue || Max.HasValue))
            {
                throw new InvalidOperationException("Min/Max 只能用在 Number 類型的欄位上");
            }
            DynamicField fieldToRender;

            if (Field != null)
            {
                // 使用完整 DynamicField
                fieldToRender = Field;
            }
            else
            {
                // 使用單個屬性組成 DynamicField
                fieldToRender = new DynamicField
                {
                    Name = Name,
                    Type = Type,
                    Must = Must,
                    Placeholder = Placeholder,
                    DefaultValue = DefaultValue,
                    Readonly = Readonly,
                    Min = Min?.ToString(),
                    Max = Max?.ToString()
                };
            }

            output.TagName = null; // 移除 <df-field> 標籤
            output.Content.SetHtmlContent(FieldRenderer.RenderField(fieldToRender));
        }
    }

    [HtmlTargetElement("df-form")]
    public class DfFormTagHelper : TagHelper
    {
        public List<DynamicField> Fields { get; set; }
        public string Key { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            //output.TagName = "div";
            //output.Attributes.SetAttribute("class", "dynamicForm");
            //output.Attributes.SetAttribute("data-df", Key);
            var sb = new StringBuilder();

            foreach (var f in Fields.OrderBy(x => x.Order))
            {
                sb.Append(FieldRenderer.RenderField(f));
            }

            output.Content.SetHtmlContent(sb.ToString());
        }
    }
}