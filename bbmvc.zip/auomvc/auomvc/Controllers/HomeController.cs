﻿using auomvc.Helper;
using auomvc.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using static auomvc.Models.Wizard;

namespace auomvc.Controllers
{
    public class HomeController : Controller
    {
        private static readonly List<WizardStepOption> Steps = new()
        {
            new WizardStepOption { StepIndex = 1, Title = "Apply New Supplier", PartialView = "Supplier/_Step1", Locked = false },
            new WizardStepOption { StepIndex = 2, Title = "Supplier Information", PartialView = "Supplier/_Step2" },

        };
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(Steps);
        }
        [HttpGet]
        public IActionResult GetUser(string value)
        {
            var userName = "Alice";
            var email = "alice@test.com";

            return Json(new
            {
                valid = true,
                data = new
                {
                    userName = userName,
                    email = email
                }
            });
        }
        [HttpGet]
        public IActionResult GetOptions(string term = "", int page = 1)
        {
            var users = Enumerable.Range(1, 100).Select(x => new
            {
                Id = x,
                Name = $"User {x}"
            });

            if (Request.Query.ContainsKey("id"))
            {
                int id = int.Parse(Request.Query["id"]);

                var item = users
                    .Where(x => x.Id == id)
                    .Select(x => new { id = x.Id, text = x.Name })
                    .FirstOrDefault();

                return Json(new
                {
                    items = item != null ? new[] { item } : Array.Empty<object>()
                });
            }
            int pageSize = 10;

            if (!string.IsNullOrWhiteSpace(term))
            {
                users = users.Where(x => x.Name.Contains(term, StringComparison.OrdinalIgnoreCase));
            }

            var filtered = users.ToList();

            var result = filtered
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new
                {
                    id = x.Id,
                    text = x.Name
                })
                .ToList();

            bool hasMore = filtered.Count > page * pageSize;

            return Json(new
            {
                items = result,
                hasMore = hasMore
            });
        }
        [HttpGet]
        public async Task<IActionResult> Step(int stepIndex, string type, string SendData)
        {
            if (stepIndex < 1 || stepIndex > Steps.Count)
                return BadRequest("Invalid step index");

            var step = Steps[stepIndex - 1];

            object model = stepIndex switch
            {
                1 => await GenerateStep(stepIndex),
                2 => await GenerateStep(stepIndex, type,
                             string.IsNullOrEmpty(SendData) ? null : JsonConvert.DeserializeObject<Dictionary<string, string>>(SendData)
                ),
                ////2 => await GenerateStep(stepIndex, type),
                _ => null
            };
            ViewBag.Title = step.Title;
            return PartialView(step.PartialView, model);
        }

        async Task<IStepViewModel> GenerateStep(int stepIndex, string type = "", Dictionary<string, string>? SendData = null)
        {

            IStepViewModel? model = null;
            Dictionary<string, object>? redirectData = new Dictionary<string, object>();

            switch (stepIndex)
            {
                case 1:
                    Dictionary<string, List<TableSchema>> dic = new Dictionary<string, List<TableSchema>>();
                    //var maker = new List<TableSchema>
                    //{
                    //     new()
                    //    {
                    //        TableId = "tbMaker1",
                    //        AjaxUrl = "/Supplier/GetMakerData",
                    //        FetchMode = FetchMode.All,
                    //        Message="* Existed in the company",
                    //        //AjaxParams  = new
                    //        //{
                    //        //    makername = "MITSUI",
                    //        //    companyid = "2"
                    //        //},

                    //        Features = new TableFeatures
                    //        {
                    //            Checkbox = false,
                    //            Export = true,
                    //            RowButtons = true,
                    //            ColumnToggle = true,
                    //            RowSelect = true,
                    //            SelectAll = true,
                    //            VirtualScroll = true,
                    //            ColumnFilter = false,   // 可選，每欄都有 filter
                    //            StickyHeader = true    // 可選，表頭固定
                    //        },

                    //        Config = new TableConfig
                    //        {
                    //            PageLength = 2,
                    //            VirtualScrollHeight = "500px",
                    //            Searching = false,
                    //            Ordering = false,
                    //            Paging = true,
                    //            LengthChange = false,
                    //            StateSave = true
                    //        },

                    //        //ToolbarButtons =
                    //        //{
                    //        //    new("Add", "add"),
                    //        //    new("Delete Selected", "deleteSelected", "btn btn-danger"),
                    //        //    new("Reload", "reload", "btn btn-secondary")
                    //        //},

                    //        Columns =
                    //        {
                    //            new("MakerCode"),
                    //            new("MakerLocalName"),
                    //            new("MakerEngName"),
                    //            new("MakerShortName"),
                    //            new("Country"),
                    //            new("City"),
                    //            new("FacilityAddress"),
                    //            //new("MakerType",visible:true)
                    //        },

                    //        RowButtons =
                    //        {
                    //            new(){ Title="Add Another Maker Type", Event="addMakerType", Icon="bi-pencil"},
                    //            new(){ Title="Add New Site", Event="addNewSite", Icon="bi-pencil"}
                    //        }
                    //    }
                    //    ,new()
                    //    {
                    //        TableId = "tbMaker2",
                    //        AjaxUrl = "",
                    //        FetchMode = FetchMode.All,
                    //        Message="* Existed in the group companyd(excluding itself)",
                    //        Features = new TableFeatures
                    //        {
                    //            Checkbox = false,
                    //            Export = true,
                    //            RowButtons = true,
                    //            ColumnToggle = true,
                    //            RowSelect = true,
                    //            SelectAll = true,
                    //            VirtualScroll = true,
                    //            ColumnFilter = false,   // 可選，每欄都有 filter
                    //            StickyHeader = true    // 可選，表頭固定
                    //        },

                    //        Config = new TableConfig
                    //        {
                    //            PageLength = 20,
                    //            VirtualScrollHeight = "500px",
                    //            Searching = false,
                    //            Ordering = false,
                    //            Paging = false,
                    //            LengthChange = false,
                    //            StateSave = true
                    //        },

                    //        //ToolbarButtons =
                    //        //{
                    //        //    new("Add", "add"),
                    //        //    new("Delete Selected", "deleteSelected", "btn btn-danger"),
                    //        //    new("Reload", "reload", "btn btn-secondary")
                    //        //},

                    //        Columns =
                    //        {
                    //            new("MakerCode"),
                    //            new("MakerLocalName"),
                    //            new("MakerEngName"),
                    //            new("MakerShortName"),
                    //            new("Country"),
                    //            new("City"),
                    //            new("FacilityAddress"),
                    //            new("MakerStatus"),
                    //            //new("MakerType",visible:true)
                    //        },

                    //        RowButtons =
                    //        {
                    //            new(){ Title="Copy Maker", Event="cpMaker", Icon="bi-pencil"},
                    //            //new(){ Title="Copy Maker", Event="cpMaker", Icon="bi-pencil"}
                    //        }
                    //    }
                    //};
                    //var vendor = new List<TableSchema>
                    //{
                    //    new()
                    //    {
                    //          TableId = "tbVendor",
                    //          AjaxUrl = "/Supplier/GetVendorData",
                    //          FetchMode = FetchMode.All,

                    //          Features = new TableFeatures
                    //          {
                    //              Checkbox = false,
                    //              Export = true,
                    //              RowButtons = true,
                    //              ColumnToggle = true,
                    //              RowSelect = true,
                    //              SelectAll = true,
                    //              VirtualScroll = true,
                    //              ColumnFilter = false,   // 可選，每欄都有 filter
                    //              StickyHeader = true    // 可選，表頭固定
                    //          },

                    //          Config = new TableConfig
                    //          {
                    //              PageLength = 20,
                    //              VirtualScrollHeight = "500px",
                    //              Searching = false,
                    //              Ordering = false,
                    //              Paging = false,
                    //              LengthChange = false,
                    //              StateSave = true
                    //          },

                    //          //ToolbarButtons =
                    //          //{
                    //          //    new("Add", "add"),
                    //          //    new("Delete Selected", "deleteSelected", "btn btn-danger"),
                    //          //    new("Reload", "reload", "btn btn-secondary")
                    //          //},

                    //          Columns =
                    //            {
                    //                new("OUSite"),
                    //                new("Inactive"),
                    //                new("GroupName"),
                    //                new("GroupCode"),
                    //                new("VendorName"),
                    //                new("VandorNameAlt"),
                    //                new("VandorCode"),
                    //                new("SSRName"),
                    //                new("TaxRegistration"),
                    //                new("SupplierType"),
                    //            }, 
                    //            //RowButtons =
                    //            //{
                    //            //    new(){ Title="Edit", Event="edit", Icon="bi-pencil"},
                    //            //    new(){ Title="Delete", Event="delete", Icon="bi-trash", CssClass="btn btn-sm btn-danger"}
                    //            //}
                    //    }
                    //};
                    //dic["maker"] = maker;
                    //dic["vendor"] = vendor;
                    dic["Step" + (stepIndex).ToString()] = new List<TableSchema>();
                    model = new StepViewModel<TableSchema>
                    {
                        Title = "第一頁",
                        Data = dic
                    };

                    break;
                case 2:

                    if (!string.IsNullOrEmpty(type))
                    {
                        redirectData = JsonConvert.DeserializeObject<Dictionary<string, object>>(type);
                    }
                    //先找CONFIG
                    Dictionary<string, List<DynamicField>> dic2 = new Dictionary<string, List<DynamicField>>();
                    //string[] sections = ["Supplier Information", "Vendor Subrange", "Company Profile"];
                    //string[] sections = ["Step1"];


                    var list = new List<DynamicField>();

                    //list.Add(new DynamicField
                    //{
                    //    Name = "Name",
                    //    Id = "Name",
                    //    Pattern = "",
                    //    Must = false,
                    //    AsyncUrl = "/Home/GetUser",
                    //    Type = FieldType.Textbox,
                    //    Target = "userName,email",
                    //    Width = 3,
                    //    Order = 1
                    //});

                    if (redirectData.GetString("type") == "A")
                    {
                        list.Add(new DynamicField
                        {
                            Name = "userName",
                            Id = "userName",
                            Pattern = "",
                            Must = false,
                            Value = redirectData.GetString("userName"),
                            Type = FieldType.Textbox,
                            Width = 3,
                            Order = 2
                        });
                    }
                    if (redirectData.GetString("type") == "B")
                    {
                        list.Add(new DynamicField
                        {
                            Name = "email",
                            Id = "email",
                            Pattern = "",
                            Must = false,
                            Value = redirectData.GetString("email"),
                            Type = FieldType.Textbox,
                            Width = 3,
                            Order = 2
                        });
                    }

                    list.Add(new DynamicField
                    {
                        Name = "age",
                        Id = "age",
                        Must = true,
                        Value = redirectData.GetString("age"),
                        Type = FieldType.Numeric,
                        Placeholder = "請輸入年齡",
                        Width = 3,
                        Pattern = "",
                        Order = 2
                    });
                    //                list.Add(new DynamicField
                    //                {
                    //                    Name = "DueDate",
                    //                    Id = "DueDate",
                    //                    Must = true,
                    //                    Type = FieldType.Date,
                    //                    Placeholder = "請輸入到期日",
                    //                    Width = 3,
                    //                    Pattern = "",
                    //                    Order = 3
                    //                });
                    //list.Add(new DynamicField
                    //{
                    //    Must = true,
                    //    Id = "status1",
                    //    Name = "status1",
                    //    Type = FieldType.Select2,
                    //    Placeholder = "請輸入關鍵字",
                    //    AsyncUrl = "/Home/GetOptions",
                    //    Width = 3,
                    //    Pattern = "",
                    //    //DefaultValue = "2",
                    //    //Options = new List<SelectItem>{
                    //    //                    new SelectItem{Value="1",Text="正常",Color="lightgreen"},
                    //    //                    new SelectItem{Value="2",Text="警告",Color="yellow"},
                    //    //                    new SelectItem{Value="3",Text="異常",Color="red"}
                    //    //                }
                    //});
                    //                list.Add(new DynamicField
                    //                {
                    //                    Must = true,
                    //                    Name = "status2",
                    //                    Id = "status2",
                    //                    Type = FieldType.Dropdown,
                    //                    Width = 3,
                    //                    Pattern = "",
                    //                    DefaultValue = "3",
                    //                    Options = new List<SelectItem>{
                    //                        new SelectItem{Value="1",Text="正常",Color="lightgreen"},
                    //                        new SelectItem{Value="2",Text="警告",Color="yellow"},
                    //                        new SelectItem{Value="3",Text="異常",Color="red"}
                    //                    }
                    //                });
                    //                list.Add(new DynamicField
                    //                {
                    //                    Name = "Name2",
                    //                    Id = "Name2",
                    //                    Pattern = "",
                    //                    Must = false,
                    //                    Type = FieldType.Textarea,
                    //                    Width = 3,
                    //                    Order = 1
                    //                });


                    //list.Add(new DynamicField
                    //{
                    //    Name = "tgtest"
                    //    ,
                    //    Id = "測試欄位B"
                    //    ,
                    //    Type = FieldType.File
                    //    ,
                    //    Must = true
                    //    ,
                    //    Width = 3
                    //    ,
                    //    Order = 2
                    //});


                    //                list.Add(new DynamicField
                    //                {
                    //                    Name = "test",
                    //                    Id = "test",
                    //                    Type = FieldType.Radio,
                    //                    Must = true,
                    //                    Width = 3,
                    //                    Order = 1,
                    //                    Options = new List<SelectItem>
                    //{
                    //    new() { Value = "1", Text = "選項一" },
                    //    new() { Value = "2", Text = "選項二" }

                    //},
                    //InverseSelect = true,

                    //DefaultValue = "2"
                    //});


                    dic2["Step" + (stepIndex).ToString()] = list;



                    model = new StepViewModel<DynamicField>
                    {
                        Title = "第二頁",
                        Data = dic2//SendData == null ? dic2 : await _supplierService.MappingSendData(dic2, SendData)
                    };


                    //foreach (var item in sections)
                    //{
                    //    dic2[item.Replace(" ", "")] = await _supplierService.GetConfigFieldAsync(item, type);
                    //}
                    //var userFromDb = new UserProfile { CompanyCode = "Johnny", MakerType = "Normal", RequestReason = "test@me.com" };

                    //_dynamicFieldService.FillSchemaWithModel(dic2, userFromDb);

                    //model = new StepViewModel<DynamicField>
                    //{
                    //    Title = "第二頁",
                    //    Data = SendData == null ? dic2 : await _supplierService.MappingSendData(dic2, SendData)
                    //};
                    break;
                    //case 2:
                    //    Dictionary<string, List<DynamicSupplierFileField>> dic3 = new Dictionary<string, List<DynamicSupplierFileField>>();
                    //    dic3["SupplierVC"] = await _supplierService.GetConfigFileListAsync(type);
                    //    model = new StepViewModel<DynamicSupplierFileField>
                    //    {
                    //        Title = "第三頁",
                    //        Data = dic3
                    //    };
                    //    break;
            }
            return model;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
