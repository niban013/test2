﻿using System.Data;

namespace OneSupplierPlatform.Utility
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection(string dbName = "AMSC-SQLDB");
    }

    public interface IGenericRepository
    {
        // =========================
        // Transaction
        // =========================
        Task BeginTransactionAsync();
        void Commit();
        void Rollback();

        // =========================
        // CRUD (Async)
        // =========================
        Task InsertAsync<T>(T entity);
        Task UpdateAsync<T>(T entity);
        Task DeleteAsync<T>(object keys);

        Task<T> GetAsync<T>(object keys) where T : new();
        Task SaveAsync<T>(T entity) where T : new();

        // =========================
        // SQL (Async)
        // =========================
        Task<int> ExecuteSqlAsync(string sql, object param = null);

        Task<List<T>> QueryAsync<T>(string sql, object param = null) where T : new();

        Task<T> QuerySingleAsync<T>(string sql, object param = null) where T : new();

        Task<object> ExecuteScalarAsync(string sql, object param = null);
    }
}
