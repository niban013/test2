﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Reflection;
using Microsoft.Data.SqlClient;
using newauo.Helper;

namespace OneSupplierPlatform.Utility
{
    // =========================
    // Extension
    // =========================
    public static class DataReaderExtensions
    {
        public static bool HasColumn(this IDataRecord reader, string columnName)
        {
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).Equals(columnName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }
    }

    // =========================
    // Connection Factory (Multi DB)
    // =========================
    public class SqlConnectionFactory : IDbConnectionFactory
    {
        private readonly IConfiguration _config;

        public SqlConnectionFactory(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection CreateConnection(string dbName = "AMSC-SQLDB")
        {
            var connStr = _config.GetConnectionString(dbName);

            var conn = new SqlConnection(connStr);
            conn.Open();
            return conn;
        }
    }

    // =========================
    // Repository
    // =========================
    public class GenericRepository : IGenericRepository, IDisposable
    {
        private readonly IDbConnectionFactory _factory;
        private IDbConnection _conn;
        private IDbTransaction _tx;
        private readonly string _dbName;

        public GenericRepository(IDbConnectionFactory factory, string dbName = "AMSC-SQLDB")
        {
            _factory = factory;
            _dbName = dbName;
        }

        // =========================
        // Connection
        // =========================
        private async Task<IDbConnection> GetOpenConnectionAsync()
        {
            if (_conn == null)
                _conn = _factory.CreateConnection(_dbName);

            // 強制轉型為 SqlConnection 以使用非同步方法
            if (_conn is SqlConnection sqlConn)
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    // 在 Open 之前最後確認一次字串是否存在
                    if (string.IsNullOrEmpty(sqlConn.ConnectionString))
                        throw new Exception($"連線字串 '{_dbName}' 遺失，請檢查 appsettings.json。");

                    await sqlConn.OpenAsync();
                }
            }
            else if (_conn.State == ConnectionState.Closed)
            {
                _conn.Open();
            }

            return _conn;
        }

        public void UseDatabase(string dbName)
        {
            _conn?.Dispose();
            _conn = _factory.CreateConnection(dbName);
        }

        // =========================
        // Transaction
        // =========================
        public async Task BeginTransactionAsync()
        {
            var conn = await GetOpenConnectionAsync();
            _tx = conn.BeginTransaction();
        }

        public void Commit()
        {
            _tx?.Commit();
            _tx = null;
        }

        public void Rollback()
        {
            _tx?.Rollback();
            _tx = null;
        }

        // =========================
        // Command
        // =========================
        private async Task<IDbCommand> CreateCommandAsync(string sql)
        {
            var conn = await GetOpenConnectionAsync();
            var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            if (_tx != null) cmd.Transaction = _tx;
            return cmd;
        }

        private void AddParameters(IDbCommand cmd, object param)
        {
            if (param == null) return;

            var props = param.GetType().GetProperties();

            foreach (var p in props)
            {
                var dbParam = cmd.CreateParameter();
                dbParam.ParameterName = "@" + p.Name;
                dbParam.Value = p.GetValue(param) ?? DBNull.Value;
                cmd.Parameters.Add(dbParam);
            }
        }

        // =========================
        // Execute Helpers
        // =========================
        private async Task ExecuteAsync(string sql, List<IDataParameter> parameters)
        {
            try
            {
                using var cmd = await CreateCommandAsync(sql);

                foreach (var p in parameters)
                    cmd.Parameters.Add(p);

                await ((SqlCommand)cmd).ExecuteNonQueryAsync();
            }
            catch (SqlException ex)
            { 
                throw new Exception($"SQL 執行失敗: {sql}", ex);
            }
        }

        private IDataParameter CreateParameter(string name, object value)
        {
            return new SqlParameter
            {
                ParameterName = name,
                Value = value ?? DBNull.Value
            }; 
        }

        // =========================
        // INSERT
        // =========================
        public async Task InsertAsync<T>(T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var props = GetProps(type);

            var cols = new List<string>();
            var vals = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var p in props)
            {
                //if (p.GetCustomAttribute<KeyAttribute>() != null)
                //    continue;
                var dbGeneratedAttr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
                if (dbGeneratedAttr != null && dbGeneratedAttr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity)
                {
                    continue; // 跳過此欄位，不寫入 INSERT 語法中
                }
                var val = p.GetValue(entity);
                if (val == null) continue;

                var col = GetColumnName(p);

                cols.Add(col);
                vals.Add("@" + col);

                parameters.Add(CreateParameter("@" + col, val));
            }

            var sql = $@"
INSERT INTO {table}
({string.Join(",", cols)})
VALUES
({string.Join(",", vals)})
";

            await ExecuteAsync(sql, parameters);
        }

        // =========================
        // UPDATE
        // =========================
        public async Task UpdateAsync<T>(T entity)
        {
            var type = typeof(T);
            var table = GetTableName(type);

            var keyProps = GetKeyProperties(type);
            var props = GetProps(type);

            var sets = new List<string>();
            var where = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var p in props)
            {
                var dbGeneratedAttr = p.GetCustomAttribute<DatabaseGeneratedAttribute>();
                if (dbGeneratedAttr != null && dbGeneratedAttr.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity)
                {
                    continue; // 跳過此欄位，不寫入 update 語法中
                }
                var skipAttr = p.GetCustomAttribute<SkipAttribute>();
                if (skipAttr != null)
                {
                    continue; 
                }
                var col = GetColumnName(p);
                var val = p.GetValue(entity) ?? DBNull.Value;

                if (keyProps.Contains(p))
                    where.Add($"{col}=@{col}");
                else
                    sets.Add($"{col}=@{col}");

                parameters.Add(CreateParameter("@" + col, val));
            }

            var sql = $@"
UPDATE {table}
SET {string.Join(",", sets)}
WHERE {string.Join(" AND ", where)}
";

            await ExecuteAsync(sql, parameters);
        }

        // =========================
        // DELETE
        // =========================
        public async Task DeleteAsync<T>(object keys)
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);
                if (!IsValidValue(val))
                    continue;
                where.Add($"{col}=@{col}");
                parameters.Add(CreateParameter("@" + col, val));
            }
            if (where.Count == 0)
                throw new Exception("No valid keys provided for DeleteAsync");
            var sql = $"DELETE FROM {table} WHERE {string.Join(" AND ", where)}";
            await ExecuteAsync(sql, parameters);
        }

        // =========================
        // GET
        // =========================
        public async Task<T> GetAsync<T>(object keys) where T : new()
        {
            var type = typeof(T);
            var table = GetTableName(type);
            var keyProps = GetKeyProperties(type);

            var where = new List<string>();
            var parameters = new List<IDataParameter>();

            foreach (var kp in keyProps)
            {
                var col = GetColumnName(kp);
                var val = GetKeyValue(keys, kp.Name);
                if (!IsValidValue(val))
                    continue;
                where.Add($"{col}=@{col}");
                parameters.Add(CreateParameter("@" + col, val));
            }
            if (where.Count == 0)
                throw new Exception("No valid keys provided for GetAsync");
            var sql = $"SELECT * FROM {table} WHERE {string.Join(" AND ", where)}";

            using var cmd = await CreateCommandAsync(sql);
            foreach (var p in parameters)
                cmd.Parameters.Add(p);

            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync();

            if (!await reader.ReadAsync())
            {
                return default;
            }
            else
            {
                var obj = new T();

                foreach (var p in GetProps(type))
                {
                    var col = GetColumnName(p);

                    if (!reader.HasColumn(col)) continue;

                    var val = reader[col];
                    if (val == DBNull.Value) continue;

                    p.SetValue(obj,
                        Convert.ChangeType(val,
                        Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType));
                }

                return obj;
            }
        }

        // =========================
        // SAVE
        // =========================
        public async Task SaveAsync<T>(T entity) where T : new()
        {
            try
            {
                var keyProps = GetKeyProperties(typeof(T));

                var keyDict = new Dictionary<string, object>();

                foreach (var kp in keyProps)
                {
                    var val = kp.GetValue(entity);

                    if (!IsValidValue(val))
                        continue;

                    keyDict[kp.Name] = val;
                }

                if (keyDict.Count == 0)
                    throw new Exception("No valid key values for SaveAsync");

                var existing = await GetAsync<T>(keyDict);

                if (existing == null)
                    await InsertAsync(entity);
                else
                    await UpdateAsync(entity);
            }
            catch (SqlException ex)
            { 
                throw new Exception($"資料庫儲存失敗，型別：{typeof(T).Name}", ex);
            }
            catch (Exception ex)
            { 
                throw;
            }
        }

        // =========================
        // QUERY
        // =========================
        public async Task<List<T>> QueryAsync<T>(string sql, object param = null) where T : new()
        {
            using var cmd = await CreateCommandAsync(sql);
            AddParameters(cmd, param);

            using var reader = await ((SqlCommand)cmd).ExecuteReaderAsync();

            var list = new List<T>();
            var props = typeof(T).GetProperties();

            while (await reader.ReadAsync())
            {
                var obj = new T();

                foreach (var p in props)
                {
                    var col = GetColumnName(p);

                    if (!reader.HasColumn(col)) continue;

                    var val = reader[col];
                    if (val == DBNull.Value) continue;

                    p.SetValue(obj,
                        Convert.ChangeType(val,
                        Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType));
                }

                list.Add(obj);
            }

            return list;
        }

        public async Task<T> QuerySingleAsync<T>(string sql, object param = null) where T : new()
        {
            var list = await QueryAsync<T>(sql, param);
            return list.FirstOrDefault();
        }

        public async Task<object> ExecuteScalarAsync(string sql, object param = null)
        {
            using var cmd = await CreateCommandAsync(sql);
            AddParameters(cmd, param);
            return await ((SqlCommand)cmd).ExecuteScalarAsync();
        }

        public async Task<int> ExecuteSqlAsync(string sql, object param = null)
        {
            using var cmd = await CreateCommandAsync(sql);
            AddParameters(cmd, param);
            return await ((SqlCommand)cmd).ExecuteNonQueryAsync();
        }

        // =========================
        // Helpers
        // =========================
        private string GetTableName(Type type)
        {
            var attr = type.GetCustomAttribute<TableAttribute>();
            return attr?.Name ?? type.Name;
        }

        private List<PropertyInfo> GetKeyProperties(Type type)
        {
            var keys = type.GetProperties()
                .Where(p => p.GetCustomAttribute<KeyAttribute>() != null)
                .ToList();

            if (!keys.Any())
                throw new Exception($"No [Key] defined on {type.Name}");

            return keys;
        }

        private string GetColumnName(PropertyInfo prop)
        {
            var json = prop.GetCustomAttribute<JsonPropertyAttribute>();
            return json?.PropertyName ?? prop.Name;
        }

        private List<PropertyInfo> GetProps(Type t)
        {
            return t.GetProperties()
                .Where(p => p.CanRead && p.CanWrite)
                .ToList();
        }

        private object GetKeyValue(object keyObj, string propName)
        {
            if (keyObj == null) return null;
            if (keyObj is System.Collections.IDictionary dict)
            {
                return dict.Contains(propName) ? dict[propName] : null;
            } 
            var prop = keyObj.GetType().GetProperty(propName);
            return prop?.GetValue(keyObj);
        }

        public void Dispose()
        {
            _tx?.Dispose();
            _conn?.Close();
            _conn?.Dispose();
        }

        private bool IsValidValue(object value)
        {
            if (value == null) return false;

            if (value is string s && string.IsNullOrWhiteSpace(s))
                return false;

            return true;
        }
    }
}
