﻿using Microsoft.AspNetCore.Mvc;
using OneSupplierPlatform.Models;
using OneSupplierPlatform.Models.Infra;
using OneSupplierPlatform.Services;

namespace OneSupplierPlatform.Controllers
{
    [ApiController]
    [Route("api/file")]
    public class FileController : BaseController
    {
        private readonly FileService _fileService;
        private readonly IWebHostEnvironment _env;

        public FileController(IWebHostEnvironment env, FileService fileService)
        {
            _env = env;
            _fileService = fileService;
        }

        [HttpPost("UploadFileAsync")]
        public async Task<IActionResult> UploadFileAsync([FromForm] FlmFileInfo file)
        {
            try
            {
                file.CUser = CurrentUser.EmployeeId;
                //await _fileService.UploadFileAsync(file);
                // 模擬 upload
                var fileId = Guid.NewGuid().ToString();

                var response = new UploadFileResponse
                {
                    FileId = fileId,
                    FileName = file.FileName,
                    Size = file.File?.Length ?? 0,
                    Mime = file.File?.ContentType
                };

                return Ok(ApiResponse<UploadFileResponse>.Ok(response));
            }
            catch (Exception ex)
            {
                return BadRequest(
                    ApiResponse<object>.Fail(ex.Message)
                );
            }
        }

        [HttpGet("/api/file/list")]
        public async Task<IActionResult> GetFileList(string formno, string key)
        {
            try
            {
                var list = await _fileService.GetFilesAsync(key, formno);

                return Ok(
                    ApiResponse<List<FlmFileInfo>>.Ok(list)
                );
            }
            catch (Exception ex)
            {
                return StatusCode(
                    500,
                    ApiResponse<object>.Fail("file list error")
                );
            }
        }
        //public async Task<List<FlmFileInfo>> GetFileList(string formno, string key)
        //{
        //    return await _fileService.GetFilesAsync(key, formno);
        //}
        [HttpGet("/api/file/{id}")]
        public async Task<IActionResult> GetFile(string id)
        {
            try
            {
                var fileInfo = await _fileService.GetFileAsync(id);

                if (fileInfo == null || fileInfo.bytes == null)
                {
                    return NotFound(
                        ApiResponse<object>.Fail("file not found")
                    );
                }

                return File(
                    fileInfo.bytes,
                    fileInfo.Mime ?? "application/octet-stream",
                    fileInfo.FileName ?? "download"
                );
            }
            catch (Exception ex)
            {
                return StatusCode(
                    500,
                    ApiResponse<object>.Fail("file error")
                );
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var result = true;// await _fileService.DeleteFileAsync(id);

                if (!result)
                {
                    return NotFound(
                        ApiResponse<object>.Fail("File not found")
                    );
                }

                return Ok(
                    ApiResponse<object>.Ok(new { id })
                );
            }
            catch (Exception)
            {
                return StatusCode(
                    500,
                    ApiResponse<object>.Fail("delete failed")
                );
            }
        }

        [HttpPost("TempUpload")]
        public async Task<IActionResult> TempUpload(IFormFile file)
        {
            var token = Guid.NewGuid().ToString();

            var tempPath =
                Path.Combine(
                    _env.WebRootPath,
                    "temp",
                    token + Path.GetExtension(file.FileName)
                );

            Directory.CreateDirectory(Path.GetDirectoryName(tempPath)!);

            using var stream = new FileStream(tempPath, FileMode.Create);

            await file.CopyToAsync(stream);

            return Ok(new
            {
                success = true,
                token,
                fileName = file.FileName
            });
        }
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(string id)
        //{
        //    var result = await _fileService.DeleteFileAsync(id);

        //    if (!result)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(new
        //    {
        //        success = true
        //    });
        //}
    }
}
