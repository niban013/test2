﻿

namespace OneSupplierPlatform.Models
{

    public class FlmFileInfo
    {
        public string ItemId { get; set; }
        public string ItemName { get; set; }

        public string FormNo { get; set; }
        public string? FileId { get; set; }
        public string FileName { get; set; }
        public string? Active { get; set; } = "Y";
        public string? CUser { get; set; }
        public string? CDate { get; set; }

        public IFormFile File { get; set; }

        public string? Mime { get; set; }

        public Byte[]? bytes { get; set; }


    }
    public class vmSupplierQuery
    {
        // === 查詢條件 (原本欄位保持不變) ===
        public string? VendorName { get; set; }
        public string? VendorCode { get; set; }
        public string? FormNo { get; set; }
        public string? FormStatus { get; set; }
        public DateTime? CreateDateFrom { get; set; }
        public DateTime? CreateDateTo { get; set; }

        // === 💡 新增：分頁控制參數 ===
        public int PageNumber { get; set; } = 1;      // 當前頁碼 (預設第 1 頁)
        public int PageSize { get; set; } = 10;        // 每頁筆數 (預設 10 筆)
        public int TotalItems { get; set; }            // 總資料筆數
        public int TotalPages => (int)Math.Ceiling((double)TotalItems / PageSize); // 計算總頁數

        // === 查詢結果清單 ===
        public List<SupplierItem> Results { get; set; } = new List<SupplierItem>();
    }

    public class SupplierItem
    {
        public string? FormNo { get; set; }
        public string? VendorName { get; set; }
        public string? VendorNameAlt { get; set; }
        public string? VendorCode { get; set; }
        public DateTime? CreateDate { get; set; }
        public string? FlowerStatus { get; set; }
        public string? ApplyType { get; set; }
        public string? Applicant { get; set; }
        public string? Department { get; set; }
    }
}




 
