﻿$(document).ready(function () {
    $("#customerDatatable").DataTable({
        "processing": true,
        "serverSide": true,
        "filter": true,
        "ajax": {
            "url": "/api/customer",
            "type": "POST",
            "datatype": "json"
        },
        "columnDefs": [{
            "targets": [0],
            "visible": false,
            "searchable": false
        }],
        "columns": [
            { "data": "id", "name": "Id", "autoWidth": true },
            { "data": "firstName", "name": "First Name", "autoWidth": true },
            { "data": "lastName", "name": "Last Name", "autoWidth": true },
            { "data": "contact", "name": "Country", "autoWidth": true },
            { "data": "email", "name": "Email", "autoWidth": true },
            { "data": "dateOfBirth", "name": "Date Of Birth", "autoWidth": true },
            {
                "render": function (data, type, full) {
                    return '<div class="btn-group"> <button type="button" id="' + full.id + '" onclick=" rowDataGet (this.id) " class="btn btn-light" ><img src="../img/enlarge.svg" alt="buttonpng" border="0" style="width: 24px;height: 16px;" /></button></div>' },
            }
        ]
    });
   
});
var jsonData = [
    { "firstname": "山田", "tel": "0000000", "year": "30", "product": "マンが" },
    { "firstname": "山田", "tel": "0000000", "year": "30", "product": "肉" },
    { "firstname": "山田", "tel": "0000000", "year": "30", "product": "魚" },
    { "firstname": "山田", "tel": "0000000", "year": "30", "product": "タバコ" },
    { "firstname": "山田", "tel": "0000000", "year": "30", "product": "皿" },
    { "firstname": "山田", "tel": "0000000", "year": "20", "product": "人形" },
    { "firstname": "山田", "tel": "0000000", "year": "30", "product": "ゲーム" },
    { "firstname": "佐藤", "tel": "0000000", "year": "30", "product": "骨" },
    { "firstname": "佐藤", "tel": "0000000", "year": "30", "product": "パッド" },
    { "firstname": "佐藤", "tel": "0000000", "year": "30", "product": "ボール" },
    { "firstname": "マイケル", "tel": "0000000", "year": "30", "product": "ゲーム" },
    { "firstname": "マイケル", "tel": "0000000", "year": "30", "product": "ボール" },
    { "firstname": "ヨーコ", "tel": "0000000", "year": "30", "product": "ゲーム" },
];
var table = $('#example').DataTable({
    'language': {
        "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Japanese.json"
    },

    scrollY: '55vh',
    //autoWidth: true,
    scrollX: false,
    scrollCollapse: true,
    //autoWidth: false, // 避免自動欄寬不穩定
    searching: false,
    ordering: false,
    data: jsonData,
    //'data': [
    //    ["山田", "0000000", "30", "マンが"],
    //    ["山田", "0000000", "30", "肉"],
    //    ["山田", "0000000", "30", "魚"],
    //    ["山田", "0000000", "30", "タバコ"],
    //    ["山田", "0000001", "30", "皿"],
    //    ["山田", "0000001", "20", "人形"],
    //    ["山田", "0000001", "30", "ゲーム"],
    //    ["佐藤", "1111111", "21", "骨"],
    //    ["佐藤", "1111111", "21", "パッド"],
    //    ["佐藤", "1111111", "21", "ボール"],
    //    ["マイケル", "2222222", "10", "バッド"],
    //    ["マイケル", "2222222", "10", "刀"],
    //    ["ヨーコ", "3333333", "40", "お花"],
    //],
    "columns": [
        { "data": "firstname", "name": "firstname", "autoWidth": false },
        { "data": "tel", "name": "tel", "autoWidth": false },
        { "data": "year", "name": "year", "autoWidth": false },
        { "data": "product", "name": "product", "autoWidth": false },
        {
            "render": function (data, type, row) { return "<a href='#' class='btn btn-danger' style='height: 16px;' onclick=DeleteCustomer('" + row.firstname + "'); >Delete</a>"; }
        },
    ],
    'columnDefs': [
        {
            'targets': [0, 1, 2, 3],
            'orderable': false,
            'searchable': false
        },
        { targets: "_all", className: "cell-bordered" }
    ],
    paging: false,
    info: false,
    'rowsGroup': [0, 1, 2],
    //"pageLength": 100,
    initComplete: function () {
        // 在 footer 內放自訂按鈕
        $('#footer-buttons').append(`
                <button id="btnExport">Export</button>
                <button id="btnReload">Reload</button>
            `);

        // 綁定事件
        $('#btnExport').on('click', function () {
            alert("Export clicked! Rows: " + table.rows().count());
        });

        $('#btnReload').on('click', function () {
            table.ajax.reload();
            alert("Reload triggered!");
        });
    },
});//.columns.adjust();
//setTimeout(function () {
//    //table.css("font-size", fontSize(0.14));
//    table.columns.adjust().draw();
//}, 200);
function rowDataGet(e) {
    console.log(e)
    $('#example').DataTable().destroy();
    $('#example thead').hide();
    $('#myModal').on('shown.bs.modal', function () {
        $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
    });
    $('#myModal').modal({ show: true });
    //alert(e)
}
function DeleteCustomer(id) {
    alert(id)
}
$('#example tbody').on('click', '[id*=btnDetails]', function () {
    var data = table.row($(this).parents('tr')).data();
    var customerID = data[0];
    var name = data[1];
    var title = data[2];
    var city = data[3];
    alert("Customer ID : " + customerID + "\n" + "Name : " + name + "\n" + "Title : " + title + "\n" + "City : " + city);
});