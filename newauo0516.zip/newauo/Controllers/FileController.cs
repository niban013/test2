﻿using Microsoft.AspNetCore.Mvc;

namespace newauo.Controllers
{
    [ApiController]
    [Route("api/file")]
    public class FileController : ControllerBase
    {
        private readonly IWebHostEnvironment _env;

        public FileController(IWebHostEnvironment env)
        {
            _env = env;
        }
        [HttpGet("/api/file/list")]
        public IActionResult GetFileList(string stepKey, string key)
        {
            var data = new[]
            {
        new { id = "f001", name = "demo-image.png", size = 12000, type = "image/png" },
        new { id = "f002", name = "report.pdf", size = 300000, type = "application/pdf" },
        new { id = "f003", name = "data.xlsx", size = 90000, type = "application/vnd" }
    };

            return Ok(data);
        }
        [HttpGet("/api/file/{id}")]
        public async Task<IActionResult> GetFile(string id)
        {
            // demo: 回傳 fake file
            var bytes = System.IO.File.ReadAllBytes("wwwroot/下載.png");

            return File(bytes, "image/png", "下載.png");
        }
        [HttpPost("upload")]
        [RequestSizeLimit(1024 * 1024 * 100)] // 100MB
        public async Task<IActionResult> Upload(IFormFile file)
        {
            try
            {
                // =========================
                // no file
                // =========================
                if (file == null || file.Length == 0)
                {
                    return BadRequest(new
                    {
                        message = "empty file"
                    });
                }

                // =========================
                // fake delay
                // =========================
                await Task.Delay(Random.Shared.Next(500, 2000));

                // =========================
                // random fail
                // =========================
                var fail = Random.Shared.Next(1, 100) <= 25;

                if (fail)
                {
                    return StatusCode(500, new
                    {
                        message = "fake upload failed"
                    });
                }

                // =========================
                // save path
                // =========================
                var uploadRoot = Path.Combine(
                    _env.ContentRootPath,
                    "App_Data",
                    "Uploads"
                );

                Directory.CreateDirectory(uploadRoot);

                // =========================
                // fake id
                // =========================
                var fileId = Guid.NewGuid().ToString("N");

                // =========================
                // extension
                // =========================
                var ext = Path.GetExtension(file.FileName);

                // =========================
                // actual filename
                // =========================
                var saveName = $"{fileId}{ext}";

                var fullPath = Path.Combine(
                    uploadRoot,
                    saveName
                );

                // =========================
                // save file
                // =========================
                await using (var fs = new FileStream(
                    fullPath,
                    FileMode.Create
                ))
                {
                    await file.CopyToAsync(fs);
                }

                // =========================
                // fake response
                // =========================
                return Ok(new
                {
                    id = fileId,

                    fileName = file.FileName,

                    size = file.Length,

                    contentType = file.ContentType,

                    uploadTime = DateTime.UtcNow,

                    lazy = true
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = ex.Message
                });
            }
        }

        //[HttpGet("{id}")]
        //public async Task<IActionResult> GetFile(string id)
        //{
        //    var uploadRoot = Path.Combine(
        //        _env.ContentRootPath,
        //        "App_Data",
        //        "Uploads"
        //    );

        //    var file = Directory
        //        .GetFiles(uploadRoot)
        //        .FirstOrDefault(x =>
        //            Path.GetFileNameWithoutExtension(x) == id
        //        );

        //    if (file == null)
        //    {
        //        return NotFound();
        //    }

        //    var bytes = await System.IO.File.ReadAllBytesAsync(file);

        //    var ext = Path.GetExtension(file).ToLower();

        //    var contentType = ext switch
        //    {
        //        ".png" => "image/png",
        //        ".jpg" => "image/jpeg",
        //        ".jpeg" => "image/jpeg",
        //        ".pdf" => "application/pdf",
        //        ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        //        _ => "application/octet-stream"
        //    };

        //    return File(
        //        bytes,
        //        contentType,
        //        Path.GetFileName(file)
        //    );
        //}

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            var uploadRoot = Path.Combine(
                _env.ContentRootPath,
                "App_Data",
                "Uploads"
            );

            var file = Directory
                .GetFiles(uploadRoot)
                .FirstOrDefault(x =>
                    Path.GetFileNameWithoutExtension(x) == id
                );

            if (file == null)
            {
                return NotFound();
            }

            System.IO.File.Delete(file);

            return Ok(new
            {
                success = true
            });
        }
    }
}
