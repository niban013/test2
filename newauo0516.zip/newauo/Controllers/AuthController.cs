﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;

namespace newauo.Controllers
{
    public class AuthController : Controller
    {
        private readonly IConfiguration _config;
        public AuthController(IConfiguration config)
        {
            _config = config;
        }
        public async Task<IActionResult> Logout()
        {
            var cookieName = _config["CapAuth:CookieName"];
            var logoutUrl = _config["CapAuth:LogoutUrl"];
            // ==========================
            // 1. 清 MVC session
            // ==========================
            await HttpContext.SignOutAsync(
                CookieAuthenticationDefaults.AuthenticationScheme);

            // ==========================
            // 2. 清 CAP cookie（本機）
            // ==========================
            Response.Cookies.Delete(cookieName);

            // ==========================
            // 3. 導向 CAP Logout（SSO 核心）
            // ==========================
            var returnUrl =
                $"{Request.Scheme}://{Request.Host}";

            var url =
                $"{logoutUrl}" +
                $"?ReturnUrl={Uri.EscapeDataString(returnUrl)}";

            return Redirect(url);
        }

        public IActionResult Denied()
        {
            return Content("Access Denied");
        }
    }
}
