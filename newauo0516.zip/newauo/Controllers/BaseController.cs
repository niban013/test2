﻿using Microsoft.AspNetCore.Mvc;
using newauo.Models;
using System.Security.Claims;

namespace newauo.Controllers
{
    public class BaseController : Controller
    {
        protected CapUser CurrentUser
        {
            get
            {
                return new CapUser
                {
                    EmpNo =
                        User.FindFirstValue(
                            ClaimTypes.NameIdentifier),

                    EmpName =
                        User.FindFirstValue(
                            ClaimTypes.Name),

                    Mail =
                        User.FindFirstValue(
                            ClaimTypes.Email),

                    DeptNo =
                        User.FindFirstValue(
                            "DeptNo"),

                    DeptName =
                        User.FindFirstValue(
                            "DeptName")
                };
            }
        }
    }
}
