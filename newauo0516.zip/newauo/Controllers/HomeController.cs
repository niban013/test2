using Microsoft.AspNetCore.Mvc;
using newauo.Helper;
namespace newauo.Controllers
{
    [CapAuthorize]
    public class HomeController : BaseController
    {
        public IActionResult Index()
        {
            ViewBag.User = CurrentUser;

            return View();
        }
    }
}