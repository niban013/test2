﻿namespace newauo.Models
{
    public class CapUser
    {
        public string EmpNo { get; set; }

        public string EmpName { get; set; }

        public string Mail { get; set; }

        public string DeptNo { get; set; }

        public string DeptName { get; set; }
    }
}
