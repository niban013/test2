﻿using newauo.Helper;
using System.Text.RegularExpressions;

namespace newauo.Models
{
    public enum FieldType
    {
        Label,
        Textbox,
        Dropdown,
        Select2,
        Numeric,
        Date,
        Textarea,
        Radio,
        File,
        //Hiddden,
        Hybrid,
        OnlyLabel,
    }

    public static class Safe
    {
        public static bool False(bool? v) => v == true;
        public static int Value(int? v, int def) => v ?? def;
    }
    public static class RuleSchemaRegistry
    {
        public static readonly Dictionary<FieldType, HashSet<string>> ValidationRules = new()
        {
            [FieldType.Textbox] = new() { "required", "maxlength", "pattern", "async", "map" },
            [FieldType.Numeric] = new() { "required", "min", "max" },
            [FieldType.Date] = new() { "required", "min", "max" },
            [FieldType.Textarea] = new() { "required", "maxlength" },
            [FieldType.Dropdown] = new() { "required" },
            [FieldType.Radio] = new() { "required" },
            [FieldType.File] = new() { "required", "accept", "maxsize", "async", "map" },
        };

        public static readonly Dictionary<FieldType, HashSet<string>> BehaviorRules = new()
        {
            [FieldType.Label] = new() { "readonly", "hidden" },
            [FieldType.Textbox] = new() { "readonly", "hidden" },
            [FieldType.Numeric] = new() { "readonly", "hidden" },
            [FieldType.Date] = new() { "readonly", "hidden" },
            [FieldType.Textarea] = new() { "readonly", "hidden" },
            [FieldType.Dropdown] = new() { "readonly", "hidden" },
            [FieldType.Radio] = new() { "readonly", "hidden" },
            [FieldType.File] = new() { "readonly", "hidden", "multiple" },
        };

        public static bool AllowValidation(FieldType t, string rule)
            => ValidationRules.TryGetValue(t, out var set) && set.Contains(rule);

        public static bool AllowBehavior(FieldType t, string rule)
            => BehaviorRules.TryGetValue(t, out var set) && set.Contains(rule);
    }

    //public class DynamicSupplierFileField : BaseDynamicField
    //{
    //    public string VCType { get; set; }
    //    public string ExpiredDate { get; set; } = "N";

    //    [System.Text.Json.Serialization.JsonIgnore]
    //    public bool IsExpired
    //    {
    //        get => ExpiredDate?.Trim() == "Y";
    //        set => ExpiredDate = value ? "Y" : "N";
    //    }
    //    public List<string> FileList { get; set; } = new List<string>();
    //}


    // =========================
    // Domain Model（高階模型）
    // =========================
    public class DynamicField
    {
        public string Col { get; set; }
        public string ColId { get; set; }
        public string ColName { get; set; }

        public string? ColValue { get; set; }
        public FieldType EnumType { get; set; }
        public string AsyncUrl { get; set; } = string.Empty;
        public string Target { get; set; } = string.Empty;
        public string DefaultValue { get; set; } = string.Empty;
        // UI Meta
        public string Placeholder { get; set; } = string.Empty;
        public int Width { get; set; } = 3;
        public int Order { get; set; } = 1;

        public List<SelectItem> Options { get; set; } = new();

        // Validation rules
        public List<ValidationRule> ValidationRules { get; set; } = new();

        // Behavior rules
        public List<BehaviorRule> BehaviorRules { get; set; } = new();

        // Helpers
        public bool HasValidation(string name)
            => ValidationRules.Any(x => x.Name == name);

        public bool HasBehavior(string name)
            => BehaviorRules.Any(x => x.Name == name);
    }

    // =========================
    // Validation Rule
    // =========================
    public class ValidationRule
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public ValidationRule() { }

        public ValidationRule(string name, string value = null)
        {
            Name = name;
            Value = value;
        }
    }

    // =========================
    // Behavior Rule
    // =========================
    public class BehaviorRule
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public BehaviorRule() { }

        public BehaviorRule(string name, string value = null)
        {
            Name = name;
            Value = value;
        }
    }

    // =========================
    // Mapper（核心轉換層）
    // =========================
    public static class DynamicFieldMapper
    {
        public static DynamicField ToDomain(BaseDynamicField e)
        {
            return new DynamicField
            {
                ColId = e.ColId,
                ColName = e.ColName,
                Col = e.Col,
                ColValue = e.ColValue,
                EnumType = e.EnumType,
                Options = OptionParser.Parse(e.OptionStr ?? ""), // ⭐ 這行

                Width = e.Width ?? 3,
                Order = e.Order ?? 0,
                Placeholder = e.Placeholder ?? "",
                DefaultValue = e.DefaultValue ?? "",
                ValidationRules = MapValidation(e),
                BehaviorRules = MapBehavior(e)
            };
        }

        //public static BaseDynamicField ToEntity(DynamicField d)
        //{
        //    var e = new BaseDynamicField
        //    {
        //        ColId = d.ColId,
        //        ColName = d.ColName,
        //        EnumType = d.EnumType.ToString(),
        //        Placeholder = d.Placeholder,
        //        Width = d.Width,
        //        Order = d.Order
        //    };

        //    foreach (var r in d.ValidationRules)
        //    {
        //        switch (r.Name)
        //        {
        //            case "required":
        //                e.Must = true;
        //                break;

        //            case "min":
        //                e.Min = r.Value;
        //                break;

        //            case "max":
        //                e.Max = r.Value;
        //                break;

        //            case "pattern":
        //                e.Pattern = r.Value;
        //                break;
        //        }
        //    }

        //    foreach (var r in d.BehaviorRules)
        //    {
        //        switch (r.Name)
        //        {
        //            case "readonly":
        //                e.Readonly = true;
        //                break;

        //                //case "hidden":
        //                //    e.Hidden = true;
        //                //    break;
        //        }
        //    }

        //    return e;
        //}

        // =========================
        // Validation mapping
        // =========================
        private static List<ValidationRule> MapValidation(BaseDynamicField e)
        {
            var rules = new List<ValidationRule>();
            var type = Enum.Parse<FieldType>(e.EnumType.ToString());

            void Add(string name, string value = null)
            {
                if (RuleSchemaRegistry.AllowValidation(type, name))
                    rules.Add(new ValidationRule(name, value));
            }

            // ✔ Must
            if (e.Must == true)
                Add("required");

            // ✔ numeric rules
            if (type == FieldType.Numeric)
            {
                if (e.Min.HasValue)
                    Add("min", e.Min.Value.ToString());

                if (e.Max.HasValue)
                    Add("max", e.Max.Value.ToString());
            }

            // ✔ textbox rules
            if (type == FieldType.Textbox)
            {
                //if (e.MaxLength.HasValue)
                //    Add("maxlength", e.MaxLength.Value.ToString());

                if (!string.IsNullOrEmpty(e.AsyncUrl))
                    Add("async", e.AsyncUrl);
                // ✔ ⭐ 新增 map
                if (!string.IsNullOrEmpty(e.Target))
                    Add("map", e.Target);

                if (!string.IsNullOrEmpty(e.Pattern))
                    Add("pattern", e.Pattern);
            }
            // ✔ file rules
            if (type == FieldType.File)
            {
                if (!string.IsNullOrEmpty(e.AsyncUrl))
                    Add("async", e.AsyncUrl);

                if (!string.IsNullOrEmpty(e.Target))
                    Add("map", e.Target);

                // ⭐ accept (用 Pattern 或自訂欄位)
                if (!string.IsNullOrEmpty(e.Pattern))
                    Add("accept", e.Pattern);

                // ⭐ maxsize（你可以用 Max 當 MB）
                if (e.Max.HasValue)
                    Add("maxsize", e.Max.Value.ToString());
            }
            return rules;
        }

        // =========================
        // Behavior mapping
        // =========================
        private static List<BehaviorRule> MapBehavior(BaseDynamicField e)
        {
            var rules = new List<BehaviorRule>();
            var type = Enum.Parse<FieldType>(e.EnumType.ToString());

            void Add(string name)
            {
                if (RuleSchemaRegistry.AllowBehavior(type, name))
                    rules.Add(new BehaviorRule(name));
            }

            if (e.Readonly == true)
                Add("readonly");

            if (e.EnumType.ToString() == "Hidden" || e.IsDisplay == false)
                Add("hidden");

            return rules;
        }
    }
    public class BaseDynamicField
    {
        /// <summary>
        /// 欄位代碼
        /// </summary>
        public string ColId { get; set; }

        /// <summary>
        /// 欄位名稱
        /// </summary>
        public string ColName { get; set; }


        public string ColValue { get; set; } = "";

        public string Col { get; set; }

        protected string IsMust { get; set; } = "";

        // 必需輸入
        public bool Must
        {
            get => IsMust.Trim() == "Y";
            set => IsMust = value ? "Y" : "N";
        }
        private string _enumTypeStr;

        public string EnumTypeStr
        {
            get => _enumTypeStr;
            set
            {
                _enumTypeStr = value;
                EnumType = ParseEnum(value);
            }
        }
        public FieldType EnumType { get; private set; }

        /// <summary>
        /// 欄位控制項類型
        /// </summary>
        //public string EnumType
        //{
        //    get => EnumTypeStr.Trim().ToLower() switch
        //    {
        //        var s when s.Contains("radio") => FieldType.Radio.ToString(),
        //        var s when s.Contains("picker") => FieldType.Date.ToString(),
        //        var s when s.Contains("date") => FieldType.Date.ToString(),
        //        var s when s.Contains("numeric") => FieldType.Numeric.ToString(),
        //        var s when s.Contains("deci") => FieldType.Numeric.ToString(),
        //        //var s when s.Contains("int") => FieldType.Int,
        //        var s when s.Contains("area") => FieldType.Textarea.ToString(),
        //        var s when s.Contains("text") => FieldType.Textbox.ToString(),
        //        var s when s.Contains("textbox") => FieldType.Textbox.ToString(),
        //        var s when s.Contains("select2") => FieldType.Select2.ToString(),
        //        var s when s.Contains("drop") => FieldType.Dropdown.ToString(),
        //        var s when s.Contains("upload") => FieldType.File.ToString(),
        //        _ => FieldType.Label.ToString() // 預設值
        //    };
        //    set
        //    {
        //        EnumTypeStr = value switch
        //        {
        //            "Radio" => FieldType.Radio.ToString(),
        //            //FieldType.Int => "Int",
        //            "Date" => FieldType.Date.ToString(),
        //            "Numeric" => FieldType.Numeric.ToString(),
        //            "Textbox" => FieldType.Textbox.ToString(),
        //            "Select2" => FieldType.Select2.ToString(),
        //            "Textarea" => FieldType.Textarea.ToString(),
        //            "Dropdown" => FieldType.Dropdown.ToString(),
        //            "File" => FieldType.File.ToString(),
        //            _ => "Label"
        //        };
        //    }
        //}
        /// <summary>
        /// 重態欄位產生區塊標識
        /// </summary>
        public string Section { get; set; } = "";
        /// <summary>
        /// 最小值判斷(數值、日期)
        /// </summary>
        public int? Min { get; set; } // 使用 string 以相容數字(0)與日期(2024-01-01)
        /// <summary>
        ///  /// <summary>
        /// 最大值判斷(數值、日期)
        /// </summary>
        /// </summary>
        public int? Max { get; set; }
        /// <summary>
        /// 預設填值
        /// </summary>
        public string? DefaultValue { get; set; } = "";
        /// <summary>
        /// 檢查正則表示
        /// </summary>
        public string Pattern { get; set; } = "";
        /// <summary>
        /// 未輸入時佔位值
        /// </summary>
        public string? Placeholder { get; set; } = "";

        /// <summary>
        /// 只讀
        /// </summary>
        public bool Readonly { get; set; } = false;


        public bool IsDisplay { get; set; } = true;
        /// <summary>
        /// 是否隱藏
        /// </summary>
        //public bool Hidden
        //{
        //    get => Display == "N";
        //}

        /// <summary>
        /// 非定位時，欄位寬位
        /// </summary>
        public int? Width { get; set; } = 3; // bootstrap col
        public int? Order { get; set; } = 0;   // 顯示順序

        public string? OptionStr { get; set; }

        /// <summary>
        /// 下拉選項組合值 AAAA,BBB
        /// </summary>
        //public string attribute { get; set; } = ""; //China Car,china_car^Global Car,global_car
        //public string? OptionStr { get; set; }
        //public List<SelectItem>? Options
        //{
        //    get
        //    {
        //        var _attribute = attribute.Trim();
        //        if (!string.IsNullOrWhiteSpace(DefaultValue.Trim()))
        //        {
        //            _attribute = DefaultValue.Trim();
        //        }
        //        if (string.IsNullOrWhiteSpace(_attribute)) return new List<SelectItem>();

        //        if (_attribute.Contains('^'))
        //        {
        //            return _attribute
        //               .Split(new[] { '^' }, StringSplitOptions.RemoveEmptyEntries)
        //               .Select(group =>
        //               {
        //                   var parts = group.Split(',');
        //                   return new SelectItem
        //                   {

        //                       Text = parts.Length > 0 ? parts[0].Trim() : "",
        //                       Value = parts.Length > 1 ? parts[1].Trim() : "",
        //                       Color = parts.Length > 1 ? parts[1].Trim() : ""
        //                   };
        //               })
        //               .ToList();
        //        }
        //        if (Regex.IsMatch(_attribute, ",|;|/")) 
        //        {
        //            return _attribute.Split(new char[] { ',', ';', '/' }, StringSplitOptions.RemoveEmptyEntries)
        //               .Select(item => new SelectItem
        //               {
        //                   Value = item?.Trim() ?? "",
        //                   Text = item?.Trim() ?? "",
        //                   Color = item?.Trim() ?? ""
        //               })
        //               .ToList();
        //        }

        //        return new List<SelectItem>(); 
        //    }
        //}

        public string SheetName { get; set; } = "";

        public string SheetColumn { get; set; } = "";

        /// <summary>
        /// 欄位定位點
        /// </summary>
        public string Position { get; set; } = "";

        /// <summary>
        /// 欄位描述
        /// </summary>
        public string ColumnDesc { get; set; } = "";


        public bool IsRedirect
        {
            get => ColId.Trim() == "vendor_class";
        }
        public bool InverseSelect
        {
            get => ColId.Trim() == "maker_type";
        }
        public string Target { get; set; } = "";

        public string AsyncUrl { get; set; } = "";

        protected BaseDynamicField() { }

        public BaseDynamicField(FieldType type)
        {
            EnumType = type;
        }
        private static FieldType ParseEnum(string value)
        {
            var s = value?.Trim().ToLower() ?? "";

            if (s.Contains("radio")) return FieldType.Radio;
            if (s.Contains("date") || s.Contains("picker")) return FieldType.Date;
            if (s.Contains("numeric") || s.Contains("deci")) return FieldType.Numeric;
            if (s.Contains("textarea") || s.Contains("area")) return FieldType.Textarea;
            if (s.Contains("text")) return FieldType.Textbox;
            if (s.Contains("select2")) return FieldType.Select2;
            if (s.Contains("drop")) return FieldType.Dropdown;
            if (s.Contains("file")) return FieldType.File;

            return FieldType.Label;
        }
        // ⭐ clone + override type
        public BaseDynamicField WithType(FieldType type)
        {
            return new BaseDynamicField(type)
            {
                ColName = this.ColName,
                ColId = this.ColId,
                ColValue = this.ColValue,
                Col = this.Col,
                Must = this.Must,
                AsyncUrl = this.AsyncUrl,
                Min = this.Min,
                Max = this.Max,
                Pattern = this.Pattern,
                Placeholder = this.Placeholder,
                DefaultValue = this.DefaultValue,
                OptionStr = this.OptionStr,
                Readonly = this.Readonly,
                IsDisplay = this.IsDisplay,
                Target = this.Target,
                Width = this.Width,
                Order = this.Order
            };
        }

        public BaseDynamicField ApplyTagHelper(DfFieldTagHelper t)
        {
            return new BaseDynamicField(this.EnumType)
            {
                ColName = t.Name ?? this.ColName,
                ColId = t.Name ?? this.ColId,
                ColValue = t.Value ?? this.ColValue,
                Col = t.Col ?? this.Col,
                Must = t.IsMust ?? this.Must,
                AsyncUrl = t.AsyncUrl ?? this.AsyncUrl,
                Min = t.Min ?? this.Min,
                Max = t.Max ?? this.Max,
                Pattern = t.Pattern ?? this.Pattern,
                Placeholder = t.Placeholder ?? this.Placeholder,
                DefaultValue = t.DefaultValue ?? this.DefaultValue,
                OptionStr = this.OptionStr,
                Readonly = t.Readonly ?? this.Readonly,
                IsDisplay = t.IsDisplay ?? this.IsDisplay,
                Target = t.Target ?? this.Target,
                Width = t.Width ?? this.Width,
                Order = t.Order ?? this.Order
            };
        }

    }
    public static class OptionParser
    {
        public static List<SelectItem> Parse(string optionstr)
        {
            var list = new List<SelectItem>();

            if (string.IsNullOrWhiteSpace(optionstr))
                return list;

            if (optionstr.Contains('^'))
            {
                return optionstr
                   .Split(new[] { '^' }, StringSplitOptions.RemoveEmptyEntries)
                   .Select(group =>
                   {
                       var parts = group.Split(',');
                       return new SelectItem
                       {

                           Text = parts.Length > 0 ? parts[0].Trim() : "",
                           Value = parts.Length > 1 ? parts[1].Trim() : "",
                           Color = parts.Length > 1 ? parts[1].Trim() : ""
                       };
                   })
                   .ToList();
            }
            if (Regex.IsMatch(optionstr, ",|;|/"))
            {
                return optionstr.Split(new char[] { ',', ';', '/' }, StringSplitOptions.RemoveEmptyEntries)
                   .Select(item => new SelectItem
                   {
                       Value = item?.Trim() ?? "",
                       Text = item?.Trim() ?? "",
                       Color = item?.Trim() ?? ""
                   })
                   .ToList();
            }

            return list;
        }
    }


    public class SelectItem
    {
        public string Value { get; set; }
        public string Color { get; set; }  // 新增顏色
        public string Text { get; set; }
    }


}