﻿const cap_Login_url = window.appConfig.CapAuth.LoginUrl;

const cap_cookie_Name = window.appConfig.CapAuth.CookieName ;

// 取得 CAP Token
function CAP_GetAuthToken(cap_cookie_Name) {

    if (document.cookie.length > 0) {

        let c_start =
            document.cookie.indexOf(
                cap_cookie_Name + "=");

        if (c_start !== -1) {

            c_start =
                c_start +
                cap_cookie_Name.length + 1;

            let c_end =
                document.cookie.indexOf(
                    ";",
                    c_start);

            if (c_end === -1)
                c_end = document.cookie.length;

            return unescape(
                document.cookie.substring(
                    c_start,
                    c_end));
        }
    }

    return null;
}

// Token 是否存在
function CAP_CheckAuthToken(authToken) {

    return !(
        authToken == null ||
        authToken === "" ||
        authToken === undefined
    );
}

// 回 CAP Login
function CAP_ReturnUrl() {

    return cap_Login_url +
        "?ReturnUrl=" +
        encodeURIComponent(window.location.href) +
        "&AppPath=" +
        encodeURIComponent(CAP_GetRootPath());
}

// Root Path
function CAP_GetRootPath() {

    var pathName =
        window.location.pathname.substring(1);

    var webName =
        pathName === ''
            ? ''
            : pathName.substring(
                0,
                pathName.indexOf('/'));

    return window.location.protocol +
        '//' +
        window.location.host +
        '/' +
        webName;
}