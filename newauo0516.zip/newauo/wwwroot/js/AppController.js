﻿window.Helpers = (() => {

    const store = () =>
        AppBootstrap.get("FlowStore");

    const state = () =>
        window.AppController.getState();

    // =========================
    // collect payload
    // =========================
    function collectPayload() {

        const payload = {};

        state().stepsRef.value.forEach(s => {

            const stepKey =
                `step${s.StepIndex}`;

            payload[stepKey] =
                store().getStep(stepKey);
        });

        return payload;
    }

    // =========================
    // validate steps
    // =========================
    async function validateAllSteps({
        showError
    }) {

        let allValid = true;

        for (const s of state().stepsRef.value) {

            const stepKey =
                `step${s.StepIndex}`;

            // submit 才顯示紅字
            if (showError) {
                store().markStepSubmitted(stepKey);
            }

            const ok =
                await GraphV2.validateStep(stepKey);

            if (!ok) {
                allValid = false;
            }
        }

        return allValid;
    }

    // =========================
    // submit form (core)
    // =========================
    async function submitForm({
        url,
        mode = "draft"
    }) {

        const isSubmit =
            mode === "submit";

        // =========================
        // validation
        // =========================
        const validationResult =
            await validateAllSteps({
                showError: isSubmit
            });

        // =========================
        // submit 才阻擋
        // =========================
        if (isSubmit && !validationResult) {

            alert("請修正錯誤欄位");

            return {
                success: false,
                reason: "validation_failed"
            };
        }

        // =========================
        // draft：允許錯誤，但仍要存
        // =========================
        const payload =
            collectPayload();

        console.log("SUBMIT PAYLOAD:", payload);

        const res = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                payload,
                mode,
                hasError: !validationResult // ⭐ 關鍵：讓後端知道
            })
        });

        return await res.json();
    }

    // =========================
    // save draft
    // =========================
    async function saveDraft() {

        return await submitForm({
            url: "/api/form/draft",
            mode: "draft"
        });
    }

    // =========================
    // finish submit
    // =========================
    async function finishSubmit() {

        return await submitForm({
            url: "/api/form/submit",
            mode: "submit"
        });
    }

    // =========================
    // next step confirm
    // =========================
    async function stepNextWithConfirm({
        stepKey = "step1",
        nextStep,
        storeKey = "decision",
        value,
        type,
        autoGoTo = true
    }) {

        const s = store();

        const oldValue =
            s.get(stepKey, storeKey);

        const isFirstTime =
            typeof oldValue === "undefined";

        const mergedValue = {
            type,
            value
        };

        const isSame =
            JSON.stringify(oldValue) ===
            JSON.stringify(mergedValue);

        let forceReload = false;

        if (!isSame && !isFirstTime) {

            const ok =
                await window.showConfirm(
                    "條件已改變",
                    "是否要重新載入下一步？"
                );

            if (!ok) {
                return { success: false };
            }

            forceReload = true;
        }

        // =========================
        // save decision
        // =========================
        s.safeSet(stepKey, storeKey, mergedValue);

        // =========================
        // go next
        // =========================
        if (autoGoTo && nextStep !== undefined) {

            await window.AppController.goTo(nextStep);

            if (forceReload) {

                const nextStepKey =
                    "step" + nextStep;

                s.clearStep(nextStepKey);

                GraphV2.clearStep(nextStepKey);
                GraphV2.unregisterStep(nextStepKey);

                await window.AppController.load?.();
            }
        }

        return {
            success: true,
            isSame,
            forceReload
        };
    }

    return {

        collectPayload,
        submitForm,
        saveDraft,
        finishSubmit,
        stepNextWithConfirm
    };

})();
const FormStore = (() => {

    const state = Vue.reactive({ steps: {} });
    const errors = Vue.reactive({ steps: {} });
    const status = Vue.reactive({ steps: {} });

    const touched = {};
    const submitState = Vue.reactive({});
    const ensure = (step) => {

        state.steps[step] ||= {};
        errors.steps[step] ||= {};
        status.steps[step] ||= {};

        state.steps[step].__version ||= {};
        touched[step] ||= new Set();
    };

    return {
        markStepSubmitted(step) {
            submitState[step] = true;
        },

        unmarkStepSubmitted(step) {
            submitState[step] = false;
        },

        isStepSubmitted(step) {
            return !!submitState[step];
        },
        getStep(step) {
            ensure(step);
            return state.steps[step];
        },

        get(step, key) {
            ensure(step);
            return state.steps[step][key];
        },
        isStepValid(step) {
            ensure(step);
            return Object.values(errors.steps[step]).every(x => !x);
        },

        // =========================
        // 🚀 safe write (version aware)
        // =========================
        safeSet(step, key, val, meta = {}) {

            ensure(step);

            const stepObj = state.steps[step];

            const current = stepObj.__version[key] || 0;

            if (meta.version != null && meta.version < current) return;

            stepObj.__version[key] = current + 1;
            console.log("🔥 BEFORE SET:", step, key, stepObj);

            stepObj[key] = val;
            console.log("🔥 AFTER SET:", stepObj);

        },

        setError(step, key, val) {
            ensure(step);
            errors.steps[step][key] = val;
        },

        clearError(step, key) {
            ensure(step);
            errors.steps[step][key] = null;
        },

        getError(step, key) {
            return errors.steps?.[step]?.[key];
        },

        setStatus(step, key, val) {
            ensure(step);
            status.steps[step][key] = val;
        },

        getStatus(step, key) {
            return status.steps?.[step]?.[key];
        },

        setTouched(step, key) {
            ensure(step);
            touched[step].add(key);
        },

        isTouched(step, key) {
            return touched?.[step]?.has(key);
        },
        deleteField(step, key) {
            ensure(step);

            delete state.steps[step][key];
            delete errors.steps[step][key];
            delete status.steps[step][key];
            delete state.steps[step].__version[key];

            touched[step]?.delete(key);
        },
        resetField(step, key) {
            ensure(step);

            state.steps[step][key] = null;
            errors.steps[step][key] = null;
            status.steps[step][key] = null;

            touched[step]?.delete(key);
        },
        clearStep(step) {

            const stepObj = state.steps[step];

            if (stepObj) {
                // 2. 逐一刪除所有屬性（這會觸發 Vue UI 偵測到屬性消失）
                Object.keys(stepObj).forEach(key => {
                    delete stepObj[key];
                });

                // 3. 重新初始化內部必要的結構
                stepObj.__version = {};
            }

            // 4. 對於 errors 和 status，如果 UI 有綁定，也建議用同樣方式處理
            if (errors.steps[step]) {
                Object.keys(errors.steps[step]).forEach(k => delete errors.steps[step][k]);
            }
            if (status.steps[step]) {
                Object.keys(status.steps[step]).forEach(k => delete status.steps[step][k]);
            }

            // 5. Touched 是普通 Set，可以直接替換
            touched[step] = new Set();

            console.log(`✅ Step [${step}] 已清空，UI 應同步更新`);


            //state.steps[step] = { __version: {} };
            //errors.steps[step] = {};
            //status.steps[step] = {};
            //touched[step] = new Set();
        },

        getErrors(step) {
            ensure(step);
            return errors.steps[step];
        }
    };

})();
window.FlowStore = (() => {

    const toStepKey = (stepKey) => {
        let state = window.AppController.getState();
        if (!stepKey) return stepKey;

        const prefix = state.flowId + ".";

        if (stepKey.startsWith(prefix)) {
            return stepKey;
        }

        if (stepKey.includes(".")) {
            console.warn("⚠️ stepKey already has prefix:", stepKey);
            return stepKey;
        }

        return prefix + stepKey;
    };

    return {

        get(stepKey, key) {
            return FormStore.get(toStepKey(stepKey), key);
        },

        getStep(stepKey) {
            return FormStore.getStep(toStepKey(stepKey));
        },

        safeSet(stepKey, key, val, meta) {
            return FormStore.safeSet(toStepKey(stepKey), key, val, meta);
        },

        setError(stepKey, key, val) {
            return FormStore.setError(toStepKey(stepKey), key, val);
        },
        setStatus(stepKey, key, val) {
            return FormStore.setStatus(toStepKey(stepKey), key, val);
        },
        getStatus(stepKey, key) {
            return FormStore.getStatus(toStepKey(stepKey), key);
        },
        getError(stepKey, key) {
            return FormStore.getError(toStepKey(stepKey), key);
        },
        clearError(stepKey, key) {
            return FormStore.clearError(toStepKey(stepKey), key);
        },
        isTouched(stepKey, key) {
            return FormStore.isTouched(toStepKey(stepKey), key);
        },
        isStepValid(stepKey) {
            return FormStore.isStepValid(toStepKey(stepKey));
        },
        isStepSubmitted(stepKey) {
            return FormStore.isStepSubmitted(toStepKey(stepKey));
        },
        setTouched(stepKey, key) {
            return FormStore.setTouched(toStepKey(stepKey), key);
        },
        markStepSubmitted(stepKey) {
            return FormStore.markStepSubmitted(toStepKey(stepKey));
        },
        deleteField(stepKey, key) {
            return FormStore.deleteField(toStepKey(stepKey), key);
        },

        clearStep(stepKey) {
            return FormStore.clearStep(toStepKey(stepKey));
        },

        resetField(stepKey, key) {
            return FormStore.resetField(toStepKey(stepKey), key);
        },
        getErrors(stepKey) { 
            return FormStore.getErrors(toStepKey(stepKey));
        }
    };

})();


window.AppController = (() => {
    const state = {
        flowId: "default",
        stepsRef: null,
        currentStep: null,
        setStep: null,
        currentPage: null,
        loading: false,
        _beforeHooks: []
    };


    function initSelect2(container) {
        function setSelect2Background(select) {
            let color = select.find("option:selected").data("color") || "";
            select.next(".select2-container")
                .find(".select2-selection--single")
                .css("background-color", color);
        }
        function formatOption(item) {
            if (!item.id) return item.text;
            let color = $(item.element).data("color") || "";
            return $('<div style="background:' + color + '; padding:4px 6px;">' + item.text + '</div>');
        }

        function formatSelection(item) { return item.text; }

        $(container).find("select.select2").each(function () {

            const $el = $(this);

            if ($el.data("select2")) return;

            $el.select2({
                width: "100%",
                placeholder: $el.attr("placeholder") || "請選擇",
                allowClear: true,
                templateResult: formatOption,
                templateSelection: formatSelection
            });
            setTimeout(() => {
                setSelect2Background($el);
            }, 0);
            $el.on("select2:select select2:clear", function () {
                setSelect2Background($el);
                // 🔥 強制同步 value
                const value = $el.val();

                // 🔥 直接用原生 dispatch（比 trigger 穩）
                $el[0].dispatchEvent(new Event("change", { bubbles: true }));
            });

            $el.trigger("change.select2");
        });
    }


    function getStepKey() {
        return `step${state.currentStep.value || 1}`;
    }

    async function init({ steps, currentStep, setStep }) {

        state.flowId = window.__FLOW_ID__ || "default";
        state.stepsRef = steps;
        state.currentStep = currentStep;
        state.setStep = setStep;
        await registerModules();
        //initInternalHooks();
        await load();


        const ribbon = document.querySelector('.wizard-ribbon');
        if (ribbon) {
            ribbon.style.setProperty('--total', steps.value.length);
        }
    }
    async function registerModules() {

        /*//AppBootstrap.register("FormStore", FormStore);*/
        AppBootstrap.register("StepLoader", StepLoader);
        AppBootstrap.register("FlowStore", FlowStore);
        //AppBootstrap.register("FormValidation", FormValidation);
        AppBootstrap.register("FilePlugin", FilePlugin);
        AppBootstrap.register("FieldBinder", FieldBinder);
        //AppBootstrap.register("ComputedRegistry", ComputedRegistry);
        //AppBootstrap.register("ComputedEngine", ComputedEngine);
        //if (window.FieldBinder)
        //    AppBootstrap.register("FieldBinder", FieldBinder);
        // 如果你有這些
        //if (window.FieldStatus)
        //    AppBootstrap.register("FieldStatus", FieldStatus);

        //if (window.ValidationCenter)
        //    AppBootstrap.register("ValidationCenter", ValidationCenter);

        await AppBootstrap.wait(); // 🔥 等全部 ready

        //const computed = AppBootstrap.get("ComputedEngine");
        //computed.init();
        //computed.enable();


    }

    //function initInternalHooks() {
    //    state._beforeHooks.push(async ({ currentStep, targetStep }) => {
    //        // 只有向後走才檢查，回退不檢查
    //        if (targetStep <= currentStep) return true;

    //        const stepKey = `step${currentStep}`;
    //        const currentPage = state.currentPage; // 這是目前頁面的實例

    //        // 💡 關鍵：我們需要從目前頁面取得「現在選了什麼」來跟「舊資料」比對
    //        // 假設你的頁面物件都有實作 getSubmitData() 
    //        if (currentPage && typeof currentPage.getSubmitData === "function") {
    //            const currentData = currentPage.getSubmitData();

    //            const result = await Helpers.stepNextWithConfirm({
    //                stepKey: stepKey,
    //                nextStep: targetStep,
    //                value: currentData.value,
    //                type: currentData.type,
    //                autoGoTo: false // ⚡ 重要：這裡必須為 false，否則會跟 goTo 互衝造成死循環
    //            });

    //            // 如果 result.success 為 false (使用者按了取消)，hook 回傳 false 攔截換頁
    //            return result.success;
    //        }

    //        return true;
    //    });
    //}




    async function load() {

        if (state.loading) return;
        state.loading = true;

        try {

            const StepLoader = AppBootstrap.get("StepLoader");
            const stepIndex = state.currentStep.value;
            const stepKey = `step${stepIndex}`;
            const container = await StepLoader.load(stepIndex, state);
            //state.currentPage = window.StepPages?.[stepKey];
            initSelect2(container)
            //hydrateFields(container, stepKey);

            const fieldBinder = AppBootstrap.get("FieldBinder");
            fieldBinder.bindFields(container, stepKey);
            return container;

        } catch (err) {

            console.error("❌ load step failed:", err);

            // 🔥 關鍵：避免卡死
            state.loading = false;

            // 🔥 可選：強制回復 UI（很重要）
            //await forceRecoverStep();

            throw err; // or swallow depending UX

        }
        finally {
            state.loading = false;
        }
    }
    function hydrateFields(container, stepKey) {
        //const store = AppBootstrap.get("FormStore");
        const store = AppBootstrap.get("FlowStore");
        container
            .querySelectorAll("input[data-field], select[data-field], textarea[data-field]")
            .forEach(el => {
                const rawCol = el.dataset.col;
                const col = rawCol && rawCol.trim() ? rawCol.trim() : null;
                const key = makeKey(el.dataset.field, col);

                const storeVal = store.get(stepKey, key);

                // 🟢 Store 優先
                if (!isEmpty(storeVal)) {

                    if (el.type === "checkbox") {
                        //el.checked = storeVal;
                        GraphV2.notify(stepKey, key, storeVal);

                    } else if (el.type === "radio") {
                        // el.checked = (el.value === storeVal);
                        GraphV2.notify(stepKey, key, (el.value === storeVal));
                    }
                    else if (el.type === "file") {

                        // ❌ 永遠不要回填 file input value
                        GraphV2.notify(stepKey, key, storeVal);
                        // ✅ 改成更新 UI 顯示區

                    }
                    else {
                        // el.value = storeVal;
                        GraphV2.notify(stepKey, key, storeVal);
                    }

                } else {

                    // 🔵 UI 補 Store（只做一次）
                    let val;

                    if (el.type === "checkbox") {
                        val = el.checked;

                    } else if (el.type === "radio") {

                        const checked = container.querySelector(
                            `input[data-field='${key}']:checked`
                        );

                        val = checked ? checked.value : null;

                    } else {
                        val = el.value;
                    }

                    if (!isEmpty(val)) {
                        /*  const token = Symbol(`${stepKey}.${key}`);*/
                        //store.safeSet(stepKey, key, val);
                        GraphV2.notify(stepKey, key, val);
                    }
                }
            });

    }
    async function next() {
        const currentStep = state.currentStep.value;
        const targetStep = currentStep + 1;

        // 1️⃣ 執行所有註冊過的 Hooks (包含你在 STEP2 init 加的那個)
        const canProceed = await runBeforeHooks(targetStep);

        // 如果 Hook 回傳 false (代表 confirm 點了取消)，就中斷，不換頁
        if (!canProceed) {
            console.log("🚫 Hook 攔截：停止換頁");
            return;
        }

        // 2️⃣ 如果 Hook 通過了，才執行原本的換頁邏輯
        const stepKey = getStepKey();
        // const store = AppBootstrap.get("FlowStore");
        // if (!store.isStepValid(stepKey)) { ... }

        // 3️⃣ 換頁前清空舊 Hook，避免 Hook 重複累積
        state._beforeHooks = [];

        state.setStep(targetStep);
        await load();
        //const stepKey = getStepKey();
        //const store = AppBootstrap.get("FlowStore");
        ////if (!store.isStepValid(stepKey)) {
        ////    alert("請修正錯誤");
        ////    return;
        ////}

        //state.setStep(state.currentStep.value + 1);
        //await load();
    }

    async function prev() {
        state._beforeHooks = [];
        state.setStep(state.currentStep.value - 1);
        await load();
    }

    async function goTo(i) {
        const target = Number(i);

        // 🔥 先跑 hook
        const ok = await runBeforeHooks(target);

        if (!ok) return;

        state._beforeHooks = [];

        state.setStep(target);
        await load();
    }
    async function saveDraft() {

        const result =
            await window.Helpers.saveDraft();

        if (!result.success)
            return;

        alert("草稿已儲存");
    }
    async function finish() {

        const result =
            await window.Helpers.finishSubmit();

        if (!result.success)
            return;

        alert("送出成功");
    }
    //async function finish() {
    //    const store = AppBootstrap.get("FlowStore");
    //    const payload = {};
    //    state.stepsRef.value.forEach(s => {
    //        payload[`step${s.StepIndex}`] = store.getStep(`step${s.StepIndex}`);
    //        store.markStepSubmitted(`step${s.StepIndex}`);
    //    });

    //    console.log("FINAL:", payload);

    //    //await fetch("/Supplier/Save", {
    //    //    method: "POST",
    //    //    headers: { "Content-Type": "application/json" },
    //    //    body: JSON.stringify(payload, (key, value) => {
    //    //        // 如果 key 是 __version，回傳 undefined 就會被從 JSON 中剔除
    //    //        if (key === "__version") return undefined;
    //    //        return value;
    //    //    })
    //    //});
    //}

    async function runBeforeHooks(targetStep) {
        for (const hook of state._beforeHooks) {
            const ok = await hook({
                currentStep: state.currentStep.value,
                targetStep,
                state
            });
            if (!ok) return false;
        }
        return true;
    }

    return {
        init,
        next,
        prev,
        goTo,
        finish, saveDraft,
        load,
        addBeforeHook(fn) {
            state._beforeHooks.push(fn);
        },
        getState: () => state,
    };

})();

