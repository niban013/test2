﻿
window.StepRegistry = (() => {


    const modules = {};
    const waiters = {};


    return {


        register(name, module) {


            modules[name] = module;



            if (waiters[name]) {
                waiters[name].forEach(fn => fn(module));
                delete waiters[name];
            }
        },


        get(name) {
            return modules[name];
        },

        wait(name) {
            return new Promise(resolve => {

                if (modules[name]) {
                    resolve(modules[name]);
                    return;
                }

                waiters[name] ||= [];
                waiters[name].push(resolve);
            });
        },

        // ⭐ 新增（很重要）
        clear(name) {
            delete modules[name];
        }
    };




})();
window.StepLoader = (() => {
    function injectHtmlWithScripts(container, html) {


        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");


        // 先塞 HTML（不含 script）
        container.innerHTML = "";


        doc.body.childNodes.forEach(node => {







            if (node.tagName === "SCRIPT") return;

            container.appendChild(node.cloneNode(true));
        });

        // 再執行 script
        doc.querySelectorAll("script").forEach(oldScript => {

            const s = document.createElement("script");


            if (oldScript.src) {
                s.src = oldScript.src;
            } else {
                s.textContent = oldScript.textContent;
            }

            document.body.appendChild(s);


        });
    }

    async function load(stepIndex, ctx) {

    const storeKey = "decision";
    const store = AppBootstrap.get("FlowStore");

    const prevStep = stepIndex > 1 ? stepIndex - 1 : stepIndex;

    const extraData = store.get(`step${prevStep}`, storeKey);

    const payload = {
        stepIndex,
        flowData: extraData
            ? {
                [`step${stepIndex}`]: {
                    type: extraData.type,
                    data: JSON.parse(JSON.stringify(extraData.value))
                }
            }
            : null
    };

    const res = await fetch(`/Supplier/Step`, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });

    if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || `Step load failed: ${res.status}`);
    }

    const html = await res.text();
    const container = document.getElementById("step-container");
    const key = `step${stepIndex}`;

    // =====================================================
    // 1️⃣ 先清掉舊頁（🔥重點在這裡）
    // =====================================================
    if (ctx.currentPage?.destroy) {
        try {
            ctx.currentPage.destroy(container, ctx.currentStep);
        } catch (e) {
            console.warn("destroy failed:", e);
        }
    }

    // =====================================================
    // 2️⃣ 清 registry + graph（安全清）
        // =====================================================
    window.FieldBinder.unbindAll(container);
        
    StepRegistry.clear(key);
    GraphV2.unregisterStep(key);

    // =====================================================
    // 3️⃣ 更新 DOM
    // =====================================================
    injectHtmlWithScripts(container, html);

    // =====================================================
    // 4️⃣ 等新 module
    // =====================================================
    const module = await window.StepRegistry.wait(key);

    if (!module) {
        throw new Error(`Step module not registered: ${key}`);
    }

    // =====================================================
    // 5️⃣ init 新 page
    // =====================================================
    ctx.currentPage = module; 

    module.init?.(container, {
        formData: store,
        currentStep: ctx.currentStep
    });

    return container;
}

    return { load };

})();