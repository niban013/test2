﻿window.PreviewModule = (() => {

    // =========================
    // STATE（原封不動）
    // =========================
    let PreviewState = {
        version: 0,
        type: null,
        payload: null
    };

    const $panel = () => $("#previewPanel");

    // =========================
    // 原 function（全部保留簽名）
    // =========================

    function clearPreview() {
        const $p = $panel();

        const iframe = $p.find("iframe");
        if (iframe.length) {
            iframe.attr("src", "about:blank");
            iframe.remove();
        }

        $p.empty();
        $p.removeData("file-name");
        $p.html(`<div class="empty">Select file</div>`);
    }

    function flushPreview() {

        const $p = $panel();

        const prevIframe = $p.find("iframe");
        if (prevIframe.length) {
            prevIframe.attr("src", "about:blank");
            prevIframe.remove();
        }

        $p.empty();

        if (!PreviewState.type) {
            $p.html(`<div class="empty">Select file</div>`);
            return;
        }

        if (PreviewState.type === "pdf") {

            const iframe = document.createElement("iframe");
            iframe.src = PreviewState.payload;
            iframe.style.cssText = "width:100%;height:100%;border:0;";

            $p.append(iframe);
            return;
        }

        if (PreviewState.type === "image") {

            const bitmap = PreviewState.payload;

            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");

            canvas.width = bitmap.width;
            canvas.height = bitmap.height;

            ctx.drawImage(bitmap, 0, 0);

            canvas.style.cssText = "max-width:100%;max-height:100%;object-fit:contain;";

            $p.append(canvas);

            bitmap.close?.();
            return;
        }

        if (PreviewState.type === "error") {
            $p.html(PreviewState.payload);
        }
    }

    function renderImage(bitmap, version) {

        if (version !== PreviewState.version) {
            bitmap.close?.();
            return;
        }

        PreviewState.type = "image";
        PreviewState.payload = bitmap;

        flushPreview();
    }

    function renderPdf(url, version) {

        if (version !== PreviewState.version) {
            URL.revokeObjectURL(url);
            return;
        }

        if (PreviewState.type === "pdf" && PreviewState.payload) {
            URL.revokeObjectURL(PreviewState.payload);
        }

        PreviewState.type = "pdf";
        PreviewState.payload = url;

        flushPreview();
    }

    function forceDownload(blob, fileName) {

        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = fileName || "download";

        document.body.appendChild(a);
        a.click();
        a.remove();

        setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    function showUnsupported(blob, message = "", fileName = "download", version) {

        if (version !== PreviewState.version) return;

        PreviewState.type = "error";
        PreviewState.payload = `
            <div class="empty text-center">
                ⚠ 無法預覽此檔案<br>
                ${message ? `<small>${message}</small><br>` : ""}
                ${blob
                ? `<button class="btn-download">下載</button>`
                : `<div>無法下載</div>`
            }
            </div>
        `;

        flushPreview();

        if (blob) {
            $(".btn-download").off("click").on("click", () => {
                forceDownload(blob, fileName);
            });
        }
    }

    async function removeFile(stepKey, key, clientId) {

        const store = FileRuntime.getStore();
        const current = store.get(stepKey, key) || [];

        const file = current.find(f => f.clientId === clientId);

        if (!file) return;

        // =========================
        // server delete only if exists
        // =========================
        if (file.status === "success" && file.id) {
            try {
                await fetch(`/api/file/${file.id}`, {
                    method: "DELETE"
                });
            } catch (err) {
                console.error("server delete failed", err);
            }
        }

        // =========================
        // local remove (ONLY by clientId)
        // =========================
        const next = current.filter(f =>
            f.clientId !== clientId
        );

        store.safeSet(stepKey, key, next);
        GraphV2.notify(stepKey, key, next);

        const previewName = $("#previewPanel").data("file-name");
        if (previewName === file.name) {
            PreviewModule.resetPreview();
        }
    }
    // =========================
    // Worker（不變）
    // =========================
    const PreviewWorker = (() => {

        let worker = null;
        let url = null;

        function getWorker() {

            if (worker) return worker;

            const code = `
                self.onmessage = async function (e) {
                    const { blob, type } = e.data;
                    try {
                        if (type.startsWith("image/")) {
                            const bitmap = await createImageBitmap(blob);
                            self.postMessage({ bitmap }, [bitmap]);
                        } else {
                            self.postMessage({ blob });
                        }
                    } catch (err) {
                        self.postMessage({ error: err.message });
                    }
                };
            `;

            const blob = new Blob([code], { type: "application/javascript" });
            url = URL.createObjectURL(blob);

            worker = new Worker(url);
            return worker;
        }

        function destroy() {
            if (worker) worker.terminate();
            if (url) URL.revokeObjectURL(url);
            worker = null;
            url = null;
        }

        return { getWorker, destroy };

    })();

    // =========================
    // PreviewService（不變但私有）
    // =========================
    const PreviewService = {

        open: async function (stepKey, key, file) {

            const $p = $panel();

            $p.data("file-name", file.name);
            $p.html(`<div class="empty">⏳ 載入中...</div>`);

            const version = ++PreviewState.version;

            let realFile;

            try {
                realFile = await FileRuntime.ensureFileObject(file, stepKey, key);
            } catch {
                if (version !== PreviewState.version) return;
                showUnsupported(null, "載入失敗", file.name, version);
                return;
            }

            const blob = realFile instanceof File ? realFile : realFile?.file;

            if (!blob) {
                showUnsupported(null, "無內容", file.name, version);
                return;
            }

            let handled = false;

            const worker = PreviewWorker.getWorker();

            worker.onmessage = (e) => {

                handled = true;

                if (version !== PreviewState.version) return;

                if (e.data.error) {
                    showUnsupported(blob, "預覽失敗", file.name, version);
                    return;
                }

                const type = (file.type || blob.type || "").toLowerCase();

                if (e.data.bitmap && type.startsWith("image/")) {
                    createImageBitmap(e.data.bitmap)
                        .then(bitmap => renderImage(bitmap, version));
                    return;
                }

                if (type === "application/pdf") {
                    const url = URL.createObjectURL(blob);
                    renderPdf(url, version);
                    return;
                }

                showUnsupported(blob, "不支援預覽", file.name, version);
            };

            worker.onerror = () => {
                showUnsupported(blob, "worker error", file.name, version);
            };

            worker.postMessage({ blob, type: file.type || blob.type || "" });

            setTimeout(() => {
                if (!handled && version === PreviewState.version) {
                    showUnsupported(blob, "逾時", file.name, version);
                }
            }, 5000);
        }
    };

    // =========================
    // PUBLIC API（只開這些）
    // =========================

    function resetPreview() {

        PreviewState.version++;

        if (PreviewState.type === "pdf" && PreviewState.payload) {
            URL.revokeObjectURL(PreviewState.payload);
        }

        PreviewState.type = null;
        PreviewState.payload = null;

        flushPreview();
        PreviewWorker.destroy();
    }
    function setUploadMode(mode) {

        const isSingle = mode === "single";

        // 左側清單（multi only）
        $(".multi-only").toggleClass("d-none", isSingle);

        // 右側 preview panel（single / multi 都要）
        $(".single-only").toggleClass("d-none", !isSingle);

        // optional：可以加 class 控制 layout
        $("#uploadModal").toggleClass("single-mode", isSingle);
    }
    function buildTooltip(file, extra = "") {

        const sizeKB = file.size ? Math.round(file.size / 1024) : 0;
        const time = file.lastModified
            ? new Date(file.lastModified).toLocaleString()
            : (file.uploadTime || "");

        return `
        <div style="text-align:left">
            <b>${file.name || "unknown"}</b><br>
            Size: ${sizeKB} KB<br>
            Time: ${time}
            ${extra ? `<br><span style="color:#dc3545">${extra}</span>` : ""}
        </div>
    `;
    }
    function getFileIcon(file) {
        if (file.status === "error") {
            return "❌";
        }
        const type = (file.type || "").toLowerCase();
        const name = (file.name || "").toLowerCase();

        // =========================
        // 圖片
        // =========================
        if (type.startsWith("image/")) {
            return "🖼️";
        }

        // =========================
        // PDF
        // =========================
        if (type === "application/pdf" || name.endsWith(".pdf")) {
            return "📕";
        }

        // =========================
        // Excel
        // =========================
        if (
            type.includes("spreadsheet") ||
            name.endsWith(".xls") ||
            name.endsWith(".xlsx")
        ) {
            return "📊";
        }

        // =========================
        // Word
        // =========================
        if (
            type.includes("word") ||
            name.endsWith(".doc") ||
            name.endsWith(".docx")
        ) {
            return "📄";
        }

        // =========================
        // 壓縮檔
        // =========================
        if (
            name.endsWith(".zip") ||
            name.endsWith(".rar") ||
            name.endsWith(".7z")
        ) {
            return "🗜️";
        }

        // =========================
        // 可執行 / DLL
        // =========================
        if (
            name.endsWith(".exe") ||
            name.endsWith(".dll")
        ) {
            return "⚙️";
        }

        // =========================
        // 預設
        // =========================
        return "📎";
    }
    function render(stepKey, key, files) {

        const $list = $("#uploadList");

        $list.empty();

        const failCount =
            files.filter(x => x.status === "error").length;

        $("#uploadSummary").html(

            failCount
                ? `
            <div class="alert alert-danger py-1 px-2 mb-2">
                ⚠ ${failCount} 個檔案上傳失敗
            </div>
        `
                : ""
        );

        files.forEach(file => {
            const isError =
                file.status === "error";
             
            const icon = isError
                ? "❌"
                : getFileIcon(file);

            const tooltip = buildTooltip(
                file,
                file.error
            );

            const $item = $(`
        
<li class="drive-item ${isError ? "file-error" : ""}">

    <div class="drive-name"

         data-bs-toggle="tooltip"
         data-bs-html="true"
         title='${tooltip}'>

        <span class="drive-icon">
            ${icon}
        </span>

        <span class="drive-scroll">

            <span class="drive-text">
                ${file.name}
            </span>

        </span>

    </div>

    <div class="drive-actions">

       <button class="btn btn-sm btn-outline-primary btn-view">

       ${isError ? "Retry" : "View"}


</button>

        <button class="btn btn-sm btn-outline-danger btn-del">
            Del
        </button>

    </div>

</li>
`);

            // =========================
            // preview
            // =========================

            const $viewBtn = $item.find(".btn-view");
            const $name = $item.find(".drive-name");

            $viewBtn
                .off("click")
                .on("click", async (e) => {

                    e.stopPropagation();

                    $(".drive-item").removeClass("active");
                    $item.addClass("active");

                    // =========================
                    // ERROR → RETRY
                    // =========================
                    if (file.status === "error") {

                        const controller = PreviewModule._uploadController;
                        const ctx = PreviewModule._ctx;

                        file.status = "pending";
                        file.error = null;
                        file.progress = 0;

                        PreviewModule.refreshList(stepKey, key, files);
                        //const ctx = {
                        //    stepKey,
                        //    key
                        //};
                        await controller.uploadSingleFile(
                            ctx,
                            key,
                            file,
                            files
                        );

                        return;
                    }

                    // =========================
                    // NORMAL → PREVIEW
                    // =========================
                    await PreviewService.open(stepKey, key, file);
                });
                $name
                .off("click")
                .on("click", async () => {
                    $viewBtn.trigger("click");
                });

            // =========================
            // delete
            // =========================

            $item.find(".btn-del")
                .off("click")
                .on("click", async (e) => {

                    e.stopPropagation();

                    await removeFile(stepKey, key,file.clientId);

                    const store = FileRuntime.getStore();
                    const updated = store.get(stepKey, key) || [];

                    // ⭐ 只做一件事：統一刷新 UI
                    PreviewModule.refreshList(stepKey, key, updated);

                    const previewName =
                        $("#previewPanel").data("file-name");

                    if (previewName === file.name) {
                        resetPreview();
                    }
                });

            $list.append($item);
        });

        setTimeout(() => {

            $('[data-bs-toggle="tooltip"]')
                .tooltip({
                    container: 'body',
                    html: true
                });

        });
    }
    function refreshList(stepKey, key, files) {
        render(stepKey, key, files);
    }
    async function loadFiles(ctx) {

        const store = FileRuntime.getStore();

        // =========================
        // 1. 從後端拿 metadata list
        // =========================
        let files = await fetch(
            `/api/file/list?stepKey=${ctx.stepKey}&key=${ctx.key}`
        ).then(r => r.json());

        // =========================
        // 2. normalize（只放 metadata，不下載）
        // =========================
        files = (files || []).map(f => ({
            id: f.id,              // serverId
            name: f.name,
            size: f.size,
            type: f.type,

            lazy: true,            // ⭐ 重點：還沒下載 blob
            file: null,           // ⭐ 不放 File object

            status: "success",
            error: null,

            progress: 100
        }));

        store.safeSet(ctx.stepKey, ctx.key, files);

        render(ctx.stepKey, ctx.key, files);
    }
    function openUploadModal(ctx) {

        let controller = new UploadController(ctx);
        PreviewModule._uploadController = controller; // ⭐ 加這行
        PreviewModule._ctx = ctx;

        resetPreview();

        const store = window.FileRuntime.getStore();
        const file = store.get(ctx.stepKey, ctx.key);

        //UploadContext.open(ctx);

        const isMulti = ctx.mode;
        setUploadMode(isMulti ? "multi" : "single");

        $("#uploadModal").modal("show");

        $("#uploadModal").one("shown.bs.modal", async () => {

            if (isMulti) {

                loadFiles(ctx);
                $panel().html(`<div class="empty">Select file</div>`);

            } else if (file) {

                $("#uploadList").empty();
                await PreviewService.open(ctx.stepKey, ctx.key, file);
            }
        });
    }

    // =========================
    // 外部只拿這些
    // =========================
    return {
        openUploadModal,
        resetPreview,
        refreshList

    };

})();


class UploadController {

    constructor(ctxProvider) {

        this.ctxProvider = ctxProvider;

        this.$modal = $("#uploadModal");

        this.$fileInput = $("<input type='file' multiple style='display:none'>");
        $("body").append(this.$fileInput);

        this.bind();
    }
    async retryFile(stepKey, key, fileModel) {

        const store = FileRuntime.getStore();

        const merged =
            store.get(stepKey, key) || [];

        try {

            fileModel.status = "uploading";
            fileModel.progress = 0;
            fileModel.error = null;

            PreviewModule.refreshList(stepKey, key, merged);

            const fd = new FormData();
            fd.append("file", fileModel.file);

            const result =
                await this.uploadWithProgress(
                    "/api/file/upload",
                    fd,
                    percent => {
                        fileModel.progress = percent;
                        PreviewModule.refreshList(stepKey, key, merged);
                    }
                );

            fileModel.status = "success";
            fileModel.id = result.id;
            fileModel.file = null;
            fileModel.lazy = true;
            fileModel.uploadTime = new Date().toISOString();

        } catch (err) {

            fileModel.status = "error";
            fileModel.error = err.message || "retry failed";
        }

        store.safeSet(stepKey, key, merged);
        GraphV2.notify(stepKey, key, merged);
        PreviewModule.refreshList(stepKey, key, merged);
    }
    bind() {

        this.$modal.on("click", "#btnSelectFile", () => {
            this.$fileInput.trigger("click");
        });

        this.$fileInput.on("change", (e) => {

            this.handleFiles(e.target.files);

            e.target.value = "";
        });

        this.$modal.on("dragover", e => e.preventDefault());

        this.$modal.on("drop", (e) => {

            e.preventDefault();

            this.handleFiles(
                e.originalEvent.dataTransfer.files
            );
        });
    }

    validateFile(file) {

        const ext = file.name
            .split(".")
            .pop()
            .toLowerCase();

        const deny = ["exe", "dll"];

        if (deny.includes(ext)) {
            return "不允許的檔案格式";
        }

        if (file.size > 20 * 1024 * 1024) {
            return "檔案超過 20MB";
        }

        return null;
    }

    createFileModel(file) {

        const error = this.validateFile(file);

        return {

            id: crypto.randomUUID(),

            file: error ? null : file,

            name: file.name,
            type: file.type,
            size: file.size,

            status: error ? "error" : "success",
            error,

            lazy: false,
            isNew: true
        };
    }
    async uploadSingleFile(
        ctx,
        key,
        fileModel,
        merged
    ) {

        const store = FileRuntime.getStore();

        try {

            // =========================
            // uploading
            // =========================

            fileModel.status = "uploading";
            fileModel.error = null;

            PreviewModule.refreshList(
                ctx.stepKey,
                key,
                merged
            );

            // =========================
            // formdata
            // =========================

            const fd = new FormData();

            fd.append(
                "file",
                fileModel.file
            );

            // =========================
            // upload
            // =========================

            const result =
                await this.uploadWithProgress(
                    "/api/file/upload",
                    fd,
                    percent => {

                        fileModel.progress = percent;

                        PreviewModule.refreshList(
                            ctx.stepKey,
                            key,
                            merged
                        );
                    }
                );

            // =========================
            // success
            // =========================

            fileModel.status = "success";

            fileModel.progress = 100;

            fileModel.uploadTime =
                new Date().toISOString();

            // backend id
            fileModel.id = result.id;

            // lazy mode
            fileModel.file = null;
            fileModel.lazy = true;
            fileModel.status = "success";
            fileModel.error = null;
        } catch (err) {

            console.error(err);

            // =========================
            // fail
            // =========================

            fileModel.status = "error";

            fileModel.error =
                err.message || "upload failed";
        }

        store.safeSet(
            ctx.stepKey,
            key,
            merged
        );

        GraphV2.notify(
            ctx.stepKey,
            key,
            merged
        );

        PreviewModule.refreshList(
            ctx.stepKey,
            key,
            merged
        );
    }
    uploadWithProgress(url, formData, onProgress) {

        return new Promise((resolve, reject) => {

            const xhr = new XMLHttpRequest();

            xhr.open("POST", url);

            // =========================
            // upload progress
            // =========================

            xhr.upload.onprogress = e => {

                if (!e.lengthComputable)
                    return;

                const percent =
                    Math.round(
                        (e.loaded / e.total) * 100
                    );

                onProgress(percent);
            };

            // =========================
            // success
            // =========================

            xhr.onload = () => {

                if (
                    xhr.status >= 200 &&
                    xhr.status < 300
                ) {

                    try {

                        resolve(
                            JSON.parse(xhr.responseText)
                        );

                    } catch {

                        resolve({});
                    }

                } else {

                    reject(
                        new Error(
                            `Upload failed (${xhr.status})`
                        )
                    );
                }
            };

            // =========================
            // network error
            // =========================

            xhr.onerror = () => {

                reject(
                    new Error("network error")
                );
            };

            // =========================
            // timeout
            // =========================

            xhr.ontimeout = () => {

                reject(
                    new Error("upload timeout")
                );
            };

            xhr.send(formData);
        });
    }
    async handleFiles(files) {

        const ctx = this.ctxProvider;
        const key = ctx.key;

        const store = FileRuntime.getStore();

        const current =
            store.get(ctx.stepKey, key) || [];

        const merged = [...current];

        // =========================
        // create file models
        // =========================

        const newItems = [];

        Array.from(files).forEach(f => {

            // duplicate
            if (merged.some(x => x.name === f.name)) {
                return;
            }

            // validate
            const validateError =
                this.validateFile(f);

            const model = {

                // backend file id
                id: null,

                // temp client id
                clientId: crypto.randomUUID(),

                // meta
                name: f.name,
                size: f.size,
                type: f.type,

                // actual file
                file: f,

                // upload state
                status:
                    validateError
                        ? "error"
                        : "pending",

                error: validateError || null,

                // %
                progress: 0,

                // server lazy mode
                lazy: false,

                // UI state
                isNew: true,

                uploadTime: null
            };

            merged.push(model);
            newItems.push(model);
        });

        // =========================
        // render immediately
        // =========================

        store.safeSet(
            ctx.stepKey,
            key,
            merged
        );

        GraphV2.notify(
            ctx.stepKey,
            key,
            merged
        );

        PreviewModule.refreshList(
            ctx.stepKey,
            key,
            merged
        );

        // =========================
        // upload queue
        // =========================

        const uploadables =
            newItems.filter(x =>
                x.status === "pending"
            );

        // parallel uploads
        await Promise.allSettled(
            uploadables.map(file =>
                this.uploadSingleFile(
                    ctx,
                    key,
                    file,
                    merged
                )
            )
        );

        // final refresh
        store.safeSet(
            ctx.stepKey,
            key,
            merged
        );

        GraphV2.notify(
            ctx.stepKey,
            key,
            merged
        );

        PreviewModule.refreshList(
            ctx.stepKey,
            key,
            merged
        );
    }
}


window.FileRuntime = (() => {

    const inflightMap = new Map();
    // =========================
    // ⭐ LRU Cache (File Object)
    // =========================
    const fileCache = new Map(); // file.id → File
    const MAX_CACHE = 30;

    function touchCache(fileId, fileObj) {

        if (fileCache.has(fileId)) {
            fileCache.delete(fileId);
        }

        fileCache.set(fileId, {
            file: fileObj,
            ts: Date.now()
        });

        // LRU cleanup
        if (fileCache.size > MAX_CACHE) {

            const oldest = [...fileCache.entries()]
                .sort((a, b) => a[1].ts - b[1].ts)[0];

            if (oldest) {
                fileCache.delete(oldest[0]);
            }
        }
    }

    function getCache(fileId) {
        const hit = fileCache.get(fileId);
        if (!hit) return null;

        hit.ts = Date.now(); // refresh
        return hit.file;
    }
    function getStore() {
        return AppBootstrap.get("FlowStore"); //AppBootstrap.get("FormStore");
    }

    //function buildKey(stepKey, field, col) {
    //    return col ? `${field}.${col}` : field;
    //}

    // =========================
    // ⭐ 共用下載（in-flight + cache + abort）
    // =========================
    async function ensureFileObject(file, stepKey, key) {

        if (file instanceof File) return file;

        if (file.file instanceof File)
            return file.file;

        if (file.status === "error") {
            throw new Error(file.error || "檔案錯誤");
        }
        if (!file.lazy) return file;

        const cached = getCache(file.id);
        if (cached) return cached;

        if (inflightMap.has(file.id)) {
            const prev = inflightMap.get(file.id);
            prev.controller.abort();
            inflightMap.delete(file.id);
        }

        const controller = new AbortController();

        const promise = (async () => {
            try {

                const res = await fetch(`/api/file/${file.id}`, {
                    signal: controller.signal
                });

                if (!res.ok) throw new Error(`下載失敗: ${res.status}`);

                const blob = await res.blob();
                if (!blob || blob.size === 0) throw new Error("空檔案");

                const realFile = new File(
                    [blob],
                    file.name,
                    { type: blob.type || "application/octet-stream" }
                );

                file.file = realFile;
                file.lazy = false;
                // 👉 ⭐ 放這裡
                touchCache(file.id, realFile);
                const store = getStore();
                const current = store.get(stepKey, key) || [];

                store.safeSet(stepKey, key,
                    current.map(f => f.id === file.id ? file : f)
                );

                return realFile;

            } catch (err) {

                if (err.name === "AbortError") return;

                console.error(err);

                file.lazy = true;
                throw err;

            } finally {
                inflightMap.delete(file.id);
            }
        })();

        inflightMap.set(file.id, { controller, promise });

        return promise;
    }

    return {
        ensureFileObject,
        //buildKey,
        getStore
    };

})();

//window.UploadContext = {

//    open({ stepKey, field, col, $row }) {
//        $("#currentStepKey").val(stepKey);
//        $("#currentField").val(field);
//        $("#currentCol").val(col || "");
//        this.$row = $row;
//    },

//    get() {
//        return {
//            stepKey: $("#currentStepKey").val(),
//            field: $("#currentField").val(),
//            col: $("#currentCol").val(),
//            $row: this.$row
//        };
//    }
//};
window.FilePlugin = {
    setFileUI(wrapper, file) {
        const input = wrapper.querySelector(".file-input");
        const nameEl = wrapper.querySelector(".file-name");
        const actions = wrapper.querySelector(".file-actions");

        const hasFile = !!file;

        if (hasFile) {

            // input 隱藏
            input.classList.add("d-none");

            // 顯示檔名
            nameEl.classList.remove("d-none");
            nameEl.textContent = file.name;

            // 顯示操作
            actions.classList.remove("d-none");

            const lineEl = wrapper.querySelector(".file-line");
            const nameValue = Array.isArray(files)
                ? files[0]?.name
                : files?.name;

            if (lineEl && nameValue) {
                lineEl.dataset.title = nameValue;
            }

        } else {

            // input 顯示
            input.classList.remove("d-none");

            // 清空 + 隱藏 name
            nameEl.textContent = "";
            nameEl.classList.add("d-none");

            // 隱藏 actions
            actions.classList.add("d-none");
        }
    },
    init(el, ctx) {
        const setFileUI = FilePlugin.setFileUI;
        if (!(el instanceof HTMLInputElement) || el.type !== "file") {
            return;
        }

        const wrapper = el.closest(".file-wrapper");

        if (!wrapper) {
            console.warn("FilePlugin: missing wrapper", el);
            return;
        }


        const store = FileRuntime.getStore();

        el.addEventListener("change", () => {

            const rawFiles = el.multiple
                ? Array.from(el.files || [])
                : el.files?.[0] || null;

            let files = null;

            // =========================
            // multi
            // =========================
            if (Array.isArray(rawFiles)) {

                files = rawFiles.map(f => ({

                    id: crypto.randomUUID(),

                    name: f.name,
                    size: f.size,
                    type: f.type,

                    file: f,

                    status: "success",
                    error: null,

                    progress: 0,

                    lazy: false,
                    isNew: true
                }));
            }

            // =========================
            // single
            // =========================
            else if (rawFiles) {

                files = {

                    id: crypto.randomUUID(),

                    name: rawFiles.name,
                    size: rawFiles.size,
                    type: rawFiles.type,

                    file: rawFiles,

                    status: "success",
                    error: null,

                    progress: 0,

                    lazy: false,
                    isNew: true
                };
            }

            store.safeSet(
                ctx.stepKey,
                ctx.key,
                files
            );
            GraphV2.notify(ctx.stepKey, ctx.key, files);
            setFileUI(wrapper, files);
            //this.render(wrapper, files);
        });

        // =========================
        // ⭐ FIX：wrapper safe check
        // =========================


        wrapper.addEventListener("click", async (e) => {

            // =========================
            // preview button ONLY
            // =========================
            const previewBtn = e.target.closest(".file-preview-btn");
            if (previewBtn) {

                PreviewModule.openUploadModal({
                    stepKey: ctx.stepKey,
                    key: ctx.key,
                    mode: false // ⭐ single
                });

                return;
            }

            // =========================
            // remove button ONLY
            // =========================
            const removeBtn = e.target.closest(".file-remove");
            if (removeBtn) {

                el.value = "";

                store.safeSet(ctx.stepKey, ctx.key, null);
                GraphV2.notify(ctx.stepKey, ctx.key, null);
                setFileUI(wrapper, null);
                //this.render(wrapper, null);
                return;
            }
        });
        setFileUI(wrapper, store.get(ctx.stepKey, ctx.key));
        //this.render(wrapper, store.get(ctx.stepKey, ctx.key));
    },
    render(wrapper, files) {

        const actions = wrapper.querySelector(".file-actions");
        const name = wrapper.querySelector(".file-name");
        const lineEl = wrapper.querySelector(".file-line");
        if (lineEl)
            lineEl.dataset.title = file.name;
        const hasFile = files && (Array.isArray(files) ? files.length > 0 : true);

        // =========================
        // ⭐ 控制顯示/隱藏
        // =========================
        if (actions) {
            actions.classList.toggle("d-none", !hasFile);
        }

        if (name) {
            name.textContent = hasFile
                ? (Array.isArray(files) ? files[0].name : files.name)
                : "";
        }
    }

};


$(function () {
    $(document).on("click", ".btn-upload", function () {

        PreviewModule.openUploadModal({
            stepKey: $(this).data("step"),
            key: $(this).data("field") + "." + $(this).data("col"),
            mode: true // multi
        });
    });
});

$(document).on("hidden.bs.modal", "#uploadModal", function () {
    PreviewModule.resetPreview();
});