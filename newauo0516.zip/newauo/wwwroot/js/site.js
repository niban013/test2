﻿async function callAsmxProxy(methodName, params) {
    const response = await fetch('/Supplier/GetERP', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            methodName: methodName, // 指定要呼叫 ASMX 的哪個 Function
            params: params          // 傳入該 Function 需要的參數物件
        })
    });
    const result = await response.json();
    return result.d; // 自動解開 ASMX 的 .d
}

function isEmpty(val) {

    if (val === undefined || val === null) {
        return true;
    }

    if (typeof val === "string") {
        return val.trim() === "";
    }

    if (Array.isArray(val)) {
        return val.length === 0;
    }

    if (val instanceof File) {
        return !val.name;
    }

    return false;
}
$(document).on("mouseenter", ".tooltip-auto", function () {

    let instance = bootstrap.Tooltip.getInstance(this);

    if (!instance) {
        instance = new bootstrap.Tooltip(this, {
            title: this.dataset.title || "",
            placement: "top",
            trigger: "manual",   // ⭐ 改 manual
            container: "body"
        });
    }

    instance.show(); // ⭐ 直接顯示
});

$(document).on("mouseleave", ".tooltip-auto", function () {
    const instance = bootstrap.Tooltip.getInstance(this);
    if (instance) instance.hide();
});


window.showAlert = (title, text, icon = 'success') => {
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        confirmButtonColor: '#004070', // 使用您的友達藍
        confirmButtonText: '確定'
    });
};

//window.showConfirm = (title, text, callback) => {
//    Swal.fire({
//        title: title,
//        text: text,
//        icon: 'warning',
//        showCancelButton: true,
//        confirmButtonColor: '#004070',
//        cancelButtonColor: '#d33',
//        confirmButtonText: '確定',
//        cancelButtonText: '取消'
//    }).then((result) => {
//        if (result.isConfirmed && callback) {
//            callback();
//        }
//    });
//};
window.showConfirm = (title, text, callback) => {
    // 加上 return，讓外部可以接到 Promise
    return Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#004070',
        cancelButtonColor: '#d33',
        confirmButtonText: '確定',
        cancelButtonText: '取消'
    }).then((result) => {
        // 1. 保留原本邏輯：如果有 callback 且點擊確定，則執行
        if (result.isConfirmed && typeof callback === 'function') {
            callback();
        }

        // 2. 擴展功能：回傳 true/false 給外部的 await 接收
        return result.isConfirmed;
    });
};


$.ajaxSetup({
    beforeSend: function (xhr) {
        // 💡 從 Layout 產生的那個隱藏 input 取值
        var token = $('input[name="__RequestVerificationToken"]').val();
        if (token) {
            xhr.setRequestHeader("RequestVerificationToken", token);
        }
    },
    // 💡 當任何 AJAX 發生錯誤時觸發
    error: function (xhr, status, error) {
        const data = xhr.responseJSON;
        if (!data) return;

        // 1. 取得後端 Filter 傳來的資訊
        const msg = (data && data.message) ? data.message : "系統連線異常";
        const reqId = (data && data.requestId) ? data.requestId : "N/A";
        const isFatal = data && data.isFatal === true;
        const targetUrl = (data && data.redirectUrl) ? data.redirectUrl : "/Error/Index";
        if (data && data.isFatal) {
            xhr.isHandledByGlobal = true;

            Swal.fire({
                title: data.isFatal ? '系統異常' : '提醒',
                html: `${data.message}<br/><br/><small class="text-muted">錯誤編號：${data.requestId}</small>`,
                icon: data.isFatal ? 'error' : 'warning',
                confirmButtonColor: '#004070',
                confirmButtonText: data.isFatal ? '查看詳細資訊' : '確定',
                allowOutsideClick: !data.isFatal
            }).then((result) => {
                if (data.isFatal && result.isConfirmed) {
                    window.location.href = data.redirectUrl;
                }
            });
        }
    }
});