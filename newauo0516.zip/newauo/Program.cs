﻿using Microsoft.AspNetCore.Authentication.Cookies;
using newauo.Helper;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddAutoMapper(config => { }, typeof(Program).Assembly);
// Add services to the container. 
builder.Services.AddControllersWithViews(options =>
{
    // ⭐ 將全域過濾器加入集合
    //options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
}).AddNewtonsoftJson(options =>
{
    // 這行很關鍵：確保 JSON 輸出名稱與 [JsonProperty] 定義完全一致
    // 而不會被自動轉成小駝峰 (CamelCase)
    options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
});

builder.Services.AddScoped<IDbConnectionFactory, SqlConnectionFactory>();
builder.Services.AddScoped<IGenericRepository, GenericRepository>();






builder.Services.AddHttpClient<CapAuthService>();

builder.Services
    .AddAuthentication(
        CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "APP_AUTH";

        options.AccessDeniedPath =
            "/Auth/Denied";

        options.ExpireTimeSpan =
            TimeSpan.FromHours(8);

        options.SlidingExpiration = true;

        // SSO 很重要
        options.Cookie.HttpOnly = true;

        options.Cookie.SameSite =
            SameSiteMode.Lax;

        options.Cookie.SecurePolicy =
            CookieSecurePolicy.SameAsRequest;

        // 不讓 ASP.NET 自己跳 LoginPath
        options.Events.OnRedirectToLogin =
            context =>
            {
                context.Response.StatusCode = 401;
                return Task.CompletedTask;
            };
    });


builder.Services.AddAuthorization();

builder.Services.AddHttpContextAccessor();







var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

// 再 Authentication
app.UseAuthentication();
// 先跑 CAP Middleware
app.UseMiddleware<CapMiddleware>();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Supplier}/{action=Index}/{id?}");

app.Run();
