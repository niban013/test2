﻿using Newtonsoft.Json;

namespace newauo.Helper
{
    public class SupplierSaveViewModel
    {
        public Step1Data Step1 { get; set; }
        public Step2Data Step2 { get; set; }
        public Dictionary<string, string> Step3 { get; set; } // Step3 欄位極多且多為字串，建議用字典
    }

    public class Step1Data
    {
        public string suppliername { get; set; }
        public string suppliertype { get; set; }
        public DecisionData decision { get; set; }
    }

    public class Step2Data : Dictionary<string, object>
    {
        // Step2 欄位太多（company_code, vendor_class...），
        // 繼承 Dictionary 可以讓你直接用 payload.Step2["company_code"] 取值，
        // 同時也能定義常用的強型別屬性。
        public DecisionData decision { get; set; }
    }

    public class DecisionData
    {
        public object type { get; set; }
        public object value { get; set; }
    }



    public class TSerives
    {
        public SupplierSaveViewModel get()
        {
            var json = """
                                {
                    "step1": {
                        "suppliername": "MITSUI",
                        "suppliertype": "Vendor",
                        "decision": {
                            "type": {
                                "suppliertype": "Vendor"
                            },
                            "value": {
                                "EventName": "addVendor"
                            }
                        }
                    },
                    "step2": { 
                        "company_code": "AMSCTW",
                        "vendor_class": "VC1",
                        "vendor_group_code": "",
                        "technology": "",
                        "request_reason": "QQ",
                        "upload_ssaaf": "",
                        "ssr_description": "QQ",
                        "currency": "",
                        "payment_term": "",
                        "incoterm": "",
                        "freight_term": "",
                        "tax_code": "",
                        "bank_name": "",
                        "bank_branch": "",
                        "branch_country": "",
                        "account_name": "W",
                        "account_number": "",
                        "branch_address": "W",
                        "bank_key": "",
                        "routing_number": "WW",
                        "swift_code": "",
                        "iban": "",
                        "company_english_name": "",
                        "company_local_name": "",
                        "company_owner": "WW",
                        "historical_name": "",
                        "country": "",
                        "city": "",
                        "facility_address": "",
                        "latitude": "",
                        "longitude": "WW",
                        "postal_code": "",
                        "website_url": "W",
                        "tax_identification": "",
                        "vat_number": "",
                        "duns_number": "",
                        "head_duns_number": "",
                        "register_number": "",
                        "contact_person": "",
                        "position": "",
                        "e_mail": "",
                        "window_phone_number": "",
                        "company_office_number": "",
                        "fax_number": "",
                        "language": "",
                        "subsidiary": "",
                        "supplier_relationship": "",
                        "edi_connection": "",
                        "decision": {
                            "type": {
                                "vendor_class": "VC1"
                            },
                            "value": {}
                        }
                    },
                    "step3": {
                        "vc1_ssa.score": "",
                        "vc1_ssa.file": "",
                        "vc1_vda63_pa_self.score": "",
                        "vc1_vda63_pa_self.file": "",
                        "vc1_iatf16949.expired": "",
                        "vc1_iatf16949.file": "",
                        "vc1_iso9001.expired": "",
                        "vc1_iso9001.file": "",
                        "vc1_iso14001.expired": "",
                        "vc1_iso14001.file": "",
                        "vc1_tisax.expired": "",
                        "vc1_tisax.file": "",
                        "vc1_iso27001.expired": "",
                        "vc1_iso27001.file": "",
                        "vc1_mpa.score": "",
                        "vc1_mpa.file": "",
                        "vc1_poi": "",
                        "vc1_poi.file": "",
                        "vc1_amsc_qrs": "",
                        "vc1_amsc_qrs.file": "",
                        "vc1_fss.score": "",
                        "vc1_fss.file": "",
                        "vc1_amsc_plg": "",
                        "vc1_amsc_plg.file": "",
                        "vc1_pscr": "",
                        "vc1_pscr.file": "",
                        "vc1_sp02_23_tp_sra.score": "",
                        "vc1_sp02_23_tp_sra.file": "",
                        "vc1_wa": "",
                        "vc1_wa.file": "",
                        "vc1_ic": "",
                        "vc1_ic.file": "",
                        "vc1_rba": "",
                        "vc1_rba.file": "",
                        "vc1_gdpr": "",
                        "vc1_gdpr.file": "",
                        "vc1_cr_pdf": "",
                        "vc1_cr_pdf.file": "",
                        "vc1_obd_pdf": "",
                        "vc1_obd_pdf.file": "",
                        "vc1_pi": "",
                        "vc1_pi.file": "",
                        "vc1_omc_agent.score": "",
                        "vc1_omc_agent.file": "",
                        "vc1_email_cert_nc.score": "",
                        "vc1_email_cert_nc.file": "",
                        "vc1_ship_rem_cn.score": "",
                        "vc1_ship_rem_cn.file": ""
                    }
                }


                """;
            return JsonConvert.DeserializeObject<SupplierSaveViewModel>(json);
        }
    }
}
