﻿using mvc5.autofac;
using mvc5.Service;
using Newtonsoft.Json;
using Quartz;
using Quartz.Impl.Matchers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using static Quartz.Logging.OperationName;

namespace mvc5.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IQuartzService _quartzService;

        public DashboardController(IQuartzService quartzService)
        {
            _quartzService = quartzService;
        }

        public async Task<ActionResult> Index()
        {
            ////var jobGroups = await _quartzService.Scheduler.GetJobGroupNames();
            //var jobs = new List<JobViewModel>();

            ////foreach (var group in jobGroups)
            ////{
            ////    var jobKeys = await _quartzService.Scheduler.GetJobKeys(GroupMatcher<JobKey>.GroupEquals(group));
            ////    foreach (var jobKey in jobKeys)
            ////    {
            ////        var detail = await _quartzService.Scheduler.GetJobDetail(jobKey);
            ////        var triggers = await _quartzService.Scheduler.GetTriggersOfJob(jobKey);
            ////        var trigger = triggers.FirstOrDefault();

            ////        bool isRunning = (bool?)_quartzService.Scheduler.Context.Get(jobKey.Name + "_IsRunning") ?? false;
            ////        DateTime? lastCompleted = (DateTime?)_quartzService.Scheduler.Context.Get(jobKey.Name + "_LastCompleted");
            ////        bool isPaused = trigger != null && (await _quartzService.Scheduler.GetTriggerState(trigger.Key)) == TriggerState.Paused;
            ////        int? completedCount = (int?)_quartzService.Scheduler.Context.Get(jobKey.Name + "_CompletedCount");

            ////        string status;
            ////        if (isRunning) status = "Running";
            ////        else if (isPaused) status = "Paused";
            ////        else if (lastCompleted.HasValue) status = "Completed";
            ////        else status = "None";
            ////        jobs.Add(new JobViewModel
            ////        {
            ////            JobName = jobKey.Name,
            ////            Group = group,
            ////            Description = detail.Description,
            ////            Trigger = trigger.Key.Name,
            ////            NextFireTime = trigger.GetNextFireTimeUtc()?.LocalDateTime,
            ////            PreviousFireTime = trigger.GetPreviousFireTimeUtc()?.LocalDateTime,
            ////            CompletedTime = lastCompleted,
            ////            CompletedCount = completedCount,
            ////            State = status// GetJobState(jobKey)  // 新增狀態
            ////        });


            ////        //foreach (var trigger in triggers)
            ////        //{
            ////        //    //var state = await _scheduler.GetTriggerState(trigger.Key);

            ////        //    // SchedulerContext 取完成次數
            ////        //    int completedCount = 0;
            ////        //    if (_scheduler.Context.ContainsKey($"{jobKey.Name}_CompletedCount"))
            ////        //        completedCount = (int)_scheduler.Context[$"{jobKey.Name}_CompletedCount"];
            ////        //    jobs.Add(new JobViewModel
            ////        //    {
            ////        //        JobName = jobKey.Name,
            ////        //        Group = group,
            ////        //        Description = detail.Description,
            ////        //        Trigger = trigger.Key.Name,
            ////        //        NextFireTime = trigger.GetNextFireTimeUtc()?.LocalDateTime,
            ////        //        PreviousFireTime = trigger.GetPreviousFireTimeUtc()?.LocalDateTime, 
            ////        //        State = await GetJobState(jobKey)  // 新增狀態
            ////        //    });
            ////        //}
            ////    }
            ////}
            //jobs = await _quartzService.GetAllJobsAsync();
            //return View(jobs);
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> TriggerJob(string jobName, string group)
        {
            var jobs = new List<JobViewModel>();
            var jobKey = new JobKey(jobName, group);
            if (await _quartzService.IsJobRunning(jobKey))
            {
                return RedirectToAction("Index");
            }
            await _quartzService.Scheduler.TriggerJob(new JobKey(jobName, group));
            return RedirectToAction("Index");
        }

        public ActionResult Create()
        {
            var model = new CreateJobViewModel
            {
                AvailableJobTypes = GetJobTypes()
            };
            return View(model);
        }
        [HttpPost]
        public async Task<ActionResult> Delete(string jobName, string group)
        {
            var jobKey = new JobKey(jobName, group);
            if (await _quartzService.Scheduler.CheckExists(jobKey))
            {
                await _quartzService.Scheduler.DeleteJob(jobKey);
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<ActionResult> Create(CreateJobViewModel model)
        {
            model.AvailableJobTypes = GetJobTypes();

            if (!ModelState.IsValid)
                return View(model);

            var jobKey = new JobKey(model.JobName, model.Group);

            if (await _quartzService.Scheduler.CheckExists(jobKey))
            {
                ModelState.AddModelError("", "Job 已存在");
                return View(model);
            }

            // 透過反射找出選中的 Job 類型
            var jobType = Type.GetType(model.SelectedJobType);
            if (jobType == null || !typeof(IJob).IsAssignableFrom(jobType))
            {
                ModelState.AddModelError("", "無效的 Job 類型");
                return View(model);
            }

            var job = JobBuilder.Create(jobType)
                                .WithIdentity(jobKey)
                                .WithDescription(model.Description)
                                .Build();

            var trigger = TriggerBuilder.Create()
                                .WithIdentity(model.JobName + "Trigger", model.Group)
                                .WithCronSchedule(model.CronExpression)
                                .StartNow()
                                .Build();

            await _quartzService.Scheduler.ScheduleJob(job, trigger);

            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<ActionResult> Pause(string jobName, string group)
        {
            var jobKey = new JobKey(jobName, group);
            if (await _quartzService.Scheduler.CheckExists(jobKey))
            {
                await _quartzService.Scheduler.PauseJob(jobKey);
            }
            return RedirectToAction("Index");
        }
        // JSON 給 DataTable 用
        [HttpGet]
        public async Task<ActionResult> GetJobs()
        {
            var jobs = await _quartzService.GetAllJobsAsync();
            var result = new
            {
                data = jobs.Select(j => new {
                    j.JobName,
                    j.Group,
                    j.Description,
                    j.Trigger,
                    j.NextFireTime,
                    j.PreviousFireTime,
                    j.CompletedTime,
                    j.CompletedCount,
                    j.State
                })
            };

            // ✅ 自行用 Newtonsoft.Json 序列化，避免 /Date(...)/
            string json = JsonConvert.SerializeObject(result, new JsonSerializerSettings
            {
                DateFormatString = "yyyy-MM-dd HH:mm:ss",
                NullValueHandling = NullValueHandling.Include
            });

            // ✅ 回傳「Content」而非「Json」，但內容是正確的 JSON
            return Content(json, "application/json");
            // ✅ 用 Content 回傳，指定正確 MIME 類型
            //return Json(JsonConvert.DeserializeObject(json), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public async Task<ActionResult> Resume(string jobName, string group)
        {
            var jobKey = new JobKey(jobName, group);
            if (await _quartzService.Scheduler.CheckExists(jobKey))
            {
                await _quartzService.Scheduler.ResumeJob(jobKey);
            }
            return RedirectToAction("Index");
        }

        // 掃描所有繼承 IJob 的類別
        private IEnumerable<SelectListItem> GetJobTypes()
        {
            return AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(a =>
                {
                    try { return a.GetTypes(); }
                    catch { return new Type[0]; }
                })
                .Where(t => typeof(IJob).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract)
                .Select(t => new SelectListItem
                {
                    Text = t.Name,
                    Value = t.AssemblyQualifiedName
                })
                .ToList();
        }
        //private async Task<string> GetJobState(JobKey jobKey)
        //{
        //    if (await IsJobRunning(jobKey))
        //        return "Running";

        //    var triggers = await _scheduler.GetTriggersOfJob(jobKey);

        //    bool isRunning = detail.JobDataMap.ContainsKey("IsRunning") && (bool)detail.JobDataMap["IsRunning"];
        //    DateTime? lastCompleted = detail.JobDataMap.ContainsKey("LastCompleted") ? (DateTime?)detail.JobDataMap["LastCompleted"] : null;
        //    bool isPaused = trigger != null && (await _scheduler.GetTriggerState(trigger.Key)) == TriggerState.Paused;

        //    string status;
        //    if (isRunning) status = "🟢 Running";
        //    else if (isPaused) status = "🟡 Paused";
        //    else if (lastCompleted.HasValue) status = $"✅ Completed at {lastCompleted.Value:HH:mm:ss}";
        //    else status = "⚪ None";


        //    if (triggers == null || !triggers.Any())
        //        return "None"; // 沒有排程

        //    foreach (var trigger in triggers)
        //    {
        //        var state = await _scheduler.GetTriggerState(trigger.Key);

        //        switch (state)
        //        {
        //            case TriggerState.Normal:
        //                return "Running"; // 或改成 "Scheduled"
        //            case TriggerState.Paused:
        //                return "Paused";
        //            case TriggerState.Complete:
        //                return "Completed";
        //            case TriggerState.Error:
        //                return "Error";
        //            case TriggerState.Blocked:
        //                return "Blocked";
        //            case TriggerState.None:
        //                return "None";
        //        }
        //    }

        //    return "Unknown";
        //}
        //private async Task<bool> IsJobRunning(JobKey jobKey)
        //{
        //    var executingJobs = await _scheduler.GetCurrentlyExecutingJobs();
        //    return executingJobs.Any(x => x.JobDetail.Key.Equals(jobKey));
        //}
    }

    public class JobViewModel
    {
        public string JobName { get; set; }
        public string Group { get; set; }
        public string Description { get; set; }
        public string Trigger { get; set; }
        public DateTime? NextFireTime { get; set; }
        public DateTime? PreviousFireTime { get; set; }
        public DateTime? CompletedTime { get; set; }
        public string State { get; set; }
        public int? CompletedCount { get; set; } = 0; // 新增欄位
    }

    public class CreateJobViewModel
    {
        public string JobName { get; set; }
        public string Group { get; set; } = "DEFAULT";
        public string Description { get; set; }
        public string CronExpression { get; set; }
        public string SelectedJobType { get; set; }

        public IEnumerable<SelectListItem> AvailableJobTypes { get; set; }
    }
}
