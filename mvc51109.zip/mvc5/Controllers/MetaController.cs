﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class MetaController : Controller
    {
        // GET: /Meta/Version
        [HttpGet]
        public ActionResult Version()
        {
            try
            {
                // 取得當前執行 Assembly
                var assembly = Assembly.GetExecutingAssembly();

                // 方式1：取 Assembly Version
                var version = assembly.GetName().Version.ToString();

                // 方式2：也可以取編譯時間 (選擇性)
                // var buildDate = System.IO.File.GetLastWriteTime(assembly.Location).ToString("yyyyMMddHHmmss");
                // var version = version + "-" + buildDate;

                return Content(version);
            }
            catch (Exception ex)
            {
                // 發生錯誤時回傳空字串
                return Content("");
            }
        }
    }
}