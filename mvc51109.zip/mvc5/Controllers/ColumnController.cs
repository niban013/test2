﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class ColumnController : Controller
    {
        // GET: Column
        public ActionResult Index()
        {
            return View();
        }
    }
}