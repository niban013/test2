﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class PortalController : Controller
    {
        // GET: /Portal/TestError
        [HttpGet]
        public ActionResult TestError()
        {
            System.Diagnostics.Debug.WriteLine("✅ TestError() 被呼叫！");
            throw new Exception("這是測試錯誤！");
        }
        [HttpGet]
        public ActionResult TestSuccess()
        {
            // 判斷是否為 AJAX / API 請求
            bool isAjax = string.Equals(
                Request.Headers["X-Requested-With"],
                "XMLHttpRequest",
                StringComparison.OrdinalIgnoreCase
            ) || Request.AcceptTypes?.Contains("application/json") == true;

            if (isAjax)
            {
                // AJAX / API 回傳 JSON
                return Json(new
                {
                    success = true,
                    message = "操作成功！",
                    data = new { value = 123 } // 可帶任意資料
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                // 一般頁面導向成功頁或顯示訊息
                ViewBag.Message = "操作成功！";
                return View(); // 可自訂 Success.cshtml
            }
        }


        // GET: Portal
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult sub1()
        {
            return View();
        }
        public ActionResult sub2()
        {
            return View();
        }
        public ActionResult z302()
        {
            return View();
        }
        public ActionResult tableau()
        {
            return View();
        }
    }
}