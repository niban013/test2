﻿using Autofac;
//using Dapper;
using mvc5.autofac;
using mvc5.Service;
//using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace mvc5.Controllers
{
    public class HomeController : Controller
    {
        //private readonly IDbService _db; 
        private readonly UserService _userService;
        private readonly ILifetimeScope _scope;
        private readonly IList<string> _stringList;
        private readonly HttpContextBase _httpContext;
        public HomeController(ILifetimeScope scope, IList<string> stringList, HttpContextBase httpContext, UserService userService)
        { 
            _scope = scope;
                _stringList = stringList;
            _httpContext = httpContext;
            _userService = userService;
            //_db = db;
            //// 預設 DB → 一行拿 DataTable
            //var dt = _scope.UsingSession(s => s.GetDataTable("SELECT * FROM Customers"));

            //// 指定 Oracle_DB1 → 一行拿 DataTable
            //var dt2 = _scope.UsingSession("Oracle_DB1", s => s.GetDataTable("SELECT * FROM Orders"));

            //// 🔹 非同步 → 一行拿 DataTable
            ////var dtAsync = await _scope.UsingSessionAsync(s => s.GetDataTableAsync("SELECT * FROM Products"));

            //// 🔹 非同步 + 指定 DB
            ////var dtAsync2 = await _scope.UsingSessionAsync("Oracle_DB1", s => s.GetDataTableAsync("SELECT * FROM Employees"));
            //// === 同步 ===
            ////var rows = _scope.UsingSession(s => s.ExecuteNonQuery("INSERT INTO LogTable(Message) VALUES('Hello')"));

            ////var dt = _scope.UsingSession(s => s.GetDataTable("SELECT * FROM Customers"));

            ////var dtProc = _scope.UsingSession(s =>
            ////    s.ExecuteProcedureToDataTable("usp_GetOrders", new SqlParameter("@CustomerId", 1)));

            ////// === 非同步 ===
            ////var rowsAsync = await _scope.UsingSessionAsync(s => s.ExecuteNonQueryAsync("DELETE FROM TempTable"));

            ////var dtAsync = await _scope.UsingSessionAsync(s => s.GetDataTableAsync("SELECT * FROM Orders"));

            ////var dtProcAsync = await _scope.UsingSessionAsync(s =>
            ////    s.ExecuteProcedureToDataTableAsync("usp_GetOrders", new SqlParameter("@CustomerId", 1)));
            //using (var session = _scope.Resolve<IDbSession>())
            //{
            //    try
            //    {
            //        session.BeginTransaction();

            //        session.ExecuteNonQuery("INSERT INTO Users(Name) VALUES(@Name)",
            //            new Dictionary<string, object> { { "@Name", "Tom" } });

            //        session.ExecuteNonQuery("UPDATE Users SET Name=@Name WHERE Id=@Id",
            //            new Dictionary<string, object> { { "@Name", "Jerry" }, { "@Id", 1 } });

            //        session.Commit();
            //    }
            //    catch
            //    {
            //        session.Rollback();
            //        throw;
            //    }
            //}

            //using (var session = _scope.Resolve<IDbSession>())
            //{
            //    try
            //    {
            //        await session.BeginTransactionAsync();

            //        await session.ExecuteNonQueryAsync("INSERT INTO Users(Name) VALUES(@Name)",
            //            new Dictionary<string, object> { { "@Name", "Alice" } });

            //        await session.ExecuteNonQueryAsync("UPDATE Users SET Name=@Name WHERE Id=@Id",
            //            new Dictionary<string, object> { { "@Name", "Bob" }, { "@Id", 2 } });

            //        await session.CommitAsync();
            //    }
            //    catch
            //    {
            //        await session.RollbackAsync();
            //        throw;
            //    }
            //}


        }





        //        using (var session = new DbSession(new OracleConnection(
        //    System.Configuration.ConfigurationManager.ConnectionStrings["Oracle_DB1"].ConnectionString)))
        //{
        //    session.ExecuteProcedure("PROC_UPDATE_USER",
        //        new OracleParameter("P_USER_ID", 1),
        //        new OracleParameter("P_USER_NAME", "Test"));

        //    await session.ExecuteProcedureAsync("PROC_UPDATE_USER",
        //        new OracleParameter("P_USER_ID", 2),
        //        new OracleParameter("P_USER_NAME", "AsyncTest"));

        //    var dt = session.ExecuteProcedureToDataTable("PROC_GET_USERS",
        //        new OracleParameter("P_ROLE_ID", 1));

        //    var dtAsync = await session.ExecuteProcedureToDataTableAsync("PROC_GET_USERS",
        //        new OracleParameter("P_ROLE_ID", 2));
        //}

        //        using (var session = new DbSession(new SqlConnection(
        //    System.Configuration.ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString)))
        //{
        //    // 同步執行 Procedure
        //    session.ExecuteProcedure("usp_UpdateUser",
        //        new SqlParameter("@UserId", 1),
        //        new SqlParameter("@UserName", "Test"));

        //    // 非同步執行 Procedure
        //    await session.ExecuteProcedureAsync("usp_UpdateUser",
        //        new SqlParameter("@UserId", 2),
        //        new SqlParameter("@UserName", "AsyncTest"));

        //    // DataTable
        //    var dt = session.ExecuteProcedureToDataTable("usp_GetUsers",
        //        new SqlParameter("@RoleId", 1));

        //    // 非同步 DataTable
        //    var dtAsync = await session.ExecuteProcedureToDataTableAsync("usp_GetUsers",
        //        new SqlParameter("@RoleId", 2));
        //}


        //public ActionResult FromSqlServer1()
        //{
        //    using (var session = _scope.ResolveNamed<IDbSession>("SqlServer_DB1"))
        //    {
        //        var repo = new UserRepository(session);
        //        var users = repo.GetUsersAsync().Result;
        //        return Json(users, JsonRequestBehavior.AllowGet);
        //    }
        //}

        //public ActionResult FromOracle()
        //{
        //    using (var session = _scope.ResolveNamed<IDbSession>("Oracle_DB1"))
        //    {
        //        var repo = new UserRepository(session);
        //        var users = repo.GetUsersAsync().Result;
        //        return Json(users, JsonRequestBehavior.AllowGet);
        //    }
        //}
        //public ActionResult GetFromSqlServer()
        //{
        //    using (var session = _scope.Resolve<IDbSession>(new NamedParameter("dbKey", "SqlServer_DB1")))
        //    {
        //        var repo = new UserRepository(session);
        //        var users = repo.GetUsersAsync().Result;
        //        return Json(users, JsonRequestBehavior.AllowGet);
        //    }
        //}

        //public ActionResult GetFromOracle()
        //{
        //    using (var session = _scope.Resolve<IDbSession>(new NamedParameter("dbKey", "Oracle_DB1")))
        //    {
        //        var repo = new UserRepository(session);
        //        var users = repo.GetUsersAsync().Result;
        //        return Json(users, JsonRequestBehavior.AllowGet);
        //    }
        //}
        [ActionName("Index2")]
        public async Task<ActionResult> IndexAsync()
        {
            try
            {

                string jsonConfig = @"
{
  ""MaxResults"": 10,
  ""fields"": [
    {
      ""index"": 0,
      ""name"": ""ID"",
      ""type"": ""List"",
      ""searchEnabled"": true,
      ""displayEnabled"": true,
      ""sort"": ""none"",
      ""condition"": [
        {
          ""key"": ""HR"",
          ""value"": ""Human Resources""
        },
        {
          ""key"": ""IT"",
          ""value"": ""Information Technology""
        },
        {
          ""key"": ""SA"",
          ""value"": ""Sales""
        }
      ],
      ""message"": """",
      ""hint"": """"
    },
    {
      ""index"": 3,
      ""name"": ""HireDate"",
      ""type"": ""Default"",
      ""searchEnabled"": true,
      ""displayEnabled"": true,
      ""sort"": ""desc"",
      ""condition"": [
        ""p,b""
      ],
      ""message"": """",
      ""hint"": """"
    }
  ]
}";

                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };

                var config = JsonSerializer.Deserialize<Root>(jsonConfig, options);

                foreach (var field in config.Fields)
                {
                    Console.WriteLine($"Field: {field.Name}");

                    foreach (var cond in field.Condition)
                    {
                        if (cond.Key != null)
                            Console.WriteLine($"  → Object condition: {cond.Key} = {cond.Value}");
                        else
                            Console.WriteLine($"  → String condition: {cond.Value}");
                    }
                }




                //using (var connection = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;"))
                //{
                //    connection.Open();
                //    var customers = connection.QueryAsync<dynamic>("SELECT * FROM Customers").Result; // 明確寫 dbo
                //    //foreach (var c in customers)
                //    //    Console.WriteLine(c);
                //}
                //using (var conn = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=jqueryDb;Trusted_Connection=True;"))
                //{
                //    var c = await conn.QueryAsync<dynamic>("SELECT * FROM Customers", null);
                //}

                //    var d2 = await _db.QueryAsync<dynamic>("delete from Customers where FirstName='Web'");

                //var d =  _db.Query<dynamic>("SELECT  * FROM Customers where FirstName=@FirstName", new { FirstName = "Web" });
                ////DataTable dt = await _db.QueryDataTableAsync("SELECT TOP 5 * FROM Customers");
                ////var name = _userService.GetUserName(123);
                ////_stringList.Add(new Random().Next(1, 100).ToString());
                //LogHelper.Info("This is an information message.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("log4net error: " + ex.Message);
            }
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        /// <summary>
        /// DataTable 轉 HTML Table
        /// </summary>
        private static string DataTableToHtmlTable(DataTable dt)
        {
            var sb = new StringBuilder();

            sb.Append(@"
            <style>
                table {
                    border-collapse: collapse;
                    width: 100%;
                }
                th, td {
                    border: 1px solid #999;
                    padding: 6px 10px;
                    text-align: center;
                }
                th {
                    background: #f2f2f2;
                }
                tr:nth-child(even){
                    background: #fafafa;
                }
            </style>
        ");

            sb.Append("<table>");

            // ✅ 表頭
            sb.Append("<tr>");
            foreach (DataColumn col in dt.Columns)
            {
                sb.Append($"<th>{col.ColumnName}</th>");
            }
            sb.Append("</tr>");

            // ✅ 資料列
            foreach (DataRow row in dt.Rows)
            {
                sb.Append("<tr>");
                foreach (var item in row.ItemArray)
                {
                    sb.Append($"<td>{item}</td>");
                }
                sb.Append("</tr>");
            }

            sb.Append("</table>");

            return sb.ToString();
        }
        static string FakeName(Random rnd)
        {
            string[] first = { "陳", "林", "張", "李", "王", "劉", "黃", "吳", "徐", "鄭" };
            string[] given = { "志明", "雅婷", "冠宇", "怡君", "家豪", "思穎", "建宏", "佩玲", "柏翰", "淑芬" };

            string n = first[rnd.Next(first.Length)] + given[rnd.Next(given.Length)];
            return n;
        }
        static DataTable CreateFakeDataTable(int n)
        {
            var dt = new DataTable("FakeReport");
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Email", typeof(string));
            dt.Columns.Add("Score", typeof(int));
            dt.Columns.Add("CreatedDate", typeof(DateTime));

            var rnd = new Random();
            for (int i = 1; i <= n; i++)
            {
                string name = FakeName(rnd);
                string email = $"{name.ToLower().Replace(" ", ".")}{i % 100}@example.com";
                int score = rnd.Next(50, 101); // 50 ~ 100
                DateTime dtCreated = DateTime.Today.AddDays(-rnd.Next(0, 365));

                dt.Rows.Add(i, name, email, score, dtCreated);
            }

            return dt;
        }
        public ActionResult Contact()
        {
             var d = HtmlReportHelper.ExcelToDataTables(@"C:\vm1\auo\Data.xlsx");
            // 取得 Sheet 名稱集合
            List<string> sheetNames = d.Select(dt => dt.TableName).ToList();
            //DataTable dt = CreateFakeDataTable(1000);

            //// 2. 包成 list 並呼叫 HtmlReportHelper 產生 HTML
            //var tables = new List<(string Title, DataTable Table)>
            //{
            //    ("測試報表 - 1000 筆假資料", dt)
            //};

            //string htmlContent = HtmlReportHelper.ConvertToHtml(tables);





            ViewBag.Message = "Your contact page.";

            return View();
        }
        [ActionName("Index")]
        public async Task<ActionResult> Index2Async()
        {
            try
            { // 建立 DataTable
                DataTable dt = new DataTable();
                dt.Columns.Add("Seq", typeof(int));
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("Phone", typeof(string));

                for (int i = 1; i <= 10; i++)
                {
                    dt.Rows.Add(i, $"王小明{i % 5}", $"09{i % 10}{i % 10}{i % 10}{i % 10}-{i % 1000000}");
                }

                // 取得 IQueryable<dynamic>
                string[] columns = { "Seq", "Name", "Phone" };
                var query = Compare.DataTableToDynamicQueryable(dt, columns);
                int batchSize = 10000;
                // 模擬從 DB 查回來的 Name 清單
                List<string> namesFromDb = new List<string> { "王", "李" };

                // 模擬從 DB 查回來的 Phone Patterns
                List<string> phonesFromDb = new List<string> { "0911", "0955" };

                // 直接用程式建立 config，而不是讀 JSON
                var config = new AdvancedFilterConfig
                {
                    MaxResults = 10,
                    Conditions = new List<AdvancedCondition>
                    {
                        new AdvancedCondition
                        {
                            PropertyName = "Name",
                           // Values = namesFromDb,   // 從 DB 來的值
                          // Not = true,
                            Mode = MatchMode.Default
                        },
                        ////new AdvancedCondition
                        ////{
                        ////    PropertyName = "Phone",
                        ////    Patterns = phonesFromDb, // 從 DB 來的值 (Regex)
                        ////    Not = true,
                        ////    Mode = MatchMode.Regex
                        ////}
                    }
                };

                // JSON 配置
                //string jsonConfig = @"
                //                    {
                //                     ""MaxResults"": 10,
                //                      ""Conditions"": [
                //                        { ""PropertyName"": ""Name"", ""Values"": [""王"", ""李""], ""Not"": true,""Mode"": 1 },
                //                        { ""PropertyName"": ""Phone"", ""Patterns"": [""0911"", ""0955""], ""Not"": true ,""Mode"": 0}
                //                      ]
                //                    }";

                //// 解析 JSON
                //var config = JsonSerializer.Deserialize<AdvancedFilterConfig>(jsonConfig);

                // 取得 Seq 陣列 (分批處理)
                var result = Compare.GetSeqByColumnInBatches(query, config, batchSize);

                // 輸出 (只列前10筆避免爆字)
                foreach (var kvp in result)
                {
                    //Console.WriteLine($"{kvp.Key} 符合條件的 Seq (前10): {string.Join(", ", kvp.Value.Take(10))} ... 共 {kvp.Value.Count} 筆");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("log4net error: " + ex.Message);
            }
            return View();
        }
        public ActionResult GetJson()
        {
            var data = Enumerable.Range(1, 10000)
                .Select(i => new { Id = i, Name = "item_" + i, Value = i * 2 })
                .ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }
    } 
}