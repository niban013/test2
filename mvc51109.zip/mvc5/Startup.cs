﻿using Microsoft.Owin;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

[assembly: OwinStartup(typeof(mvc5.Startup))]

namespace mvc5
{
	public class Startup
	{
        public void Configuration(IAppBuilder app)
        {
            // 啟用 SignalR
            app.MapSignalR();
        }
    }
}