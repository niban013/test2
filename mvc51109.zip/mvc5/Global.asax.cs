﻿using Autofac.Integration.Mvc;
using Autofac;
using mvc5.AutoFac;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using mvc5.autofac;
using Oracle.ManagedDataAccess.Client;
using System;
using Quartz.Impl;
using Quartz;
using mvc5.Service;
using Quartz.Impl.Matchers;
using mvc5.Controllers;
using Newtonsoft.Json;

namespace mvc5
{
    //public static Type GeneratedEnum { get; private set; }
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {  // 自動生成 DbKeys enum
            //GeneratedEnum = DbEnumGenerator.GenerateEnum();
            //var log4netConfigFile = new FileInfo(Server.MapPath("~/log4net.config"));
            //log4net.Config.XmlConfigurator.Configure(log4netConfigFile);
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            var builder = new ContainerBuilder();
            builder.RegisterControllers(typeof(MvcApplication).Assembly);
            // 註冊 HttpContextBase
            builder.RegisterModule<AutofacWebTypesModule>();
            builder.RegisterModule(new AutoFacModule());

            //var container = AutofacConfig.Configure();
            // 註冊 Connection Factory
            // 讀取所有 connectionStrings
            foreach (ConnectionStringSettings cs in ConfigurationManager.ConnectionStrings)
            {
                if (string.IsNullOrWhiteSpace(cs.Name) || string.IsNullOrWhiteSpace(cs.ConnectionString))
                    continue;

                builder.Register<IDbConnection>(ctx =>
                {
                    IDbConnection conn;
                    switch (cs.ProviderName.ToLower())
                    {
                        case "system.data.sqlclient":
                            conn = new SqlConnection(cs.ConnectionString);
                            break;

                        case "oracle.manageddataaccess.client":
                            conn = new OracleConnection(cs.ConnectionString);
                            break;

                        // 之後要支援 MySQL / PostgreSQL 可以再擴充
                        // case "mysql.data.mysqlclient":
                        //     conn = new MySqlConnection(cs.ConnectionString);
                        //     break;

                        default:
                            throw new NotSupportedException($"尚未支援的 Provider: {cs.ProviderName}");
                    }
                    return conn;
                })
                .Named<IDbConnection>(cs.Name)  // 每個連線用 connectionString name 當作 key
                .InstancePerLifetimeScope();
                // 預設 SQL Server DB1
                //builder.Register(c => new DbSession(
                //    new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString)))
                //    .As<IDbSession>()
                //    .InstancePerLifetimeScope();

                builder.Register<IDbSession>(c =>
                {
                    // 預設資料庫
                    return new DbSession(new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServer_DB1"].ConnectionString));
                }).As<IDbSession>().InstancePerLifetimeScope();


                // 註冊 DbSession 也用相同名字
                builder.Register<IDbSession>(ctx =>
                {
                    var conn = ctx.ResolveNamed<IDbConnection>(cs.Name);
                    return new DbSession(conn);
                })
                .Named<IDbSession>(cs.Name)
                .InstancePerLifetimeScope();
            }



            // 註冊 Repository (可以自動注入 IDbSession)
            //builder.RegisterType<UserRepository>();


            // 註冊 DbService，依照 ConnectionString 名稱
            //builder.RegisterType<DbService>()
            //       .As<IDbService>()
            //       .WithParameter("connectionName", "DefaultConnection")
            //       .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(typeof(MvcApplication).Assembly)
           .Where(t => t.Name.EndsWith("Service"))   // 類別名稱結尾是 Service
                .AsSelf() // 註冊成自己
                                                     .AsImplementedInterfaces()                // 依照介面注入，例如 UserService → IUserService

           .InstancePerLifetimeScope();              // MVC/WebApi 常用 Scope

            builder.RegisterType<StdSchedulerFactory>()
                    .As<ISchedulerFactory>()
                    .SingleInstance();
            builder.RegisterType<QuartzService>()
                   .As<IQuartzService>()
                   .SingleInstance()
                   .OnActivated(async e =>
                   {
                       // 容器解析完畢時啟動 Quartz
                       await e.Instance.StartAsync();
                       e.Instance.Scheduler.ListenerManager.AddJobListener(new JobStatusListener());
                   })
                   .OnRelease(async service =>
                   {
                       // Autofac Dispose 時自動 Shutdown
                       await service.ShutdownAsync();
                   });

           

            //   builder.Register(c =>
            //   {
            //       var schedulerFactory = c.Resolve<ISchedulerFactory>();
            //       var scheduler = schedulerFactory.GetScheduler().Result;
            //       // 註冊全域 Listener
            //       scheduler.ListenerManager.AddJobListener(new JobStatusListener());

            //       scheduler.Start().Wait();
            //       return scheduler;
            //   }).As<IScheduler>()
            //   .SingleInstance()
            //   .OnRelease(async scheduler =>
            //   {
            //       if (scheduler != null && !scheduler.IsShutdown)
            //       {
            //           await scheduler.Shutdown(waitForJobsToComplete: true);
            //       }
            //   });

            // Quartz Service
            //builder.RegisterType<QuartzService>()
            //       .As<IQuartzService>()
            //       .SingleInstance();

            // Job 也要註冊 (假設有 ExampleJob)
            //builder.RegisterType<ExampleJob>().As<IJob>();

            // 掃描目前 Assembly (或指定 Assembly)，自動註冊所有 IJob
            //builder.RegisterAssemblyTypes(AppDomain.CurrentDomain.GetAssemblies())
            //       .AssignableTo<IJob>()  // 找出所有繼承 IJob 的類別
            //       .AsSelf()              // 直接用類型解析
            //       .AsImplementedInterfaces() // 也可用介面解析
            //       .InstancePerDependency();




            var container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));

            //var quartzService = container.Resolve<IQuartzService>();
            //quartzService.StartAsync().Wait();


            //var quartz = DependencyResolver.Current.GetService<IQuartzService>();
            //quartz.ScheduleAllJobs().Wait();

            //var scheduler =  quartz.GetScheduler();
            //var jobKeys = scheduler.GetJobKeys(GroupMatcher<JobKey>.AnyGroup());
            //foreach (var jk in jobKeys)
            //{
            //    System.Diagnostics.Debug.WriteLine($"已排程 Job: {jk.Name}");
            //}


            //var quartz = DependencyResolver.Current.GetService<IQuartzService>();
            //quartz.ScheduleAllJobs().Wait(); // 自動排程所有 IJob
            // 從 Web.config 自動載入 Job
            //quartzService.LoadJobsFromConfig().Wait();

            // 或從 DB 載入
            // string connStr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            // quartzService.LoadJobsFromDb(connStr).Wait();

        }
        protected void Application_BeginRequest()
        {
            string userName = HttpContext.Current.User?.Identity?.Name ?? "Anonymous";
            userName = Regex.Replace(userName, @"[\\/:*?""<>|]", "_");

            //log4net.LogicalThreadContext.Properties["userName"] = userName;
            var response = HttpContext.Current.Response;
            var request = HttpContext.Current.Request;

            // 指定允許的前端網址 (可改為你的實際前端主機)
            string allowedOrigin = "*";
            response.AddHeader("Access-Control-Allow-Origin", allowedOrigin);
            response.AddHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With");
            response.AddHeader("Access-Control-Allow-Credentials", "true");

            // ✅ 處理預檢 (OPTIONS) 請求 — 直接結束，不進入 MVC
            if (request.HttpMethod == "OPTIONS")
            {
                response.StatusCode = 200;
                response.End();
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            var httpContext = HttpContext.Current;

            // 可依需求記錄到檔案或資料庫
            LogError(ex);

            // 清理 Response 以防止 IIS 接手顯示錯誤
            httpContext.Response.Clear();
            httpContext.ClearError();

            var statusCode = 500;
            if (ex is HttpException httpEx)
                statusCode = httpEx.GetHttpCode();
            
            var request = new HttpRequestWrapper(httpContext.Request);
            var response = new HttpResponseWrapper(httpContext.Response);

            bool isAjax = request.Headers["X-Requested-With"] == "XMLHttpRequest";

            // ✅ 錯誤日誌
            System.Diagnostics.Debug.WriteLine($"[Error] {ex.Message}");

            // ✅ 判斷是否為 AJAX / API 請求
            if (isAjax)
            {
                httpContext.Response.StatusCode = statusCode;
                httpContext.Response.ContentType = "application/json";
                var json = JsonConvert.SerializeObject(new
                {
                    success = false,
                    message = ex.Message,
                    status = statusCode
                });
                httpContext.Response.Write(json);
                httpContext.Response.End();
            }
            else
            {
                // ✅ 一般頁面導向錯誤頁
                var routeData = new RouteData();
                routeData.Values["controller"] = "Error";

                switch (statusCode)
                {
                    case 404:
                        routeData.Values["action"] = "NotFound";
                        break;
                    default:
                        routeData.Values["action"] = "ServerError";
                        break;
                }

                // 將錯誤傳遞給 Controller（若需要顯示詳細內容）
                routeData.Values["exception"] = ex;

                // 執行 ErrorController
                IController controller = new ErrorController();
                controller.Execute(new RequestContext(new HttpContextWrapper(httpContext), routeData));
            }
        }

        private bool IsAjaxRequest(HttpRequest request)
        {
            return request.Headers["X-Requested-With"] == "XMLHttpRequest"
                || request.AcceptTypes != null && Array.Exists(request.AcceptTypes, t => t.Contains("json"));
        }

        private void LogError(Exception ex)
        {
            //// TODO: 實作真實日誌，例如 NLog / Log4Net / Serilog
            //System.IO.File.AppendAllText(HttpContext.Current.Server.MapPath("~/App_Data/Error.log"),
            //    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}\r\n");
        }

    }
}
