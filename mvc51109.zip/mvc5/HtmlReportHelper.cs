﻿using System.Collections.Generic;
using System.Data;
using System.Text;
using System;
using System.IO;
using System.Net.Mail;
using ClosedXML.Excel;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System.Linq;

public static class HtmlReportHelper
{
    /// <summary>
    /// 通用讀 Excel 方法（支援 xls/xlsx）
    /// </summary>
    /// <summary>
    /// 通用讀 Excel 方法（支援 xls/xlsx，檔案路徑版）
    /// </summary>
    public static List<DataTable> ExcelToDataTables(string filePath, string[] sheets = null)
    {
        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            throw new FileNotFoundException($"找不到檔案: {filePath}");

        List<DataTable> tables = new List<DataTable>();
        IWorkbook workbook;

        using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
        {
            string ext = Path.GetExtension(filePath).ToLower();

            if (ext == ".xls")
                workbook = new HSSFWorkbook(fs);
            else if (ext == ".xlsx")
                workbook = new XSSFWorkbook(fs);
            else
                throw new Exception("不支援的檔案格式");

            string[] sheetFilter = sheets ?? Array.Empty<string>();

            for (int i = 0; i < workbook.NumberOfSheets; i++)
            {
                ISheet sheet = workbook.GetSheetAt(i);

                if (sheetFilter.Length > 0 && !sheetFilter.Contains(sheet.SheetName, StringComparer.OrdinalIgnoreCase))
                    continue;

                DataTable dt = new DataTable(sheet.SheetName);

                if (sheet.PhysicalNumberOfRows == 0)
                    continue;

                IRow headerRow = sheet.GetRow(sheet.FirstRowNum);
                int cellCount = headerRow.LastCellNum;

                // 建立欄位
                for (int c = 0; c < cellCount; c++)
                {
                    string colName = headerRow.GetCell(c)?.ToString() ?? $"Column_{c}";
                    if (dt.Columns.Contains(colName)) colName += $"_{c}";
                    dt.Columns.Add(colName);
                }

                // 讀資料
                for (int r = sheet.FirstRowNum + 1; r <= sheet.LastRowNum; r++)
                {
                    IRow row = sheet.GetRow(r);
                    if (row == null) continue;

                    DataRow dataRow = dt.NewRow();
                    for (int c = 0; c < cellCount; c++)
                        dataRow[c] = row.GetCell(c)?.ToString() ?? "";

                    dt.Rows.Add(dataRow);
                }

                tables.Add(dt);
            }
        }

        return tables;
    }


    private static void SendMail(string subject, string htmlContent, string toAddress, DataTable excelDt)
    {
        var mail = new MailMessage();
        mail.From = new MailAddress("yourEmail@test.com", "Auto Report");
        mail.To.Add(toAddress);
        mail.Subject = subject;
        mail.Body = htmlContent;
        mail.IsBodyHtml = true;

        // 附件 Excel
        byte[] excelBytes = DataTableToExcel(excelDt);
        mail.Attachments.Add(new Attachment(new MemoryStream(excelBytes), "Report.xlsx"));

        var smtp = new SmtpClient("smtp.yourserver.com")
        {
            Credentials = new System.Net.NetworkCredential("yourEmail@test.com", "yourPassword"),
            EnableSsl = true,
            Port = 587
        };

        smtp.Send(mail);
    }

    public static byte[] DataTableToExcel(DataTable dt)
    {
        using (var memoryStream = new MemoryStream())
        {
            using (var workbook = new XLWorkbook())
            {
                workbook.Worksheets.Add(dt, "Sheet1");
                workbook.SaveAs(memoryStream);
            }

            return memoryStream.ToArray(); // ← 回傳 byte[] 而不是 MemoryStream
        }
    }


    /// <summary>
    /// DataTable → HTML，可放 Email，支援超過20筆資料的下拉展開
    /// </summary>
    public static string ConvertToHtml(List<(string Title, DataTable Table)> tables)
    {
        var sb = new StringBuilder();

        sb.Append(@"
<!doctype html>
<html>
<head>
<meta charset='utf-8' />
<style>
body { font-family: Arial, Microsoft JhengHei, sans-serif; font-size: 14px; padding: 12px; }
.table-block { margin-bottom: 26px; }

.title {
    font-size: 16px;
    font-weight: bold;
    background: #007bff;
    color: white;
    padding: 8px 12px;
    border-radius: 6px 6px 0 0;
}

.table-container {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #ddd;
    border-radius: 0 0 6px 6px;
}

/* 固定表頭 */
table { border-collapse: collapse; width: 100%; }
th {
    position: sticky;
    top: 0;
    background: #f2f2f2;
    border-bottom: 2px solid #999;
    padding: 6px 8px;
    text-align: center;
}
th, td { padding: 6px 8px; border: 1px solid #ccc; text-align: center; }

tr:nth-child(even){ background: #fafafa; }

/* Email 不支援 JS，故改用純 HTML checkbox 控制 display */
.toggleBox { display:none; }
.toggleContent { display:none; }
.toggleBox:checked + label + .toggleContent { display:block; }
.toggleLabel { color:#007bff; cursor:pointer; }
</style>
</head>
<body>
");

        foreach (var (Title, Table) in tables)
        {
            sb.Append($@"
<div class='table-block'>
    <div class='title'>{HtmlEncode(Title)}（{Table.Rows.Count} 筆）</div>
    <div class='table-container'>");

            sb.Append("<table><thead><tr>");
            foreach (DataColumn col in Table.Columns)
                sb.Append($"<th>{HtmlEncode(col.ColumnName)}</th>");
            sb.Append("</tr></thead><tbody>");

            // ✅ 只顯示前20筆
            int preview = Math.Min(20, Table.Rows.Count);
            for (int i = 0; i < preview; i++)
                AppendRow(sb, Table.Rows[i]);

            // ✅ 超過20筆 → 可展開區
            if (Table.Rows.Count > 20)
            {
                string uid = Guid.NewGuid().ToString("N");

                sb.Append($@"
                </tbody>
                </table>
                <input type='checkbox' id='toggle_{uid}' class='toggleBox'>
                <label class='toggleLabel' for='toggle_{uid}'>▼ 展開剩餘 {Table.Rows.Count - 20} 筆資料</label>
                <div class='toggleContent'>
                <table><tbody>");

                for (int i = 20; i < Table.Rows.Count; i++)
                    AppendRow(sb, Table.Rows[i]);

                sb.Append("</tbody></table>");
            }

            sb.Append("</div></div>");
        }

        sb.Append("</body></html>");
        return sb.ToString();
    }

    private static void AppendRow(StringBuilder sb, DataRow row)
    {
        sb.Append("<tr>");
        foreach (var item in row.ItemArray)
            sb.Append($"<td>{HtmlEncode(item)}</td>");
        sb.Append("</tr>");
    }

    private static string HtmlEncode(object input)
    {
        if (input == null) return string.Empty;
        var s = input.ToString();
        return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;")
                .Replace("\"", "&quot;").Replace("'", "&#39;");
    }
}
