﻿export function useSelect2() {

    function init(container) {

        if (!container) return;

        $(container).find("select.select2").each(function () {

            const $el = $(this);

            if ($el.data("select2")) return;

            $el.select2({
                width: "100%"
            });

            $el.on("change", () => {
                $el[0].dispatchEvent(new Event("change", { bubbles: true }));
            });
        });
    }

    return { init };
}