﻿window.StepLoader = (() => {

    const sleep = (ms) => new Promise(r => setTimeout(r, ms));

    async function waitForStepModule(key, timeout = 3000) {

        const start = Date.now();

        while (Date.now() - start < timeout) {

            const mod = window.StepPages?.[key];
            if (mod?.init) return mod;

            await sleep(20);
        }

        console.warn("[StepLoader timeout]", key);
        return null;
    }

    function execScripts(container) {

        const scripts = [...container.querySelectorAll("script")];

        for (const old of scripts) {

            if (old.src) {
                if (document.querySelector(`script[src="${old.src}"]`)) {
                    old.remove();
                    continue;
                }
            }

            const s = document.createElement("script");

            if (old.src) s.src = old.src;
            else s.textContent = old.textContent;

            document.head.appendChild(s);
            old.remove();
        }
    }

    async function load(stepIndex, ctx) {

        const res = await fetch(`/Home/Step?stepIndex=${stepIndex}`);
        const html = await res.text();

        const container = document.getElementById("step-container");

        ctx.currentPage?.destroy?.(container);

        container.innerHTML = html;

        await Promise.resolve();
        await sleep(0);

        execScripts(container);

        await sleep(0);

        const key = `step${stepIndex}`;
        const module = await waitForStepModule(key);

        ctx.currentPage = module;

        module?.init?.(container, {
            formData: window.FormStore,
            fileCache: ctx.fileCache,
            currentStep: ctx.currentStep
        });

        return container;
    }

    return { load };

})();