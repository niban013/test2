﻿let PreviewState = {
    version: 0,
    type: null,
    payload: null
};
function clearPreview() {
    const $panel = $("#previewPanel");

    // ⭐ 清 iframe（避免 PDF 殘留）
    const iframe = $panel.find("iframe");
    if (iframe.length) {
        iframe.attr("src", "about:blank");
        iframe.remove();
    }

    // ⭐ 清內容
    $panel.empty();

    // ⭐ 清 state（你剛剛加的）
    $panel.removeData("file-name");

    // ⭐ 顯示預設
    $panel.html(`<div class="empty">Select file</div>`);
}

function flushPreview() {

    const $panel = $("#previewPanel");

    // ⭐ 清 iframe（避免 PDF 殘留）
    const prevIframe = $panel.find("iframe");
    if (prevIframe.length) {
        prevIframe.attr("src", "about:blank");
        prevIframe.remove();
    }

    $panel.empty();

    if (!PreviewState.type) {
        $panel.html(`<div class="empty">Select file</div>`);
        return;
    }
    // =========================
    //    // PDF
    //    // =========================
        if (PreviewState.type === "pdf") {

            const iframe = document.createElement("iframe");

            iframe.src = PreviewState.payload;
            iframe.style.width = "100%";
            iframe.style.height = "100%";
            iframe.style.border = "0";

            $panel.append(iframe);
            return;
        }

        // =========================
        // IMAGE
        // =========================
        if (PreviewState.type === "image") {

            const bitmap = PreviewState.payload;

            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");

            canvas.width = bitmap.width;
            canvas.height = bitmap.height;

            ctx.drawImage(bitmap, 0, 0);

            canvas.style.maxWidth = "100%";
            canvas.style.maxHeight = "100%";
            canvas.style.objectFit = "contain";

            $panel.append(canvas);

            bitmap.close?.();
            return;
        }

     //=========================
     //UNSUPPORTED
     //=========================
        if (PreviewState.type === "error") {

            $panel.html(PreviewState.payload);
        }
}
 
function renderImage(bitmap, version) {

    if (version !== PreviewState.version) {
        bitmap.close?.();
        return;
    }

    PreviewState.type = "image";
    PreviewState.payload = bitmap;

    flushPreview();
}
function renderPdf(url, version) {

    if (version !== PreviewState.version) {
        URL.revokeObjectURL(url);
        return;
    }
    if (PreviewState.type === "pdf" && PreviewState.payload) {
        URL.revokeObjectURL(PreviewState.payload);
    }
    PreviewState.type = "pdf";
    PreviewState.payload = url;

    flushPreview();
} 
async function removeFile(stepKey, key, fileName) {

    const current = FileRuntime.getStore().get(stepKey, key) || [];
    const file = current.find(f => f.name === fileName);

    // ⭐ DB file → call API
    if (file?.id && !file.isNew) {
        await fetch(`/api/file/${file.id}`, {
            method: "DELETE"
        });
    }

    const next = current.filter(f => f.name !== fileName);

    FileRuntime.getStore().safeSet(stepKey, key, next);
    GraphV2.notify(stepKey, key, next);
} 
function showUnsupported(blob, message = "", fileName = "download", version) {

    if (version !== PreviewState.version) return;

    PreviewState.type = "error";
    PreviewState.payload = `
		<div class="empty text-center">
			⚠ 無法預覽此檔案<br>
			${message ? `<small class="text-muted">${message}</small><br>` : ""}
			${blob
            ? `<button class="btn btn-sm btn-outline-primary mt-2 btn-download">⬇ 下載檔案</button>`
            : `<div class="text-muted mt-2">無法下載</div>`
        }
		</div>
	`;

    flushPreview();

    if (blob) {
        $(".btn-download").off("click").on("click", () => {
            forceDownload(blob, fileName);
        });
    }
}
function forceDownload(blob, fileName) {

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = fileName || "download";

    document.body.appendChild(a);
    a.click();
    a.remove();

    setTimeout(() => URL.revokeObjectURL(url), 60000);
}
function setUploadMode(mode) {

    const isSingle = mode === "single";

    // 左側清單（multi only）
    $(".multi-only").toggleClass("d-none", isSingle);

    // 右側 preview panel（single / multi 都要）
    $(".single-only").toggleClass("d-none", !isSingle);

    // optional：可以加 class 控制 layout
    $("#uploadModal").toggleClass("single-mode", isSingle);
}
function buildTooltip(file, extra = "") {

    const sizeKB = file.size ? Math.round(file.size / 1024) : 0;
    const time = file.lastModified
        ? new Date(file.lastModified).toLocaleString()
        : (file.uploadTime || "");

    return `
        <div style="text-align:left">
            <b>${file.name || "unknown"}</b><br>
            Size: ${sizeKB} KB<br>
            Time: ${time}
            ${extra ? `<br><span style="color:#dc3545">${extra}</span>` : ""}
        </div>
    `;
}
function getFileIcon(file) {

    const type = (file.type || "").toLowerCase();
    const name = (file.name || "").toLowerCase();

    // =========================
    // 圖片
    // =========================
    if (type.startsWith("image/")) {
        return "🖼️";
    }

    // =========================
    // PDF
    // =========================
    if (type === "application/pdf" || name.endsWith(".pdf")) {
        return "📕";
    }

    // =========================
    // Excel
    // =========================
    if (
        type.includes("spreadsheet") ||
        name.endsWith(".xls") ||
        name.endsWith(".xlsx")
    ) {
        return "📊";
    }

    // =========================
    // Word
    // =========================
    if (
        type.includes("word") ||
        name.endsWith(".doc") ||
        name.endsWith(".docx")
    ) {
        return "📄";
    }

    // =========================
    // 壓縮檔
    // =========================
    if (
        name.endsWith(".zip") ||
        name.endsWith(".rar") ||
        name.endsWith(".7z")
    ) {
        return "🗜️";
    }

    // =========================
    // 可執行 / DLL
    // =========================
    if (
        name.endsWith(".exe") ||
        name.endsWith(".dll")
    ) {
        return "⚙️";
    }

    // =========================
    // 預設
    // =========================
    return "📎";
}
const PreviewService = {
    open: async function (stepKey, key, file) {

        const $panel = $("#previewPanel");
        $panel.data("file-name", file.name); // ⭐⭐⭐ 必加
        $("#uploadList .drive-item").removeClass("active");
        $panel.html(`<div class="empty">⏳ 載入中...</div>`);

        // ⭐ 每次開新檔 +1 version
        const version = ++PreviewState.version;

        let realFile;

        try {
            realFile = await FileRuntime.ensureFileObject(file, stepKey, key);
        } catch (err) {

            if (version !== PreviewState.version) return;

            showUnsupported(null, "檔案載入失敗", file.name, version);
            return;
        }

        const blob = (realFile instanceof File)
            ? realFile
            : realFile?.file;

        if (!blob) {
            showUnsupported(null, "無法取得檔案內容", file.name, version);
            return;
        }

        let handled = false;

        const worker = PreviewWorker.getWorker();

        worker.onmessage = (e) => {

            handled = true;

            if (version !== PreviewState.version) return;

            if (e.data.error) {
                showUnsupported(blob, "預覽失敗", file.name, version);
                return;
            }

            const type = (file.type || blob.type || "").toLowerCase();

            // =========================
            // IMAGE
            // =========================
            if (e.data.bitmap && type.startsWith("image/")) {

                createImageBitmap(e.data.bitmap)
                    .then(bitmap => renderImage(bitmap, version));

                return;
            }

            // =========================
            // PDF
            // =========================
            if (type === "application/pdf") {

                const url = URL.createObjectURL(blob);
                renderPdf(url, version);

                return;
            }

            showUnsupported(blob, "不支援預覽", file.name, version);
        };

        worker.onerror = (err) => {

            if (version !== PreviewState.version) return;

            showUnsupported(blob, "worker error", file.name, version);
        };

        worker.postMessage({
            blob,
            type: file.type || blob.type || ""
        });

        // timeout
        setTimeout(() => {

            if (!handled && version === PreviewState.version) {
                showUnsupported(blob, "逾時", file.name, version);
            }

        }, 5000);
    }
}; 
const PreviewWorker = (() => {

    let worker = null;
    let url = null;

    function getWorker() {

        if (worker) return worker;

        const code = `
self.onmessage = async function (e) {

    const { blob, type } = e.data;

    try {

        if (type.startsWith("image/")) {

            const bitmap = await createImageBitmap(blob);
            self.postMessage({ bitmap }, [bitmap]);

        } else {

            self.postMessage({ blob });

        }

    } catch (err) {
        self.postMessage({ error: err.message });
    }
};
`;

        const blob = new Blob([code], { type: "application/javascript" });
        url = URL.createObjectURL(blob);

        worker = new Worker(url);

        return worker;
    }

    function destroy() {
        if (worker) worker.terminate();
        if (url) URL.revokeObjectURL(url);

        worker = null;
        url = null;
    }

    return {
        getWorker,
        destroy
    };

})();
// =========================
// render
// =========================
function render(stepKey, key, files) {

    const $list = $("#uploadList");
    $list.empty();

    files.forEach(file => {
        const icon = getFileIcon(file);
        const tooltip = buildTooltip(file);

        const $item = $(`
        <li class="drive-item">

           <div class="drive-name"  data-bs-toggle="tooltip"
     data-bs-html="true"
      title='${tooltip}'>

    <span class="drive-icon">${icon}</span>

    <span class="drive-scroll">
        <span class="drive-text">${file.name}</span>
    </span>

</div>

            <div class="drive-actions">
                <button class="btn btn-sm btn-outline-primary btn-view">View</button>
                <button class="btn btn-sm btn-outline-danger btn-del">Del</button>
            </div>

        </li>
        `);

        $item.find(".btn-view,.drive-name").click(async () => {
            $(".drive-item").removeClass("active");
            $item.addClass("active");
            await PreviewService.open(stepKey, key, file);
        });

        $item.find(".btn-del").click(async (e) => {
            e.stopPropagation();
            //const ctx = UploadContext.get();

            // ⭐ 用目前 preview 的 file（從 DOM 推不準 → 改用 preview panel）
            const previewName = $("#previewPanel").data("file-name");


            await removeFile(stepKey, key, file.name);

            $item.fadeOut(150, function () {
                $(this).remove();
            });

            if (previewName === file.name) {

                resetPreview();
            }
        });

        $list.append($item);
    });

    setTimeout(() => {
        $('[data-bs-toggle="tooltip"]').tooltip({
            container: 'body',
            html: true
        });
    });
}

// =========================
// load files
// =========================
function loadFiles() {

    const ctx = UploadContext.get();
    const key = window.FileRuntime.buildKey(ctx.stepKey, ctx.field, ctx.col);

    let files = FileRuntime.getStore().get(ctx.stepKey, key) || [];

    //if (!files || files.length === 0) {

    //    files = [
    //        { id: "f001", name: "demo-image.png", type: "image/png", lazy: true },
    //        { id: "f002", name: "report.pdf", type: "application/pdf", lazy: true },
    //        { id: "f003", name: "data.xlsx", type: "application/vnd", lazy: true }
    //    ];

    //    store().safeSet(ctx.stepKey, key, files);
    //}

    render(ctx.stepKey, key, files);
}
function resetPreview() {

    // ⭐ 讓舊 async 全部失效
    PreviewState.version++;

    // ⭐ 釋放 PDF URL
    if (PreviewState.type === "pdf" && PreviewState.payload) {
        URL.revokeObjectURL(PreviewState.payload);
    }

    PreviewState.type = null;
    PreviewState.payload = null;

    flushPreview();

    // ⭐ 保險：斷 worker
    PreviewWorker.destroy();
}
function openUploadModal(ctx) {
    resetPreview();
    
    const store = FileRuntime.getStore();
    const file = store.get(ctx.stepKey, ctx.key);

    UploadContext.open(ctx);

    const isMulti = ctx.mode;
    setUploadMode(isMulti ? "multi" : "single");
    //flushPreview();
    $("#uploadModal").modal("show");

    $("#uploadModal").one("shown.bs.modal", async () => {

        if (isMulti) {

            loadFiles();
            $("#previewPanel").html(`<div class="empty">Select file</div>`);

        } else if (file) {

            $("#uploadList").empty();
            await PreviewService.open(ctx.stepKey, ctx.key, file);
        }
    });
}

class UploadController {

    constructor() {

        this.$modal = $("#uploadModal");

        this.$fileInput = $("<input type='file' multiple style='display:none'>");
        $("body").append(this.$fileInput);

        this.bind();
    }

    bind() {

        // 選檔
        this.$modal.on("click", "#btnSelectFile", () => {
            this.$fileInput.trigger("click");
        });

        this.$fileInput.on("change", (e) => {
            this.handleFiles(e.target.files);
            e.target.value = "";
        });

        // drag
        this.$modal.on("dragover", e => e.preventDefault());

        this.$modal.on("drop", (e) => {
            e.preventDefault();
            this.handleFiles(e.originalEvent.dataTransfer.files);
        });
    }

    handleFiles(files) {

        const ctx = UploadContext.get();
        const key = FileRuntime.buildKey(ctx.stepKey, ctx.field, ctx.col);

        const store = FileRuntime.getStore();
        const current = store.get(ctx.stepKey, key) || [];

        const merged = [...current];

        Array.from(files).forEach(f => {
            if (!merged.some(x => x.name === f.name)) {
                merged.push(f);
            }
        });

        store.safeSet(ctx.stepKey, key, merged);
        GraphV2.notify(ctx.stepKey, key, merged);

        render(ctx.stepKey, key, merged);
    }
}


window.FileRuntime = (() => {

    const inflightMap = new Map();
    // =========================
    // ⭐ LRU Cache (File Object)
    // =========================
    const fileCache = new Map(); // file.id → File
    const MAX_CACHE = 30;

    function touchCache(fileId, fileObj) {

        if (fileCache.has(fileId)) {
            fileCache.delete(fileId);
        }

        fileCache.set(fileId, {
            file: fileObj,
            ts: Date.now()
        });

        // LRU cleanup
        if (fileCache.size > MAX_CACHE) {

            const oldest = [...fileCache.entries()]
                .sort((a, b) => a[1].ts - b[1].ts)[0];

            if (oldest) {
                fileCache.delete(oldest[0]);
            }
        }
    }

    function getCache(fileId) {
        const hit = fileCache.get(fileId);
        if (!hit) return null;

        hit.ts = Date.now(); // refresh
        return hit.file;
    }
    function getStore() {
        return AppBootstrap.get("FormStore");
    }

    function buildKey(stepKey, field, col) {
        return col ? `${field}.${col}` : field;
    }

    // =========================
    // ⭐ 共用下載（in-flight + cache + abort）
    // =========================
    async function ensureFileObject(file, stepKey, key) {

        if (file instanceof File) return file;
        if (file.file instanceof File) return file.file;
        if (!file.lazy) return file;

        const cached = getCache(file.id);
        if (cached) return cached;

        if (inflightMap.has(file.id)) {
            const prev = inflightMap.get(file.id);
            prev.controller.abort();
        }

        const controller = new AbortController();

        const promise = (async () => {
            try {

                const res = await fetch(`/api/file/${file.id}`, {
                    signal: controller.signal
                });

                if (!res.ok) throw new Error(`下載失敗: ${res.status}`);

                const blob = await res.blob();
                if (!blob || blob.size === 0) throw new Error("空檔案");

                const realFile = new File(
                    [blob],
                    file.name,
                    { type: blob.type || "application/octet-stream" }
                );

                file.file = realFile;
                file.lazy = false;
                // 👉 ⭐ 放這裡
                touchCache(file.id, realFile);
                const store = getStore();
                const current = store.get(stepKey, key) || [];

                store.safeSet(stepKey, key,
                    current.map(f => f.id === file.id ? file : f)
                );

                return realFile;

            } catch (err) {

                if (err.name === "AbortError") return;

                console.error(err);

                file.lazy = true;
                throw err;

            } finally {
                inflightMap.delete(file.id);
            }
        })();

        inflightMap.set(file.id, { controller, promise });

        return promise;
    }

    return {
        ensureFileObject,
        buildKey,
        getStore
    };

})();

window.UploadContext = {

    open({ stepKey, field, col, $row }) {
        $("#currentStepKey").val(stepKey);
        $("#currentField").val(field);
        $("#currentCol").val(col || "");
        this.$row = $row;
    },

    get() {
        return {
            stepKey: $("#currentStepKey").val(),
            field: $("#currentField").val(),
            col: $("#currentCol").val(),
            $row: this.$row
        };
    }
};
window.FilePlugin = {

    init(el, ctx) {

        if (!(el instanceof HTMLInputElement) || el.type !== "file") {
            return;
        }

        const wrapper = el.closest(".file-wrapper");

        if (!wrapper) {
            console.warn("FilePlugin: missing wrapper", el);
            return;
        }


        const store = FileRuntime.getStore();

        el.addEventListener("change", () => {

            const files = el.multiple
                ? Array.from(el.files || [])
                : el.files?.[0] || null;

            store.setTouched(ctx.stepKey, ctx.key);
            store.safeSet(ctx.stepKey, ctx.key, files);

            store.setStatus(ctx.stepKey, ctx.key, files ? "processing" : "idle");

            GraphV2.notify(ctx.stepKey, ctx.key, files);
            setFileUI(wrapper, files);
            //this.render(wrapper, files);
        });

        // =========================
        // ⭐ FIX：wrapper safe check
        // =========================


        wrapper.addEventListener("click", async (e) => {

            // =========================
            // preview button ONLY
            // =========================
            const previewBtn = e.target.closest(".file-preview-btn");
            if (previewBtn) {

                openUploadModal({
                    stepKey: ctx.stepKey,
                    key: ctx.key,
                    mode: false // ⭐ single
                });

                return;
            }

            // =========================
            // remove button ONLY
            // =========================
            const removeBtn = e.target.closest(".file-remove");
            if (removeBtn) {

                el.value = "";

                store.safeSet(ctx.stepKey, ctx.key, null);
                store.setStatus(ctx.stepKey, ctx.key, "idle");

                GraphV2.notify(ctx.stepKey, ctx.key, null);
                setFileUI(wrapper, null);
                //this.render(wrapper, null);
                return;
            }
        });
        setFileUI(wrapper, store.get(ctx.stepKey, ctx.key));
        //this.render(wrapper, store.get(ctx.stepKey, ctx.key));
    },
    render(wrapper, files) {

        const actions = wrapper.querySelector(".file-actions");
        const name = wrapper.querySelector(".file-name");
        const lineEl = wrapper.querySelector(".file-line");
        if (lineEl)
            lineEl.dataset.title = file.name;
        const hasFile = files && (Array.isArray(files) ? files.length > 0 : true);

        // =========================
        // ⭐ 控制顯示/隱藏
        // =========================
        if (actions) {
            actions.classList.toggle("d-none", !hasFile);
        }

        if (name) {
            name.textContent = hasFile
                ? (Array.isArray(files) ? files[0].name : files.name)
                : "";
        }
    }

};


$(function () {

    window.uploadController = new UploadController();

    $(document).on("click", ".btn-upload", function () {

        openUploadModal({
            stepKey: $(this).data("step"),
            field: $(this).data("field"),
            col: $(this).data("col"),
            key: $(this).data("field"),
            mode: true // multi
        });
    });
});

$(document).on("hidden.bs.modal", "#uploadModal", function () {
    resetPreview();
});