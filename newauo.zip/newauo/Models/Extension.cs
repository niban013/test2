﻿using Newtonsoft.Json.Linq;

namespace newauo.Helper
{
    public static class DictHelper
    {
        public static string GetString(this Dictionary<string, object> dict, string key)
        {
            return dict.ContainsKey(key) ? dict[key]?.ToString() : null;
        }

        public static List<string> GetList(this Dictionary<string, object> dict, string key)
        {
            if (!dict.ContainsKey(key)) return null;

            var arr = dict[key] as JArray;
            return arr?.ToObject<List<string>>();
        }

        public static T GetObject<T>(this Dictionary<string, object> dict, string key)
        {
            if (!dict.ContainsKey(key)) return default;

            var obj = dict[key] as JObject;
            return obj != null ? obj.ToObject<T>() : default;
        }
    }
}
