﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using newauo.Models;
using System.Text;

namespace newauo.Helper
{
    public static class RuleBuilder
    {
        public static string Build(List<ValidationRule> rules)
        {
            if (rules == null || rules.Count == 0)
                return "";

            var parts = new List<string>();

            foreach (var r in rules)
            {
                if (string.IsNullOrEmpty(r.Value))
                {
                    parts.Add(r.Name);
                }
                else
                {
                    parts.Add($"{r.Name}:{r.Value}");
                }
            }

            return string.Join("|", parts);
        }
    }
    public static class FieldRenderer
    { // =========================
      // Validation attributes
      // =========================

        private static string BuildValidationAttrs(DynamicField f)
        {
            var sb = new StringBuilder();

            // ⭐ 改這裡（統一出口）
            var rules = RuleBuilder.Build(f.ValidationRules);

            if (!string.IsNullOrEmpty(rules))
                sb.Append($"data-rule='{rules}' ");   // ⭐ 建議改 singular

            // pattern 保留（browser 原生支援）
            var pattern = f.ValidationRules.FirstOrDefault(x => x.Name == "pattern")?.Value;
            if (!string.IsNullOrEmpty(pattern))
                sb.Append($"data-pattern='{pattern}' ");

            return sb.ToString();
        }
        // =========================
        // Common attributes
        // =========================
        private static string BuildCommonAttrs(DynamicField f, bool isSelect = false)
        {
            var sb = new StringBuilder();

            if (!string.IsNullOrEmpty(f.Placeholder))
                sb.Append($"placeholder='{f.Placeholder}' ");
            if (!string.IsNullOrEmpty(f.Col))
                sb.Append($"data-col='{f.Col}' ");

            // =========================
            // Behavior Rule: readonly
            // =========================
            if (f.HasBehavior("readonly"))
            {
                sb.Append(isSelect ? "disabled " : "readonly ");
            }

            return sb.ToString();
        }



        private static string BuildAllAttrs(DynamicField f, bool isSelect = false)
        {
            return BuildCommonAttrs(f, isSelect) + BuildValidationAttrs(f);
        }

        private static string WrapField(string innerHtml)
        {

            return $@"
                <div class='field'>
                    <div class='field-input'> 
                        {innerHtml} 
                    </div>
                  
                </div>";
            //<div class='field-meta'>
            //         <small class='field-msg'></small>
            //     </div>
        }

        // =========================
        // Main render
        // =========================
        public static string RenderField(DynamicField f, bool hasLabel = true, string stepKey = "")
        {
            // =========================
            // Behavior Rule: hidden
            // ========================= 
            if (f.HasBehavior("hidden"))
                return RenderHiddenField(f, stepKey);

            var colWidth = hasLabel ? f.Width : 12;

            var label = hasLabel ? RenderOnlyLabel(f) : "";

            return $@"
                    <div class='row align-items-center mb-1'> 
                        {label} 
                        <div class='col-{colWidth}'>
                            {RenderControl(f, stepKey)}
                        </div>
                    </div>";
        }

        private static string RenderOnlyLabel(DynamicField f)
        {
            return $@"
                    <label class='col-3 mb-0 d-flex align-items-center'>
                        <span class='star'>{(f.HasValidation("required") ? "*" : "")}</span>
                        <span class='label-text tooltip-auto' data-title='{f.ColName}'>{f.ColName}</span>
                    </label>";
        }

        private static string RenderHiddenField(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            return $@"<div class='input-with-icon'>
            <input type='hidden'
                   data-field='{f.ColId}'
                   data-step='{stepKey}'
                   value='{val}' /></div>";
        }
        // =========================
        // Controls
        // =========================
        private static string RenderControl(DynamicField f, string stepKey)
        {
            return f.Type switch
            {
                FieldType.Hybrid => Renderchktext(f, stepKey),
                FieldType.Label => RenderLabel(f, stepKey),
                FieldType.OnlyLabel => RenderOnlyLabel(f),
                FieldType.Textbox => RenderTextbox(f, stepKey),
                FieldType.Numeric => RenderNumeric(f, stepKey),
                FieldType.Date => RenderDate(f, stepKey),
                FieldType.Textarea => RenderTextarea(f, stepKey),
                FieldType.Dropdown or FieldType.Select2 => RenderDropdown(f, stepKey),
                FieldType.Radio => RenderRadio(f, stepKey),
                FieldType.File => RenderFile(f, stepKey),
                _ => $"<span>未知 {f.Type}</span>"
            };
        }
        private static string RenderLabel(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            return WrapField($@" 
                        <div class='input-with-icon'>
                            <div data-field='{f.ColId}'
                                 data-step='{stepKey}'
                                 data-type='label'
                                 class='label-display'>
                                {val}
                            </div> 
                        <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
                    </div>");
        }
        private static string Renderchktext(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@"
<div class='input-with-icon checkbox-text-wrapper'
     data-field='{f.ColId}'
     data-step='{stepKey}'
     data-type='checkbox-text'>

    <div class='form-check me-2'>
        <input class='form-check-input'
               type='checkbox'
               id='{f.ColId}_chk'
               data-role='checkbox' />
    </div>

    <input type='text'
           class='form-control form-control-sm flex-fill'
           id='{f.ColId}'
           data-role='textbox'
           value='{val}' />

    <span class='field-icon'>
        <i class='bi bi-check-circle text-success'></i>
    </span>

</div>");
        }
        private static string RenderFile(DynamicField f, string stepKey)
        {
            var attrs = BuildAllAttrs(f);

            // ⭐ accept（可用 validation rule 或 behavior）
            var accept = f.ValidationRules
                ?.FirstOrDefault(x => x.Name == "accept")?.Value;

            var multiple = f.HasBehavior("multiple") ? "multiple" : "";

            if (!string.IsNullOrEmpty(accept))
                attrs += $" accept='{accept}' ";
            return WrapField($@"
<div class='file-wrapper'>

    <div class='file-control'> 

        <div class='input-with-icon'>

            <input type='file'
                   id='{f.ColId}'
                   class='file-input'
                   data-field='{f.ColId}'
                   data-step='{stepKey}'
                   data-type='file'
                   {multiple}
                   {attrs} />

            <label for='{f.ColId}' class='file-picker-btn tooltip-auto' data-title='上傳檔案'>
                <i class='bi bi-upload'></i>
            </label>

            <!-- ⭐ 改成同一列 -->
            <div class='file-line tooltip-auto' data-title='{f.Value}'>

                <div class='file-name text-truncate text-muted small d-none'></div>

                <span class='field-icon'>
                    <i class='bi bi-check-circle text-success'></i>
                </span>

            </div>

        </div>

        <div class='file-actions d-none'>    
            <button type='button'
                    class='btn btn-sm btn-outline-primary file-preview-btn tooltip-auto' data-title='預覽'>
                👁
            </button>

            <button type='button'
                    class='btn btn-sm btn-outline-danger file-remove tooltip-auto' data-title='刪除'>
                🗑
            </button>
        </div> 

    </div>
    
</div>
");
        }
        private static string RenderTextbox(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@"
            <div class='input-with-icon'>
                <input type='text'
                       class='form-control'
                       data-field='{f.ColId}'
                       data-step='{stepKey}'
                       data-type='textbox'  value='{val}'
                       {attrs} />
                <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
             </div>
            ");
        }

        private static string RenderNumeric(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var attrs = BuildAllAttrs(f);
            //已包在rule, 可以多加，browser控制
            //var min = f.ValidationRules.FirstOrDefault(x => x.Name == "min")?.Value;
            //var max = f.ValidationRules.FirstOrDefault(x => x.Name == "max")?.Value;

            //if (!string.IsNullOrEmpty(min))
            //    attrs += $" min='{min}' ";

            //if (!string.IsNullOrEmpty(max))
            //    attrs += $" max='{max}' ";

            return WrapField($@"<div class='input-with-icon'>
                <input type='number'
                       class='form-control'
                       data-field='{f.ColId}'
                       data-step='{stepKey}'
                       data-type='number'   value='{val}'
                       {attrs} />
   <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
 </div>");
        }

        private static string RenderDate(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@"<div class='input-with-icon'>
<input type='date'
       class='form-control'
       data-field='{f.ColId}'
       data-step='{stepKey}'
       data-type='date'   value='{val}'
       {attrs} />
   <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
 </div>");
        }

        private static string RenderTextarea(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            return WrapField($@" <div class='input-with-icon'>
<textarea class='form-control'
          data-field='{f.ColId}'
          
          data-step='{stepKey}'
          data-type='textarea'
          {attrs}>{val}</textarea>     
<span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
 </div>");
        }
        private static string RenderRadio(DynamicField f, string stepKey)
        {
            var val = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var attrs = BuildAllAttrs(f);

            var sb = new StringBuilder();

            sb.Append($@" <div class='input-with-icon'>
<div class='field'
     data-field='{f.ColId}'
     data-step='{stepKey}'
     data-type='radio'
     {attrs}>
     
    <div class='radio-group'>");

            foreach (var op in f.Options ?? new())
            {
                var id = $"{f.ColId}_{op.Value}";

                var isChecked =
                    string.Equals(op.Value?.Trim(),
                                  val?.ToString()?.Trim(),
                                  StringComparison.OrdinalIgnoreCase);

                sb.Append($@"
<label for='{id}'>
    <input type='radio'
           id='{id}'
           name='{f.ColId}'
           data-field='{f.ColId}'
           data-step='{stepKey}'
           value='{op.Value}'
           {(isChecked ? "checked" : "")}
           {(f.HasBehavior("readonly") ? "disabled" : "")} />
    {op.Text}
</label>");
            }

            sb.Append(@"<span class='field-icon'><i class='bi bi-check-circle text-success'></i></span>
    </div>
</div>
 </div>");

            return sb.ToString();
        }
        private static string RenderDropdown(DynamicField f, string stepKey)
        {
            var classList = new List<string> { };
            if (f.Type == FieldType.Select2) classList.AddRange(new List<string>() { "form-control", "select2" });
            if (f.Type == FieldType.Dropdown) classList.AddRange(new List<string>() { "form-control", "valueInput", "dropdownColor" });

            string classes = string.Join(" ", classList);

            var attrs = BuildAllAttrs(f, true);
            var current = ViewHelper.ResolveValue(f.Value, f.DefaultValue);
            var sb = new StringBuilder();

            sb.Append($@"<div class='input-with-icon'>
                <select class='{classes}'
                        data-field='{f.ColId}'
                        data-step='{stepKey}'
                        data-type='dropdown'
                        {attrs}>");

            sb.Append("<option value='' data-color='white' style='background-color:white'>請選擇</option>");

            foreach (var op in f.Options)
            {
                var selected = op.Value == current ? "selected" : ""; // ⭐ 在這裡

                sb.Append($@"
                        <option value='{op.Value}' data-color='{op.Color}' style='background-color:{op.Color}' {selected}>
                            {op.Text}
                        </option>");
            }

            sb.Append("</select>    <span class='field-icon'><i class='bi bi-check-circle text-success'></i></span></div>");

            return WrapField(sb.ToString());
        }
    }

    [HtmlTargetElement("df-field")]
    public class DfFieldTagHelper : TagHelper
    {
        public BaseDynamicField Field { get; set; }
        public string StepKey { get; set; }

        public string Name { get; set; }

        public string Col { get; set; }
        public string? Value { get; set; }
        public string Type { get; set; } = "Textbox";
        // ===== Validation =====
        public bool? Must { get; set; } = false;
        public string AsyncUrl { get; set; }

        // numeric only
        public int? Min { get; set; }
        public int? Max { get; set; }

        // textbox only
        public int? MaxLength { get; set; }
        public string? Pattern { get; set; }

        // ===== UI =====
        public string? Placeholder { get; set; }

        public string DefaultValue { get; set; }
        // ===== Behavior =====
        public bool? Readonly { get; set; }
        public bool? Hidden { get; set; }
        public string Target { get; set; }
        public string? OptionStr { get; set; }
        public bool HasLabel { get; set; } = true;
        //public string? GroupKey { get; set; } = "";
        public int? Width { get; set; }
        public int? Order { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if (Field != null)
            {
                Field.Type = Field.Type ?? Type;
                Field.Col = Field.Col ?? Col;
                Field.Must = Field.Must ?? Must;
            }
            var f =
                Field != null ?
                DynamicFieldMapper.ToDomain(Field) :
            DynamicFieldMapper.ToDomain(new BaseDynamicField
            {
                ColName = Name,
                ColId = Name,
                Value = Value,
                Type = Type,
                Col = Col,
                Must = Must ?? false,
                AsyncUrl = AsyncUrl,
                Min = Min,
                Max = Max,
                MaxLength = MaxLength,
                Pattern = Pattern,

                Placeholder = Placeholder,
                DefaultValue = DefaultValue,

                Readonly = Readonly ?? false,
                Hidden = Hidden,
                Target = Target,

                Width = Width,   // let mapper default
                Order = Order,
                OptionStr = OptionStr,
            });

            output.TagName = null;

            output.Content.SetHtmlContent(
                FieldRenderer.RenderField(f, HasLabel, StepKey)
            );
        }
    }

    [HtmlTargetElement("df-form")]
    public class DfFormTagHelper : TagHelper
    {
        public List<DynamicField> Fields { get; set; }
        public string StepKey { get; set; }

        public bool HasLabel { get; set; } = true;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var sb = new StringBuilder();

            foreach (var f in Fields.OrderBy(x => x.Order))
            {
                //f.GroupKey = "";//Key;

                sb.Append(FieldRenderer.RenderField(f, HasLabel, StepKey));
            }

            output.TagName = null;
            output.Content.SetHtmlContent(sb.ToString());
        }
    }
}